//! ============================================================================
//! LILA AOT BRIDGE — Zig-side runtime for AOT-compiled functions (v23.5)
//! ============================================================================
//!
//! The C-ABI surface between AOT-compiled Tier-0 functions (the `lilac aot`
//! C output and the `lilac aot-llvm` IR output) and the existing Zig
//! runtime. Every exported symbol either
//!
//!   1. calls the REAL leaf service the interpreter's opcode handler calls
//!      (audio.triggerSfx, render.drawSprite, c.sinA, ... — the handlers are
//!      one-liners over these, so the AOT path is bit-identical by
//!      construction), or
//!   2. routes through `lila_interpreter_step`, which executes the REAL
//!      decoded instruction at `pc` (vm.dispatchAt) on the live state.
//!      This is the universal mechanism for every machinery opcode (spawn,
//!      for-loops, pools, signals, swept collision, aggregates, ...) — the
//!      AOT path CANNOT drift from the interpreter because it IS the
//!      interpreter.
//!
//! ## v23.5 ABI v2 — SHARED STATE, NO MIRROR
//!
//! v23.2 kept a C-visible `LilaState` MIRROR and copied the whole
//! stack+frames (~6 KB) in and out on every Tier-0 call and every machinery
//! opcode — the last ~15% of AOT overhead. ABI v2 removes it: vm.zig's
//! `State` is now an extern struct whose leading fields ARE the C
//! `LilaState` (comptime-asserted both sides), and compiled functions
//! receive a pointer to the LIVE interpreter state (vm.statePtr()). A C fn
//! writing `st->stack[st->sp]` writes the interpreter's stack directly.
//! There is nothing to sync — the sync calls were the overhead.
//!
//! The state is THREADLOCAL on native builds, so an AOT fn invoked from a
//! v10 parallel worker touches that worker's state automatically (the v23.2
//! static mirror was shared across workers — a latent race this removes).
//! Iterators and try/catch handler stacks remain vm-internal (below the C
//! prefix): only the bridge calls mutate them, on the live state.
//!
//! ## Build + link (unchanged shape, one init call added)
//!
//!   cc -O2 -c lila_aot.c -o lila_aot.o
//!   zig build-lib src/lila_aot_bridge.zig -dynamic -O ReleaseFast
//!   cc lila_aot.o -llila_aot_bridge -o my_game
//!
//! The host must call `lila_bridge_init()` ONCE after the cartridge is
//! loaded (it aims the exported lila_code / lila_pool / lila_globals
//! pointers into the flat image) and `lila_bridge_frame_sync()` once per
//! frame after the host writes input (it refreshes the input/frame/camera
//! mirrors). Both are idempotent and cheap.
//!
//! See lila_aot_runtime.h for the C-side declarations and the opcode stack-
//! order table the AOT C emitter follows.

const std = @import("std");
const c = @import("core.zig");
const vm = @import("vm.zig");
const ent = @import("entity.zig");
const render = @import("render.zig");
const render3d = @import("render3d.zig");
const audio = @import("audio.zig");
const sf = @import("softfloat.zig");
const vm21 = @import("vm21.zig");
const vm22 = @import("vm22.zig");

// ============================================================================
// ABI MIRRORS — must stay structurally identical to lila_aot_runtime.h
// ============================================================================

/// One decoded instruction (core.zig INSTR_SIZE layout: op u8, pad[3],
/// a/b/c i32, extra_off u32 — 20 bytes).
pub const LilaInstr = extern struct {
    op: u8,
    _pad: [3]u8 = .{ 0, 0, 0 },
    a: i32,
    b: i32,
    c: i32,
    extra_off: u32,
};

comptime {
    if (@sizeOf(LilaInstr) != c.INSTR_SIZE)
        @compileError("LilaInstr mirror size != core INSTR_SIZE — the decoded-stream ABI drifted");
}

pub const LilaFrame = extern struct {
    ret_pc: u32,
    fn_idx: u32,
    locals: [vm.MAX_LOCALS]i32,
};

/// C view of the interpreter state. v23.5 ABI v2: this is a PREFIX of
/// vm.State (same fields, same order, extern layout both sides) — not a
/// copy. Comptime asserts below fail the build if the layouts drift.
pub const LilaState = extern struct {
    stack: [vm.STACK_SIZE]i32,
    sp: u32,
    frames: [vm.MAX_FRAMES]LilaFrame,
    fp: u32,
    pc: u32,
    ret_val: i32,
    /// v23.6: high cell of the (lo, hi) f64 return pair — prefix field 6,
    /// shared with compiled code exactly like ret_val (ABI v2).
    ret_hi: i32,
};

comptime {
    // ---- ABI v2 layout contract: LilaState is a prefix of vm.State ----
    if (@sizeOf(LilaFrame) != @sizeOf(vm.Frame))
        @compileError("LilaFrame != vm.Frame — the C frame ABI drifted");
    if (@offsetOf(LilaState, "sp") != @offsetOf(vm.State, "sp") or
        @offsetOf(LilaState, "frames") != @offsetOf(vm.State, "frames") or
        @offsetOf(LilaState, "fp") != @offsetOf(vm.State, "fp") or
        @offsetOf(LilaState, "pc") != @offsetOf(vm.State, "pc") or
        @offsetOf(LilaState, "ret_val") != @offsetOf(vm.State, "ret_val") or
        @offsetOf(LilaState, "ret_hi") != @offsetOf(vm.State, "ret_hi"))
        @compileError("LilaState is not a layout prefix of vm.State — resize/reorder both sides together");
    if (@sizeOf(LilaState) > @sizeOf(vm.State))
        @compileError("LilaState larger than vm.State — the C view overruns the interpreter");
}

// ============================================================================
// EXPORTED IMAGE VIEWS — self-aiming accessors into the flat image
// ============================================================================
//
// v23.2 ABI NOTE: these are exposed to C through ACCESSOR FUNCTIONS, not
// `export var` data symbols. Executable-side copy relocations (the classic
// non-PIC data-symbol footgun) give the executable its OWN copy of an
// exported variable while the library writes its internal one — the exact
// split-brain the first probe build hit (C read NULL forever). Functions
// are immune; the header re-exposes the names as macros so C sources read
// naturally: lila_code[pc].op, lila_pool[i], ...
//
// v23.5 ABI v2: the accessors aim THEMSELVES into the live image on every
// call — no init contract to forget. The input/frame/camera reads are LIVE
// (the interpreter reads the same cells), so an AOT fn and the interpreter
// can never disagree about input mid-frame; the v23.2 per-frame mirror
// refresh contract is gone.

export fn lila_bridge_init() void {
    // Kept for source compatibility — the accessors self-aim, nothing to do.
}

export fn lila_bridge_frame_sync() void {
    // Kept for source compatibility — reads are live, nothing to refresh.
}

export fn lila_code_ptr() [*]const LilaInstr {
    return @ptrCast(@alignCast(&c.mem[c.ADDR_CODE]));
}

export fn lila_pool_ptr() [*]const i32 {
    return @ptrCast(@alignCast(&c.mem[c.ADDR_POOL]));
}

export fn lila_globals_ptr() [*]i32 {
    return @ptrCast(@alignCast(&c.mem[c.ADDR_GLOBALS]));
}

// ---- typed global access ---------------------------------------------------
//
// v23.5: `a` in LD_GLBL/ST_GLBL is a TYPED-FIELD index (bit-packed global
// plane) — NOT a word index. The v23.2 C snippets wrote lila_globals_[a] —
// a raw word store at the wrong cell (the image bisector caught the score
// landing at byte 0). The correct handlers are ent.globalLoad/globalStore,
// which the engine C API ALREADY exports as lila_global_read/lila_global_write
// (lila_c.zig) — the AOT code calls those directly; nothing new to export
// here. 32-bit fields only: f64 globals are Tier-1 and never reach AOT code.

export fn lila_input_read() u32 {
    return c.rd32(c.ADDR_INPUT);
}

export fn lila_frame_read() u32 {
    return c.rd32(c.ADDR_FRAME);
}

export fn lila_cam_x_read() i32 {
    return @bitCast(c.rd32(c.ADDR_CAM_X));
}

export fn lila_cam_y_read() i32 {
    return @bitCast(c.rd32(c.ADDR_CAM_Y));
}

/// v23.5 ABI v2: the shared interpreter state, as the C LilaState view.
/// This is the EXACT pointer aot_invoke passes to compiled fns — a C body
/// (or a host tool) can obtain it to inspect/seed the live state. Threadlocal
/// on native builds: each v10 parallel worker sees its own state.
export fn lila_state_ptr() *LilaState {
    return @ptrCast(vm.statePtr());
}

/// C calling convention entry for a compiled fn: `void lila_fn_X(LilaState*)`.
pub const LilaFn = *const fn (st: *LilaState) callconv(.c) void;

// ============================================================================
// AOT DISPATCH — the host installs its compiled-fn table here
// ============================================================================

var aot_table: ?[*]const ?LilaFn = null; // NULL entries = Tier-1 (interpreter)
var aot_len: usize = 0;

/// Install the compiled Tier-0 fn table (generated by `lilac aot`) and arm
/// the VM dispatch hook. From this point every fn call routes through
/// aot_invoke: table entries run as native code, NULL entries (Tier-1) run
/// under the interpreter. Pass len = the fn count the table was generated with.
export fn lila_aot_install(t: [*]const ?LilaFn, len: u32) void {
    aot_table = t;
    aot_len = len;
    vm.aot_invoke = &aot_invoke;
}

/// Uninstall (hot-swap back to the pure interpreter without reloading).
export fn lila_aot_uninstall() void {
    aot_table = null;
    aot_len = 0;
    vm.aot_invoke = null;
}

fn aot_invoke(fi: u32) callconv(.c) void {
    const s = vm.statePtr();
    const entry_fp = s.fp;
    if (aot_table) |t| {
        if (fi < aot_len) {
            if (t[fi]) |f| {
                // ABI v2: the compiled body works DIRECTLY on the live
                // interpreter state — the pointer it receives IS vm's state.
                // No mirror, no copies. One pop_frame on completion.
                f(@ptrCast(s));
                vm.pop_frame();
                return;
            }
        }
    }
    // Tier-1 (or beyond the table): interpreter loop to completion. The
    // callee's own OP_RET pops its frame inside dispatch — do NOT pop again
    // (the v23.2 hook double-popped here; the LLVM path exposed it because
    // an un-populated table entry routes every fn through this loop).
    // entry_fp is the live frame COUNT at hook entry — the callee's frame
    // is frames[entry_fp - 1] and the loop ends when ITS ret pops the count
    // below it (the v23.2 `<=` test broke before running a single
    // instruction, because the hook is entered AFTER callFn pushed the
    // callee's frame).
    while (true) {
        const s2 = vm.statePtr();
        if (s2.fp < entry_fp or s2.halted) break;
        vm.dispatchAt(s2.pc);
    }
}

/// v23.5: AOT -> any-fn calls from generated code. Matches the
/// header/emitter contract `lila_call_fn(fi, n, st)`: runs the REAL
/// OP_CALL_FN handler through dispatch (guarded arg pops, baked-table
/// probe, coverage edge, frame push) and the AOT hook runs the callee to
/// completion + pops. One mechanism, zero drift — the v23.2 export had a
/// 2-arg signature that MISREAD the caller's registers (the C emitter
/// passes three arguments); ABI v2 makes the contract real.
/// `st` is the shared state pointer (kept in the signature for source
/// compatibility with existing generated C).
export fn lila_call_fn(fi: i32, n: i32, st: *LilaState) void {
    _ = st;
    vm.dispatch(c.OP_CALL_FN, fi, n, 0, 0);
}

// ============================================================================
// STATE — ABI v2: nothing to sync (see the header of this file)
// ============================================================================
//
// v23.2's syncIn/syncOut (the full stack+frames memcpy per call) and the
// static `aot_state` mirror are GONE. Compiled code operates on the live
// interpreter state through lila_state_ptr(); every bridge helper below
// reads/writes vm.statePtr() directly. The comptime layout asserts at the
// top of this file keep the C view and the Zig state structurally glued.

// ============================================================================
// THE UNIVERSAL FALLBACK — execute the REAL instruction at pc
// ============================================================================

/// Run the decoded instruction at `pc` through the interpreter (debugger
/// hooks included — an AOT frame is still a LILA frame) on the LIVE state.
/// The AOT code ignores the resulting pc (it owns control flow) and reads
/// results / pops operands from st->stack. Handlers that read iExtra(pc)
/// (spawn tf lists, dist-near fields) or cover.branch(pc) see the REAL
/// instruction — this is why `pc` must be the instruction's actual index in
/// the shared stream.
///
/// ABI v2: `st` IS the shared live state pointer (what aot_invoke handed
/// the compiled body) — there is nothing to sync, the v23.2 mirror copies
/// are gone. The parameter stays for source compatibility with existing
/// generated C.
export fn lila_interpreter_step(st: *LilaState, pc: u32) void {
    _ = st;
    vm.dispatchAt(pc);
}

// ---- loop machinery: branch-decision helpers -------------------------------
//
// The interpreter lowers loop control with relative jumps inside the handler;
// AOT code owns its control flow, so these return the BRANCH DECISION and
// the jump is suppressed (rel operand 0 -> any handler jump lands at pc+1,
// which the caller ignores). The iterator stack lives in the live
// interpreter state across calls, so nested loops work unchanged. The
// entered/continue decisions compare the live iterator count before and
// after the dispatch — plain locals, so parallel workers are safe by
// construction (the v23.2 module-level prev_itr was shared state).

/// OP_FOR_BGN semantics. Returns 1 = iterator pushed (run the body), 0 = no
/// live entity (skip to the loop's exit label). The first handle was written
/// into frame local `slot` exactly like the interpreter does.
export fn lila_for_bgn(st: *LilaState, typ: i32, slot: i32, pc: u32) i32 {
    _ = st;
    const pre = vm.statePtr().itr;
    vm.dispatch(c.OP_FOR_BGN, typ, slot, 0, pc + 1);
    return @intFromBool(vm.statePtr().itr == pre + 1);
}

/// OP_FOR_ADV semantics. Returns 1 = next entity written into `slot`
/// (continue the body), 0 = iterator exhausted and popped (exit).
export fn lila_for_adv(st: *LilaState, pc: u32) i32 {
    _ = st;
    const pre = vm.statePtr().itr;
    vm.dispatch(c.OP_FOR_ADV, 0, 0, 0, pc + 1);
    return @intFromBool(vm.statePtr().itr == pre);
}

/// OP_FOR_MASK_BGN semantics: the caller pushes the lane mask first (stack),
/// then calls this. Returns 1 = body runs (first candidate in `slot`),
/// 0 = exit.
export fn lila_for_mask_bgn(st: *LilaState, slot: i32, type_base: i32, mask: u32, pc: u32) i32 {
    _ = st;
    const s = vm.statePtr();
    const pre = s.itr;
    if (s.sp < vm.STACK_SIZE) {
        s.stack[s.sp] = @bitCast(mask);
        s.sp += 1;
    }
    vm.dispatch(c.OP_FOR_MASK_BGN, slot, type_base, 0, pc + 1);
    return @intFromBool(vm.statePtr().itr == pre + 1);
}

/// OP_FOR_MASK_ADV semantics: 1 = continue (next candidate in `slot`).
export fn lila_for_mask_adv(st: *LilaState, pc: u32) i32 {
    _ = st;
    const pre = vm.statePtr().itr;
    vm.dispatch(c.OP_FOR_MASK_ADV, 0, 0, 0, pc + 1);
    return @intFromBool(vm.statePtr().itr == pre);
}

/// OP_PL_FOR_BGN semantics: 1 = body runs (first pool row handle in `slot`).
export fn lila_pl_for_bgn(st: *LilaState, pool: i32, slot: i32, pc: u32) i32 {
    _ = st;
    const pre = vm.statePtr().itr;
    vm.dispatch(c.OP_PL_FOR_BGN, pool, slot, 0, pc + 1);
    return @intFromBool(vm.statePtr().itr == pre + 1);
}

/// OP_PL_FOR_ADV semantics: 1 = continue (next row handle in `slot`).
export fn lila_pl_for_adv(st: *LilaState, pc: u32) i32 {
    _ = st;
    const pre = vm.statePtr().itr;
    vm.dispatch(c.OP_PL_FOR_ADV, 0, 0, 0, pc + 1);
    return @intFromBool(vm.statePtr().itr == pre);
}

/// OP_ITER_POP semantics (break out of an entity for-loop).
export fn lila_iter_pop(st: *LilaState) void {
    _ = st;
    vm.dispatch(c.OP_ITER_POP, 0, 0, 0, vm.statePtr().pc +% 1);
}

// ============================================================================
// DIRECT LEAF SERVICES — the exact calls the opcode handlers make
// ============================================================================

// ---- Trig + math (LUT-driven, integer-exact) -------------------------------

export fn lila_sin(ang: i32) i32 {
    return c.sinA(ang);
}

export fn lila_cos(ang: i32) i32 {
    return c.cosA(ang);
}

/// C order (dx, dy); the interpreter stack pops dx then dy and calls
/// atan2ang(dy, dx) — same argument roles.
export fn lila_atan2(dx: i32, dy: i32) i32 {
    return c.atan2ang(dy, dx);
}

export fn lila_dist(x1: i32, y1: i32, x2: i32, y2: i32) i32 {
    return c.distF(x1, y1, x2, y2);
}

export fn lila_rand_max(n: i32) i32 {
    return c.randMax(n);
}

export fn lila_anim(anim_id: i32, t: i32) i32 {
    return vm.evalAnim(@as(u32, @bitCast(anim_id)) & 0xFFFF, t);
}

// ---- Input ------------------------------------------------------------------

/// OP_KEY_EDGE semantics: mode 0 = pressed (rising), 1 = released (falling).
export fn lila_key_edge(bit: i32, mode: i32) i32 {
    const k: u5 = @intCast(@as(u32, @bitCast(bit)) & 31);
    const rel = (@as(u32, @bitCast(mode)) & 0xFF) != 0;
    const reg = if (rel) c.rd32(c.ADDR_INPUT_REL) else c.rd32(c.ADDR_INPUT_PRESS);
    return @intFromBool((reg >> k) & 1 != 0);
}

// ---- Entity fields + lifecycle (HANDLE convention, gen<<20 | idx) ----------

export fn lila_ent_field(handle: i32, tf_idx: i32) i32 {
    return ent.fieldLoad(@as(u32, @bitCast(tf_idx)), @as(u32, @bitCast(handle)));
}

export fn lila_ent_set_field(handle: i32, tf_idx: i32, value: i32) void {
    std.debug.print("[setf] h={x} tf={} v={}\n", .{ @as(u32, @bitCast(handle)), tf_idx, value });
    ent.fieldStore(@as(u32, @bitCast(tf_idx)), @as(u32, @bitCast(handle)), value);
}

export fn lila_count(type_id: i32) i32 {
    return @intCast(ent.count(@as(u32, @bitCast(type_id)) & 0xFF));
}

export fn lila_kill(type_id: i32, handle: i32) void {
    const h: u32 = @bitCast(handle);
    ent.kill(@as(u32, @bitCast(type_id)) & 0xFF, h & 0xFFFFF);
}

// ---- Audio + screen ---------------------------------------------------------

export fn lila_sfx(atom: i32) void {
    audio.triggerSfx(@as(u32, @bitCast(atom)) & 0xFFFF);
}

export fn lila_music(atom: i32) void {
    audio.startMusic(@as(u32, @bitCast(atom)) & 0xFFFF);
}

export fn lila_stop_music() void {
    audio.stopMusic();
}

export fn lila_music_vol(v: i32) void {
    audio.setMusicVol(@as(u32, @bitCast(v)) & 0xFF);
}

/// OP_SHAKE semantics: overlapping shakes take the max, never cancel.
export fn lila_shake(amp: i32) void {
    const a: u32 = @as(u32, @bitCast(amp)) & 0xFF;
    if (a > c.rd32(c.ADDR_SHAKE)) c.wr32(c.ADDR_SHAKE, a);
}

/// OP_CAMERA semantics: clamp so the viewport stays inside the world.
export fn lila_camera(x: i32, y: i32) void {
    const cl = c.clampCam(x, y);
    c.wr32(c.ADDR_CAM_X, @bitCast(cl.x));
    c.wr32(c.ADDR_CAM_Y, @bitCast(cl.y));
}

// ---- SRAM persistence --------------------------------------------------------

export fn lila_save(ix: i32, value: i32) void {
    const slot: u32 = @as(u32, @bitCast(ix)) % c.SRAM_SLOTS;
    c.wr32(c.ADDR_SRAM + slot * 4, @bitCast(value));
    c.sram_dirty = 1;
}

export fn lila_saved(ix: i32) i32 {
    const slot: u32 = @as(u32, @bitCast(ix)) % c.SRAM_SLOTS;
    return @bitCast(c.rd32(c.ADDR_SRAM + slot * 4));
}

// ---- Draw calls (render stream emit) ----------------------------------------

export fn lila_draw(sprite: i32, x: i32, y: i32, rot: i32, scale: i32, rgba: i32) void {
    render.drawSprite(@as(u32, @bitCast(sprite)) & 0xFFFF, x, y, rot, scale, @bitCast(rgba));
}

export fn lila_draw_text(atom: i32, x: i32, y: i32, rgba: i32) void {
    render.drawText(@as(u32, @bitCast(atom)) & 0xFFFF, x, y, @bitCast(rgba));
}

export fn lila_draw_num(v: i32, x: i32, y: i32, rgba: i32) void {
    render.drawNum(v, x, y, @bitCast(rgba));
}

export fn lila_draw_numz(v: i32, digits: i32, x: i32, y: i32, rgba: i32) void {
    render.drawNumZ(v, @as(u32, @bitCast(digits)), x, y, @bitCast(rgba));
}

// ---- 3D pipeline ------------------------------------------------------------

export fn lila_proj3(x: i32, y: i32, z: i32) i32 {
    const p = c.proj3(x, y, z);
    c.wr32(c.ADDR_PROJ_X, @bitCast(p.sx));
    c.wr32(c.ADDR_PROJ_Y, @bitCast(p.sy));
    c.wr32(c.ADDR_PROJ_OK, @intFromBool(p.ok));
    return p.scale;
}

export fn lila_proj_x() i32 {
    return @bitCast(c.rd32(c.ADDR_PROJ_X));
}

export fn lila_proj_y() i32 {
    return @bitCast(c.rd32(c.ADDR_PROJ_Y));
}

export fn lila_proj_ok() i32 {
    return @intFromBool(c.rd32(c.ADDR_PROJ_OK) != 0);
}

// OP_DRAW3D / OP_DRAW3DI keep the FULL pipeline through the interpreter
// fallback (cull/sort/raster touch engine-wide state): the C emitter pushes
// n,x,y,z,yaw,rgba (source order) and calls lila_interpreter_step(st, pc).

// ---- Quat / mat4 rig math (pure register-plane transforms) -------------------

export fn lila_quat_aa(q: i32, off: i32, ax: i32, ay: i32, az: i32, ang: i32) void {
    render3d.quatAA(@as(u32, @bitCast(q)), off, ax, ay, az, ang);
}

export fn lila_q_mul(d: i32, doff: i32, a: i32, aoff: i32, b: i32, boff: i32) void {
    render3d.qMul(@as(u32, @bitCast(d)), doff, @as(u32, @bitCast(a)), aoff, @as(u32, @bitCast(b)), boff);
}

export fn lila_m4_qt(m: i32, moff: i32, q: i32, qoff: i32, tx: i32, ty: i32, tz: i32) void {
    render3d.m4QT(@as(u32, @bitCast(m)), moff, @as(u32, @bitCast(q)), qoff, tx, ty, tz);
}

export fn lila_m4_mul(d: i32, doff: i32, a: i32, aoff: i32, b: i32, boff: i32) void {
    render3d.m4Mul(@as(u32, @bitCast(d)), doff, @as(u32, @bitCast(a)), aoff, @as(u32, @bitCast(b)), boff);
}

export fn lila_skin3(v: i32, voff: i32, m: i32, moff: i32, x: i32, y: i32, z: i32) void {
    render3d.skin3(@as(u32, @bitCast(v)), voff, @as(u32, @bitCast(m)), moff, x, y, z);
}

export fn lila_m4_look(m: i32, moff: i32, ex: i32, ey: i32, ez: i32, tx: i32, ty: i32, tz: i32) void {
    render3d.m4Look(@as(u32, @bitCast(m)), moff, ex, ey, ez, tx, ty, tz);
}

// ---- FSM bit-plane transitions (image-only table read, same soft-lands) -----

export fn lila_fsm_next(fsm_id: i32, state: i32, event_mask: i32) i32 {
    const ti: u32 = @as(u32, @bitCast(fsm_id)) & 0xFFFF;
    if (ti >= c.n_fsms) return 0;
    const base = c.ADDR_FSM + ti * c.FSM_STRIDE;
    const nstates: u32 = c.mem[base + 2];
    const span: u32 = c.mem[base + 3];
    if (nstates == 0 or span == 0) return 0;
    const su: u32 = @as(u32, @bitCast(state)) % nstates;
    const eu: u32 = @as(u32, @bitCast(event_mask)) & (span - 1);
    return c.mem[base + 4 + su * span + eu];
}

/// v23.5: swept Minkowski interval test (OP_SWEPT) — the VM handler's body
/// verbatim (vm.zig OP_SWEPT): pure i64 math, no state, no pc dependence,
/// so a leaf helper is exact. The C emitter pops hh hw by bx avy avx ay ax
/// (VM order) and passes them here; return 1/0 = hit.
export fn lila_swept(hw: i32, hh: i32, ax: i32, ay: i32, avx: i32, avy: i32, bx: i32, by: i32) i32 {
    const dx: i64 = @as(i64, bx) - @as(i64, ax);
    const dy: i64 = @as(i64, by) - @as(i64, ay);
    const r1x: i64 = dx - @as(i64, avx);
    const r1y: i64 = dy - @as(i64, avy);
    const hitx = (dx * r1x < 0) or (@min(@abs(dx), @abs(r1x)) < @as(i64, hw));
    const hity = (dy * r1y < 0) or (@min(@abs(dy), @abs(r1y)) < @as(i64, hh));
    return @intFromBool(hitx and hity);
}

// ---- v11 ARRAYS (the interpreter's exact mask/mod indexing) -----------------
// v23.5: element addressing scales by c.arr_wide[id] (1 cell, or 2 for f64
// arrays). The 64-bit helpers below move the (lo, hi) pair as ONE u64 —
// the AOT emitters pick the 64-bit form for f64 arrays (statically typed)
// and the 32-bit form otherwise; the schema decides the cells, so the two
// views can never disagree.

export fn lila_ld_garr(arr: i32, idx: i32) i32 {
    const id: u32 = @as(u32, @bitCast(arr)) & 0xFF;
    if (id >= c.n_arrs or c.arr_ent[id] != 0xFF) return 0;
    const i = c.arrIndex(id, @bitCast(idx)) * c.arr_wide[id];
    return @bitCast(c.rd32(c.garrElem(id, i)));
}

export fn lila_st_garr(arr: i32, idx: i32, value: i32) void {
    const id: u32 = @as(u32, @bitCast(arr)) & 0xFF;
    if (id >= c.n_arrs or c.arr_ent[id] != 0xFF) return;
    const i = c.arrIndex(id, @bitCast(idx)) * c.arr_wide[id];
    c.wr32(c.garrElem(id, i), @bitCast(value));
}

/// v23.5: f64 global-array element as ONE u64 (hi << 32 | lo).
export fn lila_ld_garr64(arr: i32, idx: i32) u64 {
    const id: u32 = @as(u32, @bitCast(arr)) & 0xFF;
    if (id >= c.n_arrs or c.arr_ent[id] != 0xFF) return 0;
    const i = c.arrIndex(id, @bitCast(idx)) * c.arr_wide[id];
    const lo: u64 = @as(u32, @bitCast(c.rd32(c.garrElem(id, i))));
    const hi: u64 = @as(u32, @bitCast(c.rd32(c.garrElem(id, i + 1))));
    return (hi << 32) | lo;
}

export fn lila_st_garr64(arr: i32, idx: i32, v: u64) void {
    const id: u32 = @as(u32, @bitCast(arr)) & 0xFF;
    if (id >= c.n_arrs or c.arr_ent[id] != 0xFF) return;
    const i = c.arrIndex(id, @bitCast(idx)) * c.arr_wide[id];
    c.wr32(c.garrElem(id, i), @truncate(v));
    c.wr32(c.garrElem(id, i + 1), @truncate(v >> 32));
}

/// Entity-array access takes the packed HANDLE directly (the C body loads
/// it from its frame local, exactly like the handler reads the slot).
export fn lila_ld_earr(handle: i32, arr: i32, idx: i32) i32 {
    const id: u32 = @as(u32, @bitCast(arr)) & 0xFF;
    if (id >= c.n_arrs or c.arr_ent[id] == 0xFF) return 0;
    const h: u32 = @bitCast(handle);
    const t: u32 = c.arr_ent[id];
    const sidx = h & 0xFFFFF;
    const gen = (h >> 20) & 0xFFF;
    if (sidx >= c.maxLive(t) or ent.genOf(t, sidx) != gen or !ent.isAlive(t, sidx)) return 0;
    const i = c.arrIndex(id, @bitCast(idx)) * c.arr_wide[id];
    return @bitCast(c.rd32(c.earrRow(id, sidx) + i * 4));
}

export fn lila_st_earr(handle: i32, arr: i32, idx: i32, value: i32) void {
    const id: u32 = @as(u32, @bitCast(arr)) & 0xFF;
    if (id >= c.n_arrs or c.arr_ent[id] == 0xFF) return;
    const h: u32 = @bitCast(handle);
    const t: u32 = c.arr_ent[id];
    const sidx = h & 0xFFFFF;
    const gen = (h >> 20) & 0xFFF;
    if (sidx >= c.maxLive(t) or ent.genOf(t, sidx) != gen or !ent.isAlive(t, sidx)) return;
    const i = c.arrIndex(id, @bitCast(idx)) * c.arr_wide[id];
    c.wr32(c.earrRow(id, sidx) + i * 4, @bitCast(value));
}

/// v23.5: f64 entity-array element as ONE u64 (hi << 32 | lo).
export fn lila_ld_earr64(handle: i32, arr: i32, idx: i32) u64 {
    const id: u32 = @as(u32, @bitCast(arr)) & 0xFF;
    if (id >= c.n_arrs or c.arr_ent[id] == 0xFF) return 0;
    const h: u32 = @bitCast(handle);
    const t: u32 = c.arr_ent[id];
    const sidx = h & 0xFFFFF;
    const gen = (h >> 20) & 0xFFF;
    if (sidx >= c.maxLive(t) or ent.genOf(t, sidx) != gen or !ent.isAlive(t, sidx)) return 0;
    const i = c.arrIndex(id, @bitCast(idx)) * c.arr_wide[id];
    const lo: u64 = @as(u32, @bitCast(c.rd32(c.earrRow(id, sidx) + i * 4)));
    const hi: u64 = @as(u32, @bitCast(c.rd32(c.earrRow(id, sidx) + (i + 1) * 4)));
    return (hi << 32) | lo;
}

export fn lila_st_earr64(handle: i32, arr: i32, idx: i32, v: u64) void {
    const id: u32 = @as(u32, @bitCast(arr)) & 0xFF;
    if (id >= c.n_arrs or c.arr_ent[id] == 0xFF) return;
    const h: u32 = @bitCast(handle);
    const t: u32 = c.arr_ent[id];
    const sidx = h & 0xFFFFF;
    const gen = (h >> 20) & 0xFFF;
    if (sidx >= c.maxLive(t) or ent.genOf(t, sidx) != gen or !ent.isAlive(t, sidx)) return;
    const i = c.arrIndex(id, @bitCast(idx)) * c.arr_wide[id];
    c.wr32(c.earrRow(id, sidx) + i * 4, @truncate(v));
    c.wr32(c.earrRow(id, sidx) + (i + 1) * 4, @truncate(v >> 32));
}

// ---- v21 sort + dicts + ray + astar ------------------------------------------

export fn lila_psort(pool: i32, pfield: i32, dir: i32) void {
    vm21.psort(@as(u32, @bitCast(pool)) & 0xFF, @as(u32, @bitCast(pfield)) & 0xFFFF, @as(u32, @bitCast(dir)) & 0xFF);
}

export fn lila_m_put(dict: i32, key: i32, value: i32) void {
    vm21.mapPut(@as(u32, @bitCast(dict)) & 0xFF, @as(u32, @bitCast(key)), @as(u32, @bitCast(value)));
}

export fn lila_m_get(dict: i32, key: i32) i32 {
    return @bitCast(vm21.mapGet(@as(u32, @bitCast(dict)) & 0xFF, @as(u32, @bitCast(key))));
}

export fn lila_m_del(dict: i32, key: i32) void {
    vm21.mapDel(@as(u32, @bitCast(dict)) & 0xFF, @as(u32, @bitCast(key)));
}

export fn lila_m_len(dict: i32) i32 {
    const d: u32 = @as(u32, @bitCast(dict)) & 0xFF;
    if (d < c.n_dicts) return @bitCast(c.rd32(c.dict_base[d]));
    return 0;
}

/// Next live dict key from `cursor` (or -1). VALUE and NEXT CURSOR are
/// stashed at the engine's MN registers — read them with lila_m_next_v/_c
/// (exactly what the interpreter's OP_M_NEXTV / OP_M_NEXTC do).
export fn lila_m_next(dict: i32, cursor: i32) i32 {
    return vm22.mnext(@as(u32, @bitCast(dict)) & 0xFF, @as(u32, @bitCast(cursor)));
}

export fn lila_m_next_v() i32 {
    return @bitCast(c.rd32(c.ADDR_MN_VAL));
}

export fn lila_m_next_c() i32 {
    return @bitCast(c.rd32(c.ADDR_MN_CUR));
}

/// DDA raycast through a grid array. Returns the hit distance in fixed point
/// (or maxd when nothing hit); hit cell packs into lila_ray_x()/_y().
export fn lila_ray(grid: i32, gw: i32, gh: i32, x: i32, y: i32, ang: i32, maxd: i32) i32 {
    return vm21.ray(@as(u32, @bitCast(grid)) & 0xFF, gw, gh, x, y, ang, maxd);
}

export fn lila_ray_x() i32 {
    return @bitCast(c.rd32(c.ADDR_RAY_CELL) >> 16);
}

export fn lila_ray_y() i32 {
    return @bitCast(c.rd32(c.ADDR_RAY_CELL) & 0xFFFF);
}

export fn lila_astar(grid: i32, path: i32, gw: i32, gh: i32, sx: i32, sy: i32, tx: i32, ty: i32) i32 {
    return vm21.astar(@as(u32, @bitCast(grid)) & 0xFF, @as(u32, @bitCast(path)) & 0xFF, gw, gh, sx, sy, tx, ty);
}

// ---- v22 queues / stacks / arrays / noise (ring + plane ops) -----------------

export fn lila_qpush(arr: i32, value: i32) void {
    vm22.qpush(@as(u32, @bitCast(arr)) & 0xFF, @as(u32, @bitCast(value)));
}

export fn lila_qpop(arr: i32) i32 {
    return @bitCast(vm22.qpop(@as(u32, @bitCast(arr)) & 0xFF));
}

export fn lila_qlen(arr: i32) i32 {
    return @intCast(vm22.ringLen(@as(u32, @bitCast(arr)) & 0xFF));
}

export fn lila_spush(arr: i32, value: i32) void {
    vm22.spush(@as(u32, @bitCast(arr)) & 0xFF, @as(u32, @bitCast(value)));
}

export fn lila_spop(arr: i32) i32 {
    return @bitCast(vm22.spop(@as(u32, @bitCast(arr)) & 0xFF));
}

export fn lila_slen(arr: i32) i32 {
    return @intCast(vm22.ringLen(@as(u32, @bitCast(arr)) & 0xFF));
}

export fn lila_speek(arr: i32) i32 {
    return @bitCast(vm22.speek(@as(u32, @bitCast(arr)) & 0xFF));
}

export fn lila_afill(arr: i32, value: i32) void {
    vm22.afill(@as(u32, @bitCast(arr)) & 0xFF, @as(u32, @bitCast(value)));
}

export fn lila_acopy(dst: i32, src: i32, n: i32) void {
    vm22.acopy(@as(u32, @bitCast(dst)) & 0xFF, @as(u32, @bitCast(src)) & 0xFF, n);
}

export fn lila_ashuf(arr: i32, n: i32) void {
    vm22.ashuffle(@as(u32, @bitCast(arr)) & 0xFF, n);
}

export fn lila_afind(arr: i32, value: i32) i32 {
    return vm22.afind(@as(u32, @bitCast(arr)) & 0xFF, @as(u32, @bitCast(value)));
}

export fn lila_acount(arr: i32, value: i32) i32 {
    return @intCast(vm22.acount(@as(u32, @bitCast(arr)) & 0xFF, @as(u32, @bitCast(value))));
}

export fn lila_noise1(t: i32) i32 {
    return vm22.noise1(t);
}

export fn lila_noise2(x: i32, y: i32) i32 {
    return vm22.noise2(x, y);
}

// ---- v20 f32 software-IEEE ops (softfloat.zig, F32 = raw u32) ---------------

export fn lila_f32_add(a: u32, b: u32) u32 {
    return sf.add(a, b);
}

export fn lila_f32_sub(a: u32, b: u32) u32 {
    return sf.sub(a, b);
}

export fn lila_f32_mul(a: u32, b: u32) u32 {
    return sf.mul(a, b);
}

export fn lila_f32_div(a: u32, b: u32) u32 {
    return sf.div(a, b);
}

export fn lila_f32_sqrt(a: u32) u32 {
    return sf.sqrt(a);
}

export fn lila_f32_eq(a: u32, b: u32) i32 {
    return @intFromBool(sf.eq(a, b));
}

/// IEEE unordered: NaN != everything (the interpreter's convention).
export fn lila_f32_ne(a: u32, b: u32) i32 {
    return if (sf.eq(a, b)) 0 else 1;
}

export fn lila_f32_lt(a: u32, b: u32) i32 {
    return @intFromBool(sf.lt(a, b));
}

export fn lila_f32_gt(a: u32, b: u32) i32 {
    return @intFromBool(sf.lt(b, a));
}

export fn lila_f32_le(a: u32, b: u32) i32 {
    return @intFromBool(sf.le(a, b));
}

export fn lila_f32_ge(a: u32, b: u32) i32 {
    return @intFromBool(sf.le(b, a));
}

export fn lila_i2f32(v: i32) u32 {
    return sf.fromI32(v);
}

export fn lila_f322i(f: u32) i32 {
    return sf.toI32(f);
}

export fn lila_fix2f32(q: i32) u32 {
    return sf.fromFix(q);
}

export fn lila_f322fix(f: u32) i32 {
    return sf.toFix(f);
}

// ============================================================================
// MACHINERY OPS WITH NO DIRECT HELPER (deliberate — one mechanism, no drift)
// ============================================================================
//
// The C emitter lowers these by pushing operands in the interpreter's stack
// order and calling lila_interpreter_step(st, pc_of_that_instruction), then
// reading results from st->stack. The pc is REQUIRED: spawn/dist-near read
// their extra tf/field lists through it, and coverage sites key on it.
//
//   OP_SPAWN      a=type b=cells | stack: init cells (schema-width walk)
//                 | extra: U16 tf list          | result: none (statement)
//   OP_KILL       a=slot b=type  | frame local slot holds the handle
//                 (or use lila_kill(type, handle) directly)
//   OP_SWEPT      stack: hw,hh,ax,ay,avx,avy,bx,by (source order)
//                 | result: overlap fixed amount
//   OP_COLLIDE_MASK a=type b=hw_pool c=hh_pool | stack: cx, cy | result: mask
//   OP_DIST_NEAR  a=type | stack: x, y | extra: U16 x_tf, U16 y_tf
//                 | result: distance (0x7FFFFFFF when none)
//   OP_AGG        a=type b=mode(0 sum 1 min 2 max) | extra: U16 tf | result
//   OP_LD_GARR/OP_ST_GARR  a=arr | stack: idx (then val for ST)
//   OP_LD_EARR/OP_ST_EARR  a=handle-slot b=arr | stack: idx (then val)
//   OP_PL_PUSH    a=pool b=cells | stack: init cells | extra: U16 pf list
//   OP_PL_REM     a=slot b=pool  | frame local slot holds the row handle
//   OP_PL_LD/OP_PL_ST      a=slot b=(pool<<4|field) | ST pops value
//   OP_CALL_TBL   a=table b=ent-slot | stack: key
//   OP_CALL_FN    a=fn_idx b=arg cells | stack: args -> land in locals[0..]
//   OP_SIGNAL     a=n b/cc args     | stack: args
//   OP_LD_TF/OP_ST_TF      a=slot b=tf | LD pushes field, ST pops value
//   OP_CAM3       stack: x,y,z,yaw,pitch (source order)
//   OP_DRAW3D     a=arr | stack: n,x,y,z,yaw,rgba
//   OP_DRAW3DI    a=varr b=iarr | stack: nv,ni,x,y,z,yaw,rgba
//   OP_TRY/OP_THROW/OP_TRY_END — Tier-1 fns run under the interpreter
//   wholesale (their dispatch-table entry is NULL); no AOT lowering.
//
// Every other opcode in the stream is pure stack arithmetic the C emitter
// inlines (integer + fixed + f32 + f64 + compares + jumps), so it never
// reaches the bridge.

// ============================================================================
// SELF-CHECK
// ============================================================================

test "bridge ABI mirrors are structurally sound" {
    // The decoded-stream view must alias the image exactly.
    try std.testing.expectEqual(@sizeOf(LilaInstr), c.INSTR_SIZE);
    try std.testing.expectEqual(@sizeOf(LilaState), 512 * 4 + 4 + 32 * (8 + 128) + 4 + 4 + 4 + 4);
    // The engine services this bridge re-implements must exist at the exact
    // names the opcode handlers call (compile-time linkage check).
    _ = c.sinA;
    _ = c.cosA;
    _ = c.atan2ang;
    _ = c.distF;
    _ = c.randMax;
    _ = c.proj3;
    _ = c.clampCam;
    _ = vm.evalAnim;
    _ = vm21.psort;
    _ = vm21.mapPut;
    _ = vm21.ray;
    _ = vm21.astar;
    _ = vm22.mnext;
    _ = vm22.qpush;
    _ = vm22.afill;
    _ = vm22.ashuffle;
    _ = vm22.noise1;
    _ = audio.triggerSfx;
    _ = audio.startMusic;
    _ = render.drawSprite;
    _ = render.drawText;
    _ = render.drawNumZ;
    _ = render3d.quatAA;
    _ = render3d.m4Mul;
    _ = ent.fieldLoad;
    _ = ent.fieldStore;
    _ = ent.count;
    _ = ent.kill;
}
