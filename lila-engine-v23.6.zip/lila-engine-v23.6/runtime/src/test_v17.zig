//! runtime/src/test_v17.zig — v17 runtime feature tests.
//!
//! Loads the committed fixture built from demo/test_v17_fixture.lila
//! (v4 format: RET_V/RET_GET, ITER_POP, KEY_EDGE, DIST_NEAR, M4_LOOK) and
//! asserts every new opcode's observable result BIT-EXACTLY. The expected
//! values were hand-computed from the fixture source (see its header).
//!
//! Regenerate the fixture with:
//!   ../compiler/target/debug/lilac build ../demo/test_v17_fixture.lila \
//!       -o src/test_v17_fixture.libyte

const std = @import("std");
const c = @import("core.zig");
const engine = @import("engine.zig");
const ent = @import("entity.zig");
const tt = @import("timetravel.zig");

// typed-field ids from the fixture's disasm (globals tf[4..10])
const TF_SUM: u32 = 4;
const TF_EDGES: u32 = 5;
const TF_RELS: u32 = 6;
const TF_BRK: u32 = 7;
const TF_CONT: u32 = 8;
const TF_G2: u32 = 9;
const TF_DN: u32 = 10;

// array ids from the fixture (global arrays, id order)
const ARR_GRID: u32 = 0;
const ARR_MAT: u32 = 1;

fn loadFixture() ![]const u8 {
    // fixture lives next to this source file
    const p = comptime (std.fs.path.dirname(@src().file) orelse ".");
    _ = p;
    return @embedFile("test_v17_fixture.libyte");
}

fn frame() void {
    engine.frame();
}

test "v17: v4 fixture loads and uses edges" {
    const blob = try loadFixture();
    const rc = engine.init(blob);
    try std.testing.expectEqual(@as(i32, c.ERR_OK), rc);
    try std.testing.expect(c.uses_edges);
}

test "v17: RET_V/RET_GET — valued helper through an expression" {
    frame(); // one update tick
    // sum = int(add3(1.0, 2.0, 3.5)) = 6
    try std.testing.expectEqual(@as(i32, 6), ent.globalLoad(TF_SUM));
}

test "v17: numeric for + break + continue" {
    frame();
    try std.testing.expectEqual(@as(i32, 7), ent.globalLoad(TF_BRK));
    try std.testing.expectEqual(@as(i32, 5), ent.globalLoad(TF_CONT));
}

test "v17: 2-D array store + readback" {
    frame();
    try std.testing.expectEqual(@as(i32, 13), ent.globalLoad(TF_G2));
    // and the cells themselves (row-major: [1][2] -> 1*4+2 = 6, [3][0] -> 12)
    try std.testing.expectEqual(@as(u32, 9), c.rd32(c.garrElem(ARR_GRID, 6)));
    try std.testing.expectEqual(@as(u32, 4), c.rd32(c.garrElem(ARR_GRID, 12)));
}

test "v17: DIST_NEAREST — engine-side nearest scan" {
    frame();
    // Mob at (300, 200); dist = sqrt(300^2 + 200^2) = 360.55 -> 360 px
    try std.testing.expectEqual(@as(i32, 360), ent.globalLoad(TF_DN) >> 8);
}

test "v17: M4_LOOK — exact look-at matrix cells" {
    frame();
    // eye (0,0,256) -> target (256,0,0):
    //   f = normalize(256,0,-256) = (181, 0, -181)   [Q24.8: 256*256/362]
    //   r = normalize(-fy, fx, 0) = (0, 256, 0)
    //   u = cross(f, r)           = (181, 0, 181)
    // columns [r | f | u | eye], mat lives at mat[0..15]
    const m0: i32 = @bitCast(c.rd32(c.garrElem(ARR_MAT, 0)));
    const m1: i32 = @bitCast(c.rd32(c.garrElem(ARR_MAT, 1)));
    const m2: i32 = @bitCast(c.rd32(c.garrElem(ARR_MAT, 2)));
    const m4: i32 = @bitCast(c.rd32(c.garrElem(ARR_MAT, 4)));
    const m5: i32 = @bitCast(c.rd32(c.garrElem(ARR_MAT, 5)));
    const m6: i32 = @bitCast(c.rd32(c.garrElem(ARR_MAT, 6)));
    const m8: i32 = @bitCast(c.rd32(c.garrElem(ARR_MAT, 8)));
    const m9: i32 = @bitCast(c.rd32(c.garrElem(ARR_MAT, 9)));
    const m10: i32 = @bitCast(c.rd32(c.garrElem(ARR_MAT, 10)));
    const m12: i32 = @bitCast(c.rd32(c.garrElem(ARR_MAT, 12)));
    const m13: i32 = @bitCast(c.rd32(c.garrElem(ARR_MAT, 13)));
    const m14: i32 = @bitCast(c.rd32(c.garrElem(ARR_MAT, 14)));
    const m15: i32 = @bitCast(c.rd32(c.garrElem(ARR_MAT, 15)));
    try std.testing.expectEqual(@as(i32, 0), m0);
    try std.testing.expectEqual(@as(i32, 256), m1);
    try std.testing.expectEqual(@as(i32, 0), m2);
    try std.testing.expectEqual(@as(i32, 181), m4);
    try std.testing.expectEqual(@as(i32, 0), m5);
    try std.testing.expectEqual(@as(i32, -181), m6);
    try std.testing.expectEqual(@as(i32, 181), m8);
    try std.testing.expectEqual(@as(i32, 0), m9);
    try std.testing.expectEqual(@as(i32, 181), m10);
    try std.testing.expectEqual(@as(i32, 0), m12);
    try std.testing.expectEqual(@as(i32, 0), m13);
    try std.testing.expectEqual(@as(i32, 65536), m14); // eye z = 256.0 (Q24.8 raw)
    try std.testing.expectEqual(@as(i32, 256), m15); // w
}

test "v17: KEY_EDGE — press/release edges count exactly" {
    // re-init for a clean count
    const blob = try loadFixture();
    _ = engine.init(blob);
    // 3 cycles of: fire held 5 frames, released 5 frames
    var f: u32 = 0;
    while (f < 30) : (f += 1) {
        c.wr32(c.ADDR_INPUT, if (f % 10 < 5) @as(u32, 1) else 0);
        frame();
    }
    try std.testing.expectEqual(@as(i32, 3), ent.globalLoad(TF_EDGES));
    try std.testing.expectEqual(@as(i32, 3), ent.globalLoad(TF_RELS));
    // one more released-frame must NOT retrigger
    c.wr32(c.ADDR_INPUT, 0);
    frame();
    try std.testing.expectEqual(@as(i32, 3), ent.globalLoad(TF_EDGES));
    try std.testing.expectEqual(@as(i32, 3), ent.globalLoad(TF_RELS));
}

test "v17: determinism — the v4 opcodes replay bit-identically" {
    const blob = try loadFixture();
    // pass 1
    _ = engine.init(blob);
    var f: u32 = 0;
    while (f < 120) : (f += 1) {
        c.wr32(c.ADDR_INPUT, if (f % 9 < 4) @as(u32, 1) else 0);
        frame();
    }
    const snap1 = tt.stateHash(120);
    // pass 2: identical input script -> identical hash
    _ = engine.init(blob);
    f = 0;
    while (f < 120) : (f += 1) {
        c.wr32(c.ADDR_INPUT, if (f % 9 < 4) @as(u32, 1) else 0);
        frame();
    }
    const snap2 = tt.stateHash(120);
    try std.testing.expectEqual(snap1, snap2);
}
