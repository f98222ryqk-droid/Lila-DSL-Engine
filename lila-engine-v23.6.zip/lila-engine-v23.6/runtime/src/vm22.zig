//! ============================================================================
//! LILA v22 — DETERMINISTIC COLLECTIONS (the C++/C# parity opcodes, round 3)
//! ============================================================================
//!
//! The runtime half of the v22 feature set. Everything here executes INSIDE
//! one VM opcode and touches ONLY:
//!   * c.mem (array cells, dict tables, the LCG register) — hashed,
//!     snapshot-safe, rewind/rollback capture it with the standard memcpy;
//!   * page-0 stash cells (mnext's value/cursor — 0x1C/0x20, written only by
//!     games that contain the opcodes, so legacy hash chains replay
//!     bit-identically, the v17 edge-register doctrine).
//!
//! Determinism contract: every algorithm below is pure integer math with
//! FIXED order (slot-scan iteration, ascending Fisher-Yates swap loop over
//! the LCG chain) — bit-identical on every runtime, every build.
//!
//! The C# analogs, for the record:
//!   noise1/noise2  Mathf.PerlinNoise     (hash lattice + quintic fade)
//!   mnext/mnextv   foreach (kvp in dict) (slot-order, no allocation)
//!   qpush/qpop     Queue<T>.Enqueue/Dequeue
//!   spush/spop     Stack<T>.Push/Pop     (+ Peek via speek)
//!   afill          Array.Fill / memset
//!   acopy          Array.Copy / memcpy
//!   ashuffle       Random.Shuffle / std::shuffle (seeded = the LCG state)
//!   afind/acount   Array.IndexOf / Count(match)

const std = @import("std");
const c = @import("core.zig");

// ---------------------------------------------------------------------------
// NOISE — splitmix32 hash lattice with quintic interpolation (Q24.8)
// ---------------------------------------------------------------------------

/// Lattice hash -> Q24.8 in [0, 1.0). mix32 is the same splitmix32
/// finalizer the dicts use (zero tables, deterministic everywhere).
inline fn h1(i: i32) i32 {
    return @intCast(c.mix32(@bitCast(i)) >> 24);
}

/// 2-D lattice hash -> Q24.8 in [0, 1.0). The axes mix with DIFFERENT
/// constants so the (x, y) -> (y, x) transpose never aliases.
inline fn h2(x: i32, y: i32) i32 {
    const hx = c.mix32(@as(u32, @bitCast(x)) +% 0x9E3779B1);
    const hy = c.mix32(@as(u32, @bitCast(y)) +% 0x85EBCA77);
    return @intCast(c.mix32(hx ^ hy) >> 24);
}

/// Perlin's quintic fade on Q24.8: f(u) = u^3 (6u^2 - 15u + 10), chained
/// mulF so every intermediate stays a legal fixed-point value (<= 10.0):
/// no overflow, monotone, C2-continuous joins.
inline fn fade(u: i32) i32 {
    const usq = c.mulF(u, u);
    const ucub = c.mulF(usq, u);
    const g = 6 * usq - 15 * u + 2560; // = 6u^2 - 15u + 10 in Q24.8
    return c.mulF(ucub, g);
}

/// 1-D value noise: hash the integer lattice, quintic-interpolate the
/// fractional part. t is Q24.8; returns Q24.8 in [0, 1.0).
pub fn noise1(t: i32) i32 {
    const i = t >> 8; // arithmetic shift = floor (works for negatives)
    const u = t & 0xFF;
    const a = h1(i);
    const b = h1(i + 1);
    return a + c.mulF(b - a, fade(u));
}

/// 2-D value noise: four lattice corners, quintic bilinear blend.
/// x, y are Q24.8; returns Q24.8 in [0, 1.0).
pub fn noise2(x: i32, y: i32) i32 {
    const ix = x >> 8;
    const iy = y >> 8;
    const fx = x & 0xFF;
    const fy = y & 0xFF;
    const h00 = h2(ix, iy);
    const h10 = h2(ix + 1, iy);
    const h01 = h2(ix, iy + 1);
    const h11 = h2(ix + 1, iy + 1);
    const wx = fade(fx);
    const wy = fade(fy);
    const n0 = h00 + c.mulF(h10 - h00, wx);
    const n1 = h01 + c.mulF(h11 - h01, wx);
    return n0 + c.mulF(n1 - n0, wy);
}

// ---------------------------------------------------------------------------
// MNEXT — deterministic dict iteration (C# foreach / C++ iterator)
// ---------------------------------------------------------------------------

/// Scan slots from `cursor` for the next live entry. Returns its KEY (or
/// -1 when exhausted); stashes the entry's VALUE at ADDR_MN_VAL and the
/// next cursor at ADDR_MN_CUR (read back via mnextv()/mnextc()).
/// Slot order IS the iteration order — fixed, allocation-free, and stable
/// across the whole family of runtimes. Deleting while iterating is the
/// caller's responsibility (backward-shift moves entries behind the
/// cursor — the C# enumerator throws; LILA documents the caveat).
pub fn mnext(d: u32, cursor: u32) i32 {
    if (d >= c.n_dicts) {
        c.wr32(c.ADDR_MN_CUR, 0xFFFFFFFF);
        return -1;
    }
    const cap: u32 = c.dict_cap[d];
    var i = cursor;
    if (i > cap) i = cap; // garbage / -1 cursor: treat as exhausted
    while (i < cap) : (i += 1) {
        const k = c.rd32(c.dictKey(d, i));
        if (k != c.DICT_EMPTY) {
            c.wr32(c.ADDR_MN_VAL, c.rd32(c.dictVal(d, i)));
            c.wr32(c.ADDR_MN_CUR, i + 1);
            return @bitCast(k);
        }
    }
    c.wr32(c.ADDR_MN_CUR, 0xFFFFFFFF);
    return -1;
}

// ---------------------------------------------------------------------------
// QUEUES + STACKS — ring buffers over the array plane (Queue<T> / Stack<T>)
// ---------------------------------------------------------------------------
// Substrate (the queue/stack decl's hidden array, or ANY global array the
// game chooses — the transparent-memory doctrine):
//     cell 0 = head counter (raw u32, starts 0)
//     cell 1 = tail counter (raw u32, starts 0)
//     cell 2 + (c % dcap) = data slot c
// Zero-init means empty; len = tail -% head stays correct across the 2^32
// wrap (2.2 years of one push per frame at 60Hz — the frame-counter
// contract). Full drops the push (the soft-land convention).

const Ring = struct { base: u32, dcap: u32 };

inline fn ring(gid: u32) ?Ring {
    if (gid >= c.n_arrs) return null;
    const cap: u32 = c.arr_cap[gid];
    if (cap < 3) return null;
    return Ring{ .base = c.arr_base[gid], .dcap = cap - 2 };
}

inline fn slotAddr(r: Ring, counter: u32) u32 {
    return r.base + (2 + (counter % r.dcap)) * 4;
}

/// FIFO append (Queue<T>.Enqueue). Drops the value when full.
pub fn qpush(gid: u32, v: u32) void {
    const r = ring(gid) orelse return;
    const head = c.rd32(r.base);
    const tail = c.rd32(r.base + 4);
    if (tail -% head >= r.dcap) return; // full: drop (soft-land)
    c.wr32(slotAddr(r, tail), v);
    c.wr32(r.base + 4, tail +% 1);
}

/// FIFO pop (Queue<T>.Dequeue). 0 when empty (the cell convention).
pub fn qpop(gid: u32) u32 {
    const r = ring(gid) orelse return 0;
    const head = c.rd32(r.base);
    const tail = c.rd32(r.base + 4);
    if (tail == head) return 0;
    const v = c.rd32(slotAddr(r, head));
    c.wr32(r.base, head +% 1);
    return v;
}

/// LIFO append (Stack<T>.Push). Same cells as the queue — a game may
/// interleave, at its own declaration's peril (documented: one discipline
/// per array).
pub fn spush(gid: u32, v: u32) void {
    qpush(gid, v); // identical ring append
}

/// LIFO pop (Stack<T>.Pop). 0 when empty.
pub fn spop(gid: u32) u32 {
    const r = ring(gid) orelse return 0;
    const head = c.rd32(r.base);
    const tail = c.rd32(r.base + 4);
    if (tail == head) return 0;
    const nt = tail -% 1;
    const v = c.rd32(slotAddr(r, nt));
    c.wr32(r.base + 4, nt);
    return v;
}

/// Stack<T>.Peek: the top value without popping. 0 when empty.
pub fn speek(gid: u32) u32 {
    const r = ring(gid) orelse return 0;
    const head = c.rd32(r.base);
    const tail = c.rd32(r.base + 4);
    if (tail == head) return 0;
    return c.rd32(slotAddr(r, tail -% 1));
}

/// Queue/Stack entry count (tail - head, wrap-correct).
pub fn ringLen(gid: u32) u32 {
    const r = ring(gid) orelse return 0;
    return c.rd32(r.base + 4) -% c.rd32(r.base);
}

// ---------------------------------------------------------------------------
// ARRAY OPS — fill / copy / shuffle / find / count
// ---------------------------------------------------------------------------

/// Array.Fill / memset: every cell of the array becomes v.
pub fn afill(gid: u32, v: u32) void {
    if (gid >= c.n_arrs) return;
    var i: u32 = 0;
    while (i < c.arr_cap[gid]) : (i += 1) {
        c.wr32(c.garrElem(gid, i), v);
    }
}

/// Array.Copy / memcpy: first n cells src -> dst (clamped to both caps).
pub fn acopy(dst: u32, src: u32, n: i32) void {
    if (dst >= c.n_arrs or src >= c.n_arrs or n <= 0) return;
    const maxn = @min(c.arr_cap[dst], c.arr_cap[src]);
    const count: u32 = @min(@as(u32, @intCast(n)), maxn);
    var i: u32 = 0;
    while (i < count) : (i += 1) {
        c.wr32(c.garrElem(dst, i), c.rd32(c.garrElem(src, i)));
    }
}

/// Random.Shuffle / std::shuffle: Fisher-Yates over the first n cells
/// (clamped to cap), driven by the hashed LCG chain — the rand register
/// lives in c.mem, so the shuffle is snapshot/rewind state like everything
/// else. Seeding = writing ADDR_RAND before the call.
pub fn ashuffle(gid: u32, n: i32) void {
    if (gid >= c.n_arrs or n <= 0) return;
    const count: u32 = @min(@as(u32, @intCast(n)), c.arr_cap[gid]);
    var i: i32 = @intCast(count);
    while (i > 1) : (i -= 1) {
        const j = c.randMax(i); // [0, i)
        const ai = c.garrElem(gid, @intCast(i - 1));
        const aj = c.garrElem(gid, @intCast(j));
        const t = c.rd32(ai);
        c.wr32(ai, c.rd32(aj));
        c.wr32(aj, t);
    }
}

/// Array.IndexOf: first cell equal to val, or -1.
pub fn afind(gid: u32, val: u32) i32 {
    if (gid >= c.n_arrs) return -1;
    var i: u32 = 0;
    while (i < c.arr_cap[gid]) : (i += 1) {
        if (c.rd32(c.garrElem(gid, i)) == val) return @intCast(i);
    }
    return -1;
}

/// Count(match): how many cells equal val.
pub fn acount(gid: u32, val: u32) u32 {
    if (gid >= c.n_arrs) return 0;
    var n: u32 = 0;
    var i: u32 = 0;
    while (i < c.arr_cap[gid]) : (i += 1) {
        if (c.rd32(c.garrElem(gid, i)) == val) n += 1;
    }
    return n;
}
