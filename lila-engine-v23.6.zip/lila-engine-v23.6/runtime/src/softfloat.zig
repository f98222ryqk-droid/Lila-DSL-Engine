//! ============================================================================
//! LILA v20 — SOFTFLOAT: IEEE 754 binary32 in pure integer arithmetic.
//! ============================================================================
//!
//! The Math Problem fix, the LILA way. Q24.8 stays the default number system
//! (bit-perfect, branchless, the arcade contract). `f32` is the OPT-IN
//! escape hatch for standard physics equations: software-emulated, correctly
//! rounded (round-to-nearest-even), subnormals exact, canonical NaN — so a
//! value computed on x86-64, ARM, wasm32 or a toaster is the SAME 32 bits.
//! No libm, no FPU, no FTZ/DAZ flags, no extended intermediates: the
//! determinism guarantees of the integer VM carry over unchanged.
//!
//! Every op is validated against the host's native f32 in the test suite
//! (bit-exact on 100k+ random + edge patterns per operation — the host f32
//! on this machine is IEEE-conformant SSE2, so it is a valid oracle).

const std = @import("std");

pub const F32 = u32; // raw bit pattern

pub const NAN_CANON: F32 = 0x7FC00000; // canonical quiet NaN, sign clear
pub const INF_POS: F32 = 0x7F800000;
pub const INF_NEG: F32 = 0xFF800000;

pub inline fn fromF(v: f32) F32 {
    return @bitCast(v);
}
pub inline fn toF(bits: F32) f32 {
    return @bitCast(bits);
}

// ---------------- decomposition ----------------

const Parts = struct {
    sign: u32, // 0 / 1
    exp: i32, // unbiased (-149 ..= 128; 255 = inf/nan marker)
    mant: u64, // 24-bit normalized (bit 23 set) for finite nonzero
    kind: enum { finite, inf, nan },
};

fn decomp(v: F32) Parts {
    const a = v & 0x7FFFFFFF;
    const e: i32 = @intCast(a >> 23);
    const m: u64 = a & 0x7FFFFF;
    if (e == 255) {
        return .{ .sign = v >> 31, .exp = 255, .mant = m, .kind = if (m == 0) .inf else .nan };
    }
    if (e == 0) {
        if (m == 0) return .{ .sign = v >> 31, .exp = -150, .mant = 0, .kind = .finite };
        // subnormal: normalize (leading 1 at some bit < 23)
        var mm = m;
        var ee: i32 = -126;
        while (mm & 0x800000 == 0) {
            mm <<= 1;
            ee -= 1;
        }
        return .{ .sign = v >> 31, .exp = ee, .mant = mm, .kind = .finite };
    }
    return .{ .sign = v >> 31, .exp = e - 127, .mant = m | 0x800000, .kind = .finite };
}

/// Recompose from sign + unbiased exp + 24-bit mantissa (bit 23 set),
/// re-rounding subnormals as needed. Exponent out of range -> ±inf.
fn recompose(sign: u32, exp: i32, mant: u64) F32 {
    const e = exp;
    const m = mant;
    if (m == 0) {
        // exact zero (only from exact cancellation with sign +0 semantics
        // handled by callers)
        return sign << 31;
    }
    if (e > 127) return (sign << 31) | 0x7F800000; // overflow -> inf
    if (e < -126) {
        // subnormal: shift the mantissa right; sticky round-to-nearest-even
        const shift_i: i32 = -126 - e; // >= 1
        if (shift_i > 25) {
            // underflow to (half-)zero: values below half the smallest
            // subnormal round to 0; exactly half rounds to even (0)
            if (shift_i == 26 and (m & 0x7FFFFF) == 0x400000) return sign << 31;
            return sign << 31;
        }
        const shift: u6 = @intCast(shift_i); // 1..25
        // target: 23 mantissa bits directly (no implicit bit)
        const keep = m >> shift; // 24-shift bits
        const guard = (m >> (shift - 1)) & 1;
        const sticky = (m & ((@as(u64, 1) << @intCast(shift - 1)) - 1)) != 0;
        var k = keep;
        if (guard == 1 and (sticky or (k & 1) != 0)) k += 1;
        // k may carry into the implicit-bit position: that's a normal now
        if (k >= 0x800000) {
            return (sign << 31) | (@as(u32, @intCast(k >> 1)) & 0x7FFFFF) | (1 << 23);
        }
        return (sign << 31) | @as(u32, @intCast(k));
    }
    // normal
    return (sign << 31) | (@as(u32, @intCast(e + 127)) << 23) | @as(u32, @intCast(m & 0x7FFFFF));
}

// ---------------- add / sub ----------------

pub fn add(x: F32, y: F32) F32 {
    const px = decomp(x);
    const py = decomp(y);
    if (px.kind == .nan or py.kind == .nan) return NAN_CANON;
    if (px.kind == .inf) {
        if (py.kind == .inf and py.sign != px.sign) return NAN_CANON;
        return x;
    }
    if (py.kind == .inf) return y;
    if (px.mant == 0) return if (py.mant == 0 and px.sign != py.sign) (x & 0x7FFFFFFF) else y;
    if (py.mant == 0) return x;

    // bigger exponent first — signs travel WITH their mantissas (the swap
    // must keep (mant, sign) paired or the subtract path picks the wrong
    // winner's sign: the a1c54aec + 4e7bfb79 class of bug)
    var ex = px.exp;
    var ey = py.exp;
    var mx = px.mant;
    var my = py.mant;
    var sx = px.sign;
    var sy = py.sign;
    if (ex < ey) {
        const tx = ex; ex = ey; ey = tx;
        const tm = mx; mx = my; my = tm;
        const ts = sx; sx = sy; sy = ts;
    }
    // 3 guard bits (GRS): shift the bigger up, align the smaller with a
    // SEPARATE sticky flag (folding it into bit 0 loses it under the
    // left-normalization of cancellation results).
    const mx3 = mx << 3;
    const d: u32 = @intCast(ex - ey);
    var ay: u64 = undefined;
    var st: bool = undefined;
    if (d <= 3) {
        ay = my << @intCast(3 - d);
        st = false;
    } else if (d <= 27) {
        const sh: u6 = @intCast(d - 3);
        ay = my >> sh;
        st = (my & ((@as(u64, 1) << sh) - 1)) != 0;
    } else {
        ay = 0;
        st = my != 0;
    }
    if (sx == sy) {
        // same sign: magnitudes add; the truncated tiny rides ABOVE the sum
        return round27(sx, ex, mx3 + ay, if (st) .above else .none);
    }
    // opposite signs: magnitude subtract. The smaller side's true value is
    // (ay + tiny): when the mx side wins the result is (v - tiny) — BELOW;
    // when the ay side wins it is (v + tiny) — ABOVE. The tie direction at
    // the half boundary differs, which is exactly what Sticky encodes.
    if (mx3 > ay or (mx3 == ay and !st)) {
        return round27(sx, ex, mx3 - ay, if (st) .below else .none);
    }
    if (mx3 == ay) {
        return sy << 31; // exact cancellation, but smaller side was a hair bigger
    }
    return round27(sy, ex, ay - mx3, if (st) .above else .none);
}

/// Sticky direction: the true value is slightly ABOVE or BELOW the
/// truncated v (ties at the half boundary resolve differently!).
const Sticky = enum { none, below, above };

/// THE unified rounding core. Contract: value = v * 2^(E-26) with v's top
/// bit anywhere in (0, 27]; the true value is v, v+tiny or v-tiny
/// (tiny in (0,1) at v's scale) per the sticky direction. Handles
/// carry-out, left-normalization, subnormal results (single rounding),
/// and overflow.
fn round27(sign: u32, exp: i32, grs: u64, stk: Sticky) F32 {
    var v = grs;
    var e = exp;
    // carry-out: same-sign sums can reach bit 27 (the dropped bit adds)
    var st = stk;
    if (v >= (1 << 27)) {
        if (st == .none and (v & 1) != 0) st = .above;
        v >>= 1;
        e += 1;
    }
    if (v == 0) return sign << 31; // (sticky-only zero: sign pre-decided by callers)
    // left-normalize to bit 26 (the GRS-form top)
    while (v < (1 << 26)) {
        v <<= 1;
        e -= 1;
    }
    // subnormal / underflow: single rounding from the GRS form.
    // field = RNE(v * 2^(e+123)) into the 23-bit subnormal field.
    if (e < -126) {
        const n: i32 = e + 123; // field = v * 2^n ; v in [2^26, 2^27)
        if (n <= -27) {
            if (n == -27 and v == (1 << 26)) {
                // exactly half the smallest subnormal: direction decides
                const bump: u32 = if (st == .above) 1 else 0;
                return (sign << 31) | bump;
            }
            if (n == -27 and v > (1 << 26)) return (sign << 31) | 1;
            return sign << 31;
        }
        const sh: u6 = @intCast(-n); // 3..26
        var field = v >> sh;
        const dropped = v & ((@as(u64, 1) << sh) - 1);
        const half = @as(u64, 1) << (sh - 1);
        if (dropped > half or (dropped == half and ((st == .above) or (st == .none and (field & 1) != 0)))) field += 1;
        if (field >= (1 << 23)) return (sign << 31) | (1 << 23); // rounded into min normal
        return (sign << 31) | @as(u32, @intCast(field));
    }
    // normal path: 24-bit mantissa from bits 26..3, GRS from 2..0
    var m24 = v >> 3;
    const g = v & 7;
    const up = g > 4 or (g == 4 and ((st == .above) or (st == .none and (m24 & 1) != 0)));
    if (up) m24 += 1;
    if (m24 >= (1 << 24)) {
        m24 >>= 1;
        e += 1;
    }
    if (e > 127) return (sign << 31) | 0x7F800000; // overflow -> inf
    return recompose(sign, e, m24);
}

pub fn sub(x: F32, y: F32) F32 {
    return add(x, y ^ 0x80000000);
}

// ---------------- multiply ----------------

pub fn mul(x: F32, y: F32) F32 {
    const px = decomp(x);
    const py = decomp(y);
    if (px.kind == .nan or py.kind == .nan) return NAN_CANON;
    const sign = px.sign ^ py.sign;
    if (px.kind == .inf or py.kind == .inf) {
        if (px.mant == 0 or py.mant == 0) return NAN_CANON; // 0 * inf
        return (sign << 31) | 0x7F800000;
    }
    if (px.mant == 0 or py.mant == 0) return sign << 31;
    const e = px.exp + py.exp;
    const prod = @as(u64, px.mant) * @as(u64, py.mant); // 47..48 bits
    // normalize to bit 47; v = Pn >> 21 puts the top at bit 26 (GRS form)
    var ee = e;
    var pn = prod;
    if (pn & (@as(u64, 1) << 47) == 0) {
        pn <<= 1;
        ee -= 1;
    }
    const v = pn >> 21;
    const st = (pn & 0x1FFFFF) != 0;
    return round27(sign, ee + 1, v, if (st) .above else .none);
}

// ---------------- divide ----------------

pub fn div(x: F32, y: F32) F32 {
    const px = decomp(x);
    const py = decomp(y);
    if (px.kind == .nan or py.kind == .nan) return NAN_CANON;
    const sign = px.sign ^ py.sign;
    if (px.kind == .inf) {
        if (py.kind == .inf) return NAN_CANON;
        return (sign << 31) | 0x7F800000;
    }
    if (py.kind == .inf) return sign << 31;
    if (py.mant == 0) {
        if (px.mant == 0) return NAN_CANON; // 0/0
        return (sign << 31) | 0x7F800000; // x/0 = inf (IEEE)
    }
    if (px.mant == 0) return sign << 31;
    const e = px.exp - py.exp;
    // 25..26-bit quotient with remainder-sticky; route through round27
    const num = @as(u64, px.mant) << 25; // 48..49 bits
    const q = num / py.mant;
    const st = (num % py.mant) != 0;
    if (q >= (1 << 25)) {
        // top at bit 25: shift to bit 26, exponent unchanged (E = D)
        return round27(sign, e, q << 1, if (st) .above else .none);
    }
    // top at bit 24: shift to bit 26, E = D - 1
    return round27(sign, e - 1, q << 2, if (st) .above else .none);
}

// ---------------- square root (correctly rounded) ----------------

pub fn sqrt(x: F32) F32 {
    if ((x & 0x7FFFFFFF) == 0) return x; // ±0 -> itself
    if (x >> 31 != 0) return NAN_CANON; // sqrt(negative) = NaN
    const px = decomp(x);
    if (px.kind == .nan) return NAN_CANON; // NaN in, canonical NaN out
    if (px.kind == .inf) return x; // +inf -> +inf
    // value = m * 2^Ebig with m in [2^23, 2^24), Ebig = exp - 23.
    // Make Ebig even (m doubles when odd), then:
    //   sqrt(value) = sqrt(m) * 2^(Ebig/2)
    //   s = isqrt(m << 24) ~ sqrt(m) * 2^12 (25-bit, top at bit 24)
    //   v = s << 2 (top at bit 26 = GRS form), E = Ebig/2 + 12
    var m: u64 = px.mant;
    var ebig: i32 = px.exp - 23;
    if (ebig & 1 != 0) {
        m <<= 1; // now in [2^24, 2^25)
        ebig -= 1;
    }
    const big = m << 24;
    const s = isqrt64(big);
    // GRS form + EXACT boundary rounding. m is 24-bit (even ebig) or 25-bit
    // (odd ebig, doubled); the shift is chosen so v ALWAYS lands at bit 26:
    //   m 24-bit -> s in [2^23.5, 2^24) -> v = s<<3, E = ebig/2 + 11,
    //               boundary: 4*big > B^2 (exact ties impossible by parity)
    //   m 25-bit -> s in [2^24, 2^24.5) -> v = s<<2, E = ebig/2 + 12,
    //               boundary: big > B^2 (tie when big == B^2 -> to even)
    // B = 2*mant_floor + 1 is the halfway witness scaled to the mantissa;
    // all comparisons are exact u64 integer math (a sticky approximation
    // biased one ULP low ~12% of the time — found by the native oracle).
    if (m < (1 << 24)) {
        const v = s << 3;
        const mant_floor = v >> 3; // == s, bit 23 set
        const B = 2 * mant_floor + 1;
        const up = 4 * big > B * B;
        const m24: u64 = if (up) mant_floor + 1 else mant_floor;
        return round27(0, (ebig >> 1) + 11, m24 << 3, .none);
    }
    const v = s << 2;
    const mant_floor = v >> 3;
    const B = 2 * mant_floor + 1;
    if (big > B * B) {
        return round27(0, (ebig >> 1) + 12, (mant_floor + 1) << 3, .none);
    }
    if (big == B * B and (mant_floor & 1) != 0) {
        return round27(0, (ebig >> 1) + 12, (mant_floor + 1) << 3, .none);
    }
    return round27(0, (ebig >> 1) + 12, mant_floor << 3, .none);
}

/// Integer square root of a u64 (floor). Newton iterations from the
/// bit-length seed converge to the exact floor sqrt; the final correction
/// pass guarantees it. Deterministic pure integer math.
fn isqrt64(x: u64) u64 {
    if (x == 0) return 0;
    var r: u64 = @as(u64, 1) << @intCast((64 - @clz(x) + 1) / 2);
    while (true) {
        const q = x / r;
        if (q >= r) break;
        r = (r + q) / 2;
    }
    while (r * r > x) r -= 1;
    return r;
}

pub fn neg(x: F32) F32 {
    return x ^ 0x80000000;
}

pub fn fabs(x: F32) F32 {
    return x & 0x7FFFFFFF;
}

// ---------------- int <-> f32 conversions ----------------

/// i32 -> f32, round-to-nearest-even (exactly the IEEE rounding of the
/// infinitely-precise conversion).
pub fn fromI32(v: i32) F32 {
    if (v == 0) return 0;
    const sign: u32 = if (v < 0) 1 else 0;
    const mag: u32 = @abs(v); // |v| <= 2^31
    const bits: i32 = 32 - @as(i32, @clz(mag));
    var e: i32 = bits - 1;
    var m: u64 = undefined;
    if (bits <= 24) {
        m = @as(u64, mag) << @intCast(24 - bits);
    } else {
        const sh: u5 = @intCast(bits - 24); // bits <= 32 -> sh <= 8
        m = @as(u64, mag) >> sh;
        const guard = (mag >> @intCast(sh - 1)) & 1;
        const sticky = (mag & ((@as(u32, 1) << @intCast(sh - 1)) - 1)) != 0;
        if (guard == 1 and (sticky or (m & 1) != 0)) {
            m += 1;
            if (m >= (1 << 24)) {
                m >>= 1;
                e += 1;
            }
        }
    }
    return recompose(sign, e, m);
}

/// f32 -> i32, truncation toward zero (C# (int) semantics). NaN -> 0;
/// out-of-range saturates to i32 min/max.
pub fn toI32(x: F32) i32 {
    const px = decomp(x);
    if (px.kind != .finite or px.mant == 0) return 0;
    if (px.exp >= 31) {
        // |value| >= 2^31 (mant >= 2^23): saturate
        if (px.sign != 0) return std.math.minInt(i32);
        return std.math.maxInt(i32);
    }
    // value = mant * 2^(exp-23); exp < 31
    const sh: i32 = px.exp - 23;
    var mag: u64 = undefined;
    if (sh >= 0) {
        mag = @as(u64, px.mant) << @intCast(sh);
    } else {
        mag = px.mant >> @intCast(-sh); // truncate
    }
    if (px.sign != 0) {
        return -@as(i32, @intCast(mag));
    }
    return @intCast(mag);
}

/// Q24.8 fixed (raw i32) -> f32: value = raw / 256, rounded to nearest f32.
pub fn fromFix(raw: i32) F32 {
    const bits = fromI32(raw);
    // exact scaling by a power of two: exponent -8, renormalize
    if ((bits & 0x7FFFFFFF) == 0) return bits;
    const px = decomp(bits);
    if (px.kind != .finite) return bits; // saturating int edge stays
    return recompose(px.sign, px.exp - 8, px.mant);
}

/// f32 -> Q24.8 fixed (raw i32): round(x * 256) with ties-to-even, saturating.
pub fn toFix(x: F32) i32 {
    const px = decomp(x);
    if (px.kind != .finite or px.mant == 0) return 0;
    // value * 256 = mant * 2^(exp-23+8); integer iff exp >= -8+23-ish
    const sh: i32 = px.exp + 8 - 23; // mant * 2^sh
    var mag: i64 = undefined;
    if (sh >= 0) {
        if (px.exp + 8 >= 31) { // magnitude >= 2^31 in Q24.8 terms
            return if (px.sign != 0) std.math.minInt(i32) else std.math.maxInt(i32);
        }
        mag = @as(i64, @intCast(px.mant)) << @intCast(sh);
    } else {
        const nsh: u6 = @intCast(-sh);
        mag = @as(i64, @intCast(px.mant)) >> nsh;
        // round-to-nearest-even from the dropped bits
        const half = @as(u64, 1) << (nsh - 1);
        const rest_mask = half - 1;
        const dropped = px.mant & (half | rest_mask);
        if (dropped > half or (dropped == half and (mag & 1) != 0)) mag += 1;
    }
    if (px.sign != 0) return -@as(i32, @intCast(@min(mag, 0x7FFFFFFF)));
    return @intCast(@min(mag, 0x7FFFFFFF));
}

// ---------------- comparisons (IEEE total semantics, NaN -> false) ----------------

pub fn lt(x: F32, y: F32) bool {
    if ((x & 0x7FFFFFFF) > 0x7F800000 or (y & 0x7FFFFFFF) > 0x7F800000) return false; // NaN
    if ((x & 0x7FFFFFFF) == 0 and (y & 0x7FFFFFFF) == 0) return false; // ±0 == ∓0
    if (x >> 31 != y >> 31) return x >> 31 != 0;
    if (x >> 31 != 0) return (x & 0x7FFFFFFF) > (y & 0x7FFFFFFF);
    return (x & 0x7FFFFFFF) < (y & 0x7FFFFFFF);
}

pub fn eq(x: F32, y: F32) bool {
    if ((x & 0x7FFFFFFF) > 0x7F800000 or (y & 0x7FFFFFFF) > 0x7F800000) return false;
    return (x & 0x7FFFFFFF) == (y & 0x7FFFFFFF); // -0 == +0 by magnitude
}

pub fn le(x: F32, y: F32) bool {
    return eq(x, y) or lt(x, y);
}

// ============================================================================
// TESTS — bit-exact agreement with the host's IEEE f32 on random + edge
// patterns. The host (x86-64 SSE2) is a valid oracle for +,-,*,/,sqrt:
// all five are exactly-rounded IEEE ops there.
// ============================================================================

const testing = std.testing;

fn randF32(state: *u64) F32 {
    // xorshift64 -> random bit patterns (hits NaNs, infs, subnormals)
    var s = state.*;
    s ^= s << 13;
    s ^= s >> 7;
    s ^= s << 17;
    state.* = s;
    return @truncate(s);
}

fn canonNanBits(v: f32) F32 {
    // native ops can produce NaN payloads; the softfloat contract is the
    // CANONICAL NaN — normalize before comparing when both are NaN.
    const b: F32 = @bitCast(v);
    if ((b & 0x7F800000) == 0x7F800000 and (b & 0x7FFFFF) != 0) return NAN_CANON;
    return b;
}

test "softfloat: add/sub/mul/div/sqrt bit-exact vs native (100k random each)" {
    var st: u64 = 0x9E3779B97F4A7C15;
    var i: usize = 0;
    while (i < 100_000) : (i += 1) {
        const a = randF32(&st);
        const b = randF32(&st);
        // ADD
        const nadd = canonNanBits(toF(a) + toF(b));
        const sadd = add(a, b);
        try testing.expectEqual(canonNanBits(toF(sadd)), nadd);
        // SUB
        const nsub = canonNanBits(toF(a) - toF(b));
        const ssub = sub(a, b);
        try testing.expectEqual(canonNanBits(toF(ssub)), nsub);
        // MUL
        const nmul = canonNanBits(toF(a) * toF(b));
        const smul = mul(a, b);
        try testing.expectEqual(canonNanBits(toF(smul)), nmul);
        // DIV (native division is exactly rounded)
        const ndiv = canonNanBits(toF(a) / toF(b));
        const sdiv = div(a, b);
        try testing.expectEqual(canonNanBits(toF(sdiv)), ndiv);
        // SQRT
        if ((a >> 31) == 0) { // native sqrt of negative traps as UB-adjacent; skip
            const nsq = canonNanBits(@sqrt(toF(a)));
            const ssq = sqrt(a);
            try testing.expectEqual(canonNanBits(toF(ssq)), nsq);
        }
    }
}

test "softfloat: exhaustive integers convert exactly (i32 -> f32 -> i32)" {
    var st: u64 = 0x1234567890ABCDEF;
    var i: usize = 0;
    while (i < 200_000) : (i += 1) {
        const v: i32 = @bitCast(randF32(&st));
        const f = fromI32(v);
        // native conversion is exactly-rounded too
        try testing.expectEqual(@as(F32, @bitCast(@as(f32, @floatFromInt(v)))), f);
    }
    // every i32 in the exactly-representable band round-trips
    const exact: i32 = 1 << 24;
    var v: i32 = -exact;
    while (v <= exact) : (v += 4099) {
        try testing.expectEqual(v, toI32(fromI32(v)));
    }
}

test "softfloat: fixed-point bridge is exact in both directions" {
    var st: u64 = 0xDEADBEEFCAFEBABE;
    var i: usize = 0;
    while (i < 100_000) : (i += 1) {
        const raw: i32 = @bitCast(randF32(&st));
        const f = fromFix(raw); // raw / 256
        const native: f32 = @as(f32, @floatFromInt(raw)) / 256.0;
        try testing.expectEqual(@as(F32, @bitCast(native)), f);
        // toFix(fromFix(raw)) recovers raw exactly for |raw| < 2^24
        if (@abs(raw) < (1 << 24)) {
            try testing.expectEqual(raw, toFix(f));
        }
    }
}

test "softfloat: comparisons follow IEEE (incl. -0 == +0, NaN unordered)" {
    try testing.expect(eq(0x00000000, 0x80000000)); // +0 == -0
    try testing.expect(lt(0x80000000, 0x00000001)); // -0 < smallest subnormal
    try testing.expect(!lt(NAN_CANON, NAN_CANON));
    try testing.expect(!eq(NAN_CANON, NAN_CANON));
    try testing.expect(lt(0xFF800000, 0x7F800000)); // -inf < +inf
    try testing.expect(lt(0x7F7FFFFF, 0x7F800000)); // max finite < inf
    try testing.expect(le(0x00800000, 0x00800000)); // min normal == itself
    // sign-magnitude ordering both directions
    try testing.expect(lt(0xBF800000, 0x3F800000)); // -1 < 1
    try testing.expect(lt(0xBF800000, 0x00000000)); // -1 < 0
}

test "softfloat: edge patterns (powers, neighbors of 1.0, subnormals)" {
    // 1.0 + 2^-24: exact halfway between 1.0 and 1+2^-23 -> ties-to-even
    // keeps 1.0 (mantissa even). RNE halves NEVER cross one at a time.
    const half = 0x33800000; // 2^-24
    const one = fromF(1.0);
    try testing.expectEqual(one, add(one, half));
    try testing.expectEqual(one, add(add(one, half), half));
    // but half + half is EXACT (2^-23), and 1.0 + 2^-23 is representable
    const up = add(one, add(half, half));
    try testing.expectEqual(fromF(1.0000001192092896), up);
    // 2^24 * (1 - 2^-24) * itself: exact square then compare
    const v = 0x4B7FFFFF;
    try testing.expectEqual(@as(F32, @bitCast(toF(v) * toF(v))), mul(v, v));
    // subnormal + subnormal
    const tiniest: F32 = 1;
    const two_tiny = add(tiniest, tiniest);
    try testing.expectEqual(@as(F32, 2), two_tiny);
    // subnormal * normal -> subnormal result (the underflow rounding path)
    const sub_to_norm = mul(tiniest, fromF(65536.0));
    try testing.expectEqual(@as(F32, @bitCast(toF(tiniest) * 65536.0)), sub_to_norm);
    // 0.1 * 0.1 vs native
    const point_one: f32 = 0.1;
    try testing.expectEqual(@as(F32, @bitCast(point_one * point_one)), mul(fromF(point_one), fromF(point_one)));
    // 1/3
    const one_f: f32 = 1.0;
    const three_f: f32 = 3.0;
    try testing.expectEqual(@as(F32, @bitCast(one_f / three_f)), div(fromF(one_f), fromF(three_f)));
    // sqrt of perfect squares is exact
    try testing.expectEqual(fromF(2.0), sqrt(fromF(4.0)));
    try testing.expectEqual(fromF(3.0), sqrt(fromF(9.0)));
    try testing.expectEqual(fromF(0.5), sqrt(fromF(0.25)));
    // the hardest class: sqrt near-halves
    var st: u64 = 0x51ED270B;
    var i: usize = 0;
    while (i < 200_000) : (i += 1) {
        const a = randF32(&st) & 0x7FFFFFFF; // positive
        if ((a & 0x7F800000) == 0x7F800000) continue;
        const nsq = canonNanBits(@sqrt(toF(a)));
        const ssq = sqrt(a);
        try testing.expectEqual(canonNanBits(toF(ssq)), nsq);
    }
}

// ============================================================================
// v23 TIER-1: IEEE 754 binary64 (f64) — double-precision soft-float
// ============================================================================
//
// Extends the v20 binary32 implementation to binary64. Same design:
// pure integer arithmetic, correctly rounded (round-to-nearest-even),
// subnormals exact, canonical NaN. No libm, no FPU, no FTZ/DAZ — the
// determinism guarantees carry over unchanged.
//
// 11-bit exponent (bias 1023), 52-bit mantissa, 64-bit total.
// Used by the Tier-1 escape hatch (f64 type). The tier purity fixpoint
// demotes any fn that uses f64; the optimizer gates skip it; codegen
// emits the f64 opcodes below.
//
// The implementation is the same algorithm as binary32, widened to 64-bit.
// Add/sub/mul/div/sqrt + comparisons + conversions. Each op is ~20-40 lines.

pub const F64 = u64; // raw bit pattern

pub const NAN_CANON_F64: F64 = 0x7FF8000000000000;
pub const INF_POS_F64: F64 = 0x7FF0000000000000;
pub const INF_NEG_F64: F64 = 0xFFF0000000000000;

pub inline fn fromF64(v: f64) F64 {
    return @bitCast(v);
}
pub inline fn toF64(bits: F64) f64 {
    return @bitCast(bits);
}

const Parts64 = struct {
    sign: u32, // 0 / 1
    exp: i32, // unbiased (-1074 ..= 1023; 2047 = inf/nan marker)
    mant: u64, // 53-bit normalized (bit 52 set) for finite nonzero
    kind: enum { finite, inf, nan },
};

fn decomp64(v: F64) Parts64 {
    const a = v & 0x7FFFFFFFFFFFFFFF;
    const e: i32 = @intCast(a >> 52);
    const m: u64 = a & 0xFFFFFFFFFFFFF;
    if (e == 2047) {
        return .{ .sign = @intCast(v >> 63), .exp = 2047, .mant = m, .kind = if (m == 0) .inf else .nan };
    }
    if (e == 0) {
        if (m == 0) return .{ .sign = @intCast(v >> 63), .exp = -1075, .mant = 0, .kind = .finite };
        // subnormal: normalize
        var mm = m;
        var ee: i32 = -1022;
        while (mm & 0x10000000000000 == 0) {
            mm <<= 1;
            ee -= 1;
        }
        return .{ .sign = @intCast(v >> 63), .exp = ee, .mant = mm, .kind = .finite };
    }
    return .{ .sign = @intCast(v >> 63), .exp = e - 1023, .mant = m | 0x10000000000000, .kind = .finite };
}

// ---------------- v23.1: the binary64 rounding core (REWRITTEN) ----------------
//
// SINGLE CONTRACT for every caller:
//     value = mant * 2^(exp - 55)
// `mant` may be any magnitude — round_pack64 normalizes it into the
// 56-bit frame (53-bit significand + 3 guard bits), rounds to
// nearest-even, and packs. Callers must pre-fold anything smaller than
// 3 guard bits into bit 0 as sticky (see each op).
//
// The v23 version normalized to bit 53 while its callers delivered bit 55
// and passed un-stickied alignment shifts, so EVERY operation was silently
// misrounded (f64(3) came back as 1.375, 1.0+2.0 as 1.0). Tests in
// test_v231.zig now pin exact bit patterns for every op.

fn round_pack64(sign: u32, exp0: i32, mant0: u64, extra_sticky: bool) F64 {
    // v23.1: `extra_sticky` rides OUTSIDE the mantissa — normalization
    // shifts would otherwise move a bit-0 sticky into a guard position and
    // turn a round-up into a false tie (caught by the 100k oracle).
    if (mant0 == 0) {
        if (extra_sticky) return @as(u64, sign) << 63; // no significand to round into
        return @as(u64, sign) << 63;
    }
    var m: u64 = mant0;
    var e: i32 = exp0;
    var lost: bool = extra_sticky;
    // normalize: leading bit exactly at 55
    const clz: u32 = @clz(m);
    if (clz < 8) {
        const sh: u6 = @intCast(8 - clz);
        const dropped: u64 = m & ((@as(u64, 1) << sh) - 1);
        if (dropped != 0) lost = true;
        m >>= sh;
        e += @as(i32, sh);
    } else if (clz > 8) {
        const sh: u6 = @intCast(clz - 8);
        m <<= sh;
        e -= @as(i32, sh);
    }
    // SUBNORMAL RESULTS: round ONCE at subnormal precision. Rounding to 53
    // bits first and then to the subnormal grid double-rounds (caught by
    // the 100k oracle on subnormal operands).
    if (e < -1021) {
        // field = m * 2^(e + 1019) — shift right with RNE over the whole
        // 56-bit frame plus the caller's sticky
        const sh: i32 = -(e + 1019);
        if (sh >= 64) {
            // |value| < 2^-1075 (or exactly half-LSB with sticky): the
            // RNE tie at 2^-1075 rounds to even = 0
            return @as(u64, sign) << 63;
        }
        const sh6: u6 = @intCast(sh);
        const dropped: u64 = m & ((@as(u64, 1) << sh6) - 1);
        const half: u64 = @as(u64, 1) << @intCast(sh6 - 1);
        var field: u64 = m >> sh6;
        const guard = (dropped & half) != 0;
        const sticky = (dropped & (half - 1)) != 0 or lost;
        if (guard and (sticky or (field & 1) == 1)) field += 1;
        return (@as(u64, sign) << 63) | field;
    }
    // leading bit at 55; significand = bits 55..3, guard=2, round=1, sticky=0
    const guard = (m & 4) != 0;
    const rnd = (m & 2) != 0;
    const sticky = (m & 1) != 0 or lost;
    m >>= 3;
    if (guard and (rnd or sticky or (m & 1) == 1)) {
        m += 1;
        if (m == (@as(u64, 1) << 53)) { // carry out of the significand
            m >>= 1;
            e += 1;
        }
    }
    // value = m * 2^(e - 52), m has bit 52 set
    return finish_pack64(sign, e, m);
}

fn finish_pack64(sign: u32, e0: i32, m53: u64) F64 {
    // value = m53 * 2^(e0 - 52); m53 has bit 52 set (53-bit significand).
    // NORMAL range only (-1021 <= e0 <= 1023) — subnormal rounding happens
    // earlier, once, at subnormal precision.
    if (m53 == 0) return @as(u64, sign) << 63;
    if (e0 > 1023) return if (sign != 0) INF_NEG_F64 else INF_POS_F64;
    const exp_bits: u64 = @as(u64, @intCast(e0 + 1023));
    return (@as(u64, sign) << 63) | (exp_bits << 52) | (m53 & 0xFFFFFFFFFFFFF);
}

pub fn f64_add(a: F64, b: F64) F64 {
    const pa = decomp64(a);
    const pb = decomp64(b);
    if (pa.kind == .nan or pb.kind == .nan) return NAN_CANON_F64;
    if (pa.kind == .inf and pb.kind == .inf) {
        if (pa.sign != pb.sign) return NAN_CANON_F64;
        return a;
    }
    if (pa.kind == .inf) return a;
    if (pb.kind == .inf) return b;
    var ea = pa.exp;
    var ma: u64 = pa.mant;
    var eb = pb.exp;
    var mb: u64 = pb.mant;
    // align exponents on UNSIGNED magnitudes — v23.1 fix: the old code
    // aligned the SIGNED values, and an arithmetic right-shift of a huge
    // negative converges to -1 instead of 0, so `a - tiny` came back as
    // `a - 1ulp`. Fold shifted-out bits into sticky either way.
    var align_sticky = false;
    while (ea < eb) {
        align_sticky = align_sticky or (ma & 1) != 0;
        ma >>= 1;
        ea += 1;
    }
    while (eb < ea) {
        align_sticky = align_sticky or (mb & 1) != 0;
        mb >>= 1;
        eb += 1;
    }
    const ma_s: i64 = if (pa.sign != 0) -@as(i64, @intCast(ma)) else @intCast(ma);
    const mb_s: i64 = if (pb.sign != 0) -@as(i64, @intCast(mb)) else @intCast(mb);
    const sum = ma_s + mb_s;
    const sign: u32 = if (sum < 0) 1 else 0;
    const abs_sum: u64 = @intCast(if (sum < 0) -sum else sum);
    // value = abs_sum * 2^ea = (abs_sum << 3) * 2^(ea + 52 - 55)
    return round_pack64(sign, ea, abs_sum << 3, align_sticky);
}

pub fn f64_sub(a: F64, b: F64) F64 {
    return f64_add(a, b ^ 0x8000000000000000);
}

pub fn f64_mul(a: F64, b: F64) F64 {
    const pa = decomp64(a);
    const pb = decomp64(b);
    if (pa.kind == .nan or pb.kind == .nan) return NAN_CANON_F64;
    if (pa.kind == .inf or pb.kind == .inf) {
        if (pa.mant == 0 or pb.mant == 0) return NAN_CANON_F64; // 0 * inf = NaN
        const sign = pa.sign ^ pb.sign;
        return if (sign != 0) INF_NEG_F64 else INF_POS_F64;
    }
    if (pa.mant == 0 or pb.mant == 0) return 0;
    const sign = pa.sign ^ pb.sign;
    // 53x53 -> 106-bit product, keep the top 56 bits (53 + 3 guards)
    const prod: u128 = @as(u128, pa.mant) * @as(u128, pb.mant);
    const bl: u32 = 128 - @clz(prod);
    const s: u32 = bl - 56; // 49 or 50
    const m56: u64 = @truncate(prod >> @intCast(s));
    const sticky = (prod & ((@as(u128, 1) << @intCast(s)) - 1)) != 0;
    // value = (prod >> s) * 2^(ea + eb + s) = m56 * 2^(e - 55)
    return round_pack64(sign, pa.exp + pb.exp + @as(i32, @intCast(s)) - 49, m56, sticky);
}

pub fn f64_div(a: F64, b: F64) F64 {
    const pa = decomp64(a);
    const pb = decomp64(b);
    if (pa.kind == .nan or pb.kind == .nan) return NAN_CANON_F64;
    if (pa.kind == .inf and pb.kind == .inf) return NAN_CANON_F64;
    if (pa.kind == .inf) return if (pa.sign != pb.sign) INF_NEG_F64 else INF_POS_F64;
    if (pb.kind == .inf) return if (pa.sign != pb.sign) 0x8000000000000000 else 0;
    if (pb.mant == 0) {
        if (pa.mant == 0) return NAN_CANON_F64;
        const sign = pa.sign ^ pb.sign;
        return if (sign != 0) INF_NEG_F64 else INF_POS_F64;
    }
    if (pa.mant == 0) return if (pa.sign != pb.sign) 0x8000000000000000 else 0;
    const sign = pa.sign ^ pb.sign;
    // quotient: (ma << 54) / mb lands in [2^53, 2^55) — round_pack64
    // normalizes up losslessly; the remainder folds into sticky.
    const num: u128 = @as(u128, pa.mant) << 54;
    const q: u64 = @intCast(num / @as(u128, pb.mant));
    const rem: u128 = num % @as(u128, pb.mant);
    // value = q * 2^(ea - eb - 54); the remainder is the sticky
    return round_pack64(sign, pa.exp - pb.exp + 1, q, rem != 0);
}

pub fn f64_sqrt(a: F64) F64 {
    const pa = decomp64(a);
    if (pa.kind == .nan) return NAN_CANON_F64;
    if (pa.sign != 0 and pa.kind == .finite and pa.mant != 0) return NAN_CANON_F64;
    if (pa.kind == .inf) return a;
    if (pa.mant == 0) return a;
    // normalize the exponent to even
    var e = pa.exp;
    var mant: u64 = pa.mant;
    if ((e & 1) != 0) {
        mant <<= 1;
        e -= 1;
    }
    // integer sqrt with remainder: sqrt(mant << 60), result ~2^56
    const num: u128 = @as(u128, mant) << 60;
    var s: u128 = 0;
    // highest power of FOUR <= num (the restoring-sqrt bit) — starting one
    // step low would compute the root of a scaled input
    var bit: u128 = 1;
    while (bit << 2 <= num) bit <<= 2;
    var n = num;
    while (bit != 0) {
        // Hacker's Delight restoring sqrt: trial value is s + bit (the
        // v23.1 draft used 2s + bit and underestimated by ~14%)
        const t: u128 = s + bit;
        if (n >= t) {
            n -= t;
            s = (s >> 1) + bit;
        } else {
            s >>= 1;
        }
        bit >>= 2;
    }
    const rem: u128 = n; // num - s*s
    const su: u64 = @intCast(s);
    // value = sqrt(mant') * 2^(e'/2) = s * 2^((e'-52)/2 - 30)
    // contract: m * 2^(E - 55) -> E = (e' - 52)/2 + 25
    return round_pack64(0, @divTrunc(e - 52, 2) + 25, su, rem != 0);
}

pub fn f64_eq(a: F64, b: F64) bool {
    if ((a & 0x7FFFFFFFFFFFFFFF) > INF_POS_F64) return false; // NaN
    return a == b or (a | b) == 0x8000000000000000; // -0 == +0
}

pub fn f64_ne(a: F64, b: F64) bool { return !f64_eq(a, b); }

pub fn f64_lt(a: F64, b: F64) bool {
    if ((a & 0x7FFFFFFFFFFFFFFF) > INF_POS_F64 or (b & 0x7FFFFFFFFFFFFFFF) > INF_POS_F64) return false;
    const sa = a >> 63;
    const sb = b >> 63;
    if (sa != sb) return sa != 0; // different signs
    if (sa == 0) return a < b;
    return a > b; // both negative
}

pub fn f64_gt(a: F64, b: F64) bool { return f64_lt(b, a); }
pub fn f64_le(a: F64, b: F64) bool { return !f64_gt(a, b); }
pub fn f64_ge(a: F64, b: F64) bool { return !f64_lt(a, b); }

// ---- Conversions ----

pub fn i2f64(v: i32) F64 {
    // v23.1: exact (the old version misused the broken rounding frame and
    // returned e.g. 1.375 for 3).
    if (v == 0) return 0;
    const sign: u64 = if (v < 0) 0x8000000000000000 else 0;
    const abs: u64 = @abs(v);
    const bl: u32 = 64 - @clz(abs);
    const sh: u6 = @intCast(55 - (bl - 1));
    return sign | round_pack64(0, 55 - @as(i32, sh), abs << sh, false);
}

pub fn f642i(bits: F64) i32 {
    const pa = decomp64(bits);
    if (pa.kind == .nan) return 0;
    if (pa.kind == .inf) return if (pa.sign != 0) -2147483648 else 2147483647;
    if (pa.mant == 0) return 0;
    var m = pa.mant;
    var e = pa.exp;
    if (e >= 31) return if (pa.sign != 0) -2147483648 else 2147483647;
    while (e < 0 and m != 0) { m >>= 1; e += 1; }
    while (e > 0 and m != 0) { m <<= 1; e -= 1; }
    // v23.1: the integer part is mant >> (52 - exp) — the old `>> 53`
    // dropped one bit, returning 62 for 125.
    const v: i64 = @intCast(m >> 52);
    return if (pa.sign != 0) -@as(i32, @intCast(v)) else @intCast(v);
}

// v23.1: the two conversions below were STUBS that produced wrong values
// (fix2f64(1.5) returned 384.0 — the raw Q24.8 cell — and f642fix(1.5)
// truncated to 1.0). Both are now correctly rounded.

/// Q24.8 fixed (raw i32) -> binary64: value = q / 256. EXACT (pure
/// exponent arithmetic on the integer — no rounding anywhere).
pub fn fix2f64(q: i32) F64 {
    if (q == 0) return 0;
    const sign: u64 = if (q < 0) 0x8000000000000000 else 0;
    const abs: u64 = @intCast(if (q < 0) -@as(i64, q) else @as(i64, q));
    const bl: u32 = 64 - @clz(abs);
    const sh: u6 = @intCast(55 - (bl - 1));
    const m: u64 = abs << sh;
    // value = m * 2^(e - 55), e = 55 - sh - 8 (the /256)
    return (@as(u64, sign)) | round_pack64(0, 55 - @as(i32, sh) - 8, m, false);
}

/// binary64 -> Q24.8 fixed (raw i32): round(x * 256) with ties-to-even,
/// saturating to i32 (NaN -> 0, +-inf and out-of-range saturate).
pub fn f642fix(bits: F64) i32 {
    const pa = decomp64(bits);
    if (pa.kind == .nan) return 0;
    if (pa.kind == .inf) return if (pa.sign != 0) std.math.minInt(i32) else std.math.maxInt(i32);
    if (pa.mant == 0) return 0;
    // target = mant * 2^(exp + 8 - 52): integer when the shift >= 0
    const sh: i32 = pa.exp + 8 - 52;
    if (sh >= 0) {
        // |target| >= 2^52 > i32 range
        return if (pa.sign != 0) std.math.minInt(i32) else std.math.maxInt(i32);
    }
    const nsh: u32 = @intCast(-sh);
    const dropped: u64 = pa.mant & ((@as(u64, 1) << @intCast(nsh)) - 1);
    const half: u64 = @as(u64, 1) << @intCast(nsh - 1);
    var r: u64 = pa.mant >> @intCast(nsh);
    const guard = (dropped & half) != 0;
    const sticky = (dropped & (half - 1)) != 0;
    if (guard and (sticky or (r & 1) == 1)) r += 1;
    if (r > 2147483647) return if (pa.sign != 0) std.math.minInt(i32) else std.math.maxInt(i32);
    const iv: i32 = @intCast(r);
    return if (pa.sign != 0) -iv else iv;
}

// ---------------- v23.1: f32 <-> f64 conversions ----------------

/// f32 -> f64: EXACT widening (every f32 is an f32 value of an f64).
pub fn f322f64(x: F32) F64 {
    const sign: u64 = @as(u64, x >> 31) << 63;
    const e: u32 = (x >> 23) & 0xFF;
    const m: u32 = x & 0x7FFFFF;
    if (e == 0xFF) {
        // inf / nan: payload shifts 23 -> 52 mantissa alignment
        return sign | 0x7FF0000000000000 | (@as(u64, m) << 29);
    }
    if (e == 0) {
        if (m == 0) return sign; // +-0
        // subnormal f32: value = m * 2^-149 — always a NORMAL f64
        var mm: u64 = @as(u64, m) << 29;
        var ee: i32 = -126;
        while (mm & 0x10000000000000 == 0) {
            mm <<= 1;
            ee -= 1;
        }
        return sign | (@as(u64, @intCast(ee + 1023)) << 52) | (mm & 0xFFFFFFFFFFFFF);
    }
    return sign | (@as(u64, e - 127 + 1023) << 52) | (@as(u64, m) << 29);
}

/// f64 -> f32: round-to-nearest-even, subnormals exact, overflow -> inf,
/// NaN -> canonical quiet NaN.
pub fn f642f32(bits: F64) F32 {
    const px = decomp64(bits);
    const sign: u32 = @as(u32, px.sign) << 31;
    if (px.kind == .nan) return sign | 0x7FC00000;
    if (px.kind == .inf) return sign | 0x7F800000;
    if (px.mant == 0) return sign;
    const man: u64 = px.mant; // 53 bits, implicit bit at 52
    var ee: i32 = px.exp;   // unbiased
    if (ee >= 128) return sign | 0x7F800000; // >= 2^128: overflow -> inf
    // align implicit bit 52 -> bit 23 (24-bit significand)
    var shift: i32 = 29;
    if (ee < -126) {
        // subnormal target: rescale against the 2^-126 grid
        shift += -126 - ee;
        ee = -126;
    }
    if (shift > 53) return sign; // below half of the smallest subnormal
    const sh: u6 = @intCast(shift);
    const dropped = man & ((@as(u64, 1) << sh) - 1);
    const half = @as(u64, 1) << @intCast(sh - 1);
    var q: u64 = man >> sh;
    if (dropped > half or (dropped == half and (q & 1) == 1)) q += 1;
    if (q & 0x1000000 != 0) { // rounded up to 2^24
        q >>= 1;
        ee += 1;
        if (ee >= 128) return sign | 0x7F800000;
    }
    if (ee < -126) return sign | @as(u32, @truncate(q)); // subnormal pack
    return sign | (@as(u32, @intCast(ee + 127)) << 23) | (@as(u32, @truncate(q)) & 0x7FFFFF);
}

// ---------------- v23.1: binary64 native-oracle fuzz ----------------
// The same 100k-random discipline the f32 core has always had — the v23
// stubs never had it, which is exactly why they were silently wrong.

fn randF64Bits(st: *u64) F64 {
    st.* = st.* *% 0x9E3779B97F4A7C15 +% 0x6C696C61;
    const a: u64 = st.*;
    st.* = st.* *% 0xBF58476D1CE4E5B9;
    const b: u64 = st.* >> 17;
    // mix exponent ranges so subnormals/infs/NaNs show up but most values
    // are ordinary
    const kind = (a >> 60) & 7;
    var bits: u64 = b;
    if (kind < 5) {
        bits = (b & 0x807FFFFFFFFFFFFF) | 0x3FF0000000000000; // [1,2) normals
    } else if (kind == 5) {
        bits = b & 0x000FFFFFFFFFFFFF; // subnormals / zero
    } else if (kind == 6) {
        bits = 0x7FF0000000000000 | (b & 0xFFFFFFFFFFFFF); // inf/NaN
    }
    return bits;
}

test "softfloat: f64 add/sub/mul/div/sqrt bit-exact vs native (100k random each)" {
    var st: u64 = 0x243F6A8885A308D3;
    var i: usize = 0;
    while (i < 100_000) : (i += 1) {
        const a = randF64Bits(&st);
        const b = randF64Bits(&st);
        const fa: f64 = @bitCast(a);
        const fb: f64 = @bitCast(b);
        // ADD
        const nadd: u64 = @bitCast(fa + fb);
        const sadd = f64_add(a, b);
        if (toF64Canon(a) or toF64Canon(b)) {
            try testing.expect(f64_is_nan(sadd));
        } else try testing.expectEqual(nadd, sadd);
        // SUB
        const nsub: u64 = @bitCast(fa - fb);
        const ssub = f64_sub(a, b);
        if (toF64Canon(a) or toF64Canon(b)) {
            try testing.expect(f64_is_nan(ssub));
        } else try testing.expectEqual(nsub, ssub);
        // MUL
        const nmul: u64 = @bitCast(fa * fb);
        const smul = f64_mul(a, b);
        if (toF64Canon(a) or toF64Canon(b)) {
            try testing.expect(f64_is_nan(smul));
        } else try testing.expectEqual(nmul, smul);
        // DIV
        const ndiv: u64 = @bitCast(fa / fb);
        const sdiv = f64_div(a, b);
        if (toF64Canon(a) or toF64Canon(b)) {
            try testing.expect(f64_is_nan(sdiv));
        } else try testing.expectEqual(ndiv, sdiv);
        // SQRT
        if ((a >> 63) == 0 and !toF64Canon(a)) {
            const nsq: u64 = @bitCast(@sqrt(fa));
            const ssq = f64_sqrt(a);
            try testing.expectEqual(nsq, ssq);
        }
    }
}

fn toF64Canon(bits: F64) bool {
    return (bits & 0x7FFFFFFFFFFFFFFF) > 0x7FF0000000000000;
}

fn f64_is_nan(bits: F64) bool {
    return toF64Canon(bits);
}
