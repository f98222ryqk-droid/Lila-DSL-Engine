//! probe17 — v17 feature-demo gameplay probe.
//! Loads demo17.libyte, drives a scripted pilot (movement + edge-triggered
//! fire), and prints per-60-frame telemetry. Verifies the whole v17 stack
//! end to end: includes, return values, expression calls, switch AI,
//! numeric for, 2-D arrays, key edges, dist_nearest, m4look + skinv.
//!
//! Typed-field indices verified against `lilac disasm demo17.libyte`:
//!   tf[12] = score (u16)  tf[18/19] = tx/ty  tf[20] = target_d (fixed)
//!
//! Usage: zig run src/probe17.zig -- <path-to-demo17.libyte>

const std = @import("std");
const c = @import("core.zig");
const engine = @import("engine.zig");
const ent = @import("entity.zig");

const TF_SCORE: u32 = 12;
const TF_TX: u32 = 18;
const TF_TY: u32 = 19;
const TF_TD: u32 = 20;
const TF_PX: u32 = 14;
const TF_PY: u32 = 15;

pub fn main(init: std.process.Init) !void {
    const io = init.io;
    const arena: std.mem.Allocator = init.arena.allocator();
    const args = try init.minimal.args.toSlice(arena);
    const path = if (args.len > 1) args[1] else "demo17.libyte";
    var buf: [1 << 20]u8 = undefined;
    var dir = try std.Io.Dir.cwd().openDir(io, ".", .{});
    const blob = dir.readFile(io, path, &buf) catch {
        std.debug.print("cannot read {s}\n", .{path});
        std.process.exit(1);
    };
    const rc = engine.init(blob);
    if (rc != c.ERR_OK) {
        std.debug.print("init failed: {}\n", .{rc});
        std.process.exit(1);
    }

    // input bits: #left,#right,#up,#down,#fire = 0..4
    var frame: u32 = 0;
    while (frame < 600) : (frame += 1) {
        var m: u32 = 0;
        // PILOT: steer toward the current aim target (tx/ty globals), keep
        // firing one-frame pulses aligned with the game's t%6 cooldown
        const gpx = ent.globalLoad(TF_PX);
        const gpy = ent.globalLoad(TF_PY);
        const gtx = ent.globalLoad(TF_TX);
        const gty = ent.globalLoad(TF_TY);
        const dx: i64 = @as(i64, gtx) - gpx;
        const dy: i64 = @as(i64, gty) - gpy;
        if (dx > 12 << 8) m |= 1 << 1; // right
        if (dx < -(12 << 8)) m |= 1 << 0; // left
        if (dy > 12 << 8) m |= 1 << 3; // down
        if (dy < -(12 << 8)) m |= 1 << 2; // up
        if (frame % 12 == 5) m |= 1 << 4; // fire edge
        c.wr32(c.ADDR_INPUT, m);
        engine.frame();
        if (frame % 60 == 59) {
            const n_en = ent.count(1); // Enemy = type index 1
            const n_bu = ent.count(0); // Bullet = type index 0
            const td = ent.globalLoad(TF_TD);
            const aimed = td < 999 << 8;
            std.debug.print("f{d:0>3}: enemies={d} bullets={d} score={d} aim={s} td={d}\n", .{
                frame + 1,
                n_en,
                n_bu,
                ent.globalLoad(TF_SCORE),
                if (aimed) "LOCK" else "----",
                td >> 8,
            });
        }
    }
    std.debug.print("uses_edges={} (the game uses key_pressed)\n", .{c.uses_edges});
}
