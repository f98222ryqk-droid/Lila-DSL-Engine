const std = @import("std");
const c = @import("core.zig");
const engine = @import("engine.zig");
const ent = @import("entity.zig");
test "iso" {
    std.debug.print("rc={d}\n", .{engine.init(@embedFile("iso.libyte"))});
    std.debug.print("g(v) = 0x{X:08} (want 281E140A)\n", .{@as(u32, @bitCast(ent.globalLoad(0)))});
    std.debug.print("h(w after fixed-only spawn) = 0x{X:08} (want 04030201)\n", .{@as(u32, @bitCast(ent.globalLoad(1)))});
}
