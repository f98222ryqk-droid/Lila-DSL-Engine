//! runtime/src/test_v20.zig — v20 POOL runtime feature tests.
//!
//! Loads the committed fixture built from demo/test_v20_fixture.lila
//! (v5 format: PL_PUSH/PL_REM/PL_LEN/PL_LD/PL_ST/PL_FOR_BGN/PL_FOR_ADV +
//! the pool schema trailer) and asserts the observable results BIT-EXACTLY:
//! push with defaults, count-ordered iteration, swap-remove semantics
//! (including the documented skip-the-swapped-row-this-frame rule), the
//! plen/pfull surface, capacity denial, stale-free lifetime math, and the
//! determinism hash chain.
//!
//! Regenerate the fixture with:
//!   ../compiler/target/release/lilac build ../demo/test_v20_fixture.lila \
//!       -o src/test_v20_fixture.libyte

const std = @import("std");
const c = @import("core.zig");
const engine = @import("engine.zig");
const ent = @import("entity.zig");
const tt = @import("timetravel.zig");

// typed-field ids from the fixture's disasm (globals tf[0..4])
const TF_SUM: u32 = 0;
const TF_CNT: u32 = 1;
const TF_PLEN: u32 = 2;
const TF_FULL: u32 = 3;
const TF_SOLO: u32 = 4;

// pools: Trail = 0 (x=0, y=1, life=2, kind=3), Solo = 1 (v=0)
const P_TRAIL: u32 = 0;
const P_SOLO: u32 = 1;
const F_X: u32 = 0;
const F_LIFE: u32 = 2;
const F_KIND: u32 = 3;
const F_V: u32 = 0;

fn loadFixture() ![]const u8 {
    return @embedFile("test_v20_fixture.libyte");
}

fn frame() void {
    engine.frame();
}

test "v20: v5 fixture loads with the pool schema installed" {
    const blob = try loadFixture();
    const rc = engine.init(blob);
    try std.testing.expectEqual(@as(i32, c.ERR_OK), rc);
    try std.testing.expectEqual(@as(u32, 2), c.n_pools);
    // Trail: cap 8, 4 fields; Solo: cap 1, 1 field
    try std.testing.expectEqual(@as(u16, 8), c.pool_cap[P_TRAIL]);
    try std.testing.expectEqual(@as(u8, 4), c.pool_nfields[P_TRAIL]);
    try std.testing.expectEqual(@as(u16, 1), c.pool_cap[P_SOLO]);
    // bases pack in id order from the image tail
    try std.testing.expectEqual(c.ADDR_POOLPLANE, c.pool_base[P_TRAIL]);
    try std.testing.expectEqual(
        c.pool_base[P_TRAIL] + c.poolPlaneBytes(P_TRAIL),
        c.pool_base[P_SOLO],
    );
}

test "v20: push appends rows with defaults for unlisted fields" {
    const blob = try loadFixture();
    _ = engine.init(blob);
    // init pushed 6 Trail rows: x = i*2.0 (raw i*512), life = 20+i
    try std.testing.expectEqual(@as(u32, 6), c.poolCount(P_TRAIL));
    var i: u32 = 0;
    while (i < 6) : (i += 1) {
        const xb = c.poolFieldBase(P_TRAIL, F_X) + i * 4;
        const lb = c.poolFieldBase(P_TRAIL, F_LIFE) + i * 4;
        try std.testing.expectEqual(i * 512, c.rd32(xb));
        try std.testing.expectEqual(20 + i, c.rd32(lb));
    }
    // kind was NOT in any init list -> the u2 default 1 fills every row
    i = 0;
    while (i < 6) : (i += 1) {
        try std.testing.expectEqual(@as(u32, 1),
            c.rd32(c.poolFieldBase(P_TRAIL, F_KIND) + i * 4));
    }
}

test "v20: capacity denial is a counter, never a trap" {
    const blob = try loadFixture();
    _ = engine.init(blob);
    // Solo cap 1: the second push was denied
    try std.testing.expectEqual(@as(u32, 1), c.poolCount(P_SOLO));
    try std.testing.expectEqual(@as(u32, 7), c.rd32(c.poolFieldBase(P_SOLO, F_V)));
    try std.testing.expectEqual(@as(u64, 1), c.pool_denied_total);
}

test "v20: iteration order, field math and aggregation" {
    const blob = try loadFixture();
    _ = engine.init(blob);
    frame(); // frame 1: six rows alive, x = 0..10 (int), sum = 30
    try std.testing.expectEqual(@as(i32, 6), ent.globalLoad(TF_CNT));
    try std.testing.expectEqual(@as(i32, 30), ent.globalLoad(TF_SUM));
    try std.testing.expectEqual(@as(i32, 6), ent.globalLoad(TF_PLEN));
    try std.testing.expectEqual(@as(i32, 0), ent.globalLoad(TF_FULL));
    // Solo stays full across the frame (removal never touches it)
    try std.testing.expectEqual(@as(i32, 1), ent.globalLoad(TF_SOLO));
    var f: u32 = 2;
    while (f < 20) : (f += 1) frame();
    // frame 19: still six rows (row 0 dies exactly at frame 20)
    try std.testing.expectEqual(@as(i32, 6), ent.globalLoad(TF_CNT));
    try std.testing.expectEqual(@as(i32, 30), ent.globalLoad(TF_SUM));
}

test "v20: swap-remove — row data moves, skipped row this frame" {
    const blob = try loadFixture();
    _ = engine.init(blob);
    var f: u32 = 0;
    while (f < 20) : (f += 1) frame();
    // frame 20: row 0's life hits 0 and is removed mid-iteration. The last
    // row (x=10.0) swaps into index 0; the iterator (already past 0)
    // DOCUMENTED-SKIPS it this frame: exactly 5 rows counted, sum 0+2+4+6+8.
    try std.testing.expectEqual(@as(i32, 5), ent.globalLoad(TF_CNT));
    try std.testing.expectEqual(@as(i32, 20), ent.globalLoad(TF_SUM));
    // the swapped-in row at index 0 carries the LAST row's x (10.0 = 2560)
    try std.testing.expectEqual(@as(u32, 2560),
        c.rd32(c.poolFieldBase(P_TRAIL, F_X)));
    // count dropped to 5
    try std.testing.expectEqual(@as(u32, 5), c.poolCount(P_TRAIL));
}

test "v20: pools drain to empty and the hash chain is deterministic" {
    const blob = try loadFixture();
    _ = engine.init(blob);
    var f: u32 = 0;
    while (f < 60) : (f += 1) frame();
    // every Trail row's life expired (max 25 + bounded skip delays)
    try std.testing.expectEqual(@as(i32, 0), ent.globalLoad(TF_PLEN));
    try std.testing.expectEqual(@as(i32, 0), ent.globalLoad(TF_CNT));
    const h1 = tt.stateHash(60);
    // replay: fresh init, same frames -> bit-identical chain
    _ = engine.init(blob);
    f = 0;
    while (f < 60) : (f += 1) frame();
    try std.testing.expectEqual(h1, tt.stateHash(60));
}

test "v20: snapshot/rollback roundtrips pool state (memcpy contract)" {
    const blob = try loadFixture();
    _ = engine.init(blob);
    var f: u32 = 0;
    while (f < 10) : (f += 1) frame();
    const snap = try tt.Snapshot.capture(std.testing.allocator, 10);
    defer std.testing.allocator.free(snap.mem);
    while (f < 40) : (f += 1) frame();
    // pools mutated (rows died) — restore must bring the exact frame-10
    // pool counts, gens and cells back (they are plain c.mem bytes).
    snap.restore();
    try std.testing.expectEqual(@as(u32, 6), c.poolCount(P_TRAIL));
    try std.testing.expectEqual(@as(u32, 512),
        c.rd32(c.poolFieldBase(P_TRAIL, F_X) + 4));
    // the restored engine's frame counter is back at 10 — run 50 more so
    // the hash pairs against a true 60-frame timeline (the c_host lesson:
    // hash pairing must match the ENGINE counter, not the harness loop var)
    var g: u32 = 10;
    while (g < 60) : (g += 1) frame();
    const h_restored = tt.stateHash(60);
    _ = engine.init(blob);
    f = 0;
    while (f < 60) : (f += 1) frame();
    try std.testing.expectEqual(h_restored, tt.stateHash(60));
}

test "v20: v5 files with unknown opcodes are still soft-lands" {
    // A v1 legacy cartridge still loads (the pool plane stays zeroed and
    // hashed identically — byte-neutral by construction).
    const legacy = @embedFile("test_fixture.libyte");
    const rc = engine.init(legacy);
    try std.testing.expectEqual(@as(i32, c.ERR_OK), rc);
    try std.testing.expectEqual(@as(u32, 0), c.n_pools);
    _ = frame();
}
