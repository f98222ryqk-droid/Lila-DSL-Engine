//! runtime/src/test_v23.zig — v23 POINTER-OVERLAY runtime tests.
//!
//! Loads the committed fixture built from src/test_v23_fixture.lila
//! (optimize: true — access-density reordering + zero-hole repack, every
//! lane kind: fixed->f32, f32 raw bits, u8/u3/bool/ang int lanes, an s16
//! signed lane, and a cold field that must stay OUT of the row) and proves
//! the pointer-overlay ABI end to end:
//!
//!   1. the LAYOUT HASH pin — overlay.layoutHash() equals the hash lilac
//!      stamped into LilaInterop.h / LilaInterop.cs (cross-language pin;
//!      a mismatch anywhere in the pipeline fails here)
//!   2. row sizes match the generated struct sizes
//!   3. install rejects bad type / stale hash / short stride
//!   4. the flush mirrors fieldLoad EXACTLY, lane by lane, through the
//!      offsets the EMITTED header asserts (the external contract)
//!   5. dead rows report alive=0 — hosts never render ghosts
//!   6. the hash chain is BIT-IDENTICAL with overlays installed+flushed
//!      every frame vs. a clean run — the overlay never touches engine
//!      memory (the determinism red line, pinned)
//!   7. spawn_from quantizes host floats at the boundary — bit-identical
//!      to the host calling lila_field_write with lila_f_to_q itself
//!   8. cap clamping + written-row diagnostics
//!
//! Regenerate the fixture with:
//!   ../compiler/target/release/lilac build src/test_v23_fixture.lila \
//!       -o src/test_v23_fixture.libyte --emit-bridges src

const std = @import("std");
const c = @import("core.zig");
const engine = @import("engine.zig");
const ent = @import("entity.zig");
const tt = @import("timetravel.zig");
const audio = @import("audio.zig");
const overlay = @import("overlay.zig");

// ---- external contract: these values come from the EMITTED LilaInterop.h
// (regenerate the fixture + bridges together; the hash pins the pair) ----
const T_DRONE: u32 = 0;
const T_SPARK: u32 = 1;
const DRONE_ROW: u32 = 31; // sizeof(LilaDroneRow)
const SPARK_ROW: u32 = 13; // sizeof(LilaSparkRow)
const LAYOUT_HASH: u32 = 0xC7C37E25; // LILA_INTEROP_LAYOUT_HASH

// registry order (fixture declaration + access-density reorder; entities
// first, then globals — see the emitted header for the lane map)
const TF_DX: u32 = 0; // Drone.x   float @ 4
const TF_DY: u32 = 1; // Drone.y   float @ 8
const TF_DVX: u32 = 2; // Drone.vx  float @ 12
const TF_DVY: u32 = 3; // Drone.vy  float @ 16
const TF_DHEAT: u32 = 4; // Drone.heat s16 @ 20
const TF_DHP: u32 = 5; // Drone.hp  u8   @ 22
const TF_DWF: u32 = 6; // Drone.wf  f32  @ 23
const TF_DKIND: u32 = 7; // Drone.kind u3 @ 27
const TF_DARMED: u32 = 8; // Drone.armed bool @ 28
const TF_DSPIN: u32 = 9; // Drone.spin ang  @ 29
const TF_SLIFE: u32 = 11; // Spark.life u8 @ 4
const TF_SX: u32 = 12; // Spark.x   float @ 5
const TF_SY: u32 = 13; // Spark.y   float @ 9

fn loadFixture() ![]const u8 {
    return @embedFile("test_v23_fixture.libyte");
}

fn boot() !void {
    const blob = try loadFixture();
    if (engine.init(blob) != c.ERR_OK) return error.BootFailed;
}

fn runFrames(n: u32) void {
    var sink: [735]i16 = undefined;
    var i: u32 = 0;
    while (i < n) : (i += 1) {
        engine.frame();
        _ = audio.pull(&sink);
    }
}

fn handle(t: u32, idx: u32) u32 {
    return (@as(u32, ent.genOf(t, idx)) << 20) | idx;
}

inline fn readF32(buf: []const u8, off: u32) f32 {
    return @bitCast(std.mem.readInt(u32, buf[off..][0..4], .little));
}
inline fn readU16(buf: []const u8, off: u32) u16 {
    return std.mem.readInt(u16, buf[off..][0..2], .little);
}
inline fn readU8(buf: []const u8, off: u32) u8 {
    return buf[off];
}
inline fn metaOf(buf: []const u8) u32 {
    return std.mem.readInt(u32, buf[0..4], .little);
}
inline fn qToF(q: i32) f32 {
    return @as(f32, @floatFromInt(q)) * 0.00390625;
}
inline fn writeF32(buf: []u8, off: u32, v: f32) void {
    std.mem.writeInt(u32, buf[off..][0..4], @bitCast(v), .little);
}

// ---------------------------------------------------------------------------

test "layout hash pin — the runtime mirrors the compiler" {
    try boot();
    try std.testing.expectEqual(LAYOUT_HASH, overlay.layoutHash());
    try std.testing.expectEqual(@as(i32, DRONE_ROW), overlay.rowBytes(T_DRONE));
    try std.testing.expectEqual(@as(i32, SPARK_ROW), overlay.rowBytes(T_SPARK));
    try std.testing.expectEqual(@as(i32, -1), overlay.rowBytes(9));
}

test "install rejects bad type / stale hash / short stride" {
    try boot();
    var buf: [64 * DRONE_ROW]u8 = undefined;
    try std.testing.expectEqual(@as(i32, -1), overlay.install(7, &buf, DRONE_ROW, 8, LAYOUT_HASH));
    try std.testing.expectEqual(@as(i32, -2), overlay.install(T_DRONE, &buf, DRONE_ROW, 8, 0xDEADBEEF));
    try std.testing.expectEqual(@as(i32, -3), overlay.install(T_DRONE, &buf, 2, 8, LAYOUT_HASH));
    try std.testing.expectEqual(@as(i32, 0), overlay.install(T_DRONE, &buf, DRONE_ROW, 64, LAYOUT_HASH));
}

test "flush mirrors fieldLoad exactly — every lane kind" {
    try boot();
    var dbuf: [64 * DRONE_ROW]u8 = undefined;
    var sbuf: [64 * SPARK_ROW]u8 = undefined;
    try std.testing.expectEqual(@as(i32, 0), overlay.install(T_DRONE, &dbuf, DRONE_ROW, 64, LAYOUT_HASH));
    try std.testing.expectEqual(@as(i32, 0), overlay.install(T_SPARK, &sbuf, SPARK_ROW, 64, LAYOUT_HASH));

    // 5 frames with the flush riding along (what lila_overlay_tick does)
    var sink: [735]i16 = undefined;
    var f: u32 = 0;
    while (f < 5) : (f += 1) {
        engine.frame();
        _ = audio.pull(&sink);
        overlay.flushAll();
    }

    // ---- drone slot 0: spawned x=10.0 y=20.0 vx=0.5 vy=1.5 heat=-300 wf=1.5f
    const d0 = handle(T_DRONE, 0);
    const row = dbuf[0..DRONE_ROW];
    const m = metaOf(row);
    try std.testing.expectEqual(@as(u32, 1), m & 1); // alive
    try std.testing.expectEqual(@as(u32, ent.genOf(T_DRONE, 0)), (m >> 4) & 0xFFF);

    // fixed -> float lanes: EXACT (Q24.8 * 2^-8 never rounds)
    try std.testing.expectEqual(qToF(ent.fieldLoad(TF_DX, d0)), readF32(row, 4));
    try std.testing.expectEqual(qToF(ent.fieldLoad(TF_DY, d0)), readF32(row, 8));
    try std.testing.expectEqual(qToF(ent.fieldLoad(TF_DVX, d0)), readF32(row, 12));
    try std.testing.expectEqual(qToF(ent.fieldLoad(TF_DVY, d0)), readF32(row, 16));
    // signed int lane
    try std.testing.expectEqual(ent.fieldLoad(TF_DHEAT, d0), @as(i32, @as(i16, @bitCast(readU16(row, 20)))));
    // unsigned int lanes
    try std.testing.expectEqual(ent.fieldLoad(TF_DHP, d0), @as(i32, readU8(row, 22)));
    try std.testing.expectEqual(ent.fieldLoad(TF_DKIND, d0), @as(i32, readU8(row, 27)));
    try std.testing.expectEqual(ent.fieldLoad(TF_DARMED, d0), @as(i32, readU8(row, 28)));
    try std.testing.expectEqual(ent.fieldLoad(TF_DSPIN, d0), @as(i32, readU16(row, 29)));
    // f32 lane: the raw IEEE bits, reinterpreted
    try std.testing.expectEqual(ent.fieldLoad(TF_DWF, d0), @as(i32, @bitCast(readF32(row, 23))));
    // sanity: the numbers themselves. x = 10.0 + 5 frames × (update +0.5
    // AND v7 auto-integration +0.5 — the fixture integrates twice on
    // purpose, proving the overlay mirrors whatever the engine computes)
    try std.testing.expectEqual(@as(f32, 15.0), readF32(row, 4));
    try std.testing.expectEqual(@as(f32, 1.5), readF32(row, 16));
    try std.testing.expectEqual(@as(f32, 1.5), readF32(row, 23));
    try std.testing.expectEqual(@as(i32, -300), ent.fieldLoad(TF_DHEAT, d0));

    // ---- drone slot 1: spawn defaults (hp: u8 = 9 etc.)
    const d1 = handle(T_DRONE, 1);
    const row1 = dbuf[DRONE_ROW .. 2 * DRONE_ROW];
    try std.testing.expectEqual(@as(u32, 1), metaOf(row1) & 1);
    try std.testing.expectEqual(@as(i32, 9), ent.fieldLoad(TF_DHP, d1));
    try std.testing.expectEqual(@as(u8, 9), readU8(row1, 22));
    try std.testing.expectEqual(@as(f32, 30.0 + 5 * 0.5), readF32(row1, 4));

    // ---- spark (life 3): after 5 frames it is DEAD -> meta alive=0
    const srow = sbuf[0..SPARK_ROW];
    try std.testing.expectEqual(@as(u32, 0), metaOf(srow) & 1);
    // both drones live, one spark was there and died: written counters
    try std.testing.expectEqual(@as(i32, 2), overlay.written(T_DRONE));
    try std.testing.expectEqual(@as(i32, 0), overlay.written(T_SPARK));
}

test "dead rows report alive=0 — no ghosts" {
    try boot();
    var sbuf: [8 * SPARK_ROW]u8 = undefined;
    try std.testing.expectEqual(@as(i32, 0), overlay.install(T_SPARK, &sbuf, SPARK_ROW, 8, LAYOUT_HASH));

    var sink: [735]i16 = undefined;
    // 3 frames: life 3 -> 2 -> 1 -> 0 (killed on the frame it hits 0).
    // Frames 1-2: still alive; frame 3: dead -> meta alive flips to 0.
    var i: u32 = 0;
    while (i < 3) : (i += 1) {
        engine.frame();
        _ = audio.pull(&sink);
        overlay.flushAll();
        if (i < 2) try std.testing.expectEqual(@as(i32, 1), overlay.written(T_SPARK));
    }
    try std.testing.expectEqual(@as(i32, 0), overlay.written(T_SPARK));
    try std.testing.expectEqual(@as(u32, 0), metaOf(sbuf[0..SPARK_ROW]) & 1);
}

test "the hash chain is untouched by the overlay (determinism red line)" {
    // Run A: overlays installed, flushed every frame.
    try boot();
    var dbuf: [64 * DRONE_ROW]u8 = undefined;
    var sbuf: [64 * SPARK_ROW]u8 = undefined;
    try std.testing.expectEqual(@as(i32, 0), overlay.install(T_DRONE, &dbuf, DRONE_ROW, 64, LAYOUT_HASH));
    try std.testing.expectEqual(@as(i32, 0), overlay.install(T_SPARK, &sbuf, SPARK_ROW, 64, LAYOUT_HASH));

    var sink: [735]i16 = undefined;
    var ha: [32]u64 = undefined;
    var f: u32 = 0;
    while (f < 32) : (f += 1) {
        engine.frame();
        _ = audio.pull(&sink);
        overlay.flushAll();
        ha[f] = tt.stateHash(f);
    }

    // Run B: same frames, fresh boot, NO overlay activity at all.
    try boot();
    var hb: [32]u64 = undefined;
    f = 0;
    while (f < 32) : (f += 1) {
        engine.frame();
        _ = audio.pull(&sink);
        hb[f] = tt.stateHash(f);
    }

    // bit-identical — the flush is read-only on engine memory, and that is
    // a pinned contract, not a hope.
    for (ha, hb) |a, b| try std.testing.expectEqual(a, b);
}

test "spawn_from quantizes at the boundary (lila_field_write-identical)" {
    try boot();
    var rows: [2 * DRONE_ROW]u8 = undefined;
    @memset(&rows, 0);
    // row 0: x=64.0 y=-8.5 vx=0.5 vy=0.25 heat=-1234 hp=77 wf=3.25 kind=5 armed=1 spin=4321
    writeF32(&rows, 4, 64.0);
    writeF32(&rows, 8, -8.5);
    writeF32(&rows, 12, 0.5);
    writeF32(&rows, 16, 0.25);
    std.mem.writeInt(i16, rows[20..][0..2], -1234, .little);
    rows[22] = 77;
    writeF32(&rows, 23, 3.25);
    rows[27] = 5;
    rows[28] = 1;
    std.mem.writeInt(u16, rows[29..][0..2], 4321, .little);

    const n = overlay.spawnFrom(T_DRONE, &rows, 2);
    try std.testing.expectEqual(@as(i32, 2), n);

    // slots 2,3 (0,1 taken by init); spawn stored through fieldStore — the
    // same path lila_field_write takes, so the engine state is identical.
    const h2 = handle(T_DRONE, 2);
    const h3 = handle(T_DRONE, 3);
    try std.testing.expectEqual(@as(i32, 16384), ent.fieldLoad(TF_DX, h2)); // 64.0 * 256
    try std.testing.expectEqual(@as(i32, -2176), ent.fieldLoad(TF_DY, h2)); // -8.5 * 256
    try std.testing.expectEqual(@as(i32, 128), ent.fieldLoad(TF_DVX, h2)); // 0.5 * 256
    try std.testing.expectEqual(@as(i32, 64), ent.fieldLoad(TF_DVY, h2)); // 0.25 * 256
    try std.testing.expectEqual(@as(i32, -1234), ent.fieldLoad(TF_DHEAT, h2));
    try std.testing.expectEqual(@as(i32, 77), ent.fieldLoad(TF_DHP, h2));
    try std.testing.expectEqual(@as(i32, @bitCast(@as(u32, 0x40500000))), ent.fieldLoad(TF_DWF, h2)); // 3.25f bits
    try std.testing.expectEqual(@as(i32, 5), ent.fieldLoad(TF_DKIND, h2));
    try std.testing.expectEqual(@as(i32, 1), ent.fieldLoad(TF_DARMED, h2));
    try std.testing.expectEqual(@as(i32, 4321), ent.fieldLoad(TF_DSPIN, h2));
    // row 1 was all zeros (defaults after applyDefaults, then zero writes)
    try std.testing.expectEqual(@as(i32, 0), ent.fieldLoad(TF_DX, h3));

    // bad type refuses
    try std.testing.expectEqual(@as(i32, -1), overlay.spawnFrom(9, &rows, 1));

    // and the spawned values flow back out through the flush identically
    var dbuf: [64 * DRONE_ROW]u8 = undefined;
    try std.testing.expectEqual(@as(i32, 0), overlay.install(T_DRONE, &dbuf, DRONE_ROW, 64, LAYOUT_HASH));
    overlay.flushAll();
    try std.testing.expectEqual(qToF(ent.fieldLoad(TF_DX, h2)), readF32(dbuf[2 * DRONE_ROW ..], 4));
}

test "cap clamps the mirror surface + retarget0 one-call form" {
    try boot();
    var dbuf: [2 * DRONE_ROW]u8 = undefined; // room for 2 rows only
    try std.testing.expectEqual(@as(i32, 0), overlay.install(T_DRONE, &dbuf, DRONE_ROW, 2, LAYOUT_HASH));
    overlay.flushAll();
    try std.testing.expectEqual(@as(i32, 2), overlay.written(T_DRONE)); // both live drones fit
    try std.testing.expectEqual(@as(u32, 1), metaOf(dbuf[0..DRONE_ROW]) & 1);

    // the one-call pipeline's retarget: fresh buffer, canonical stride
    var big: [64 * DRONE_ROW]u8 = undefined;
    try std.testing.expectEqual(@as(i32, 0), overlay.retarget0(&big, 64));
    var sink: [735]i16 = undefined;
    engine.frame();
    _ = audio.pull(&sink);
    overlay.flushAll();
    try std.testing.expectEqual(@as(i32, 2), overlay.written(T_DRONE));
    // and the sim actually advanced: x moved by vx
    const d0 = handle(T_DRONE, 0);
    try std.testing.expectEqual(qToF(ent.fieldLoad(TF_DX, d0)), readF32(big[0..DRONE_ROW], 4));
}
