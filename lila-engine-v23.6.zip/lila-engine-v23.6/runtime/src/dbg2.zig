const std = @import("std");
const c = @import("core.zig");
const engine = @import("engine.zig");
const ent = @import("entity.zig");
test "dbg2" {
    std.debug.print("rc={d}\n", .{engine.init(@embedFile("test_v231_fixture.libyte"))});
    const names = [_][]const u8{ "Cell.acc", "Cell.tag", "acc", "flag", "ic", "sv", "c1", "r", "e", "gcell", "g64" };
    for (names, 0..) |n, i| {
        const iu: u32 = @intCast(i);
        const bits = c.tfBits(iu) & 0x7F;
        if (bits > 32) {
            std.debug.print("tf{d} {s} = 0x{X:016}\n", .{ i, n, ent.globalLoad64(iu) });
        } else {
            std.debug.print("tf{d} {s} = 0x{X:08} ({d})\n", .{ i, n, @as(u32, @bitCast(ent.globalLoad(iu))), ent.globalLoad(iu) });
        }
    }
}
