//! v20 MOVIE CODEC — a movie is its own checksum, so ship only its entropy.
//!
//! An LIR1 movie spends 12 bytes/frame: a u32 input mask plus a u64 state
//! hash. But the hash chain is RECOMPUTABLE — that is the entire point of
//! a deterministic engine: physics IS the checksum. So the compressed
//! format ("LIZ1") carries only the input masks, entropy-coded with a
//! binary range Asymmetric Numeral System (rANS), and lets replay verify
//! the timeline the only trustworthy way: by re-simulating it.
//!
//! The model is deliberately honest and deliberately tiny: one adaptive
//! binary context per (button, next-frame-button) — 64 contexts, each two
//! Krichevsky-Trofimov-smoothed counters. Buttons are the atoms of arcade
//! time; held directions, fire bursts and idle stretches are exactly the
//! low-entropy structures this model captures with no game-specific
//! knowledge. Measured on dream-found movies it lands within a few
//! percent of the adaptive conditional entropy summed over buttons — the
//! Shannon floor for this model class, printed by the dream report next
//! to the achieved size.
//!
//! Why rANS and not Huffman/arithmetic: rANS is exact, integer-only,
//! table-free, and its state is a single u64 — bit-exact on every
//! platform this engine ships to (native, wasm32). The decoder mirrors
//! the encoder's state machine exactly; no floats anywhere in the codec
//! path. (The entropy TABLE used for reporting is computed at comptime
//! from f64 log2 — display only, never decoded.)
//!
//! rANS contract (ryg-rans mechanics, 64-bit state, proven by roundtrip
//! property tests):
//!   * L = 2^40; x_max(f) = ((L >> 12) << 8) * f — a PER-SYMBOL bound.
//!   * ENCODER (per symbol, processing in reverse canonical order):
//!     renorm BEFORE the step — while x >= x_max(f): emit low byte, x >>= 8;
//!     then x = (x/f)*M + (x%f) + cum. Starts at x = L, flushes x as 8
//!     bytes into the header.
//!   * DECODER (forward): slot = x & (M-1) resolves the symbol; x =
//!     f*(x>>12) + slot - cum; then pull-renorm: if x < L, pull bytes
//!     (x = (x<<8)|byte, walking the emission order backwards) until
//!     x >= L. After the last symbol x must equal L exactly with every
//!     byte consumed — the built-in corruption check.
//!
//! ADAPTIVE MODEL + BACKWARD rANS = TWO PASSES (the classic trap):
//! rANS is LIFO, so the decoder walks the frames FORWARD while adapting
//! on what it has already decoded. The model for a symbol may therefore
//! depend only on the DECODED PREFIX — which the encoder cannot know
//! while walking backward. Fix: pass 1 walks the canonical (decoder)
//! order, adapting and recording the probability each symbol will use;
//! pass 2 encodes in reverse canonical order with those frozen
//! probabilities. Both sides adapt on identical prefixes — exact mirror,
//! zero drift.
//!
//! Layout (little endian):
//!   "LIZ1" | u32 version=1 | u32 n_frames | u64 final_hash
//!   | u64 init_state | u32 n_stream | stream bytes (emission order)
//!
//! final_hash is a convenience for humans (a grep-able timeline id); the
//! real verification is replaying the masks through the engine.

const std = @import("std");

pub const MAGIC = "LIZ1";
pub const VERSION: u32 = 1;

// ---- rANS parameters (ryg-rans shape, 64-bit state) ----
//   M = 2^12 frequency scale; L = 2^40 state lower bound.
//   x_max(f) = (L >> 12 << 8) * f <= 2^36 * 4095 < 2^48; the encode step
//   keeps x < L*256 = 2^48 — ample u64 headroom everywhere.
const SCALE_BITS: u6 = 12;
const M: u64 = 1 << SCALE_BITS;
const L: u64 = 1 << 40;

inline fn xMax(freq: u64) u64 {
    return ((L >> SCALE_BITS) << 8) * freq;
}

pub const Error = error{ BadMagic, BadVersion, Truncated, Corrupt };

/// comptime log2 table: LOG2_Q16[f] = round(log2(4096 / f) * 65536),
/// f in [1..4095]. Used ONLY for the reported ideal-bit count.
const LOG2_Q16: [4096]i64 = blk: {
    @setEvalBranchQuota(10000);
    var t: [4096]i64 = undefined;
    t[0] = 0;
    var f: usize = 1;
    while (f < 4096) : (f += 1) {
        const v = @log2(@as(f64, 4096.0) / @as(f64, @floatFromInt(f)));
        t[f] = @intFromFloat(v * 65536.0 + 0.5);
    }
    break :blk t;
};

/// The adaptive binary model: 64 contexts = 32 buttons x (next bit 0/1).
/// Counters cap out at u32 naturally (movies are millions of frames max).
/// KT smoothing: p1 = (2*n1 + 1) / (2*(n0+n1+1)).
pub const Model = struct {
    n0: [64]u32 = [_]u32{0} ** 64,
    n1: [64]u32 = [_]u32{0} ** 64,

    inline fn f1(self: *const Model, ctx: u32) u64 {
        const i = ctx & 63;
        const num: u64 = @as(u64, self.n1[i]) * 2 + 1;
        const den: u64 = @as(u64, self.n0[i]) + @as(u64, self.n1[i]) + 1;
        const f = (num * 2048) / den; // p1 * M, integer-exact
        if (f < 1) return 1;
        if (f > M - 1) return M - 1;
        return f;
    }

    inline fn update(self: *Model, ctx: u32, bit: u1) void {
        const i = ctx & 63;
        if (bit == 1) self.n1[i] += 1 else self.n0[i] += 1;
    }
};

pub const Encoded = struct {
    /// Complete LIZ1 file image (header + stream).
    data: []u8,
    /// Sum of -log2(p) over all symbols, Q16 — the model's Shannon floor.
    ideal_bits_q16: u64,
    n_frames: u32,
    final_hash: u64,
};

/// Encode masks to a complete LIZ1 image.
///
/// Canonical symbol order (the decoder's processing order): frames
/// forward, buttons 31..0 within each frame, each bit's context = the
/// PREVIOUS frame's bit for the same button (already decoded on the
/// far side). Pass 1 records the adaptive probability each symbol will
/// use; pass 2 rANS-encodes in reverse canonical order.
pub fn encode(alloc: std.mem.Allocator, masks: []const u32, final_hash: u64) !Encoded {
    const n = masks.len;
    var stream: std.ArrayList(u8) = .empty;
    defer stream.deinit(alloc);
    var ideal_q16: u64 = 0;

    // pass 1: canonical order, adapt + record (f1 per symbol, u16)
    const f1s = try alloc.alloc(u16, n * 32);
    defer alloc.free(f1s);
    {
        var mod_ = Model{};
        var f: usize = 0;
        while (f < n) : (f += 1) {
            const prev: u32 = if (f > 0) masks[f - 1] else 0;
            var kk: u32 = 32;
            while (kk > 0) {
                kk -= 1;
                const k: u5 = @intCast(kk);
                const bit: u1 = @truncate(masks[f] >> k & 1);
                const ctx: u32 = @as(u32, k) * 2 + (prev >> k & 1);
                const f1 = mod_.f1(ctx);
                f1s[f * 32 + kk] = @intCast(f1);
                const freq: u64 = if (bit == 1) f1 else M - f1;
                ideal_q16 += @intCast(LOG2_Q16[@intCast(freq)]);
                mod_.update(ctx, bit);
            }
        }
    }

    // pass 2: reverse canonical order (frames backward, buttons forward)
    // — renorm BEFORE each step with the PER-SYMBOL bound, then step.
    var x: u64 = L;
    {
        var f: usize = n;
        while (f > 0) {
            f -= 1;
            var k: u5 = 0;
            while (true) : (k += 1) {
                const bit: u1 = @truncate(masks[f] >> k & 1);
                const f1: u64 = f1s[f * 32 + k];
                const f0 = M - f1;
                // slot layout: bit 1 owns [0, f1), bit 0 owns [f1, M)
                const freq: u64 = if (bit == 1) f1 else f0;
                const cum: u64 = if (bit == 1) 0 else f1;
                const xm = xMax(freq);
                if (x >= xm) {
                    while (x >= xm) {
                        try stream.append(alloc, @truncate(x & 0xFF));
                        x >>= 8;
                    }
                }
                x = (x / freq) * M + (x % freq) + cum;
                if (k == 31) break;
            }
        }
    }

    // flush the final state into the header (decoder initializes from it)
    const total = 32 + stream.items.len;
    const data = try alloc.alloc(u8, total);
    @memcpy(data[0..4], MAGIC);
    std.mem.writeInt(u32, data[4..8], VERSION, .little);
    std.mem.writeInt(u32, data[8..12], @intCast(n), .little);
    std.mem.writeInt(u64, data[12..20], final_hash, .little);
    std.mem.writeInt(u64, data[20..28], x, .little);
    std.mem.writeInt(u32, data[28..32], @intCast(stream.items.len), .little);
    @memcpy(data[32..], stream.items);
    return .{
        .data = data,
        .ideal_bits_q16 = ideal_q16,
        .n_frames = @intCast(n),
        .final_hash = final_hash,
    };
}

pub const Header = struct {
    version: u32,
    n_frames: u32,
    final_hash: u64,
    init_state: u64,
    n_stream: u32,
};

/// Parse + validate the LIZ1 header.
pub fn parseHeader(bytes: []const u8) Error!Header {
    if (bytes.len < 32) return Error.Truncated;
    if (!std.mem.eql(u8, bytes[0..4], MAGIC)) return Error.BadMagic;
    const ver = std.mem.readInt(u32, bytes[4..8], .little);
    if (ver != VERSION) return Error.BadVersion;
    const n = std.mem.readInt(u32, bytes[8..12], .little);
    const fh = std.mem.readInt(u64, bytes[12..20], .little);
    const init = std.mem.readInt(u64, bytes[20..28], .little);
    const ns = std.mem.readInt(u32, bytes[28..32], .little);
    if (bytes.len < 32 + @as(usize, ns)) return Error.Truncated;
    if (init < L) return Error.Corrupt;
    return .{ .version = ver, .n_frames = n, .final_hash = fh, .init_state = init, .n_stream = ns };
}

/// Decode a LIZ1 image back to masks. Fails with Corrupt if the rANS state
/// does not close the loop exactly (x == L with every byte consumed) — the
/// codec's own integrity check, on top of replay verification.
pub fn decode(alloc: std.mem.Allocator, bytes: []const u8) ![]u32 {
    const h = try parseHeader(bytes);
    const n: usize = h.n_frames;
    const masks = try alloc.alloc(u32, n);
    errdefer alloc.free(masks);
    @memset(masks, 0);

    const stream = bytes[32 .. 32 + h.n_stream];
    var pos: usize = stream.len; // walk emission order backwards
    var x: u64 = h.init_state;
    var mod_ = Model{};

    // canonical order: frames forward, buttons 31..0; context = the
    // PREVIOUS frame's bit (already reconstructed). The rANS state hands
    // us symbols in exactly this order because pass 2 encoded the reverse.
    var f: usize = 0;
    var kk: u32 = 32;
    while (f < n) {
        kk -= 1;
        const k: u5 = @intCast(kk);
        const prev: u32 = if (f > 0) masks[f - 1] else 0;
        const ctx: u32 = @as(u32, k) * 2 + (prev >> k & 1);
        const f1 = mod_.f1(ctx);
        const f0 = M - f1;
        const slot: u64 = x & (M - 1);
        const bit: u1 = if (slot < f1) 1 else 0;
        const freq: u64 = if (bit == 1) f1 else f0;
        const cum: u64 = if (bit == 1) 0 else f1;
        x = (x >> SCALE_BITS) * freq + slot - cum;
        mod_.update(ctx, bit);
        if (bit == 1) masks[f] |= @as(u32, 1) << k;
        if (kk == 0) {
            kk = 32;
            f += 1;
        }
        // pull-renorm (the exact inverse of the encoder's pre-step renorm)
        if (x < L) {
            while (x < L) {
                if (pos == 0) return Error.Corrupt;
                pos -= 1;
                x = (x << 8) | stream[pos];
            }
        }
    }
    if (pos != 0 or x != L) return Error.Corrupt; // every byte consumed, loop closed
    return masks;
}

// ---------------- report helpers ----------------

/// Empirical adaptive entropy of a mask stream under the same model the
/// codec uses (Q16 bits) — what the codec should achieve, computed
/// WITHOUT encoding (the dream prints this for any movie). Walks the
/// canonical order, mirroring encode's pass 1 exactly.
pub fn entropyQ16(masks: []const u32) u64 {
    var mod_ = Model{};
    var bits: u64 = 0;
    var f: usize = 0;
    while (f < masks.len) : (f += 1) {
        const prev: u32 = if (f > 0) masks[f - 1] else 0;
        var kk: u32 = 32;
        while (kk > 0) {
            kk -= 1;
            const k: u5 = @intCast(kk);
            const bit: u1 = @truncate(masks[f] >> k & 1);
            const ctx: u32 = @as(u32, k) * 2 + (prev >> k & 1);
            const f1 = mod_.f1(ctx);
            const f0 = M - f1;
            const freq: u64 = if (bit == 1) f1 else f0;
            bits += @intCast(LOG2_Q16[@intCast(freq)]);
            mod_.update(ctx, bit);
        }
    }
    return bits;
}

pub fn q16ToBits(q: u64) f64 {
    return @as(f64, @floatFromInt(q)) / 65536.0;
}

// ---------------- tests ----------------

test "codec: roundtrip zeros / ones / empty / single" {
    const alloc = std.testing.allocator;
    const cases: [4][]const u32 = .{
        &[_]u32{0} ** 500,
        &[_]u32{0} ** 1,
        &[_]u32{},
        &[_]u32{ 0xF0F0F0F0, 1, 1, 2, 0, 0x80000000, 0x80000000, 0xFFFFFFFF },
    };
    for (cases) |masks| {
        const enc = try encode(alloc, masks, 0xABCD);
        defer alloc.free(enc.data);
        const dec = try decode(alloc, enc.data);
        defer alloc.free(dec);
        try std.testing.expectEqualSlices(u32, masks, dec);
    }
}

test "codec: roundtrip random + sparse movies (property)" {
    var prng = std.Random.DefaultPrng.init(0xD2EABEEF);
    const rnd = prng.random();
    const alloc = std.testing.allocator;
    // fully random masks
    {
        const masks = try alloc.alloc(u32, 300);
        defer alloc.free(masks);
        for (masks) |*m| m.* = rnd.int(u32);
        const enc = try encode(alloc, masks, 0x1234);
        defer alloc.free(enc.data);
        const dec = try decode(alloc, enc.data);
        defer alloc.free(dec);
        try std.testing.expectEqualSlices(u32, masks, dec);
    }
    // sparse arcade-shaped: mostly idle, single buttons, held runs
    {
        var masks: [400]u32 = undefined;
        for (&masks) |*m| m.* = 0;
        var i: usize = 0;
        while (i < masks.len) : (i += 1) {
            if (rnd.boolean()) {
                masks[i] = @as(u32, 1) << rnd.uintLessThan(u5, 10);
                if (rnd.boolean() and i + 1 < masks.len) masks[i + 1] = masks[i];
            }
        }
        const enc = try encode(alloc, &masks, 9);
        defer alloc.free(enc.data);
        const dec = try decode(alloc, enc.data);
        defer alloc.free(dec);
        try std.testing.expectEqualSlices(u32, &masks, dec);
    }
}

test "codec: zeros compress hard (idle attract stretches)" {
    const alloc = std.testing.allocator;
    const masks = [_]u32{0} ** 1000;
    const enc = try encode(alloc, &masks, 0);
    defer alloc.free(enc.data);
    // 1000 idle frames must cost far less than the raw 4KB of masks —
    // or the 12KB of LIR1. Budget: generous, asserted hard.
    try std.testing.expect(enc.data.len < 200);
    try std.testing.expect(enc.ideal_bits_q16 < 300 * 65536);
}

test "codec: entropyQ16 matches encode ideal bits" {
    const masks = [_]u32{ 0, 1, 1, 2, 0, 4, 4, 4, 8, 0, 16, 32, 0, 0, 0, 3 };
    const e = entropyQ16(&masks);
    try std.testing.expect(e > 0);
    const alloc = std.testing.allocator;
    const enc = try encode(alloc, &masks, 7);
    defer alloc.free(enc.data);
    try std.testing.expectEqual(e, enc.ideal_bits_q16);
}

test "codec: corruption is caught (truncate / final-state loop)" {
    const alloc = std.testing.allocator;
    var masks: [200]u32 = undefined;
    var prng = std.Random.DefaultPrng.init(99);
    const rnd = prng.random();
    for (&masks) |*m| m.* = if (rnd.boolean()) rnd.int(u32) & 0xFFF else 0;
    const enc = try encode(alloc, &masks, 42);
    defer alloc.free(enc.data);
    // truncation: header claims more stream bytes than present
    {
        const cut = enc.data[0 .. enc.data.len - 1];
        try std.testing.expectError(Error.Truncated, parseHeader(cut));
    }
    // any single flipped byte either errors or changes the movie — it can
    // never silently round-trip to the original (state-loop check or
    // model divergence). Property over every byte position.
    var i: usize = 32;
    var silent: usize = 0;
    while (i < enc.data.len) : (i += 1) {
        const mut = try alloc.dupe(u8, enc.data);
        defer alloc.free(mut);
        mut[i] ^= 0xA5;
        const dec = decode(alloc, mut) catch continue; // caught: good
        defer alloc.free(dec);
        if (std.mem.eql(u32, &masks, dec)) silent += 1;
    }
    try std.testing.expectEqual(@as(usize, 0), silent);
}
