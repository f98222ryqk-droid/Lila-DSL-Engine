//! v20 COVER — execution-coverage instrumentation for the DREAM pass.
//!
//! The v19 known-gaps list said it plainly: "corpus instrumentation
//! (branch-exact PGO) not yet emitting". This module is the fix, built the
//! LILA way: no allocator, no hashing of the hashed, no new contracts.
//!
//! Two parallel records, one per control-flow event:
//!
//!   1. NOVELTY MAP (the search objective): a 64K-slot AFL-style bucket
//!      map. Index = hash(pc, direction-context); buckets saturate at 255.
//!      Hash collisions are FINE here — the map only drives curiosity in
//!      the dream search ("did I see something NEW?"), where an occasional
//!      false-negative merely makes exploration marginally less greedy.
//!      `filled` counts slots that ever went 0 -> nonzero, so the O(1)
//!      novelty gain of a candidate timeline is one subtraction.
//!
//!   2. EXACT SITE COUNTERS (the evidence): taken[]/not_taken[] indexed by
//!      pc directly — no hashing, no collisions. This is what ships to
//!      `lilac dreamtrace` as branch-exact evidence: which JZ sites were
//!      only ever one-sided across everything the dream ever played.
//!
//! Everything is host-side global state OUTSIDE the flat memory image and
//! OUTSIDE the VM State: bumping it cannot change any hash chain, ever.
//! When `on` is false (every normal run), each hook compiles to one
//! well-predicted not-taken branch — measured on the interpreter stress
//! cart before this shipped (see FORGE.md v20).
//!
//! Determinism: the dream forces sequential execution (like --mine), so
//! there is exactly one writer. The counters are order-dependent, but the
//! search evaluates candidates in a fixed seeded order, so the whole
//! record is a pure function of (cartridge, seed) — replayable forever.

const std = @import("std");

/// Site capacity: engine profiles cap instructions at 16384 (huge profile).
pub const MAX_SITES: u32 = 16384;
/// Novelty map slots (64K, power of two, masked).
pub const MAP_SIZE: u32 = 1 << 16;
pub const MAP_MASK: u32 = MAP_SIZE - 1;

/// Master switch. The dream turns this on before its first frame and off
/// after its last; every other build path leaves it false forever.
pub var on: bool = false;

/// AFL-style saturating bucket map + its filled-slot count.
pub var map: [MAP_SIZE]u8 = [_]u8{0} ** MAP_SIZE;
pub var filled: u32 = 0;

/// Exact per-site branch evidence (indexed by instruction pc).
pub var taken: [MAX_SITES]u32 = [_]u32{0} ** MAX_SITES;
pub var not_taken: [MAX_SITES]u32 = [_]u32{0} ** MAX_SITES;

/// Total control-flow events recorded (sanity metric for the report).
pub var events: u64 = 0;

/// First distinct control-flow site hash seen (for the report).
pub var distinct_sites: u32 = 0;
var seen_site: [MAX_SITES]bool = [_]bool{false} ** MAX_SITES;

/// Zero every record. Called by the dream between phases it wants
/// separated, and before a fresh search (defensive: tests rely on it).
pub fn reset() void {
    @memset(&map, 0);
    filled = 0;
    @memset(&taken, 0);
    @memset(&not_taken, 0);
    events = 0;
    distinct_sites = 0;
    @memset(&seen_site, false);
}

/// A conditional edge: `branch(pc, did_it_jump)`. One line inside each
/// control-flow opcode of vm.zig — the direction is part of the identity,
/// so a JZ site that only ever falls through is a DIFFERENT map slot from
/// the same site jumping.
pub inline fn branch(pc: u32, did_take: bool) void {
    if (!on) return;
    bump(pc, if (did_take) 0x9E3779B1 else 0x85EBCA6B);
    if (pc < MAX_SITES) {
        if (did_take) taken[pc] += 1 else not_taken[pc] += 1;
    }
}

/// An unconditional edge with a semantic context: call sites use the
/// callee (fn idx + 1), returns use 0. Collisions between a call edge and
/// a branch edge at the same pc are impossible (different opcodes), and
/// map-slot collisions are acceptable by design (see above).
pub inline fn edge(pc: u32, ctx: u32) void {
    if (!on) return;
    bump(pc, ctx);
    if (pc < MAX_SITES) taken[pc] += 1;
}

inline fn bump(pc: u32, ctx: u32) void {
    events += 1;
    const idx: u32 = ((pc *% 0x9E3779B1) ^ (ctx *% 0xC2B2AE35)) >> 13 & MAP_MASK;
    if (map[idx] == 0) filled += 1;
    if (map[idx] < 255) map[idx] += 1;
    if (pc < MAX_SITES and !seen_site[pc]) {
        seen_site[pc] = true;
        distinct_sites += 1;
    }
}

// ---------------- DRM1: the serialized evidence ----------------
//
// Layout (little endian):
//   "DRM1" | u32 version=1 | u32 n_sites | u64 events
//   | u32 taken[n_sites] | u32 not_taken[n_sites] | u8 map[MAP_SIZE]
//
// The map rides along so a dream run is fully reproducible from its
// artifacts: novelty map + site table + the movie = the entire search
// state that mattered. `lilac dreamtrace` reads the site tables; the map
// is for archive/debug value.

pub const DRM_MAGIC = "DRM1";

/// Serialize the site tables + map into `dst`; returns bytes written.
/// n_sites is the cartridge's real instruction count (caller knows it).
pub fn serialize(dst: []u8, n_sites: u32) usize {
    if (dst.len < drm1Size(n_sites)) return 0;
    var w: usize = 0;
    @memcpy(dst[w..][0..4], DRM_MAGIC);
    w += 4;
    std.mem.writeInt(u32, dst[w..][0..4], 1, .little);
    w += 4;
    std.mem.writeInt(u32, dst[w..][0..4], n_sites, .little);
    w += 4;
    std.mem.writeInt(u64, dst[w..][0..8], events, .little);
    w += 8;
    const n = @min(n_sites, MAX_SITES);
    for (0..n) |i| {
        std.mem.writeInt(u32, dst[w..][0..4], taken[i], .little);
        w += 4;
    }
    for (0..n) |i| {
        std.mem.writeInt(u32, dst[w..][0..4], not_taken[i], .little);
        w += 4;
    }
    @memcpy(dst[w..][0..MAP_SIZE], &map);
    w += MAP_SIZE;
    return w;
}

pub fn drm1Size(n_sites: u32) usize {
    return 20 + @as(usize, @min(n_sites, MAX_SITES)) * 8 + MAP_SIZE;
}

/// Count one-sided / never-executed sites over the first `n_sites` pcs.
/// A "site" is any pc with taken+not_taken > 0. Returns:
///   .sites   — total distinct control-flow sites observed
///   .both    — sites seen taken AND not-taken
///   .one     — sites seen in exactly one direction
///   .never   — 0 here (sites never observed are not in the table; the
///              CALLER cross-references the disassembly for those)
pub const SiteStats = struct { sites: u32, both: u32, one: u32 };
pub fn siteStats(n_sites: u32) SiteStats {
    var s: SiteStats = .{ .sites = 0, .both = 0, .one = 0 };
    const n = @min(n_sites, MAX_SITES);
    for (0..n) |i| {
        const t = taken[i];
        const f = not_taken[i];
        if (t == 0 and f == 0) continue;
        s.sites += 1;
        if (t != 0 and f != 0) s.both += 1 else s.one += 1;
    }
    return s;
}

test "cover: reset zeroes and filled is monotone" {
    reset();
    try std.testing.expectEqual(@as(u32, 0), filled);
    const before = filled;
    on = true;
    branch(5, true);
    branch(5, true);
    branch(5, false);
    on = false;
    // same pc+direction lands the same slot; distinct directions differ
    try std.testing.expect(filled > before);
    // exact: branch(5,true) twice -> taken[5] == 2; branch(5,false) once -> not_taken[5] == 1
    try std.testing.expectEqual(@as(u32, 2), taken[5]);
    try std.testing.expectEqual(@as(u32, 1), not_taken[5]);
    reset();
    try std.testing.expectEqual(@as(u32, 0), taken[5]);
}

test "cover: map saturates and filled stays monotone" {
    reset();
    on = true;
    var i: u32 = 0;
    while (i < 1000) : (i += 1) edge(7, 3);
    on = false;
    try std.testing.expectEqual(@as(u8, 255), map[((7 *% 0x9E3779B1) ^ (3 *% 0xC2B2AE35)) >> 13 & MAP_MASK]);
    try std.testing.expectEqual(@as(u32, 1), filled); // same slot, no double count
    try std.testing.expectEqual(@as(u64, 1000), events);
}

test "cover: serialize roundtrips through parse" {
    reset();
    on = true;
    branch(1, true);
    branch(2, false);
    edge(3, 9);
    on = false;
    var buf: [drm1Size(64)]u8 = undefined;
    const n = serialize(&buf, 64);
    try std.testing.expect(n >= 20 + 64 * 8);
    try std.testing.expect(std.mem.eql(u8, buf[0..4], DRM_MAGIC));
    const sites = std.mem.readInt(u32, buf[8..12], .little);
    try std.testing.expectEqual(@as(u32, 64), sites);
    // taken[1] == 1, not_taken[2] == 1, taken[3] == 1
    try std.testing.expectEqual(@as(u32, 1), std.mem.readInt(u32, buf[20 + 1 * 4 ..][0..4], .little));
    try std.testing.expectEqual(@as(u32, 1), std.mem.readInt(u32, buf[20 + 64 * 4 + 2 * 4 ..][0..4], .little));
}
