//! runtime/src/test_v21.zig — v21 ENGINE FUNDAMENTALS runtime tests.
//!
//! Loads the committed fixture built from src/test_v21_fixture.lila
//! (v5 format: the v21 opcodes PSORT/M_PUT/M_GET/M_DEL/M_LEN/RAY/ASTAR/
//! FRAME/DRAW_NUMZ + the dict schema trailer on flags bit 6) and asserts
//! every observable result BIT-EXACTLY: the Mathf builtin lowerings, dict
//! insert/overwrite/delete with backward-shift probing, the stable radix
//! pool sort, the DDA raycast, the A* planner's deterministic route, the
//! compiled collide pair-scan, every-frame timers, body dynamics with
//! restitution, ASCII level placement — and that the wyhash chain stays
//! stable while all of it runs.
//!
//! Regenerate the fixture with:
//!   ../compiler/target/release/lilac build src/test_v21_fixture.lila \
//!       -o src/test_v21_fixture.libyte

const std = @import("std");
const c = @import("core.zig");
const engine = @import("engine.zig");
const ent = @import("entity.zig");
const tt = @import("timetravel.zig");
const vm21 = @import("vm21.zig");
const audio = @import("audio.zig");

// global typed-field ids (fixture declaration order)
const TF_FLOOR: u32 = 8;
const TF_CEIL: u32 = 9;
const TF_ROUND: u32 = 10;
const TF_SIGN: u32 = 11;
const TF_SMOOTH: u32 = 12;
const TF_MOVETO: u32 = 13;
const TF_REPEAT: u32 = 14;
const TF_PING: u32 = 15;
const TF_DAMP: u32 = 16;
const TF_DANG: u32 = 17;
const TF_LANG: u32 = 18;
const TF_MGET: u32 = 19;
const TF_MLEN: u32 = 20;
const TF_FRAME: u32 = 21;
const TF_SORTED: u32 = 22;
const TF_SCORE: u32 = 23;
const TF_RAY: u32 = 24;
const TF_RAYX: u32 = 25;
const TF_RAYY: u32 = 26;
const TF_ASTAR: u32 = 27;
const TF_AX: u32 = 28;
const TF_AY: u32 = 29;
const TF_TICK: u32 = 30;
const TF_BOUNCE_Y: u32 = 31;
const TF_LEVEL_CELLS: u32 = 32;

fn loadFixture() ![]const u8 {
    return @embedFile("test_v21_fixture.libyte");
}

fn g(tf: u32) i32 {
    return ent.globalLoad(tf);
}

fn runFrames(n: u32) void {
    var sink: [735]i16 = undefined;
    var i: u32 = 0;
    while (i < n) : (i += 1) {
        engine.frame();
        _ = audio.pull(&sink);
    }
}

test "v21: v5 fixture loads with the dict schema installed" {
    const blob = try loadFixture();
    const rc = engine.init(blob);
    try std.testing.expectEqual(@as(i32, c.ERR_OK), rc);
    try std.testing.expectEqual(@as(u32, 1), c.n_dicts);
    try std.testing.expectEqual(@as(u16, 64), c.dict_cap[0]);
    // after init the fixture holds exactly one entry (7 -> 71)
    try std.testing.expectEqual(@as(u32, 1), c.rd32(c.dict_base[0]));
}

test "v21: Mathf builtins lower bit-exactly" {
    try std.testing.expectEqual(@as(i32, c.ERR_OK), engine.init(try loadFixture()));
    // floor(2.75) = 2.0
    try std.testing.expectEqual(@as(i32, 512), g(TF_FLOOR));
    // ceil(2.25) = 3.0
    try std.testing.expectEqual(@as(i32, 768), g(TF_CEIL));
    // round(2.5) = 3.0 (bias + floor; ties resolve up)
    try std.testing.expectEqual(@as(i32, 768), g(TF_ROUND));
    // sign(-4.0) = -1.0
    try std.testing.expectEqual(@as(i32, -256), g(TF_SIGN));
    // smoothstep(0,10,5) = 0.5 (the hermite is exact in Q24.8)
    try std.testing.expectEqual(@as(i32, 128), g(TF_SMOOTH));
    // move_to(0,10,3) = 3.0
    try std.testing.expectEqual(@as(i32, 768), g(TF_MOVETO));
    // repeat(-1,4) = 3.0 (true modulo, negative-safe)
    try std.testing.expectEqual(@as(i32, 768), g(TF_REPEAT));
    // pingpong(5,4) = 3.0
    try std.testing.expectEqual(@as(i32, 768), g(TF_PING));
    // damp(0,100,12/s): k = round(256*(1-e^-0.2)) = 46 -> 100*46/256 = 17.96875
    try std.testing.expectEqual(@as(i32, 4600), g(TF_DAMP));
    // delta_ang(2040, 20) = -2020 (the signed smallest rotation)
    try std.testing.expectEqual(@as(i32, -2020), g(TF_DANG));
    // lerp_ang(4080, 20, 0.5) = 2 (wrap-aware half-step)
    try std.testing.expectEqual(@as(i32, 2), g(TF_LANG));
}

test "v21: dict put/overwrite/delete + backward-shift probing" {
    try std.testing.expectEqual(@as(i32, c.ERR_OK), engine.init(try loadFixture()));
    // mput 7->70, 8->80, 7->71; mdel 8: exactly one entry survives
    try std.testing.expectEqual(@as(i32, 71), g(TF_MGET));
    try std.testing.expectEqual(@as(i32, 1), g(TF_MLEN));
    // the deleted key reads 0 (cell convention)
    // direct engine-side round-trip through the ops
    vm21.mapPut(0, 1234, 4321);
    try std.testing.expectEqual(@as(u32, 4321), vm21.mapGet(0, 1234));
    try std.testing.expectEqual(@as(u32, 0), vm21.mapGet(0, 5555));
    vm21.mapDel(0, 1234);
    try std.testing.expectEqual(@as(u32, 0), vm21.mapGet(0, 1234));
    // probe chains survive deletion (backward shift keeps lookups whole)
    var k: u32 = 0;
    while (k < 40) : (k += 1) vm21.mapPut(0, 1000 + k, k * 3);
    var dels: u32 = 0;
    while (dels < 40) : (dels += 1) {
        if (dels % 2 == 0) vm21.mapDel(0, 1000 + dels);
    }
    k = 0;
    while (k < 40) : (k += 1) {
        const want: u32 = if (k % 2 == 0) 0 else k * 3;
        try std.testing.expectEqual(want, vm21.mapGet(0, 1000 + k));
    }
}

test "v21: frame() reads the page-0 counter" {
    try std.testing.expectEqual(@as(i32, c.ERR_OK), engine.init(try loadFixture()));
    // init runs before the first frame tick: the counter reads 0
    try std.testing.expectEqual(@as(i32, 0), g(TF_FRAME));
    runFrames(1);
    try std.testing.expectEqual(@as(u32, 1), c.rd32(c.ADDR_FRAME));
}

test "v21: psort orders pool rows stably by key" {
    try std.testing.expectEqual(@as(i32, c.ERR_OK), engine.init(try loadFixture()));
    // rows pushed with scores 30, 10, 20 -> sorted first row is x=2.0
    try std.testing.expectEqual(@as(i32, 512), g(TF_SORTED));
}

test "v21: compiled collide pair-scan fires exactly once (handler kills)" {
    try std.testing.expectEqual(@as(i32, c.ERR_OK), engine.init(try loadFixture()));
    try std.testing.expectEqual(@as(i32, 0), g(TF_SCORE));
    runFrames(1);
    try std.testing.expectEqual(@as(i32, 1), g(TF_SCORE));
    runFrames(30);
    try std.testing.expectEqual(@as(i32, 1), g(TF_SCORE)); // bullet is dead
}

test "v21: DDA raycast finds the wall face and stashes the cell" {
    try std.testing.expectEqual(@as(i32, c.ERR_OK), engine.init(try loadFixture()));
    // from (4,4) heading east (ang 1024): wall column 6 -> cell (6,4). The
    // distance is in the engine's own velocity units: sin(90 deg) is
    // 255/256 in the shared ang LUT, so a projectile moving vx = sin(a),
    // vy = -cos(a) reaches the wall after EXACTLY this many frames (2.0078).
    try std.testing.expectEqual(@as(i32, 514), g(TF_RAY));
    try std.testing.expectEqual(@as(i32, 6), g(TF_RAYX));
    try std.testing.expectEqual(@as(i32, 4), g(TF_RAYY));
}

test "v21: A* routes around the wall deterministically" {
    try std.testing.expectEqual(@as(i32, c.ERR_OK), engine.init(try loadFixture()));
    const n = g(TF_ASTAR);
    try std.testing.expect(n > 0); // reachable
    // the path buffer's last pair is the target-adjacent step: the final
    // waypoint IS the target (start is excluded)
    const path_arr: u32 = 1; // second global array (grid=0, path=1)
    const fx = c.rd32(c.garrElem(path_arr, @intCast((n - 1) * 2)));
    const fy = c.rd32(c.garrElem(path_arr, @intCast((n - 1) * 2 + 1)));
    try std.testing.expectEqual(@as(i32, 7), @as(i32, @bitCast(fx)));
    try std.testing.expectEqual(@as(i32, 1), @as(i32, @bitCast(fy)));
    // first waypoint is the diagonal step from the start (1,1)
    try std.testing.expectEqual(@as(i32, 2), g(TF_AX));
    try std.testing.expectEqual(@as(i32, 2), g(TF_AY));
    // the deterministic octile-optimal route around the wall is 12 nodes
    try std.testing.expectEqual(@as(i32, 12), n);
    // no waypoint may sit on a wall (column 6, rows 0..6)
    var i: u32 = 0;
    while (i < n) : (i += 1) {
        const x = c.rd32(c.garrElem(path_arr, i * 2));
        const y = c.rd32(c.garrElem(path_arr, i * 2 + 1));
        const cell = c.rd32(c.garrElem(0, @as(u32, @bitCast(y)) * 8 + @as(u32, @bitCast(x))));
        try std.testing.expectEqual(@as(u32, 0), cell);
    }
    // deterministic: re-plan and get the identical route
    try std.testing.expectEqual(@as(i32, c.ERR_OK), engine.init(try loadFixture()));
    try std.testing.expectEqual(n, g(TF_ASTAR));
}

test "v21: every-timer fires on the frame modulo (no synthesized state)" {
    try std.testing.expectEqual(@as(i32, c.ERR_OK), engine.init(try loadFixture()));
    try std.testing.expectEqual(@as(i32, 0), g(TF_TICK));
    runFrames(100);
    // frame()%32==0 lands on updates 0/32/64/96 -> 4 ticks in 100 frames
    try std.testing.expectEqual(@as(i32, 4), g(TF_TICK));
}

test "v21: body gravity + restitution arc" {
    try std.testing.expectEqual(@as(i32, c.ERR_OK), engine.init(try loadFixture()));
    runFrames(20);
    // semi-implicit Euler, gravity 0.15/frame^2 from rest:
    // y = 32 + 0.15 * (20*21/2) = 63.5 px — squarely mid-fall
    try std.testing.expect(g(TF_BOUNCE_Y) > 50 * 256);
    try std.testing.expect(g(TF_BOUNCE_Y) < 80 * 256);
    runFrames(280);
    // after bounces with restitution 0.5 the ball settles in the lower band
    try std.testing.expect(g(TF_BOUNCE_Y) > 128 * 256);
}

test "v21: ASCII level placed every legended cell" {
    try std.testing.expectEqual(@as(i32, c.ERR_OK), engine.init(try loadFixture()));
    try std.testing.expectEqual(@as(i32, 3), g(TF_LEVEL_CELLS));
    // 3 rocks from the level + 1 collide-test rock = 4 live
    try std.testing.expectEqual(@as(u32, 4), ent.count(2)); // Rock = type 2
}

test "v21: the wyhash chain stays deterministic across the whole stack" {
    try std.testing.expectEqual(@as(i32, c.ERR_OK), engine.init(try loadFixture()));
    var sink: [735]i16 = undefined;
    _ = &sink;
    runFrames(120);
    const h1 = tt.stateHash(119);
    // fresh boot, same input -> identical chain
    try std.testing.expectEqual(@as(i32, c.ERR_OK), engine.init(try loadFixture()));
    runFrames(120);
    try std.testing.expectEqual(h1, tt.stateHash(119));
}
