//! ============================================================================
//! LILA OVERLAY — v23 ZERO-COPY POINTER OVERLAYS (ABI 5)
//! ============================================================================
//!
//!   UNREAL (C++) / UNITY (C#)                    LILA RUNTIME (Zig)
//!   +----------------------------+            +-------------------------+
//!   | Exposes Raw Memory Buffer  | =========> | Wraps Pointer Natively  |
//!   | (TArray / NativeArray)     | [No Copy]  | (Reads Q24.8 SoA rows)  |
//!   +----------------------------+            +-------------------------+
//!                   ^                                         |
//!                   +=========================================+
//!                          Direct In-Place Lane Scatter
//!
//! The host engine allocates the entity arrays ITSELF and hands us the raw
//! pointer; every tick we scatter the live dense rows straight into that
//! memory, lane by lane — no marshalling, no per-field FFI calls, nothing
//! for the C# GC to track and no UObject for Unreal to traverse.
//!
//! THE LAYOUT (mirrored bit-for-bit from compiler/src/forge/interop.rs):
//!   - lane 0: u32 lila_meta = (alive & 1) | (slot generation << 4)
//!   - then every DENSE field of the type, in FINAL registry order (the
//!     access-density order opt::soa computed), lane sizes:
//!       fixed (vt 0) -> f32   (exact: value * 2^-8)
//!       f32   (vt 4) -> f32   (raw IEEE-754 bits)
//!       int   (vt 1/2/3, any bits) -> 1/2/4-byte integer lane
//!   - the array index of a row IS the entity slot index
//!
//! THE STALE-CODE TRIPWIRE: the compiler stamps an FNV-1a layout hash into
//! LilaInterop.h / LilaInterop.cs; `install` recomputes it from the loaded
//! cartridge's typed-field registry and REFUSES the buffer when they
//! disagree (same discipline as lila_tables_install's pack check).
//!
//! DETERMINISM — both red lines hold:
//!   - flush is an EXPORT surface: engine memory is only ever READ here, so
//!     the wyhash chain, snapshots and rollback are bit-identical with or
//!     without overlays installed. (Pinned by test_v23.zig: hash chains of
//!     identical runs with/without a live overlay must be equal.)
//!   - the import path (`spawnFrom`) quantizes host floats through the same
//!     truncating f*256 conversion as lila.h's lila_f_to_q — a spawn is a
//!     hashed, snapshot-safe simulation event like any other. No float ever
//!     lands in a simulation word unquantized.

const std = @import("std");
const c = @import("core.zig");
const ent = @import("entity.zig");

/// total lane records — the registry budget (MAX_TF) is the hard ceiling.
const MAX_LANES: u32 = c.MAX_TF;

const Lane = struct {
    tf: u32, // typed-field registry index (spawnFrom writes back through it)
    off: u32, // byte offset of the lane inside the interop row
    off_bits: u16, // bit offset inside the engine's dense row
    bits: u8, // field width in bits (signed flag STRIPPED)
    signed: bool,
    vt: u8, // wire value-type code: 0 fixed, 1 int, 2 bool, 3 ang, 4 f32
    size: u8, // lane size in bytes: 1, 2 or 4
};

var lanes: [MAX_LANES]Lane = undefined;
var lane_start: [c.MAX_TYPES]u32 = [_]u32{0} ** c.MAX_TYPES;
var lane_count: [c.MAX_TYPES]u32 = [_]u32{0} ** c.MAX_TYPES;
var row_size: [c.MAX_TYPES]u32 = [_]u32{0} ** c.MAX_TYPES;
var n_built_types: u32 = 0;
var lanes_built: bool = false;

var install_ptr: [c.MAX_TYPES]?[*]u8 = [_]?[*]u8{null} ** c.MAX_TYPES;
var install_stride: [c.MAX_TYPES]u32 = [_]u32{0} ** c.MAX_TYPES;
var install_cap: [c.MAX_TYPES]u32 = [_]u32{0} ** c.MAX_TYPES;
var written_rows: [c.MAX_TYPES]u32 = [_]u32{0} ** c.MAX_TYPES;

// ----------------------------------------------------------------------------
// lane table construction — from the LOADED cartridge's tf registry
// ----------------------------------------------------------------------------

fn laneSizeFor(vt: u8, bits: u8) u8 {
    return switch (vt) {
        0, 4 => 4, // fixed -> f32 lane, f32 -> f32 lane
        else => if (bits <= 8) 1 else if (bits <= 16) 2 else 4,
    };
}

/// Walk the tf registry in index order and build the per-type lane tables.
/// Registry order == the compiler's final field order (rebuild_registry
/// pushes ctx.entities[t].fields in sequence; the loader preserves it), so
/// this enumerates EXACTLY the lanes forge/interop.rs emitted.
fn buildLanes() void {
    var li: u32 = 0;
    var t: u32 = 0;
    n_built_types = @min(c.n_entities, c.MAX_TYPES);
    while (t < n_built_types) : (t += 1) {
        lane_start[t] = li;
        var off: u32 = 4; // lane 0 is lila_meta
        var tf: u32 = 0;
        while (tf < c.n_tfs) : (tf += 1) {
            if (c.tfEnt(tf) == t and c.tfCold(tf) == 0) {
                const bits = c.tfBits(tf) & 0x7F;
                const vt = c.tfVt(tf);
                lanes[li] = .{
                    .tf = tf,
                    .off = off,
                    .off_bits = c.tfOff(tf),
                    .bits = bits,
                    .signed = (c.tfBits(tf) & 0x80) != 0,
                    .vt = vt,
                    .size = laneSizeFor(vt, bits),
                };
                li += 1;
                off += lanes[li - 1].size;
                if (li >= MAX_LANES) break; // registry ceiling; install refuses
            }
        }
        lane_count[t] = li - lane_start[t];
        row_size[t] = off;
    }
    lanes_built = true;
}

fn ensureLanes() void {
    if (!lanes_built) buildLanes();
}

// ----------------------------------------------------------------------------
// the FNV-1a layout hash — the stale-code tripwire
// ----------------------------------------------------------------------------

inline fn fnvMix(h: u32, b: u8) u32 {
    return (h ^ @as(u32, b)) *% 0x01000193;
}

/// Mirrors forge/interop.rs `layout_hash` byte-for-byte: the compiler stamps
/// this into both emitted files; a host buffer installed with a different
/// hash is a stale generated pair and is refused.
pub fn layoutHash() u32 {
    ensureLanes();
    var h: u32 = 0x811c9dc5;
    h = fnvMix(h, @intCast(n_built_types));
    var t: u32 = 0;
    while (t < n_built_types) : (t += 1) {
        h = fnvMix(h, @intCast(lane_count[t]));
        h = fnvMix(h, @truncate(row_size[t]));
        h = fnvMix(h, @truncate(row_size[t] >> 8));
        var i = lane_start[t];
        const end = lane_start[t] + lane_count[t];
        while (i < end) : (i += 1) {
            const l = lanes[i];
            h = fnvMix(h, l.vt);
            h = fnvMix(h, l.size);
            h = fnvMix(h, if (l.signed) @as(u8, 1) else @as(u8, 0));
            h = fnvMix(h, l.bits);
            h = fnvMix(h, @truncate(l.off_bits));
            h = fnvMix(h, @truncate(l.off_bits >> 8));
        }
    }
    return h;
}

// ----------------------------------------------------------------------------
// install / retarget
// ----------------------------------------------------------------------------

pub const ERR_BAD_TYPE: i32 = -1;
pub const ERR_LAYOUT_MISMATCH: i32 = -2;
pub const ERR_STRIDE: i32 = -3;
pub const ERR_CAP: i32 = -4;

/// Register a host buffer as entity type t's mirror surface.
///   ptr    — the host's row array (TArray data / NativeArray / malloc)
///   stride — bytes per host row; >= rowBytes(t) so hosts may embed the
///            interop row inside a larger struct of their own
///   cap    — rows allocated; slots >= cap are simply not mirrored
///   hash   — LILA_INTEROP_LAYOUT_HASH from the generated file (drift check)
/// 0 = ok; -1 bad type; -2 layout hash mismatch (REGENERATE the interop
/// files); -3 stride < row size; -4 cap > MAX_ENT.
pub fn install(t: u32, ptr: [*]u8, stride: u32, cap: u32, hash: u32) i32 {
    ensureLanes();
    if (t >= n_built_types) return ERR_BAD_TYPE;
    if (hash != layoutHash()) return ERR_LAYOUT_MISMATCH;
    if (stride < row_size[t]) return ERR_STRIDE;
    if (cap > c.MAX_ENT) return ERR_CAP;
    install_ptr[t] = ptr;
    install_stride[t] = stride;
    install_cap[t] = cap;
    return 0;
}

/// The one-call form's retarget: point type 0 at a fresh buffer, reusing the
/// already-verified layout (stride = the canonical row size).
pub fn retarget0(ptr: [*]u8, cap: u32) i32 {
    ensureLanes();
    if (n_built_types == 0) return ERR_BAD_TYPE;
    return install(0, ptr, row_size[0], cap, layoutHash());
}

pub fn rowBytes(t: u32) i32 {
    ensureLanes();
    if (t >= n_built_types) return -1;
    return @intCast(row_size[t]);
}

pub fn written(t: u32) i32 {
    if (t >= n_built_types) return -1;
    return @bitCast(written_rows[t]);
}

/// Clear installs + lane cache (lila_init / lila_hot_swap call this — a new
/// cartridge means new layouts, and stale host pointers are host business).
pub fn reset() void {
    lanes_built = false;
    n_built_types = 0;
    for (&install_ptr) |*p| p.* = null;
    for (&install_stride) |*s| s.* = 0;
    for (&install_cap) |*s| s.* = 0;
    for (&written_rows) |*s| s.* = 0;
}

// ----------------------------------------------------------------------------
// the flush — dense SoA rows -> host memory, in place
// ----------------------------------------------------------------------------

/// fieldLoad's exact widening (entity.zig semantics, no second
/// implementation of the rules): signed lanes sign-extend from `bits`,
/// everything else zero-extends through the 32-bit truncation.
inline fn widen(raw: u64, bits: u8, signed: bool) i32 {
    if (signed) {
        const sh: u6 = @intCast(64 - @as(u32, bits));
        return @truncate((@as(i64, @bitCast(raw)) << sh) >> sh);
    }
    return @bitCast(@as(u32, @truncate(raw)));
}

inline fn writeLane(row: [*]u8, off: u32, size: u8, v: u64) void {
    switch (size) {
        1 => row[off] = @truncate(v),
        2 => std.mem.writeInt(u16, row[off..][0..2], @truncate(v), .little),
        else => std.mem.writeInt(u32, row[off..][0..4], @truncate(v), .little),
    }
}

inline fn writeMeta(row: [*]u8, alive: bool, gen: u16) void {
    const meta: u32 = (if (alive) @as(u32, 1) else 0) | (@as(u32, gen) << 4);
    std.mem.writeInt(u32, row[0..4], meta, .little);
}

/// Scatter one type's live dense rows into its installed host buffer.
/// READ-ONLY on engine memory: the hash chain is untouched by construction.
fn flushType(t: u32) void {
    const ptr = install_ptr[t] orelse return;
    const stride = install_stride[t];
    const cap = install_cap[t];
    const base = ent.denseBase(t);
    const rb = c.rowBytes(t);
    var n: u32 = 0;
    var from: u32 = 0;

    while (true) {
        const idx = ent.nextLive(t, from);
        if (idx == 0xFFFFFFFF) break;
        from = idx + 1;
        if (idx >= cap) continue;

        const row = ptr + @as(usize, stride) * idx;
        writeMeta(row, true, ent.genOf(t, idx));
        const drow = base + idx * rb;
        var i = lane_start[t];
        const end = lane_start[t] + lane_count[t];
        while (i < end) : (i += 1) {
            const l = lanes[i];
            const raw = ent.extractBits(drow, l.off_bits, l.bits);
            switch (l.vt) {
                0 => { // fixed Q24.8 -> f32: exact, the multiply IS the LUT
                    const q = widen(raw, l.bits, l.signed);
                    const f: f32 = @as(f32, @floatFromInt(q)) * 0.00390625;
                    std.mem.writeInt(u32, row[l.off..][0..4], @bitCast(f), .little);
                },
                4 => { // f32: raw IEEE-754 bits, reinterpreted
                    const bits32: u32 = @truncate(raw);
                    std.mem.writeInt(u32, row[l.off..][0..4], bits32, .little);
                },
                else => { // int / bool / ang lanes
                    writeLane(row, l.off, l.size, raw);
                },
            }
        }
        n += 1;
    }

    // mark dead-but-installed rows so hosts never render ghosts: a slot that
    // was live in the PREVIOUS flush and died this frame keeps its bytes,
    // so clear its meta lane once. (Revives re-write meta above.)
    var idx2: u32 = 0;
    while (idx2 < cap) : (idx2 += 1) {
        if (!ent.isAlive(t, idx2)) {
            const row = ptr + @as(usize, stride) * idx2;
            const meta: u32 = @as(u32, ent.genOf(t, idx2)) << 4; // alive bit = 0
            std.mem.writeInt(u32, row[0..4], meta, .little);
        }
    }

    written_rows[t] = n;
}

/// Flush every installed type. Call AFTER engine.frame() (lila_overlay_tick
/// / lila_tick_pipeline do this); hosts wanting manual timing can call
/// lila_overlay_flush directly.
pub fn flushAll() void {
    var t: u32 = 0;
    while (t < n_built_types) : (t += 1) {
        flushType(t);
    }
}

// ----------------------------------------------------------------------------
// the import — host rows -> spawns (deterministic, quantized at the boundary)
// ----------------------------------------------------------------------------

/// lila.h lila_f_to_q semantics: truncating f*256, saturated at the i32
/// rails (the C helper is UB out of range; saturating keeps it deterministic
/// on every platform).
inline fn fToQ(f: f32) i32 {
    const scaled = std.math.trunc(f * 256.0);
    const cl = std.math.clamp(scaled, -2147483648.0, 2147483520.0);
    return @intFromFloat(cl);
}

inline fn readLane(row: [*]const u8, off: u32, size: u8, signed: bool) i32 {
    switch (size) {
        1 => {
            const b: u8 = row[off];
            return if (signed) @as(i8, @bitCast(b)) else @as(i32, b);
        },
        2 => {
            const v = std.mem.readInt(u16, row[off..][0..2], .little);
            return if (signed) @as(i16, @bitCast(v)) else @as(i32, v);
        },
        else => {
            const v = std.mem.readInt(u32, row[off..][0..4], .little);
            return @bitCast(v);
        },
    }
}

/// Spawn `count` entities of type t from host interop rows (contiguous, the
/// same layout the flush writes). Floats quantize through fToQ at this
/// boundary — the same conversion lila.h documents for host-fed words, so
/// a spawn-from-overlay is bit-identical to the host calling lila_field_write
/// with lila_f_to_q itself. Returns rows spawned (a full pool stops early);
/// -1 = bad type.
pub fn spawnFrom(t: u32, ptr: [*]const u8, count: u32) i32 {
    ensureLanes();
    if (t >= n_built_types) return ERR_BAD_TYPE;
    if (count > c.MAX_ENT) return ERR_CAP;
    const stride = row_size[t];
    var n: i32 = 0;
    var i: u32 = 0;
    while (i < count) : (i += 1) {
        const row = ptr + @as(usize, stride) * i;
        const h = ent.spawn(t);
        if (h == 0xFFFFFFFF) break; // pool full — spawn_denied was counted
        ent.applyDefaults(t, h);
        var li = lane_start[t];
        const end = lane_start[t] + lane_count[t];
        while (li < end) : (li += 1) {
            const l = lanes[li];
            const v: i32 = switch (l.vt) {
                0 => blk: {
                    const bits32 = std.mem.readInt(u32, row[l.off..][0..4], .little);
                    const f: f32 = @bitCast(bits32);
                    break :blk fToQ(f);
                },
                4 => blk: {
                    const bits32 = std.mem.readInt(u32, row[l.off..][0..4], .little);
                    break :blk @bitCast(bits32);
                },
                else => readLane(row, l.off, l.size, l.signed),
            };
            ent.fieldStore(l.tf, h, v);
        }
        n += 1;
    }
    return n;
}

// ----------------------------------------------------------------------------
// tests (self-contained; the cross-language hash pin lives in test_v23.zig)
// ----------------------------------------------------------------------------

const testing = std.testing;

test "fnvMix is the standard FNV-1a-32 (compiler mirror)" {
    // The published test vector: FNV-1a-32("a") == 0xe40c292c.
    // forge/interop.rs hashes with the same constants — this pins the
    // algorithm shape; the cross-language LAYOUT pin lives in test_v23.zig.
    var h: u32 = 0x811c9dc5;
    h = fnvMix(h, 'a');
    try testing.expectEqual(@as(u32, 0xe40c292c), h);
    // offset basis + a second byte ("ab" == 0x4d2505ca)
    h = fnvMix(h, 'b');
    try testing.expectEqual(@as(u32, 0x4d2505ca), h);
}
