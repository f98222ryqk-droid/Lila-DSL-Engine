const std = @import("std");
const c = @import("core.zig");
const engine = @import("engine.zig");
const ent = @import("entity.zig");
test "dbg3" {
    std.debug.print("rc={d}\n", .{engine.init(@embedFile("iso.libyte"))});
    std.debug.print("rowBytes(0)={d} denseBase(0)=0x{X} n_ent={d}\n", .{ c.rowBytes(0), ent.denseBase(0), c.n_entities });
    // dump the dense rows for entity type 0, slots 0-2
    var slot: u32 = 0;
    while (slot < 3) : (slot += 1) {
        const base = ent.denseBase(0) + slot * c.rowBytes(0);
        std.debug.print("row[{d}] @0x{X}: {x:02} {x:02} {x:02} {x:02} {x:02} {x:02} {x:02} {x:02} {x:02} {x:02} {x:02} {x:02}\n", .{
            slot, base, c.mem[base], c.mem[base+1], c.mem[base+2], c.mem[base+3],
            c.mem[base+4], c.mem[base+5], c.mem[base+6], c.mem[base+7],
            c.mem[base+8], c.mem[base+9], c.mem[base+10], c.mem[base+11],
        });
    }
}
