//! runtime/src/test_agg_sig.zig — v20 AGGREGATES + SIGNALS tests.
//!
//! Fixture: 3 Coins (gold 3/4/5). update() computes sum/fmin/fmax; the
//! gold==4 coin kills itself and emits #pickup (handlers ping_a, ping_b
//! increment fired and record fire ORDER — declaration order is the
//! contract).

const std = @import("std");
const c = @import("core.zig");
const engine = @import("engine.zig");
const ent = @import("entity.zig");
const tt = @import("timetravel.zig");

// typed-field ids from the fixture's disasm (globals)
const TF_SUM: u32 = 3;  // globals follow entity fields in the tf registry
const TF_MIN: u32 = 4;
const TF_MAX: u32 = 5;
const TF_FIRED: u32 = 6;
const TF_ORDER: u32 = 7;

fn loadFixture() ![]const u8 {
    return @embedFile("test_agg_sig_fixture.libyte");
}

fn frame() void {
    engine.frame();
}

test "agg: sum/fmin/fmax over live entities (engine-side scan)" {
    const blob = try loadFixture();
    const rc = engine.init(blob);
    try std.testing.expectEqual(@as(i32, c.ERR_OK), rc);
    frame();
    // 3+4+5 = 12; min 3; max 5
    try std.testing.expectEqual(@as(i32, 12), ent.globalLoad(TF_SUM));
    try std.testing.expectEqual(@as(i32, 3), ent.globalLoad(TF_MIN));
    try std.testing.expectEqual(@as(i32, 5), ent.globalLoad(TF_MAX));
}

test "signal: emit fires handlers in declaration order" {
    const blob = try loadFixture();
    _ = engine.init(blob);
    frame();
    // the gold==4 coin killed itself and emitted once: ping_a then ping_b
    try std.testing.expectEqual(@as(i32, 2), ent.globalLoad(TF_FIRED));
    try std.testing.expectEqual(@as(i32, 12), ent.globalLoad(TF_ORDER)); // "1","2" -> 12
}

test "agg: aggregates track the live set after kills" {
    const blob = try loadFixture();
    _ = engine.init(blob);
    frame();
    // frame 2: gold==4 is gone; sum 3+5 = 8, min 3, max 5
    frame();
    try std.testing.expectEqual(@as(i32, 8), ent.globalLoad(TF_SUM));
    try std.testing.expectEqual(@as(i32, 3), ent.globalLoad(TF_MIN));
    try std.testing.expectEqual(@as(i32, 5), ent.globalLoad(TF_MAX));
    try std.testing.expectEqual(@as(i32, 2), ent.globalLoad(TF_FIRED)); // no re-emit
    // deterministic replay
    const h1 = tt.stateHash(2);
    _ = engine.init(blob);
    frame();
    frame();
    try std.testing.expectEqual(h1, tt.stateHash(2));
}
