# FORGE — the whole-game optimizer (v18)

```
      source (.lila)     art (.qoi/.bmp/.ppm/.obj/.wav)     playtests (.lir)
           │                        │                           │
           ▼                        ▼                           ▼
   ┌──────────────────────────  F O R G E  ───────────────────────────┐
   │  ANALYZE   exact facts: unique colors, alpha classes, block       │
   │            self-similarity, usage sizes from the DRAW CALLS,      │
   │            weldable verts, loop candidates, input coverage         │
   │  DECIDE    per-resource decision trees, steered by the platform    │
   │            card (desktop / mobile / cloud_min)                    │
   │  VERIFY    every lossy step round-trips; residual MEASURED and     │
   │            printed; over budget -> automatic demotion              │
   │  EMIT      game.forgepack (binary sections)                        │
   │            game.lilamanifest (JSON decisions lockfile, sha256)     │
   └───────────────────────────────────────────────────────────────────┘
           │                                        │
           ▼                                        ▼
   .libyte (UNCHANGED, byte-identical)     Unity / Unreal importers
   hash chains bit-identical forever       (token interpretation layer)
```

FORGE is `optimizer.rs` grown up. The v17 tree (`opt/`) optimized the
*simulation program* — bit widths, SoA rows, physics rewrites, FSM bit
planes, audio fits, SDF shaders. FORGE keeps every one of those passes
(the cartridge build is untouched, byte-identical, `optimize: true` games
included) and adds the missing half of the world: **assets, usage, corpus,
and the host renderer**. Its job is not "make code faster". Its job is
**make the game cheaper** — measured in sim cycles, VRAM bytes, draw
calls, disk, and load time, with every decision printed, verified, and
pinned.

## The three laws (inherited, not invented)

1. **Measure, never assume.** Every lossy transform round-trips through
   its own decoder and the residual is printed (audio residual %, texture
   max/mean channel delta, mesh position error in world units and pixels
   at usage distance, octahedral normal degrees, ADPCM SNR dB). Over the
   platform card's budget → automatic demotion to the next format. A bad
   fit is a loud build diagnostic, never a silent surprise.
2. **The cartridge never changes.** FORGE emits side-car artifacts only
   (`game.lilamanifest` + `game.forgepack`). `demo17.lila` builds
   bit-identical before and after v18 (sha256 `5424de1f…`), and every
   legacy hash chain replays unchanged. Presentation is the host's
   business; determinism is ours.
3. **The manifest is the lockfile.** Decisions are data — hash-stamped
   (`libyte_sha256`, `forgepack_sha256`, corpus digest), diffable,
   reviewable. Rebuilds are reproducible; a "sealed" build can prove
   which playtests its decisions were made against.

## The whole-game superpower: usage mining

An importer sees a PNG. FORGE sees **"a PNG that this code draws at
scale 2.0 from these three call sites, on a 512×512 screen"** — because
it reads the same AST that draws it (`forge/logic.rs`):

- every `draw(#x, …, scale)` literal → per-sprite scale ceiling
- every particle emitter → travel span (speed × life)
- the declared screen/world dims → the hard ceiling

Textures are then **usage-clamped before any other decision** — a
1024px source drawn at 64px ships as 64px. *The resolution IS the
compression.* No other asset pipeline can do this, because no other
pipeline knows how the asset is used.

## Resource classes

| class | analyzer facts | decisions (in order, first that VERIFIES wins) | emitted |
|---|---|---|---|
| texture (`img.rs`, `texture.rs`) | exact uniques, alpha class, grayscale, 8×8 block self-similarity, gradient score | procedural gradient (4 texels + GPU bilinear) → R8/A8 → palette 1/2/4/8bpp → host-block (bc7/astc) → RGB565 → RGBA32 | packed indices + shared palette banks + SDF bake + normal bake + atlas slots |
| mesh (`mesh.rs`) | weld duplicates, bbox, quant error at usage distance, ACMR | i16 positions + octahedral i8 normals + u16 UVs (12 B/vert) with **px-at-distance budgets** | FGM1: 12B/vert packed, vertex-cache reordered, meshlets (64v/124t, bounds), LOD ladder (cluster merges) |
| audio (`audio.rs`) | loop candidate (envelope autocorrelation), lead/tail silence, DC | synth fit (O(1) voice, residual ≤ card) → IMA ADPCM 4:1 (SNR ≥ card) → raw PCM16 (flagged) | synth params (in-cartridge, zero bytes) or ADPCM bank + loop facts |
| corpus (`corpus.rs`) | input coverage, distinct masks, movie lengths, digest | (planning input for budgets) | corpus digest pinned in the manifest |
| logic (`logic.rs`) | pure-fn table candidates (side-effect scan + narrow int domains), entity mix | **report-only in v18** — table promotion emission is planned (code-gen stays untouched) | candidates list, usage bounds |

The derivations matter as much as the formats: **SDF bake** (alpha →
signed distance: smooth zoom, 2D shadows, outlines), **normal bake**
(sprite shading → tangent-space normals: host dynamic lights on flat
2D art), **palette banks** (runtime `SET_PALETTE` recolors — retro
palettes for free).

## The platform cards

```
desktop   bc7, 2048px, tolerance 8, SDF+normals, 0.5px mesh budget
mobile    astc-6x6, 1024px, tolerance 6, SDF, 0.75px @ 720p
cloud_min raw formats, 1024px, tolerance 4, 0.35px @ 1080p — the 2-core
          reference box class (same machine the bench suite runs on)
```

## The manifest = token interpretation layer

The manifest is not just a decisions log — it is the **rendering
contract** between the cartridge and the host:

```json
"textures": [ { "name": "ship", "sprite_atom": 14, "sprite_index": 0,
                "format": "palette2", "residual_max": 0, "sdf": true } ]
"meshes":   [ { "entity": "Enemy", "verts": 26, "tris": 48, "meshlets": 1 } ]
"fx":       [ { "name": "boom", "sprite_atom": 8, "burst": 420,
                "life_min": 10, "life_max": 34, "grav_q8": 520 } ]
```

- `sprite_atom`/`sprite_index` bind host assets to cartridge tokens —
  zero game-specific host code, any cartridge.
- `render.kind` reinterprets a token: **quad → mesh → fx → light**. The
  engine keeps emitting "token at (x,y) with tint"; the manifest decides
  what that MEANS. The same cartridge can be re-forged (HD art, 3D swaps,
  particle bursts) without touching one simulation byte.
- The **fx rules are the cosmetic layer's contract**: LILA decides WHEN
  and WHERE (deterministic, hash-covered); the host decides HOW IT LOOKS
  (render-rate, host RNG, zero feedback). Replays stay bit-identical;
  the fireworks merely differ between runs, like a real cabinet's phosphor.

## Host consumption

- **Unity** (`hosting/unity/LilaGraphics/`): `LilaManifestImporter.cs`
  (editor) — forgepack → exact-format `Texture2D`/`Mesh` assets, sha256
  verified, emits `LilaTokenTable` (ScriptableObject). `LilaGraphicsBridge.cs`
  (runtime) — stream batches → one instanced draw per token; entity bridge
  → pooled prefabs; fx tokens → particle bursts (cosmetic layer).
- **Unreal** (`hosting/unreal/LilaGraphics/`): same pack format, same
  manifest; `LilaGraphicsComponent` renders path A/B and routes fx to
  Niagara.
- IDE status: complete logic over the test-verified C ABI; studio pass
  pending (the same honest status the Unity/UE glue has had since v17.1).

## The netcode dividend (hosting/net/lilanet.c)

Determinism was always for this. The reference client (two modes,
8 players, 60 simulated seconds, ground-truth referee):

| mode | predicted | rollbacks | mean cost | worst | divergences |
|---|---|---|---|---|---|
| input-delay 4 (broadband) | 100% | 3594 | **1.02 ms** | 3.4 ms | **0** |
| zero-delay stress | 100% | 3583 | **1.02 ms** | 5.6 ms | **0** |

Under a hostile 0–8 frame jitter wire with 8 players — every single frame
predicted, corrections constantly arriving late — the client converges at
~1 ms per rollback, worst 5.6 ms, with **every** corrected frame verified
against the referee's hash chain. Wire cost: 240 B/s/player of input plus
12 B/s of hash gossip. The entire netcode state is a 64-slot delta ring.
(Earlier in this very session the harness itself had three bugs — an
off-by-one restore, per-frame instead of per-prefix verification, and a
premature exit before the final rollback — each caught by exactly this
referee discipline, fixed, and now reported as measured.)

## Corpus PGO — measured by determinism (v18 reads, 19 writes)

Every `runner --record` movie is a bit-exact, infinitely re-verifiable
playtest — not a sample. v18 reads them (input coverage, digests,
durations — pinned in the manifest). The 19 step is instrumentation:
branch-exact coverage from replay, feeding table promotion and
specialization emission. When other engines profile, they interrupt
threads and hope. LILA replays ground truth.

## Command reference

```
lilac forge <game.lila>
    [--assets mapping.lilaforge]   # default: assets.lilaforge next to source
    [--corpus dir-or-file]          # LIR1 movies
    [--card desktop|mobile|cloud_min]
    [-o outdir]                     # default: source's directory
```

Mapping grammar (the side-car that names your art):

```
sprite  #ship   = art/ship.qoi        # path-B texture for the sprite
sprite  #bullet = art/bullet.qoi 16 16 # + explicit usage clamp
texture bg      = art/bg.qoi          # standalone
mesh    Drone   = art/drone.obj       # entity -> 3D via the bridge
sfx     #boom   = art/boom.wav        # synth-vs-ADPCM by card
fx      #boom   = burst=420,life=10-34,grav=520,spread=5.5
```

Inputs: `.qoi`, `.bmp` (24/32), `.ppm` (P6) — anything else is one
`ffmpeg` command away; `.obj` for meshes; `.wav` PCM 16/8-bit.

## Measured on the v18 kit (demo17 + forged assets)

```
texture ship   48x48:   4 uniques -> palette2, residual max 0 (exact)
texture bullet 48x48:   usage-clamped -> 16x16 (never drawn larger)
texture bg     256x128: gradient 1.0000 -> PROCEDURAL: payload 0B,
                       4 corner texels, GPU regenerates any resolution
mesh Enemy:  34 verts -> 26 welded (12B/v), ACMR 0.54, normal err 0.40°
sfx shoot:   decaying 620Hz -> synth program, residual 4.3%,
             19404B of sample RAM never shipped
corpus:      900-frame movie: 4/32 input bits, 16 distinct masks,
             digest pinned in the manifest
logic:       fn hp_color (256 entries), fn cell_free (65536 entries)
             — table-promotion candidates, reported
```

The full pipeline runs in ~31 ms on the 2-core cloud box.

## What v19 owes

1. Table-promotion emission (codegen change, hence its own release — the
   byte-identity guarantee is not given up cheaply). **[v19: DONE — and
   without touching codegen; see the next section]**
2. Branch-exact corpus instrumentation (the movies already carry the
   input timeline it needs). **[v19: DONE for pure fns — argument-domain
   mining through the real VM]**
3. Atlas emission (the packer is tested; wiring into the importer's UV
   remap tables) and host block-compression transcodes (bc7/astc via
   engine-native import settings). **[PGX made flat-art atlases moot; the
   block transcodes remain directives]**
4. Sockets for lilanet (the CPU numbers are in; the wire is a solved
   problem elsewhere).

# v19 — EXECUTION BECOMES DATA

The v19 pass pushes the optimizer at the THEORETICAL MAXIMUM of what a
deterministic game permits: a deterministic game is a pure function of
its inputs, so everything that can be PROVEN immutable becomes data the
runtime looks up instead of work it performs. Four resource classes,
one discipline (analyze -> decide -> VERIFY -> emit), zero cartridge
bytes changed:

## 1. TBL — pure fns become VM-baked tables (code)

* **Purity is PROVEN, not assumed**: an interprocedural fixpoint over the
  AST. A tableable fn may touch params, locals and constants — nothing
  else. No global/entity/array reads (they change; a table baked at boot
  would go stale), no draws/audio/rng (they mutate), no entity iteration
  (the live set is hashed state). The v18 report-only scan allowed
  global reads; v19 does not, because v19's tables REPLACE the fn on
  every frame, not just at build time.
* **Domains come from REAL EXECUTION**: the runner mines actual argument
  values across the replay corpus (`--mine`); without a mine file the
  declared u8/s8 width is the conservative fallback. `shade(u8,u8)` is
  65,536 combinations in theory and `[0..15]x[0..15]` in the corpus —
  the pipeline knows how the game CALLS the fn, not just how it reads.
* **The VALUES are baked by the VM itself** at install: the pack ships
  ~20 bytes of decisions per table (name, fn_idx, domain, spot flag);
  `tables.installPack` runs the REAL fn once per entry and caches. There
  is no second implementation of your logic anywhere.
* **HASH NEUTRAL BY CONSTRUCTION**: the probe performs the same stack
  pops and the same ret_val store the real call's OP_RET_V would; a pure
  fn touches nothing else; the VM's stack/frames/ret_val are threadlocal
  and outside the hashed 2MB. Proof: `--replay movie --tables pack`
  reproduces the recorded hash chain bit-for-bit (300/300 on demo19).
* **Defense in depth**: out-of-domain args take the real call (the table
  is a cache, not a contract); the first 64 hits of small tables are
  spot-verified against a re-run of the real fn and the table is RETIRED
  on any mismatch. The canary caught a real reentrancy bug during v19
  development (runValue's frame guard) — the discipline works.
* **Measured** (bench19, 768 pure calls/frame, ReleaseSafe, 2-core box):
  126.7 -> 77.2 us/frame — **1.64x on the pure-call workload**. Bake
  cost: 57-66 us one-time at install.

## 2. PGX — flat sprites become rect geometry (textures)

A flat-color arcade sprite is not 2,304 texels — it is ~10 rectangles
and a palette. PGX decomposes the exact-palette (<=16 colors, no
quantization) sprite into a greedy maximal-rectangle cover per color;
transparent pixels cost nothing; the round-trip must be pixel-EXACT or
the format demotes to palette/block paths. Chosen only when its byte
count beats the next candidate: the kit's `ship.ppm` (48x48, 4 colors,
diagonal hull) = 57 rect quads / 423B vs 596B of 2bpp palette indices;
`badge.ppm` (64x40, 6 colors, pure rects) = 20 quads / 172B vs 688B —
the texture unit never touches these sprites, the host draws indexed
quads (render.kind = "pgx").

## 3. HRM — sustained tones become partial tables (audio)

The v18 gap: a NON-decaying tone (menu hum, pad, drone) cannot be a
chip voice (attack + linear decay) and correctly fell to ADPCM — 4
bits/sample forever to encode what is mathematically ~24 numbers. HRM
projects the signal onto its harmonic series (exact DFT-at-frequency
inner products — no FFT), refines f0 by phase-slope (0.1 Hz of error
over a second of window destroys the fit: measured 42 dB -> 12 dB;
the refinement recovers all of it), keeps the top-K partials, models
attack + infinite sustain, and verifies by SNR against the original:
`hum.wav` (1.5s, 220 Hz, 4 partials) = **161B partial table at 45.8 dB
SNR vs 33,073B of ADPCM — 205x smaller, infinite sustain**. A decaying
pluck or a melody fits poorly and demotes, exactly like v18.

## 4. STEPS — the shader's march loop becomes a measured constant (shader)

The WGSL tracer is branchless with a FIXED 96-step march — a hand-picked
safety number. But the camera is a pure function of time (`ang = t*0.35`
orbit around the declared eye/look), time is the frame counter, and the
frame counter is corpus-recorded: the exact ray set the shader will ever
march is KNOWN at forge time. The forge CPU-marches it with the same node
formulas the emitter emits, finds each ray's settling step (hit registers,
t passes MAX_DIST, or the march freezes inside geometry — all terminal),
and emits `STEPS = max_settling x 1.15 + 8` (margin for GPU FP variance),
verified by re-marching every sampled ray at the new count and comparing
the hit set and t: demo19's scene = **96 -> 76 steps over 13,000 sampled
rays, 0 diffs** — a straight ~20% cut of the shader's inner loop with a
proof attached, still naga-validated.

## The loop (the whole pipeline, copy-pasteable)

```
lilac build game.lila                       # cartridge (unchanged by forge)
lilac forge game.lila --corpus dir/         # report + game.minelist
runner game.libyte --replay movie.lir \
       --mine game.minelist --mine-out game.mine
lilac forge game.lila --corpus dir/ --mine-file game.mine
runner game.libyte --replay movie.lir --tables game.forgepack
# -> 300/300 hash chain MATCH = the tables changed nothing observable
```

Unity/UE hosts: `lila_tables_install(pack, len)` after init (ABI 3);
`lila_tables_stats(...)` for telemetry.

## Measured on the v19 kit (demo19 "ORBIT CELLS")

```
tables:   hp_color  [3..24]      22 entries (mined; default 256)
          shade     [0..15]x[0..15]  256 entries (mined from 65,536)
          wave_row  [1..300]     300 entries (mined from 65,536)
          bake 65 us; 4,820 hits / 0 misses / 0 mismatches over the corpus
shader:   sdf scene 96 -> 76 steps (13,000 rays, 0 diffs)
audio:    hum 161B @ 45.8 dB (vs 33,073B ADPCM — 205x)
textures: ship 48x48 -> PGX 57 rect quads, 423B (pixel-exact; vs 596B
          2bpp palette)
          badge 64x40 -> PGX 20 rect quads, 172B (vs 688B palette8)
cartridge: 1639B, byte-identical before/after the whole v19 pass
```

## What v20 owes (honesty, as always)

1. The purity fixpoint is name-based on the re-parsed AST (no checker
   context) — sound, but a fn shadowing a builtin name would confuse it.
   Wiring it into the checker's refs would make it airtight.
2. Tables are single-VM-image (the pack pins the libyte sha; hot-swap
   invalidates them — install again after `lila_hot_swap`).
3. STEPS PGO assumes the host feeds `time` as seconds-since-boot at the
   recorded frame rate; a host feeding wall-clock time voids the proof
   (documented in lila.h — determinism boundary rules already cover it).
4. PGX covers opaque rects only; anti-aliased edges stay palette/SDF.
