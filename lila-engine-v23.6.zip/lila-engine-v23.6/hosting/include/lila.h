#ifndef LILA_API
#  if defined(_WIN32)
#    define LILA_API /* declspec not needed for plain consumption */
#  else
#    define LILA_API
#  endif
#endif

/* ============================================================================
 * lila.h — LILA deterministic game console, native host ABI (v1)
 * ============================================================================
 *
 * THE MODEL
 *   LILA is a cartridge console. Your engine (Unity, Unreal, plain C, a
 *   server, a test rig) is the TV set. This header is the cartridge slot.
 *
 *   - The simulation: 100% integer (Q24.8), flat 2MB memory, one fixed
 *     60Hz tick, bit-identical on every platform forever. Rollback netcode,
 *     TAS replay, save-anywhere are memcpy-grade primitives here.
 *   - The presentation: YOUR renderer, YOUR asset pipeline, YOUR audio
 *     mixer. The engine hands you screen-space vertices / entity tables /
 *     i16 PCM; you turn them into GameObjects or UComponents or meshes.
 *
 * THE FRAME CONTRACT (mirror of the native runner)
 *     for (f = 0; ; f++) {
 *         lila_input_set(mask);          // BEFORE the frame
 *         lila_frame();                   // one tick
 *         lila_audio_fill(pcm, 735);      // exactly 44100/60 samples
 *         h = lila_state_hash(f);         // AFTER the f-th frame, pass f
 *     }
 *
 * DETERMINISM BOUNDARY RULES
 *   1. Convert Q24.8 to float ONLY at the render boundary. Never write a
 *      float back into simulation words (round-trip loss forks timelines).
 *   2. The host may write: input (0x00), camera regs (0x54..0x6C), SRAM
 *      (before init). Anything else diverges recorded movies — allowed,
 *      but then it's YOUR timeline, not the movie's.
 *   3. Fixed timestep always. Never scale simulation by wall-clock dt.
 *
 * Engine address map (word units, see docs/SPEC.md):
 *   0x0000 input bitmask        0x0004 frame counter     0x0008 RNG state
 *   0x000C scene domain+1       0x0010 input prev         0x0014 input press
 *   0x0018 input release        0x0050 screen-shake amp   0x0054 camera x (2D)
 *   0x0058 camera y (2D)        0x005C..0x6C camera3 pos+yaw+pitch (Q24.8/ang)
 *   0x0080 bit-packed globals   0x0100 entity metadata    dense/cold rows...
 *
 * Build (from runtime/ — the -lc is REQUIRED, see INTEGRATION.md "The -lc
 * lesson": the VM state is threadlocal and without libc Zig emits its
 * freestanding TLS model, which crashes inside a glibc/UCRT host process):
 *   zig build-lib src/lila_c.zig -dynamic -O ReleaseFast -lc   # .so/.dll
 *   zig build-lib src/lila_c.zig -O ReleaseFast -lc -fPIC      # .a/.lib
 * ==========================================================================*/

#ifndef LILA_H
#define LILA_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// ----------------------------------------------------------------------------
// v19 ABI 3 - EXECUTION-AS-DATA (forged tables)
//
// The forgepack may carry TBL1 sections: pure-fn argument domains proven
// by the forge's interprocedural purity fixpoint. The host already holds
// the pack bytes (it parses them for graphics); hand them to the VM and
// every call inside a baked domain becomes a load instead of a program.
// The VALUES are baked by this very VM at install - there is no second
// implementation of the game's logic anywhere.
//
// Call AFTER lila_init, BEFORE the first lila_frame. Returns the number
// of tables installed; negative = the pack does not match this cartridge
// (stale pack / wrong game) or is malformed - treat it as a load error.
LILA_API int32_t lila_tables_install(const uint8_t* pack, uintptr_t len);

// Table telemetry (outside the hashed memory - diagnostics only):
// hits/misses of the bounds-checked probe, spot-checks (the first hits of
// small tables are re-run against the real fn; any mismatch RETIRES the
// table), and how many tables remain active.
LILA_API void lila_tables_stats(uint64_t* hits, uint64_t* misses,
                                uint64_t* spot_checks, uint64_t* mismatches,
                                uint32_t* active);

/* ============================================================================
 * v20 / ABI 4 — pools, reflection, memory tiers
 * ============================================================================
 * The C#/C++ parity round: dynamic side tables (List<T>), reflection names,
 * and the declared memory tier. Everything rides the same flat-image
 * contract (pools are INSIDE the hashed memory — snapshots and rollback
 * capture them with the standard memcpy).
 */

/* Reflection name for an id. kind: 0=entity(a=type) 1=field(a=tf)
 * 2=fn(a=fi) 3=pool(a=pi) 4=pool field(a=pi,b=field).
 * Copies into out (NUL-terminated, at most cap-1 bytes); returns the full
 * length, or -1 when unknown. Requires the cartridge to ship
 * `game { reflection: true }`. */
LILA_API int32_t lila_name(uint8_t kind, uint32_t a, uint32_t b,
                           char* out, uint32_t cap);

/* Dynamic pools declared by the cartridge (v20). */
LILA_API int32_t lila_pool_count(void);
LILA_API int32_t lila_pool_cap(int32_t pool);   /* declared capacity, -1 */
LILA_API int32_t lila_pool_len(int32_t pool);   /* live rows (flat image), -1 */

/* This engine build's flat-image size, in MB (the memory tier). */
LILA_API int32_t lila_mem_mb(void);

/* ============================================================================
 * v23 / ABI 5 — POINTER OVERLAYS (zero-copy host memory)
 * ============================================================================
 *
 *   UNREAL (C++) / UNITY (C#)                LILA RUNTIME (Zig)
 *   +----------------------------+          +-------------------------+
 *   | Exposes Raw Memory Buffer  | =======> | Wraps Pointer Natively  |
 *   | (TArray / NativeArray)     | [No Copy]| (Reads Q24.8 SoA rows)  |
 *   +----------------------------+          +-------------------------+
 *                 ^                                         |
 *                 +=========================================+
 *                        Direct In-Place Lane Scatter
 *
 * The host allocates the entity arrays ITSELF — TArray<FLilaEnemyRow>,
 * NativeArray<LilaEnemyRow>(Allocator.Persistent), malloc — and hands the
 * raw pointer to LILA. Every tick, the entity bridge scatters the live
 * dense rows straight into that memory, lane by lane: no marshalling, no
 * per-field FFI calls, and nothing the C# GC ever tracks.
 *
 * THE LAYOUTS ARE GENERATED, not hand-written:
 *     lilac build game.lila --emit-bridges [dir]
 * emits LilaInterop.h (pack(1) structs + _Static_asserts + offsetof pins)
 * and LilaInterop.cs ([StructLayout(Pack = 1)] + a Validate() that throws
 * on drift). Row i mirrors entity slot i; lane 0 is always
 *     uint32_t lila_meta  (bit0 = alive, bits 4..15 = slot generation)
 * and the game's dense fields follow in access-density order — x/y/vx/vy
 * first, the same hot register window the SoA repacker computed.
 *
 * DETERMINISM BOUNDARY (both red lines hold):
 *   - the flush READS engine memory and WRITES host memory only: the wyhash
 *     chain, snapshots and rollback are bit-identical with overlays
 *     installed or not (pinned by runtime/src/test_v23.zig).
 *   - the import path (lila_overlay_spawn_from) quantizes host floats
 *     through the SAME truncating f*256 as lila_f_to_q below — a spawn is
 *     a hashed, snapshot-safe simulation event like any other.
 *
 * A dead row keeps its last lane bytes — check lila_meta bit0 before reading
 * lanes. Little-endian hosts only (UE/Unity targets are LE). Cold fields
 * stay behind the lila_field_read pull API: the interop row is the hot
 * register window, and it stays minimal.
 */

/* The loaded cartridge's interop layout hash — compare against
 * LILA_INTEROP_LAYOUT_HASH in the generated LilaInterop.h / .cs. */
LILA_API uint32_t lila_overlay_layout_hash(void);

/* Interop row size in bytes for entity type t (lila_meta included);
 * -1 = bad type. Equals sizeof(LilaXRow) in the generated files. */
LILA_API int32_t lila_overlay_row_bytes(uint32_t type);

/* Register a host buffer as type t's mirror surface.
 *   ptr     the host's row array (TArray data / NativeArray / malloc)
 *   stride  bytes per row; >= row_bytes (embed the row in a bigger host
 *           struct of your own if you like)
 *   cap     rows allocated; slots >= cap are simply not mirrored
 *   hash    LILA_INTEROP_LAYOUT_HASH from the generated file
 * Returns 0 ok; -1 bad type; -2 layout hash mismatch (REGENERATE the
 * interop files — a schema changed under you); -3 stride < row size;
 * -4 cap > MAX_ENT. */
LILA_API int32_t lila_overlay_install(uint32_t type, uint8_t *ptr,
                                       uint32_t stride, uint32_t cap,
                                       uint32_t layout_hash);

/* Flush every installed overlay NOW (after the last lila_frame of the
 * tick). Read-only on engine memory. */
LILA_API void lila_overlay_flush(void);

/* One tick + flush: lila_input_set BEFORE this, as with lila_frame. */
LILA_API void lila_overlay_tick(void);

/* The one-call pointer-overlay pipeline (single-entity-type games):
 * point type 0 at host_ptr (entity_count rows, canonical stride) and run
 * one full frame with the flush built in. Multi-type games: install per
 * type, then lila_overlay_tick / lila_overlay_flush. */
LILA_API void lila_tick_pipeline(uint8_t *host_ptr, uint32_t entity_count);

/* Rows written by the last flush (diagnostics). -1 = bad type. */
LILA_API int32_t lila_overlay_written(uint32_t type);

/* Spawn entities of type t from host interop rows (the import path —
 * boot/level loads): floats quantize through the lila_f_to_q truncation at
 * this boundary, so the result is bit-identical to the host calling
 * lila_field_write with lila_f_to_q itself. Returns rows spawned;
 * -1 = bad type. */
LILA_API int32_t lila_overlay_spawn_from(uint32_t type, const uint8_t *ptr,
                                          uint32_t count);

/* ---------------- identity ---------------- */

int32_t  lila_abi_version(void);   /* this header's ABI: 5 (v23) */
int32_t  lila_engine_version(void);/* engine release: 23 */

/* ---------------- lifecycle ---------------- */

/* Load a .libyte (v1..v4) and run init() fns. 0 = ok, else loader error
 * (see lila_last_error / docs/SPEC.md error codes). */
int32_t  lila_init(const uint8_t *blob, uintptr_t len);

/* Live reload preserving entity+globals state when the schema matches.
 * Returns 1 if state was preserved, 0 if full re-init. */
int32_t  lila_hot_swap(const uint8_t *blob, uintptr_t len);

/* ---------------- the frame ---------------- */

void     lila_frame(void);        /* one 60Hz simulation tick */
uint32_t lila_tick(void);         /* frame counter (word at 0x04) */

/* ---------------- input ---------------- */

/* Bitmask BEFORE lila_frame(). Bit i = key i as the game's key() queries
 * define (demo: 0=left 1=right 2=up 3=fire). Edge regs are automatic. */
void     lila_input_set(uint32_t mask);
uint32_t lila_input_get(void);

/* ---------------- determinism primitives ---------------- */

/* Wyhash over (frame, 2MB flat memory, scalars) — pure integer math.
 * Call AFTER stepping the f-th frame, passing the same 0-based f. */
uint64_t lila_state_hash(uint32_t frame);

/* LSA1 save states: the whole engine is one flat image, so saving IS a
 * memcpy. Sizes: 44 + lila_mem_size(). */
uintptr_t lila_snapshot_size(void);
int32_t   lila_snapshot_save(uint8_t *dst, uintptr_t len);      /* 0 = ok */
int32_t   lila_snapshot_load(const uint8_t *src, uintptr_t len); /* frame, -1 = reject */

/* ---------------- memory bridge ---------------- */

uint8_t *lila_mem_ptr(void);      /* flat engine memory (read by convention) */
uintptr_t lila_mem_size(void);
int32_t   lila_read32(uint32_t engine_addr);
void     lila_write32(uint32_t engine_addr, int32_t v); /* host-fed words only */

/* Q24.8 helpers (render boundary only — see boundary rule 1) */
static inline float    lila_q_to_f(int32_t q) { return (float)q / 256.0f; }
static inline int32_t  lila_f_to_q(float f)   { return (int32_t)(f * 256.0f); }

/* ---------------- render stream: path A (render the game's draws) -------- */

/* The game's own draw orders from this frame: lila_stream_count() verts of
 * 14 bytes each (int16 x, int16 y, uint16 uv, uint32 rgba, uint16 token),
 * screen-space pixels, already wrapped/projected by the engine. Turn them
 * into quads (Unity), dynamic meshes (Unreal), or a canvas like the wasm
 * host does. */
const uint8_t *lila_stream_ptr(void);
int32_t  lila_stream_count(void);

/* ---------- v17.2: batched feed (instancing-friendly path A+) ------------ */

/* The same verts, counting-sorted by token: one batch per distinct token,
 * batches in FIRST-APPEARANCE order (painter's algorithm preserved across
 * batches), verts stable within a batch (preserved for additive blending).
 * Render batches in order -> pixel-identical to the raw stream, but with
 * one instanced draw per sprite instead of per-vert host work.
 * *out_count == 0 -> no batches this frame; use the raw stream. */
typedef struct LilaBatch_ {
    uint16_t token;   /* domain token (sprite/text/... index)   */
    uint16_t _pad;
    uint32_t first;   /* first vert in the SORTED stream        */
    uint32_t count;   /* verts in this batch                    */
} LilaBatch;

const LilaBatch *lila_stream_batches(int32_t *out_count);
const uint8_t   *lila_stream_sorted_ptr(void); /* 14B verts, grouped    */

/* ---------- v17.2: delta snapshots (rollback memory + netcode wire) ------ */

/* LDL1: a full LSA1 snapshot minus the unchanged words (regions of
 * differing u32s + the three host scalars). Pairs with the BASE full
 * snapshot it was saved against:
 *     lila_snapshot_save(base, sz);            // once
 *     ... frames ... ;
 *     n = lila_delta_save(base, sz, dst, max);// per frame, tiny
 *     ... later ...
 *     lila_delta_load(base, sz, dst, n);       // == snapshot_load at that
 *                                              //   frame, verified by hash
 * Invariant: hash(delta_load(base,d)) == recorded chain hash. The host
 * owns the base<->delta pairing. Typical cost: 1-4KB/frame vs 2MB. */
uintptr_t lila_delta_max(void);
uintptr_t lila_delta_save(const uint8_t *base, uintptr_t base_len,
                          uint8_t *dst, uintptr_t dst_len); /* 0 = no room */
int32_t   lila_delta_load(const uint8_t *base, uintptr_t base_len,
                          const uint8_t *delta, uintptr_t delta_len);

/* ---------- v17.2: built-in history ring (instant rewind) ---------------- */

/* Opt-in recorder: when started, EVERY lila_frame() is delta-captured
 * into a 512-slot ring (keyframe every 64 frames). seek() restores any
 * buffered frame and truncates the future (GGPO semantics); recording
 * resumes from there. An external lila_snapshot_load is detected (frame
 * counter jump) and the ring restarts — a host can mix its own rollback
 * with the ring safely. Deterministic: capture is read-only. */
int32_t  lila_history_start(uint32_t frames); /* slots, <= 512; -1 if 0 */
void     lila_history_stop(void);
int32_t  lila_history_begin(void);  /* oldest buffered frame, -1 = empty */
int32_t  lila_history_frames(void); /* buffered count                  */
int32_t  lila_history_seek(uint32_t frame);    /* frame, -1 = not buffered */

/* ---------- v17.2: sprite manifest (path B asset discovery) -------------- */

/* The sprite table the loader placed in flat memory, in the SAME 14B
 * vert layout as the render stream (i16 x, i16 y, u16 uv, u32 rgba,
 * u16 token; coordinates sprite-local). Rasterize each sprite once at
 * boot into a Texture2D (or build a mesh) and you can render ANY
 * cartridge's path-B entities with zero game-specific host code. */
int32_t        lila_sprite_count(void);
int32_t        lila_sprite_vert_count(uint32_t i); /* -1 = OOB */
const uint8_t *lila_sprite_verts(uint32_t i);      /* NULL = OOB */

/* ---------------- audio ---------------- */

/* Pull i16 mono PCM. Call ONCE per frame with 735 samples AFTER
 * lila_frame() (audio phase lives in the hashed memory — skipping it
 * forks the hash chain). Returns samples written. */
uintptr_t lila_audio_fill(int16_t *dst, uintptr_t samples);

/* ---------------- entity bridge: path B (read tables) ------------------- */

/* Walk the typed-field registry (SPEC.md "typed-field registry") to find
 * fields by schema, then per type: iterate live slots, read fields, drive
 * transforms. This is the data source when you render with YOUR sprites. */
int32_t  lila_entity_types(void);
int32_t  lila_entity_count(uint32_t type);
int32_t  lila_live_ents(void);

int32_t  lila_tf_count(void);
int32_t  lila_tf_ent(uint32_t tf);   /* 0xFF = global, else entity type */
int32_t  lila_tf_off(uint32_t tf);   /* byte offset in the 32B dense row */
int32_t  lila_tf_bits(uint32_t tf);  /* field width in bits */
int32_t  lila_tf_vt(uint32_t tf);   /* value type (0 = fixed Q24.8) */
int32_t  lila_tf_cold(uint32_t tf);  /* 1 = cold row (8B stride) */

int32_t  lila_next_live(uint32_t type, uint32_t from_idx); /* idx or -1 */
int32_t  lila_gen(uint32_t type, uint32_t idx);             /* slot generation */
uint32_t lila_make_handle(uint32_t gen, uint32_t idx);      /* (gen<<20)|idx */

int32_t  lila_field_read(uint32_t tf, uint32_t handle);
void     lila_field_write(uint32_t tf, uint32_t handle, int32_t v); /* next frame visible */
int32_t  lila_global_read(uint32_t tf);
void     lila_global_write(uint32_t tf, int32_t v);

/* ---------------- SRAM persistence ---------------- */

uint8_t *lila_sram_ptr(void);      /* 256B battery block; copy BEFORE init */
uintptr_t lila_sram_size(void);
int32_t  lila_sram_dirty(void);    /* 1 once per change (poll + persist) */

/* ---------------- build profile + diagnostics ---------------- */

int32_t  lila_cap_types(void);
int32_t  lila_cap_ent(void);
int32_t  lila_cap_verts(void);
int32_t  lila_cap_instr(void);
int32_t  lila_screen_w(void);      /* declared viewport */
int32_t  lila_screen_h(void);
int32_t  lila_world_w(void);       /* simulation bounds */
int32_t  lila_world_h(void);
int32_t  lila_last_error(void);    /* loader rc of the last load attempt */
int32_t  lila_stream_dropped(void);/* cumulative budget drops */
int32_t  lila_spawn_denied(void);  /* cumulative pool-full denials */

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* LILA_H */
