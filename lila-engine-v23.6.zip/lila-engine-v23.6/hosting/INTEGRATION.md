# Embedding LILA in a real engine — the Host SDK

> **The question this answers:** "Is there an easier way to get
> Unity/Unreal-level engine capabilities while keeping LILA's performance
> and determinism — by technically using them?"
>
> **Yes.** It's not even a hack — it's the industry-standard architecture
> for deterministic games. LILA stays the simulation brain; Unity/Unreal
> becomes the presentation body; the C ABI below is the spinal cord.

```
            ┌──────────────────────────── your engine (Unity / Unreal / C) ────┐
            │  renderer (URP/HDRP/Nanite)   asset pipeline   audio mixer      │
            │  input devices   platform ports   editor/tooling   storefronts   │
            │                                                                    │
            │   input bits ──────────┐            ┌── stream verts (path A)   │
            │   camera regs (opt) ───┤            ├── entity tables (path B)  │
            │                        ▼            ├── PCM audio               │
            │                ┌──────────────┐     └── state hash              │
            │                │  liblila_c   │   Q24.8 ints out — floats      │
            │                │  (this ABI)  │   converted at this boundary,   │
            │                └──────────────┘   never written back            │
            └────────────────────────────────────────────────────────────────┘
```

## 1. Why this is the right shape (honest version)

**What Unity/Unreal are actually great at:** rendering, asset pipelines,
platform ports, audio mixing, tooling, marketplace. Thousands of engineer-years
you cannot rebuild — and don't need to, because none of it has to be
deterministic.

**What they are bad at:** determinism. Float physics varies across CPUs and
compiler versions; garbage collection and unordered parallel iteration make
"same input → same state" a per-project audit nightmare. Every serious
lockstep RTS or rollback fighting game *inside* those engines ends up
quarantining its simulation away from the engine's own sim — exactly the
wall LILA's design already is.

**What LILA is great at:** the quarantined simulation. Integer-only Q24.8,
flat 2MB memory, one fixed 60Hz tick, hash chains, `memcpy` snapshots.
Replay verification, rollback netcode, and save-anywhere are load-bearing
primitives, not aspirations.

**What LILA is bad at (still true):** content pipelines, renderers,
platform breadth. That's the half you're borrowing.

So the honest framing: this is not "cheating your way to Unreal" — it's
**buying Unreal's strengths while keeping the one thing Unreal can't sell
you.** The pattern is how Factorio, GGPO-era fighting games, and lockstep
RTS games already work; the SDK here just makes it a 30-line embedding.

## 2. The frame contract

The whole integration is one loop, identical to what the native runner does
(this exact order is what `verify.sh` proves bit-identical):

```c
lila_init(blob, len);                    // once: boot the cartridge

for (uint32_t f = 0; ; f++) {
    lila_input_set(mask);                // BEFORE the frame
    lila_frame();                        // one 60Hz simulation tick
    lila_audio_fill(pcm, 735);           // exactly 44100/60 samples
    uint64_t h = lila_state_hash(f);     // AFTER the f-th frame, pass f
}
```

Determinism boundary rules (breaking these forks you off recorded
timelines — deterministic, but *your* timeline, not the movie's):

1. **Q24.8 → float is one-way.** Convert when placing transforms/sprites
   (`lila_q_to_f`). Never convert back into simulation words.
2. **Host-writable words:** input (`0x00`), camera registers
   (`0x54..0x6C`), SRAM (before init, battery-style). Nothing else.
3. **Fixed timestep forever.** Use an accumulator (max ~5 catch-up steps);
   a GC hitch or streaming stall becomes slow-motion, never divergence.
   Host frame rate is irrelevant to the simulation.

## 3. Presentation — two paths

**Path A — render the game's own draws.** After each `lila_frame()`,
`lila_stream_ptr()` holds `lila_stream_count()` records of 14 bytes:
`int16 x, int16 y, uint16 uv, uint32 rgba, uint16 token` — screen-space
pixels, already wrapped/projected by the engine. Feed them into a dynamic
mesh (UE) or a quad batch (Unity). Zero game-specific schema knowledge
needed; you literally draw what the game drew.

**Path B — your assets, LILA's state.** Walk the typed-field registry once
(`lila_tf_count/ent/off/bits/vt/cold` — see SPEC.md), then per frame:
`lila_next_live` + `lila_make_handle` + `lila_field_read` for position/
anim fields, and drive *your* prefabs/components. This is how you get LILA
gameplay with AAA art. Handles are stable across respawns
(`gen<<20 | idx`) — use them as instance keys.

Both paths can coexist (A for background/HUD, B for characters).

## 4. The deterministic party tricks (all through this ABI)

- **Save anywhere, instantly:** `lila_snapshot_save` is one 2MB `memcpy`
  (44-byte header + flat memory). F5/F9 in the Unity/Unreal skeletons.
- **Rollback netcode (GGPO recipe):** keep a ring of snapshots
  (`save` every frame or every N frames — 2MB × 8 = 16MB for an
  8-frame window) plus an input ring per player. On a late input at
  frame F: `snapshot_load(ring[F])`, apply the corrected input,
  re-simulate F..now with `lila_frame()` (cheap — the VM steps arcade
  entity counts in microseconds), re-present. The hash chain proves the
  resim matched the original where inputs agreed.
- **TAS / automated QA:** record inputs + hashes with the native runner
  (`--record movie.lir`), replay them inside your engine build, compare
  `lila_state_hash(f)` per frame. `verify.sh` does exactly this against
  the same ABI your engine calls — that's the guarantee.
- **SRAM persistence:** copy saved bytes into `lila_sram_ptr()` BEFORE
  `lila_init` (the zeroing pass skips that range); poll
  `lila_sram_dirty()` and persist on change.

## 5. The `-lc` lesson (read before rebuilding the library)

The library must be built with **`-lc`**:

```
zig build-lib src/lila_c.zig -dynamic -O ReleaseFast -lc      # .so/.dll
zig build-lib src/lila_c.zig -O ReleaseFast -lc -fPIC          # .a/.lib
```

The VM's interpreter state is `threadlocal` (that's what makes the v10
parallel systems safe). Without libc, Zig emits its freestanding TLS
model, which **segfaults inside a glibc/UCRT host process** — the native
runner gets away with it only because `zig build-exe` owns the whole
process. With `-lc` the lib uses proper ELF TLS + `pthread_create`,
i.e. exactly what a Unity P/Invoke or Unreal module link expects. This
was found the hard way during this SDK's verification; it is now part of
the build lines everywhere and of `verify.sh`.

Cross-compiling for Windows (for Unity users) is one line and needs no
Windows SDK:
```
zig build-lib src/lila_c.zig -dynamic -O ReleaseFast -lc -target x86_64-windows-gnu
```

## 6. What is verified vs. what is a template

| Piece | Status |
|-------|--------|
| `lila_c.zig` ABI over the engine core | **verified** — built + run in CI (`verify.sh`) |
| C host: 300/300 hash-chain replay of a runner movie | **verified** — bit-identical to the native timeline |
| C host: snapshot rollback roundtrip (save @101, re-run 199) | **verified** |
| C host: WAV byte-identical to runner's `game.wav` | **verified** |
| Entity bridge reads (registry walk, handles, globals) | **verified** (telemetry in c_host output) |
| `LilaBridge.cs` (Unity P/Invoke bindings) | mirror of the verified header; Unity-side marshalling is standard |
| `LilaClient.cs`, `LilaEntityView.cs` | **skeletons** — follow documented Unity APIs, not compiled here (no Unity in the engine repo) |
| `Lila.Build.cs`, `LilaVM.h/.cpp` | **skeletons** — idiomatic UBT/UE5, not compiled here (no UE in the engine repo) |
| Windows/macOS/Android binaries | Linux `.so`/`.a` verified here; cross-compiles but **not run** on those OSes yet |

If something misbehaves in the engine-side skeletons, suspect the glue,
not the console — the ABI under it has a standing proof.

## 7. Roadmap (bigger cheats, in order of payoff)

1. **Tier 2 — pure C# VM port for Unity** (no native plugin at all):
   the interpreter is a few thousand lines of integer math with zero
   allocation; a faithful port keeps byte-level determinism because there
   is no float hardware in the sim and no GC in the loop. Best debugging
   story (step through the sim in VS).
2. **Tier 3 — transpile LILA → C++/C#**: `lilac` already lowers to
   bytecode; emit engine-native source instead. No VM at runtime, inline
   speeds, deterministic by construction (fixed evaluation order, integer
   math). The hash chain survives by keeping the memory layout and
   computing it in generated code. This is the full "cheat": LILA becomes
   a deterministic DSL that compiles *into* Unity/Unreal projects.
3. **Wasm/GPU host**: the browser host (`web/index.html` — still missing
   from the bundle) is the same architecture in JS; the wasm ABI
   (`lila_init/lila_frame/...`) already exists and ships.

## 8. Known gaps (honest)

- The wasm bundle still lacks `web/index.html` (the JS canvas host
  `scripts/mkhtml.py` expects) — the "runs in a browser" story has a
  hole until it's written.
- The typed-field registry has no field *names* on the wire; hosts map
  fields by schema position (the runner does the same). A v17.2 could
  add a name table to the `.libyte` or emit a sidecar JSON.
- The parallel-system worker pool is Linux-only at the moment (futex);
  other OSes fall back to the sequential sweep — bit-identical results,
  just single-lane. A portable park/wake shim would restore lanes.
- `lila_audio_fill`'s ring/drift handling in the Unity skeleton is
  presentation-only pragmatism; the *simulation's* audio pull is exact.

## 9. v17.2 host services — rendering, assets, and rewind (all verified)

Four additions, all in the host layer (`runtime/src/hostopt.zig`) — OUTSIDE
the hashed 2MB flat memory, so the simulation core and every legacy hash
chain are untouched by construction. ABI bumped to 2 (additive; `lila_abi_version()`).

### 9.1 Batched render feed — what optimizes RENDERING

`lila_stream_batches()` groups the frame's vert stream by token with a
counting sort: one batch per distinct sprite/text, batches in
first-appearance order (painter's algorithm preserved), verts stable within
a batch (additive-blend order preserved). Render batches in order and you
get pixel-identical output — but with **one instanced draw call per
sprite** instead of per-vert host work:

    measured (demo17, worst case): 3,258 verts -> 2 instanced draws, 0.5 us scan

In Unity: one `Graphics.DrawMeshInstanced` per batch (build the
`Matrix4x4` from vert triples or use verts directly in a custom shader).
In Unreal: one `UPrimitiveComponent` batch / RHI instanced draw per batch.

### 9.2 Sprite manifest — what optimizes ASSETS

Path B (host-side prefabs) needed per-game host code to know what sprites
exist. Now the loader's sprite table is exposed: `lila_sprite_count()`,
`lila_sprite_vert_count(i)`, `lila_sprite_verts(i)` — the same 14B vert
layout as the render stream (sprite-local coords, per-vert rgba). Rasterize
each sprite ONCE at boot into a `Texture2D`/`UTexture2D` (or build a
procedural mesh), and ANY cartridge renders with zero game-specific host
code. The compile-time optimizer (`opt/`) already min/maxes and packs the
polys — the manifest is the runtime view of that work.

### 9.3 Delta snapshots — what optimizes ROLLBACK MEMORY + NETCODE

An LDL1 delta is a full LSA1 snapshot minus the unchanged words: regions of
differing u32s plus the three host scalars. Pair it with the full base it
was saved against:

    lila_snapshot_save(base, sz);              // once
    ... frames ...
    n = lila_delta_save(base, sz, dst, max);  // per frame
    ... later ...
    lila_delta_load(base, sz, dst, n);        // == snapshot_load at that frame

Measured (demo17 steady state): **10.4 KB per 60 frames — 0.50% of a full
2 MB image.** A 512-frame rollback ring costs ~5 MB instead of 1 GB; the
netcode wire format (send-the-diff) falls out for free. Trade, honestly:
delta LOAD is 325 us vs 140 us for a full restore (it reconstructs through
a scratch image) — deltas are for DEPTH and BANDWIDTH, fulls for latency.
The built-in ring (below) picks the right one per seek automatically.

### 9.4 History ring — instant rewind, three calls

    lila_history_start(512);        // opt-in, before your first frame
    ... play ...                    // every lila_frame() is delta-captured
    lila_history_seek(f);           // rewind to any buffered frame

512 buffered frames (keyframe every 64), ~500 us per recorded frame
(includes the delta scan), 788 us per seek. GGPO semantics: seek truncates
the future; recording resumes. External `lila_snapshot_load` (your own
rollback) is detected via the frame counter and the ring restarts cleanly
— you can mix both. Verified: seeks restore hash-chain-exact states
(state@tick X hashes identically to the recorded chain), replays after
seek are 100% clean, 50-seek storms pass.

Subtlety the tests caught (documented so you don't rediscover it): the
ring captures at frame START — the state the hash contract hashes — but
the host has usually already written the NEXT frame's input mask by then.
The ring patches the input word to the previously observed mask during
capture (a transient, between-frames mutation invisible to both the game
and the hash chain) so restored images are hash-exact. One byte, one
lesson: it was found by the hash discipline, not by eyeballing.

### 9.5 Compile-time budget report — `lilac build`

Every build now prints the static per-frame VM instruction budget:

    budget: 1068 instr code, per-frame worst = update 379 + draw 185 +
            per-entity (174 x cap 512) = 89652 instr (~3.6% of the 2.5M/frame
            60Hz headroom)

Worst case (full pools) against the measured ~151M instr/s interpreter
ceiling — the number that tells you if your game logic fits the frame
BEFORE it ships. (demo17: 3.6%; classic demo.lila: 1.0%.)

## 10. v18 FORGE — the whole-game optimizer and the graphics foundry

`lilac forge` (see `docs/FORGE.md`) turns art + recorded playtests into
`game.lilamanifest` + `game.forgepack` — the decisions lockfile and the
binary pack. The cartridge never changes: v18 shipped with demo17
building byte-identical (sha256 `5424de1f…`) and every legacy chain
replaying clean.

**Unity**: `hosting/unity/LilaGraphics/`
1. `lilac forge game.lila --assets assets.lilaforge`
2. Copy `game.lilamanifest` + `game.forgepack` into `Assets/LilaGame/`
3. Menu `Lila / Import Forged Assets` → textures (exact formats),
   meshes (FGM1), and a `LilaTokenTable` appear as assets.
4. Add `LilaGraphicsBridge` next to your `LilaClient`; assign the table.
   Stream batches render as instanced quads; entities drive pooled
   prefabs; fx-marked tokens emit cosmetic particles instead of drawing.

**Unreal**: `hosting/unreal/LilaGraphics/` — same pack, same manifest,
`LilaGraphicsComponent` on the `ALilaVM` actor; fx routes to Niagara.

**Netcode**: `hosting/net/lilanet.c` — the 8-player lockstep+rollback
reference. Build from `runtime/`:

    zig build-lib src/lila_c.zig -dynamic -O ReleaseFast -lc
    cc -O2 ../hosting/net/lilanet.c -o /tmp/lilanet \
        -I../hosting/include -L. -llila_c -Wl,-rpath,$PWD
    /tmp/lilanet ../demo/demo17.libyte

Two modes, ground-truth referee, zero divergences: ~1.02 ms mean / 5.6 ms
worst per rollback under a hostile 0–8-frame jitter wire, 240 B/s/player.

**Cosmetic/deterministic split** (the discipline that makes the host
graphics layer safe): LILA owns WHEN and WHERE (hash-covered); the host
owns HOW IT LOOKS (render rate, host RNG, no feedback). Particle bursts,
LOD, palette animation, post effects — all host. Anything a gameplay
system reads (positions, HP, collisions) — only ever LILA.

IDE status: the C side (lilanet, pack format, ABI) is test-verified on
this machine; the Unity/UE graphics glue is complete-logic skeletons,
same honest status as v17.1's glue.

## 11. v19 — Execution-as-data: installing forged tables in a host

The forgepack now carries TBL1 sections (pure-fn argument domains, ~20
bytes each). The values are BAKED BY THE VM AT INSTALL — the host never
interprets them, never ships a second implementation of game logic:

```c
// after lila_init, before the first lila_frame:
int installed = lila_tables_install(pack_bytes, pack_len);
// negative = the pack was forged for a different cartridge (or corrupt);
// 0 = the pack has no tables (still fine); N = N tables baked+active.

// telemetry (optional — outside the hashed memory, diagnostics only):
uint64_t hits, misses, spot_checks, mismatches; uint32_t active;
lila_tables_stats(&hits, &misses, &spot_checks, &mismatches, &active);
```

What this buys: every call to a tabled fn inside the domain is a load
instead of executing the fn (measured 1.64x on a pure-call stress cart).
What this costs: a one-time bake (microseconds — the VM executes the fn
once per domain entry at install).

The guarantees (see FORGE.md for the full proofs):
- hash-neutral: with tables installed, a recorded movie's hash chain
  still matches bit-for-bit (the runner's `--replay movie --tables pack`
  is the proof command; demo19 ships with it green);
- out-of-domain arguments take the REAL call — the table is a cache,
  not a contract;
- small tables are spot-verified on their first hits and retire
  themselves on any mismatch (a purity-bug canary);
- hot-swap invalidates tables (they are pinned to the cartridge's
  sha256) — call lila_tables_install again after lila_hot_swap.

PGX sprites and HRM voices need NO new runtime API: the host's existing
pack parser just meets two new section tags (PGX1: rect quads + palette
for geometry rendering; HRM1: f0/partials/attack for a ~30-line
sine-bank voice) and the manifest's render.kind gains "pgx" (and audio
decisions gain "harmonic").

## 12. v20 — ABI 4: pools, reflection, memory tiers

The C#/C++ parity round adds host-visible surface:

- **`lila_name(kind, a, b, out, cap)`** — reflection labels (requires the
  cartridge's `game { reflection: true }`): entity/field/fn/pool names by
  id. Editors can finally render real names next to typed-field ids.
- **`lila_pool_count / lila_pool_cap / lila_pool_len`** — dynamic side
  tables introspection. `lila_pool_len` reads the live count straight from
  the flat image — the same bytes the hash chain covers, so a host-side
  read is always consistent with the replayed timeline.
- **`lila_mem_mb()`** — the build's memory tier (flat-image size).

Determinism rules are unchanged: pools live inside the hashed image (the
snapshot/rollback contract carries them with the standard memcpy); the
names trailer is host-only metadata (hash-neutral, gameplay never reads
it); f32 values in fields are raw IEEE bits — convert at the render
boundary exactly like Q24.8 (the boundary rule applies to both number
systems now).

## 13. v23 — ABI 5: pointer overlays (zero-copy host memory)

The boundary itself is the feature now. Instead of the host POLLING fields
one `lila_field_read` call at a time, the host allocates the entity arrays
itself — `TArray<FLilaXRow>` (Unreal), `NativeArray<LilaXRow>(
Allocator.Persistent)` (Unity), `malloc` (C) — and hands LILA the raw
pointer. Every tick, the engine scatters the live dense SoA rows straight
into that memory, lane by lane, in place:

```
UNREAL (C++) / UNITY (C#)              LILA RUNTIME (Zig)
+----------------------------+        +-------------------------+
| Exposes Raw Memory Buffer  | =====> | Wraps Pointer Natively  |
| (TArray / NativeArray)     | [No    | (Reads Q24.8 SoA rows)  |
+----------------------------+  Copy] +-------------------------+
              ^                                        |
              +========================================+
                     Direct In-Place Lane Scatter
```

**The layouts are generated, never hand-written.**
`lilac build game.lila --emit-bridges [dir]` (the Rust compiler is the
source of truth, iterating the same post-SoA `Ctx` that built the
.libyte) emits:

- **`LilaInterop.h`** — pack(1) row structs with `_Static_assert`s on the
  exact size AND `offsetof` of every lane. Compiling your host is the
  layout proof.
- **`LilaInterop.cs`** — `[StructLayout(LayoutKind.Sequential, Pack = 1)]`
  twins + `LilaInteropLayout.Validate()` that throws on drift.

Row `i` mirrors entity slot `i`. Lane 0 is always `uint32_t lila_meta`
(bit0 = alive, bits 4..15 = slot generation — stale rows are unambiguous,
like handles). Then the DENSE fields in access-density order (x/y/vx/vy
first — the same hot register window the SoA repacker computed), with lane
sizes: fixed Q24.8 -> `float` (exact ×2⁻⁸), f32 -> `float` (raw IEEE
bits), int/bool/ang -> byte-rounded integer lanes (signed per the
registry). Cold fields stay behind `lila_field_read` — the row is the hot
window and stays minimal.

**The ABI** (all in `lila.h` "v23 / ABI 5"):

| call | what it does |
|---|---|
| `lila_overlay_layout_hash()` | FNV-1a of the loaded cartridge's lane layout — must equal `LILA_INTEROP_LAYOUT_HASH` |
| `lila_overlay_row_bytes(t)` | `sizeof(LilaXRow)` per the runtime |
| `lila_overlay_install(t, ptr, stride, cap, hash)` | register a host buffer; `-2` = stale generated files, `-3` = stride < row size |
| `lila_overlay_flush()` | scatter every installed type NOW |
| `lila_overlay_tick()` | one tick + flush (input_set before, like lila_frame) |
| `lila_tick_pipeline(ptr, count)` | the one-call form: retarget type 0 + tick + flush |
| `lila_overlay_written(t)` | rows written by the last flush |
| `lila_overlay_spawn_from(t, ptr, count)` | the import path: host rows -> spawns, floats quantized by the `lila_f_to_q` truncation at the boundary |

**Determinism — both red lines hold, and this is pinned, not hoped:**
the flush READS engine memory and WRITES host memory only, so the wyhash
chain, snapshots and rollback are bit-identical with overlays installed or
not (`test_v23.zig` proves it on a 32-frame chain; `overlay_test.c` proves
it again in the C host). The import path quantizes host floats through the
same truncating f×256 as `lila_f_to_q` — a spawn is a hashed, snapshot-safe
simulation event, bit-identical to the host calling `lila_field_write`
itself. No float ever lands in a simulation word unquantized.

**The stale-code tripwire:** the compiler stamps the FNV-1a layout hash
into both emitted files; `lila_overlay_install` recomputes it from the
loaded cartridge's typed-field registry and REFUSES the buffer when they
disagree (the same discipline as `lila_tables_install`'s pack check).
Change your schema, forget to regenerate, and the failure is a loud `-2`
plus a C# `InvalidOperationException` from `Validate()` — never a silent
garbage read.

Host-side code lives in `hosting/unreal/LilaOverlay/` (the hijack
component: `lila_tick_pipeline` per TickComponent, `lila_hot_swap` for
gameplay reloads without compiling Unreal) and `hosting/unity/
LilaOverlayClient.cs` (NativeArray + `GetUnsafeBufferPointerWithoutChecks`
— the C# GC never tracks a single row, zero allocation per frame). The
whole gate is `hosting/examples/c_host/verify.sh` step 6: bridges emit,
`cc` compiles the generated header, and every lane lands at the exact
fixture value through the C compiler itself.
