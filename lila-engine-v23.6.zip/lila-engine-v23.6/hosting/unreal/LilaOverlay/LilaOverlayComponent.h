// ============================================================================
// LilaOverlayComponent.h — v23 the hijack component (Unreal skeleton)
// ============================================================================
//
// Embeds the whole LILA console pipeline in ONE component and drives it
// through the zero-copy pointer overlay:
//
//   - BeginPlay:  lila_init(cartridge) + rows allocated + install
//   - TickComponent: fixed 60Hz accumulator -> input_set ->
//                    lila_tick_pipeline(Rows) -> audio pull -> broadcast
//   - HotSwapCartridge(): lila_hot_swap — reload gameplay code WITHOUT
//     compiling a single line of Unreal. That is the point: your daily
//     iteration loop is `lilac build` (milliseconds, 3MB toolchain), not
//     UBT (minutes of reflection scanning). UE's renderer, its asset
//     pipeline, its input — all still yours; only the GAMEPLAY lives in
//     the cartridge.
//
// The game's own C++ code can hold the row TArray instead — see
// LilaOverlay.h (Install/TickPipeline work on any TArray<T>) — this
// component just shows the full self-contained pattern.
// ============================================================================

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "LilaOverlay/LilaOverlay.h"
#include "LilaOverlayComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnLilaOverlayFrame, int32, LiveRows);

UCLASS(ClassGroup = (Lila), meta = (BlueprintSpawnableComponent))
class ULilaOverlayComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	ULilaOverlayComponent();

	/** Compiled .libyte, e.g. "Lila/game.libyte" under Content/. */
	UPROPERTY(EditAnywhere, Category = "Lila")
	FString CartridgeContentPath = TEXT("Lila/game.libyte");

	/** Entity type this component mirrors (see LilaInterop.h: LILA_X_TYPE). */
	UPROPERTY(EditAnywhere, Category = "Lila")
	int32 EntityType = 0;

	/** Rows to allocate (LILA_X_MAX_LIVE mirrors everything). */
	UPROPERTY(EditAnywhere, Category = "Lila")
	int32 MaxRows = 512;

	/** Input bitmask, written by your input code BEFORE the tick. */
	UPROPERTY(BlueprintReadWrite, Category = "Lila")
	int32 InputMask = 0;

	/** Fired after every simulated frame, once the overlay is flushed. */
	UPROPERTY(BlueprintAssignable, Category = "Lila")
	FOnLilaOverlayFrame OnLilaOverlayFrame;

	/** Live rows after the last flush (bit0 of lila_meta = alive). */
	UFUNCTION(BlueprintPure, Category = "Lila")
	int32 GetLiveRows() const { return LiveRows; }

	/** Rows written by the last flush, straight from the ABI. */
	UFUNCTION(BlueprintPure, Category = "Lila")
	int32 GetWrittenRows() const { return LilaOverlay::Written(EntityType); }

	/**
	 * Hot-swap gameplay WITHOUT recompiling Unreal: read a freshly built
	 * .libyte and flash it into the running process. Entity + globals state
	 * survive when the schema matches (lila_hot_swap); the overlay
	 * reinstalls itself against the new layout hash (a stale LilaInterop.h
	 * is refused loudly — regenerate it with --emit-bridges).
	 */
	UFUNCTION(BlueprintCallable, Category = "Lila")
	bool HotSwapCartridge(const FString& InPath);

	/** The import path: spawn entities from filled rows (level loads). */
	UFUNCTION(BlueprintCallable, Category = "Lila")
	int32 SpawnRows(const TArray<uint8>& RowBytes, int32 Count)
	{
		return lila_overlay_spawn_from((uint32)EntityType,
		                               RowBytes.GetData(), (uint32)Count);
	}

	virtual void BeginPlay() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType,
	                           FActorComponentTickFunction* ThisTickFunction) override;
	virtual void EndPlay(const EEndPlayReason::Type Reason) override;

private:
	void StepOneFrame();

	/** The mirror surface: UE-allocated rows LILA writes in place. */
	TArray<uint8> Rows;
	int32 RowStride = 0;
	int32 LiveRows = 0;

	/** One frame of audio — 735 samples, exact (hash-relevant phase). */
	UPROPERTY(Transient)
	TArray<int16> Pcm;

	float Accumulator = 0.0f;
	uint32 FrameNo = 0;
	bool bBooted = false;
};
