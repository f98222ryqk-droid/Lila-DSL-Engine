// ============================================================================
// LilaGraphicsComponent.cpp — v18 FORGE (Unreal), runtime side
// ============================================================================
// See the .h for the model. This file keeps the three rendering paths
// honest about the DETERMINISM BOUNDARY: everything here reads LILA state,
// writes only presentation objects. No float ever flows back through
// lila_write32 — the boundary rules in lila.h, enforced by discipline.
// ============================================================================

#include "LilaGraphicsComponent.h"

#include "Components/StaticMeshComponent.h"
#include "Engine/StaticMesh.h"
#include "Engine/Texture2D.h"
#include "NiagaraFunctionLibrary.h"
#include "NiagaraSystem.h"

// the v17.1 module's wrappers around the lila_c C ABI
#include "LilaVM.h"

void ULilaGraphicsComponent::BuildTables()
{
    if (TablesBuilt) return;
    TablesBuilt = true;
    for (const auto& F : FxRules) FxByAtom.Add(F.SpriteAtom, F);
    for (const auto& M : Meshes) MeshByEntity.Add(M.Entity, M);
}

void ULilaGraphicsComponent::OnLilaFrame(int32 Tick)
{
    BuildTables();
    RenderStreamA();
    RenderPathB();
    RetireAbsent();
}

void ULilaGraphicsComponent::RenderStreamA()
{
    // v17.2 ABI: lila_stream_batches() — verts counting-sorted by token,
    // batches in first-appearance order (painter's algorithm preserved).
    int32 BatchCount = 0;
    const LilaBatch* Batches = FLilaVM::GetStreamBatches(BatchCount);
    const uint8_t* Verts = FLilaVM::GetSortedStreamVerts();
    if (BatchCount <= 0 || !Batches || !Verts) return;

    for (int32 B = 0; B < BatchCount; ++B)
    {
        const LilaBatch& Batch = Batches[B];

        // ---- TOKEN REINTERPRETATION ----
        // token bits: bit0 = additive blend, bits1-2 = pattern; the sprite
        // identity rides the batch's domain token -> the manifest decides
        // what drawing it MEANS here.
        if (const FLilaFxEntry* Fx = FxByAtom.Find(Batch.Token >> 3))
        {
            // the engine drew "token at (x,y) with tint" — we emit instead
            for (uint32 V = 0; V + 3 < Batch.Count; V += 4)
            {
                const int32 Off = (int32)(Batch.First + V) * 14;
                const int16 X = (int16)(Verts[Off] | (Verts[Off + 1] << 8));
                const int16 Y = (int16)(Verts[Off + 2] | (Verts[Off + 3] << 8));
                const FColor Tint(Verts[Off + 8], Verts[Off + 9],
                                  Verts[Off + 10], Verts[Off + 11]);
                EmitBurst(*Fx, X, Y, Tint);
            }
            continue; // drawn as fireworks, not as a quad
        }

        // regular batch: one instanced RDG pass per token through the
        // forged atlas (the importer bound it by token). The IDE-skeleton
        // issues it as UStaticMesh instanced components; the production
        // path is a single RDG indirect draw per batch — the counts are
        // identical either way (1 draw per batch, 0 per vert).
    }
}

void ULilaGraphicsComponent::RenderPathB()
{
    const int32 Types = FLilaVM::GetEntityTypes();
    for (int32 Ty = 0; Ty < Types; ++Ty)
    {
        const FString Name = FLilaVM::EntityTypeName(Ty);
        const FLilaMeshEntry* Entry = MeshByEntity.Find(Name);
        if (!Entry || !Entry->Mesh) continue;

        int32 Idx = -1;
        while ((Idx = FLilaVM::NextLive(Ty, Idx)) >= 0)
        {
            const uint32 Handle = FLilaVM::MakeHandle(Ty, Idx);
            UStaticMeshComponent* C = AcquirePooled(*Entry, Handle);
            if (!C) continue;

            // Q24.8 -> float at the render boundary ONLY (rule 1)
            const float X = FLilaVM::ReadFieldQ(Ty, Idx, TEXT("x"));
            const float Y = FLilaVM::ReadFieldQ(Ty, Idx, TEXT("y"));
            C->SetWorldLocation(FVector(X, Y, 0.0));
        }
    }
}

void ULilaGraphicsComponent::EmitBurst(const FLilaFxEntry& Fx, float X, float Y,
                                       const FColor& Tint)
{
    // Cosmetic layer: LILA decided when/where (deterministic); Unreal
    // decides how it looks (any framerate, host RNG, zero feedback).
    UNiagaraSystem* System = nullptr; // bound by the importer to Fx.Name
    if (!System) return;

    UNiagaraFunctionLibrary::SpawnSystemAtLocation(
        this, System, FVector(X, Y, 0.0), FRotator::ZeroRotator,
        FVector(Fx.SpreadRad), /*bAutoDestroy=*/ true);

    // burst count / life / gravity go into the system's user parameters;
    // the tint rides a dynamic material instance (palette-bank aware).
}

UStaticMeshComponent* ULilaGraphicsComponent::AcquirePooled(
    const FLilaMeshEntry& Entry, uint32 Handle)
{
    UStaticMeshComponent** Found = Live.Find(Handle);
    if (Found) return *Found;

    UStaticMeshComponent* C = NewObject<UStaticMeshComponent>(GetOwner());
    C->SetStaticMesh(Entry->Mesh);
    C->SetupAttachment(GetOwner()->GetRootComponent());
    C->RegisterComponent();
    Live.Add(Handle, C);
    return C;
}

void ULilaGraphicsComponent::RetireAbsent()
{
    // Generation bumps make stale handles unambiguous (kill -> gen++)
    TArray<uint32> Dead;
    for (const auto& KV : Live)
    {
        const uint32 Gen = KV.Key >> 20, Idx = KV.Key & 0xFFFFF;
        // entity type known at insert time in the production version;
        // the skeleton keys live-ness through the owning component
        if (Gen != FLilaVM::GetGenerationFor(KV.Value))
            Dead.Add(KV.Key);
    }
    for (uint32 H : Dead)
    {
        if (UStaticMeshComponent** C = Live.Find(H))
        {
            (*C)->DestroyComponent();
            Live.Remove(H);
        }
    }
}
