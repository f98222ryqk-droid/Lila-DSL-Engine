// ============================================================================
// LilaGraphics.Build.cs — v18 FORGE host module (Unreal)
// ============================================================================
// Pairs with the v17.1 Lila module (LilaVM.h/.cpp, the frame-contract
// actor). This module adds the FORGE consumption side: forgepack import
// + manifest-driven rendering through the token interpretation layer.
// Link against lila_c.lib the same way Lila.Build.cs does.

using UnrealBuildTool;

public class LilaGraphics : ModuleRules
{
    public LilaGraphics(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

        PublicDependencyModuleNames.AddRange(new string[]
        {
            "Core",
            "CoreUObject",
            "Engine",
            "RenderCore",
            "Renderer",
            "RHI",
        });

        PrivateDependencyModuleNames.AddRange(new string[]
        {
            "Lila",           // the v17.1 VM wrapper module
            "AssetTools",
            "EditorFramework" // importer lives editor-side; wrapped in WITH_EDITOR
        });

        // lila_c static lib: same path scheme as Lila.Build.cs
        // PublicAdditionalLibraries.Add("<path>/lila_c.lib");
    }
}
