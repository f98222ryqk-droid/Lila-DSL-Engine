// ============================================================================
// LilaGraphicsComponent.h — v18 FORGE: manifest-driven rendering (Unreal)
// ============================================================================
// Attach to the ALilaVM actor (v17.1). After each fixed tick this component
// pulls the batched stream + entity bridge and interprets tokens through
// the imported manifest (game.lilamanifest):
//
//   path A: stream quads  -> one instanced RDG pass per token batch
//   path B: entity rows   -> pooled static-mesh components (forged FGM1)
//   fx:     sprite tokens marked kind=fx in the manifest -> Niagara bursts
//           (cosmetic layer: host-rate, zero feedback into LILA)
//
// The importer (LilaManifestImporter, editor module) turns the forgepack
// into UTexture2D / UStaticMesh / UNiagaraSystem assets exactly like the
// Unity importer does — same pack format, same sha256 discipline.
//
// IDE status: complete logic against the verified C ABI; studio-testing
// pending (same honest status as the rest of the UE glue).
// ============================================================================

#pragma once

#include "Components/ActorComponent.h"
#include "LilaGraphicsComponent.generated.h"

class UStaticMesh;
class UTexture2D;
class UNiagaraSystem;

USTRUCT(BlueprintType)
struct FLilaTexEntry
{
    GENERATED_BODY()
    UPROPERTY() FString Name;
    UPROPERTY() int32 SpriteAtom = -1;
    UPROPERTY() int32 SpriteIndex = -1;
    UPROPERTY() TObjectPtr<UTexture2D> Texture = nullptr;
    UPROPERTY() FString RenderKind = TEXT("quad");
};

USTRUCT(BlueprintType)
struct FLilaMeshEntry
{
    GENERATED_BODY()
    UPROPERTY() FString Entity;
    UPROPERTY() TObjectPtr<UStaticMesh> Mesh = nullptr;
    UPROPERTY() int32 MeshletCount = 0;
};

USTRUCT(BlueprintType)
struct FLilaFxEntry
{
    GENERATED_BODY()
    UPROPERTY() FString Name;
    UPROPERTY() int32 SpriteAtom = -1;
    UPROPERTY() int32 Burst = 128;
    UPROPERTY() float LifeMin = 16.f, LifeMax = 32.f;   // frames @60Hz
    UPROPERTY() float GravPx = 0.f;                      // px/frame^2 (cosmetic)
    UPROPERTY() float SpreadRad = 1.f;
};

UCLASS(ClassGroup = (Lila), meta = (BlueprintSpawnableComponent))
class LILAGRAPHICS_API ULilaGraphicsComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    // filled by the importer / by hand in the editor
    UPROPERTY(EditAnywhere, Category = "Lila FORGE")
    TArray<FLilaTexEntry> Textures;

    UPROPERTY(EditAnywhere, Category = "Lila FORGE")
    TArray<FLilaMeshEntry> Meshes;

    UPROPERTY(EditAnywhere, Category = "Lila FORGE")
    TArray<FLilaFxEntry> FxRules;

    // called by the ALilaVM owner after the frame contract's lila_frame()
    void OnLilaFrame(int32 Tick);

    // the batched-stream pass (v17.2 ABI: counting-sorted, painter order)
    void RenderStreamA();

    // entity bridge -> pooled mesh components with LOD (forged ladder)
    void RenderPathB();

    // cosmetic layer: token reinterpretation fx -> Niagara, host RNG only
    void EmitBurst(const FLilaFxEntry& Fx, float X, float Y, const FColor& Tint);

private:
    TMap<int32, FLilaFxEntry> FxByAtom;
    TMap<FString, FLilaMeshEntry> MeshByEntity;
    TMap<uint32, class UStaticMeshComponent*> Live;
    bool TablesBuilt = false;

    void BuildTables();
    class UStaticMeshComponent* AcquirePooled(const FLilaMeshEntry& Entry, uint32 Handle);
    void RetireAbsent();
};
