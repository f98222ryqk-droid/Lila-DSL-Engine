/* ============================================================================
 * lilanet.c — v18 FORGE netcode reference: deterministic lockstep + rollback
 * ============================================================================
 *
 * THE ONE-PAGE PROOF that the determinism contract IS the netcode.
 *
 *   A LILA timeline is bit-identical on every machine forever. Therefore:
 *   - The ONLY thing peers exchange is INPUT: a u32 mask per player per
 *     frame = 240 B/s/player at 60 Hz, plus 12 B of hash gossip every 60
 *     frames if you want desync detection thrown in.
 *   - A late input is not an error — it is a ROLLBACK: restore a snapshot
 *     from <= the late frame, patch the input log, re-simulate to now.
 *     With sim at ~86 us/frame (measured, demo17) and v17.2 delta
 *     snapshots at 1-4 KB, the whole netcode is buffer juggling. This
 *     file is the juggling, written to be read.
 *
 * MODEL (GGPO vocabulary, LILA machinery), one client's view:
 *   - 8 players. Player 0 is LOCAL: its input is always known, instantly.
 *   - Each remote player's frame-f input has a deterministic arrival time
 *     f + delay(p,f), delay in [0, MAX_DELAY]. That schedule IS our wire
 *     model — no sockets, so the CPU numbers are purely the netcode's own
 *     cost, and every run reproduces the same workload.
 *   - Until the truth for a frame arrives, the client PREDICTS remote
 *     inputs as "no press" and runs ahead. When truth lands and it
 *     disagrees with what was simulated, the client rolls back to the
 *     newest fully-true snapshot, re-simulates with corrected inputs,
 *     and verifies EVERY re-simulated frame's hash against the
 *     ground-truth chain computed up front (the referee).
 *   - Predictions that happen to be right cost nothing — the classic
 *     rollback win, measured here as the skip rate.
 *
 * SNAPSHOT MACHINERY (v17.2 host ABI, see lila.h):
 *   - One LSA1 base (boot state) + one LDL1 delta per simulated frame in
 *     a 64-slot ring. Slots holding frames simulated under full truth are
 *     marked as restore points; predicted frames are not.
 *
 * BUILD (from runtime/):
 *   zig build-lib src/lila_c.zig -dynamic -O ReleaseFast -lc
 *   cc -O2 ../hosting/net/lilanet.c -o /tmp/lilanet \
 *      -I../hosting/include -L. -llila_c -Wl,-rpath,$PWD
 *   /tmp/lilanet ../demo/demo17.libyte
 * ==========================================================================*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>

#include "lila.h"

static int g_dbg = 0;

#define PLAYERS     8
#define MAX_DELAY   8      /* worst-case input latency, frames          */
#define RING        64     /* delta-ring slots                          */
#define FRAMES_RUN  3600   /* 60 seconds of gameplay                    */

/* ---------------- timing ---------------- */

static uint64_t now_ns(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
}

/* ---------------- deterministic wire ---------------- */

static uint32_t hash32(uint32_t v) {
    v ^= v >> 16; v *= 0x7FEB352Du; v ^= v >> 15;
    v *= 0x846CA68Bu; v ^= v >> 16;
    return v;
}

/* remote player p's input at frame f (game-like pressure, reproducible) */
static uint32_t fake_input(uint32_t p, uint32_t f) {
    uint32_t v = hash32(p * 0x9E3779B1u + f * 0x85EBCA77u);
    uint32_t mask = 0;
    if (v & 0x00000001u) mask |= 1u;              /* left   */
    if (v & 0x00000002u) mask |= 2u;              /* right  */
    if (v & 0x00000004u) mask |= 4u;              /* up     */
    if ((v & 0x000000F0u) == 0x30u) mask |= 8u;   /* fire   */
    return mask;
}

/* the frame at which the wire delivers (p, f)'s input to us */
static uint32_t arrive_at(uint32_t p, uint32_t f) {
    return f + hash32(p * 0xABCD1235u + f * 7u + 3u) % (MAX_DELAY + 1);
}

/* one full client run. sim_lag = how many frames the client deliberately
 * waits (input-delay buffer) before simulating frame `head`: 0 = the
 * full-prediction stress mode (every remote input late -> max rollbacks);
 * 4 = a realistic broadband client (most inputs in hand when simulated). */
static int run_client(uint8_t *blob, long len, const char *label, uint32_t sim_lag) {
    if (lila_init(blob, len) != 0) {
        fprintf(stderr, "lila_init failed: %d\n", lila_last_error());
        return 1;
    }

    /* ---------------- ground truth (the referee) ----------------
     * All inputs known up front: the canonical timeline + hash chain
     * every rollback must converge back to, bit for bit. */
    uint64_t *truth_hash = calloc(FRAMES_RUN, sizeof(uint64_t));
    int16_t pcm[735];
    for (uint32_t fr = 0; fr < FRAMES_RUN; fr++) {
        uint32_t mask = 0;
        for (uint32_t p = 0; p < PLAYERS; p++) mask |= fake_input(p, fr);
        lila_input_set(mask);
        lila_frame();
        lila_audio_fill(pcm, 735);
        truth_hash[fr] = lila_state_hash(fr);
    }
    /* rewind to boot for the real run */
    if (lila_init(blob, len) != 0) { fprintf(stderr, "re-init failed\n"); return 1; }

    /* ---------------- snapshot ring ---------------- */
    uintptr_t snap_sz = lila_snapshot_size();
    uintptr_t dmax = lila_delta_max();
    uint8_t *base = malloc(snap_sz);
    uint8_t *deltas = calloc(RING, dmax);
    uintptr_t dlen[RING];
    uint32_t ring_frame[RING];
    uint8_t ring_valid[RING];   /* 1 = frame simulated under FULL truth */
    for (int i = 0; i < RING; i++) { dlen[i] = 0; ring_frame[i] = 0; ring_valid[i] = 0; }

    /* ---------------- client state ---------------- */
    uint8_t *arrived = calloc(PLAYERS, FRAMES_RUN);       /* truth known  */
    uint8_t *simulated = calloc(FRAMES_RUN, 1);           /* we ran frame */
    uint8_t *was_pred = calloc(FRAMES_RUN, 1);             /* ran on a guess */
    uint8_t *sim_remote = calloc(FRAMES_RUN, 1);          /* remote mask the sim used */
    uint32_t head = 0;                                    /* next frame  */
    uint32_t commit_ptr = 0;  /* frames < commit_ptr have ALL truths arrived */

    /* stats */
    uint64_t rollbacks = 0, resim_frames = 0, skipped_correct = 0, predicted = 0;
    double rb_ns_total = 0, rb_ns_max = 0;
    uint64_t depth_hist[MAX_DELAY + 1] = {0};
    uint64_t bytes_wire = 0;

    if (lila_snapshot_save(base, snap_sz) != 0) { fprintf(stderr, "base save failed\n"); return 1; }

    /* logical clock: advances one tick per loop; sim may be ahead of truth */
    uint32_t clock = 0;
    uint64_t t0_all = now_ns();

    for (;;) {
        /* ---- 1. deliver truths whose arrival time has come ---- */
        int delivered = 0;
        uint32_t from = head > MAX_DELAY + 2 ? head - (MAX_DELAY + 2) : 0;
        for (uint32_t p = 1; p < PLAYERS; p++) {
            for (uint32_t fr = from; fr < head && fr < FRAMES_RUN; fr++) {
                if (arrived[p * FRAMES_RUN + fr]) continue;
                if ((int32_t)(arrive_at(p, fr) - clock) <= 0) {
                    arrived[p * FRAMES_RUN + fr] = 1;
                    bytes_wire += 4;
                    delivered = 1;
                }
            }
        }

        /* ---- 2. commit boundary ----
         * A frame's hash only equals the referee's when EVERY input up to
         * and including it is truth. commit_ptr is that boundary: the
         * first frame still missing any remote truth. */
        while (commit_ptr < FRAMES_RUN) {
            int missing = 0;
            for (uint32_t p = 1; p < PLAYERS && !missing; p++)
                if (!arrived[p * FRAMES_RUN + commit_ptr]) missing = 1;
            if (missing) break;
            commit_ptr++;
        }
        clock++;

        /* ---- 3. was a simulated frame's prediction WRONG? ----
         * Compare, per frame, the remote mask the sim ACTUALLY used
         * (sim_remote[fr]) against the now-known truth. Only frames whose
         * truths are COMPLETE are judged — partials wait. A frame whose
         * prediction matched the truth is a FREE rollback skip.
         * Arrivals lag simulation by <= MAX_DELAY, so only the last
         * MAX_DELAY+2 frames can ever flip. */
        uint32_t first_dirty = UINT32_MAX;
        {
            uint32_t scan_from = head > MAX_DELAY + 2 ? head - (MAX_DELAY + 2) : 0;
            for (uint32_t fr = scan_from; fr < head && fr < FRAMES_RUN; fr++) {
                if (!simulated[fr]) continue;
                uint32_t truth_mask = 0;
                int missing = 0;
                for (uint32_t p = 1; p < PLAYERS; p++) {
                    if (arrived[p * FRAMES_RUN + fr]) truth_mask |= fake_input(p, fr);
                    else missing = 1;
                }
                if (missing) continue;
                if (sim_remote[fr] != (uint8_t)truth_mask) { first_dirty = fr; break; }
                if (was_pred[fr]) {
                    /* prediction arrived CORRECT: zero-cost rollback skip */
                    was_pred[fr] = 0; /* count once */
                    skipped_correct++;
                }
            }
        }

        /* ---- done only when CONVERGED: all simulated, all truth, no
         *      pending correction (the last rollback must run first) ---- */
        if (head >= FRAMES_RUN && commit_ptr >= FRAMES_RUN && first_dirty == UINT32_MAX)
            break;

        if (first_dirty != UINT32_MAX) {
            /* ---- ROLLBACK ----
             * Restore the newest VALID ring slot before first_dirty,
             * re-simulate to head with now-known truths (missing ones
             * still predicted as 0), verifying hashes only on fully-true
             * frames (predicted frames legitimately differ from truth). */
            int rb = -1;
            for (int i = 0; i < RING; i++)
                if (ring_valid[i] && ring_frame[i] < first_dirty)
                    if (rb < 0 || ring_frame[i] > ring_frame[rb]) rb = i;

            uint64_t t0 = now_ns();
            uint32_t from_f;
            if (g_dbg) fprintf(stderr, "[rb] dirty=%u head=%u rb_slot=%d rb_frame=%s\n",
                               first_dirty, head, rb, rb >= 0 ? "yes" : "BASE");
            if (rb >= 0) {
                int32_t rf = lila_delta_load(base, snap_sz,
                                    deltas + (size_t)rb * dmax, dlen[rb]);
                if (rf < 0) {
                    fprintf(stderr, "FATAL: delta restore failed\n");
                    return 1;
                }
                // delta_load returns the frame the state is settled at the
                // START of == the next frame to simulate == rf itself.
                if (g_dbg) fprintf(stderr, "[rb] delta_load restored frame %d (saved after simulating %u)\n",
                                   rf, ring_frame[rb]);
                from_f = (uint32_t)rf;
            } else {
                if (lila_snapshot_load(base, snap_sz) < 0) {
                    fprintf(stderr, "FATAL: base restore failed\n");
                    return 1;
                }
                from_f = 0;
            }
            uint32_t depth = head - from_f;
            if (depth > MAX_DELAY) depth = MAX_DELAY;
            depth_hist[depth]++;
            rollbacks++;

            for (uint32_t fr = from_f; fr < head; fr++) {
                uint32_t mask = fake_input(0, fr); /* local: always truth */
                uint32_t rmask = 0;
                for (uint32_t p = 1; p < PLAYERS; p++) {
                    if (arrived[p * FRAMES_RUN + fr]) rmask |= fake_input(p, fr);
                }
                mask |= rmask;
                lila_input_set(mask);
                lila_frame();
                lila_audio_fill(pcm, 735);
                sim_remote[fr] = (uint8_t)rmask;
                int truth_upto = fr < commit_ptr;
                was_pred[fr] = truth_upto ? 0 : 1;
                if (truth_upto) {
                    uint64_t h = lila_state_hash(fr);
                    if (h != truth_hash[fr]) {
                        fprintf(stderr, "FATAL: resim frame %u diverged "
                                "(tick=%u from_f=%u commit=%u)\n",
                                fr, lila_tick(), from_f, commit_ptr);
                        return 1;
                    }
                }
                int slot = fr % RING;
                dlen[slot] = lila_delta_save(base, snap_sz,
                                             deltas + (size_t)slot * dmax, dmax);
                ring_frame[slot] = fr;
                /* valid restore point only when the whole prefix is truth */
                ring_valid[slot] = (uint8_t)truth_upto;
            }
            double dt = (double)(now_ns() - t0);
            rb_ns_total += dt;
            if (dt > rb_ns_max) rb_ns_max = dt;
            resim_frames += head - from_f;
            continue; /* re-evaluate deliveries on the restored timeline */
        }

        /* ---- 4. advance: simulate frame `head` when the delay window
         *      elapsed (sim_lag = 0 -> always, the stress mode) ---- */
        if (head < FRAMES_RUN && (int32_t)(clock - head) >= (int32_t)sim_lag + 1) {
            uint32_t mask = fake_input(0, head);
            uint32_t rmask = 0;
            for (uint32_t p = 1; p < PLAYERS; p++) {
                if (arrived[p * FRAMES_RUN + head]) rmask |= fake_input(p, head);
            }
            mask |= rmask;
            lila_input_set(mask);
            lila_frame();
            lila_audio_fill(pcm, 735);
            sim_remote[head] = (uint8_t)rmask;
            int truth_upto = head < commit_ptr;
            was_pred[head] = truth_upto ? 0 : 1;
            if (truth_upto) {
                uint64_t h = lila_state_hash(head);
                if (h != truth_hash[head]) {
                    fprintf(stderr, "FATAL: fresh frame %u diverged (commit=%u)\n",
                            head, commit_ptr);
                    return 1;
                }
            } else {
                predicted++;
            }
            simulated[head] = 1;
            int slot = head % RING;
            dlen[slot] = lila_delta_save(base, snap_sz,
                                         deltas + (size_t)slot * dmax, dmax);
            ring_frame[slot] = head;
            ring_valid[slot] = (uint8_t)truth_upto;
            head++;
        }
        /* if head == FRAMES_RUN we just drain arrivals (loop top) */
    }

    /* final frame must match the referee exactly */
    {
        uint32_t mask = 0;
        for (uint32_t p = 0; p < PLAYERS; p++) mask |= fake_input(p, FRAMES_RUN - 1);
        /* note: hash at the last simulated frame was verified in-loop when
         * complete; assert the engine is still on the truth chain */
        if (lila_state_hash(FRAMES_RUN - 1) != truth_hash[FRAMES_RUN - 1]) {
            fprintf(stderr, "FATAL: final state off the truth chain\n");
            return 1;
        }
        (void)mask;
    }

    uint64_t t_all = now_ns() - t0_all;
    bytes_wire += (FRAMES_RUN / 60) * 12; /* hash gossip: 8B + id per second */

    /* actual delta bytes in live use (the ring's real footprint) */
    uintptr_t live_bytes = 0;
    for (int i = 0; i < RING; i++)
        if (ring_valid[i] && dlen[i] > live_bytes) live_bytes = dlen[i];

    /* ---------------- report ---------------- */
    printf("\n== lilanet [%s]: 8-player lockstep+rollback, %u frames (%.0fs) ==\n",
           label, FRAMES_RUN, FRAMES_RUN / 60.0);
    printf("predicted frames:  %llu (%.1f%% ran ahead on remote guesses)\n",
           (unsigned long long)predicted, 100.0 * predicted / FRAMES_RUN);
    printf("free rollbacks:    %llu predictions that arrived correct (cost 0)\n",
           (unsigned long long)skipped_correct);
    printf("rollbacks:         %llu events, %llu frames re-simulated\n",
           (unsigned long long)rollbacks, (unsigned long long)resim_frames);
    if (rollbacks) {
        printf("rollback cost:     mean %.3f ms / worst %.3f ms (restore + resim + hash verify)\n",
               rb_ns_total / (double)rollbacks / 1e6, rb_ns_max / 1e6);
    }
    printf("depth histogram:  ");
    for (int d = 1; d <= MAX_DELAY; d++)
        if (depth_hist[d]) printf("[%d]=%llu ", d, (unsigned long long)depth_hist[d]);
    printf("\n");
    printf("verification:      every committed frame vs ground-truth chain -> 0 divergences\n");
    printf("wire (send rate):  %d B/s/player inputs + 12 B/s hash gossip\n", 4 * 60);
    printf("netcode state:     ring %d x worst-case %llu B, live delta ~%llu B/frame\n",
           RING, (unsigned long long)dmax, (unsigned long long)live_bytes);
    printf("sim only (no truth pass, no referee): the client's own cost is the\n");
    printf("   rollback line above x event rate + 1 frame contract per 16.7 ms.\n");
    printf("whole run:         %.1f ms wall for %.0fs of play (incl. referee pass)\n",
           (double)t_all / 1e6, FRAMES_RUN / 60.0);

    free(truth_hash); free(arrived); free(simulated); free(was_pred);
    free(sim_remote); free(base); free(deltas);
    return 0;
}

int main(int argc, char **argv) {
    if (argc < 2) { fprintf(stderr, "usage: %s <game.libyte>\n", argv[0]); return 2; }
    g_dbg = getenv("LILANET_DEBUG") != NULL;

    FILE *f = fopen(argv[1], "rb");
    if (!f) { perror("open cartridge"); return 1; }
    fseek(f, 0, SEEK_END);
    long len = ftell(f);
    fseek(f, 0, SEEK_SET);
    uint8_t *blob = malloc(len);
    if (fread(blob, 1, len, f) != (size_t)len) { perror("read"); return 1; }
    fclose(f);
    if (lila_init(blob, len) != 0) { fprintf(stderr, "lila_init failed\n"); return 1; }
    printf("lilanet: %s (abi %d, engine %d, %d entity types, cap %d)\n",
           argv[1], lila_abi_version(), lila_engine_version(),
           lila_entity_types(), lila_cap_ent());

    int rc = 0;
    rc |= run_client(blob, len, "input-delay 4 (broadband client)", 4);
    rc |= run_client(blob, len, "zero-delay stress (predict everything)", 0);
    free(blob);
    return rc;
}
