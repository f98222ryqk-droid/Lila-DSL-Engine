/* ============================================================================
 * lilanet_udp.c — the same netcode as lilanet.c, on a REAL wire (UDP)
 * ============================================================================
 *
 * lilanet.c proves the netcode's CPU shape with a deterministic FAKE
 * transport (arrival schedule). This file keeps the entire rollback engine
 * — same 8-player model, same 64-slot LDL1 delta ring, same commit/dirty
 * scan — and swaps the fake schedule for POSIX UDP sockets:
 *
 *   - input packets: one 20 B datagram per player per frame (12 B header +
 *     frame u32 + mask u32) = 240 B/s/player at 60 Hz, exactly the send
 *     rate lilanet.c reports. Every frame is sent unconditionally so a lost
 *     datagram costs one rollback, never a stall (a changed-only delta
 *     would need ACK/retransmit — a bandwidth optimization, not a
 *     correctness one; deliberately out of scope).
 *   - hash gossip: every GOSSIP_PERIOD frames each peer sends the state
 *     hash of its newest committed frame (12 B header + frame u32 + hash
 *     u64) — the desync detector.
 *   - hello: a bare header, sent once per second to every configured peer
 *     until all of them have been heard from. UDP is connectionless, so a
 *     player's slot address is pinned by the FIRST datagram that carries
 *     its peer_id (NAT re-binding / slot migration is out of scope).
 *
 * WIRE FORMAT (all integers LITTLE-ENDIAN — LILA hosts are LE; big-endian
 * machines byte-swap in the accessors below):
 *   offset 0  magic  'L','I','L','A'          (4 B)
 *   offset 4  version u8  (1)
 *   offset 5  type    u8   (0=hello 1=input 2=hash)
 *   offset 6  peer_id u8   (sender's player slot)
 *   offset 7  reserved u8
 *   --- type 1 (input): frame u32, mask u32            (20 B total)
 *   --- type 2 (hash):  frame u32, hash u64            (24 B total)
 *   --- type 0 (hello): no payload                     (12 B total)
 *
 * WHAT REPLACES THE REFEREE: lilanet.c precomputes the ground-truth hash
 * chain because it owns every input. A real client cannot — so per-frame
 * verification happens through the GOSSIP: when a peer's hash for a frame
 * we have committed disagrees with ours, that is a DIVERGENCE (counted and
 * reported; a full resync/rejoin protocol is future work). Within one peer
 * the engine's determinism still guarantees: identical delivered inputs =>
 * identical state, which is the claim being deployed.
 *
 * BUILD (from runtime/):
 *   zig build-lib src/lila_c.zig -dynamic -O ReleaseFast -lc
 *   cc -O2 ../hosting/net/lilanet_udp.c -o /tmp/lilanet_udp \
 *      -I../hosting/include -L. -llila_c -Wl,-rpath,$PWD
 * RUN (loopback, 3 players on one machine):
 *   /tmp/lilanet_udp ../demo/demo17.libyte 9000 0 127.0.0.1:9001 127.0.0.1:9002 &
 *   /tmp/lilanet_udp ../demo/demo17.libyte 9001 1 127.0.0.1:9000 127.0.0.1:9002 &
 *   /tmp/lilanet_udp ../demo/demo17.libyte 9002 2 127.0.0.1:9000 127.0.0.1:9001
 *
 * STATUS: the rollback core is the same code path lilanet.c exercises
 * (300/300 hash chain, 0 divergences). The socket layer is written to the
 * reference shape but NOT run in the engine's test sandbox (no network
 * there); point the referee harness at run_client once a two-box rig
 * exists. The LOCAL player's input is the same synthetic generator as
 * lilanet.c so two peers run a reproducible, hash-comparable workload —
 * a real client replaces exactly that one call (local_input) with its
 * input layer; nothing else knows the input is synthetic.
 * ==========================================================================*/

/* clock_gettime/clock_nanosleep/getaddrinfo are POSIX, not ISO C99 — ask
 * for them explicitly so this compiles under -std=c99 as well as gnu17. */
#define _POSIX_C_SOURCE 200112L

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#include <errno.h>

#include <unistd.h>
#include <poll.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#include "lila.h"

/* ---------------- the model, identical to lilanet.c ---------------- */

#define PLAYERS       8      /* hard cap, matching lilanet.c's structure      */
#define MAX_DELAY     8      /* worst-case input latency budget, frames       */
#define RING          64     /* delta-ring slots                              */
#define FRAMES_RUN    3600   /* 60 seconds of gameplay, then the report       */
#define GOSSIP_PERIOD 60     /* hash gossip every second of game time         */
#define PEER_TIMEOUT  900    /* 15 s of silence before a peer is presumed gone */
#define WIRE_VERSION  1

enum { PKT_HELLO = 0, PKT_INPUT = 1, PKT_HASH = 2 };
#define HDR_LEN   12
#define MAX_DGRAM 64

/* ---------------- timing ---------------- */

static uint64_t now_ns(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
}

/* pace one 60 Hz tick (the client IS the fixed timestep; a lagging machine
 * runs flat out rather than drifting — same policy as the sim accumulator) */
static void sleep_until(uint64_t deadline_ns) {
    struct timespec ts;
    uint64_t now = now_ns();
    if (deadline_ns <= now) return;
    ts.tv_sec  = (time_t)((deadline_ns - now) / 1000000000ull);
    ts.tv_nsec = (long)((deadline_ns - now) % 1000000000ull);
    clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &ts, NULL);
}

/* ---------------- little-endian wire accessors ---------------- */

static void put_u32(uint8_t *p, uint32_t v) {
    p[0] = (uint8_t)v;         p[1] = (uint8_t)(v >> 8);
    p[2] = (uint8_t)(v >> 16); p[3] = (uint8_t)(v >> 24);
}
static void put_u64(uint8_t *p, uint64_t v) {
    for (int i = 0; i < 8; i++) p[i] = (uint8_t)(v >> (8 * i));
}
static uint32_t get_u32(const uint8_t *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}
static uint64_t get_u64(const uint8_t *p) {
    uint64_t v = 0;
    for (int i = 0; i < 8; i++) v |= (uint64_t)p[i] << (8 * i);
    return v;
}

/* ---------------- synthetic local input (harness only — see header) ----- */

static uint32_t hash32(uint32_t v) {
    v ^= v >> 16; v *= 0x7FEB352Du; v ^= v >> 15;
    v *= 0x846CA68Bu; v ^= v >> 16;
    return v;
}
static uint32_t local_input(uint32_t f) {
    uint32_t v = hash32(f * 0x85EBCA77u + 0x1234u);
    uint32_t mask = 0;
    if (v & 0x00000001u) mask |= 1u;              /* left   */
    if (v & 0x00000002u) mask |= 2u;              /* right  */
    if (v & 0x00000004u) mask |= 4u;              /* up     */
    if ((v & 0x000000F0u) == 0x30u) mask |= 8u;   /* fire   */
    return mask;
}

/* ---------------- the transport ---------------- */

typedef struct {
    struct sockaddr_in addr;      /* pinned by this slot's first datagram */
    uint32_t           last_seen; /* tick counter of the last datagram    */
} peer_t;

typedef struct {
    int      sock;
    int      self;                          /* our player slot              */
    uint32_t tick;                          /* logical 60 Hz ticks elapsed  */
    peer_t   peer[PLAYERS];
    struct sockaddr_in boot[PLAYERS];       /* CLI bootstrap endpoints      */
    int      n_boot;
    uint64_t sent, recvd;                   /* wire counters                */
} udp_t;

static int peer_online(const udp_t *u, int p) {
    return u->peer[p].last_seen != 0 &&
           u->tick - u->peer[p].last_seen <= PEER_TIMEOUT;
}

static void udp_send_to(udp_t *u, const struct sockaddr_in *to,
                        const uint8_t *buf, size_t len) {
    if (sendto(u->sock, buf, len, 0, (const struct sockaddr *)to,
               sizeof *to) == (ssize_t)len)
        u->sent++;
    /* send errors (ICMP port-unreachable etc.) are expected on a lossy
     * wire: the arrivals table simply stays empty and rollback of the
     * predicted frames absorbs it — same model as the fake transport. */
}

static void udp_broadcast(udp_t *u, const uint8_t *buf, size_t len) {
    for (int p = 0; p < PLAYERS; p++)
        if (p != u->self && peer_online(u, p))
            udp_send_to(u, &u->peer[p].addr, buf, len);
}

static void make_hdr(uint8_t *pkt, uint8_t type, uint8_t self) {
    memcpy(pkt, "LILA", 4);
    pkt[4] = WIRE_VERSION; pkt[5] = type; pkt[6] = self; pkt[7] = 0;
}

static void udp_send_input(udp_t *u, uint32_t frame, uint32_t mask) {
    uint8_t pkt[HDR_LEN + 8];
    make_hdr(pkt, PKT_INPUT, (uint8_t)u->self);
    put_u32(pkt + 8, frame);
    put_u32(pkt + 12, mask);
    udp_broadcast(u, pkt, sizeof pkt);
}

static void udp_send_hash(udp_t *u, uint32_t frame, uint64_t h) {
    uint8_t pkt[HDR_LEN + 12];
    make_hdr(pkt, PKT_HASH, (uint8_t)u->self);
    put_u32(pkt + 8, frame);
    put_u64(pkt + 12, h);
    udp_broadcast(u, pkt, sizeof pkt);
}

static void udp_hello_to(udp_t *u, const struct sockaddr_in *to) {
    uint8_t pkt[HDR_LEN];
    make_hdr(pkt, PKT_HELLO, (uint8_t)u->self);
    udp_send_to(u, to, pkt, HDR_LEN);
}

/* Pin a slot's address on first contact (first-wins: slot migration would
 * be a protocol change — see header). */
static void udp_learn(udp_t *u, int player, const struct sockaddr_in *from) {
    if (player < 0 || player >= PLAYERS || player == u->self) return;
    if (u->peer[player].last_seen == 0) {
        char ip[INET_ADDRSTRLEN] = "?";
        inet_ntop(AF_INET, &from->sin_addr, ip, sizeof ip);
        printf("lilanet_udp: player %d @ %s:%d joined\n",
               player, ip, (int)ntohs(from->sin_port));
        u->peer[player].addr = *from;
    }
    u->peer[player].last_seen = u->tick;
}

/* Non-blocking drain of everything the wire has right now. Fills the
 * arrivals/remote-mask tables and runs the gossip desync cross-check. */
static void udp_pump(udp_t *u,
                     uint8_t  *arrived,       /* [PLAYERS][FRAMES_RUN]       */
                     uint32_t *remote_mask,   /* [PLAYERS][FRAMES_RUN] truth */
                     uint64_t *our_hash,      /* our committed frame hashes  */
                     uint64_t *desyncs) {
    uint8_t buf[MAX_DGRAM];
    for (;;) {
        struct pollfd pf = { .fd = u->sock, .events = POLLIN, .revents = 0 };
        if (poll(&pf, 1, 0) != 1) return;            /* nothing more this tick */
        struct sockaddr_in from; socklen_t flen = sizeof from;
        ssize_t n = recvfrom(u->sock, buf, sizeof buf, 0,
                             (struct sockaddr *)&from, &flen);
        if (n < 0) return;                           /* EAGAIN / EINTR: done   */
        if (n < HDR_LEN || memcmp(buf, "LILA", 4) != 0 || buf[4] != WIRE_VERSION)
            continue;                                /* junk on the wire       */
        u->recvd++;
        int p = buf[6];
        if (p < 0 || p >= PLAYERS || p == u->self) continue;   /* slot spoof  */
        udp_learn(u, p, &from);
        uint32_t frame = get_u32(buf + 8);
        if (frame >= FRAMES_RUN) continue;
        switch (buf[5]) {
        case PKT_INPUT:
            if (n < HDR_LEN + 8) continue;
            arrived[(size_t)p * FRAMES_RUN + frame] = 1;
            remote_mask[(size_t)p * FRAMES_RUN + frame] = get_u32(buf + 12);
            break;
        case PKT_HASH:
            if (n < HDR_LEN + 12) continue;
            /* desync detector: a frame we committed must hash exactly like
             * every peer's gossip for that frame (determinism, deployed).
             * our_hash[f] == 0 means "not committed / frame 0 sentinel" —
             * wyhash never emits 0 for a real state in practice. */
            if (our_hash[frame] != 0) {
                uint64_t theirs = get_u64(buf + 12);
                if (theirs != our_hash[frame]) {
                    if (*desyncs < 5)
                        fprintf(stderr, "lilanet_udp: DIVERGENCE frame %u vs player %d "
                                        "(theirs %016llx ours %016llx)\n", frame, p,
                                (unsigned long long)theirs,
                                (unsigned long long)our_hash[frame]);
                    (*desyncs)++;
                }
            }
            break;
        default:
            break;                                   /* hello: learned above   */
        }
    }
}

/* ---------------- address parsing ---------------- */

static int parse_endpoint(const char *s, struct sockaddr_in *out) {
    char host[256];
    const char *colon = strrchr(s, ':');
    if (!colon || (size_t)(colon - s) >= sizeof host) return -1;
    memcpy(host, s, (size_t)(colon - s));
    host[colon - s] = 0;
    int port = atoi(colon + 1);
    if (port <= 0 || port > 65535) return -1;

    memset(out, 0, sizeof *out);
    out->sin_family = AF_INET;
    out->sin_port = htons((uint16_t)port);
    if (inet_pton(AF_INET, host, &out->sin_addr) == 1) return 0;
    struct addrinfo hints = { .ai_family = AF_INET, .ai_socktype = SOCK_DGRAM }, *res = NULL;
    if (getaddrinfo(host, NULL, &hints, &res) != 0 || !res) return -1;
    out->sin_addr = ((struct sockaddr_in *)res->ai_addr)->sin_addr;
    freeaddrinfo(res);
    return 0;
}

/* ---------------- the client (structurally = lilanet.c run_client) --------
 * Steps 3-5 (commit boundary, dirty scan, rollback, advance) are the same
 * algorithm as the reference client; only the wire feeding steps 1-2 and
 * the verification source differ (gossip instead of a precomputed chain). */

static int run_client(udp_t *u, uint32_t sim_lag) {
    /* ---------------- snapshot ring (identical to lilanet.c) -------------- */
    uintptr_t snap_sz = lila_snapshot_size();
    uintptr_t dmax = lila_delta_max();
    uint8_t *base = malloc(snap_sz);
    uint8_t *deltas = calloc(RING, dmax);
    uintptr_t dlen[RING];
    uint32_t ring_frame[RING];
    uint8_t ring_valid[RING];   /* 1 = frame simulated under FULL truth */
    for (int i = 0; i < RING; i++) { dlen[i] = 0; ring_frame[i] = 0; ring_valid[i] = 0; }
    if (lila_snapshot_save(base, snap_sz) != 0) { fprintf(stderr, "base save failed\n"); return 1; }

    /* ---------------- client state (identical to lilanet.c) --------------- */
    uint8_t  *arrived     = calloc((size_t)PLAYERS * FRAMES_RUN, 1);
    uint32_t *remote_mask = calloc((size_t)PLAYERS * FRAMES_RUN, sizeof(uint32_t));
    uint8_t  *simulated   = calloc(FRAMES_RUN, 1);
    uint8_t  *was_pred    = calloc(FRAMES_RUN, 1);
    uint32_t *sim_remote  = calloc(FRAMES_RUN, sizeof(uint32_t));
    uint64_t *our_hash    = calloc(FRAMES_RUN, sizeof(uint64_t));
    uint32_t head = 0, commit_ptr = 0;

    uint64_t rollbacks = 0, resim_frames = 0, skipped_correct = 0, predicted = 0;
    uint64_t desyncs = 0, hellos = 0;
    double rb_ns_total = 0, rb_ns_max = 0;
    int16_t pcm[735];

    uint64_t t0_all = now_ns();
    uint64_t next_tick = now_ns();
    uint32_t sent_upto = 0;         /* local inputs pushed to the wire       */
    uint32_t last_gossiped = 0;     /* newest committed frame we gossiped    */

    for (;;) {
        sleep_until(next_tick);
        next_tick += 16666666ull;                   /* 1/60 s in nanoseconds */
        u->tick++;

        /* ---- 1. push OUR input for frames whose window opened. The fake
         *      transport modelled this as arrive_at(p,f) = f + jitter; here
         *      the jitter IS the network. We send ahead of the sim head by
         *      MAX_DELAY+2 frames so late-but-in-budget inputs still land
         *      before their frame is simulated. ------------------------- */
        while (sent_upto < head + MAX_DELAY + 2 && sent_upto < FRAMES_RUN) {
            udp_send_input(u, sent_upto, local_input(sent_upto));
            sent_upto++;
        }
        /* join rule: hello the configured endpoints once per second until
         * every one of them has answered (cheap: 12 B/s while joining). */
        if (u->n_boot > 0 && u->tick % GOSSIP_PERIOD == 0) {
            int online = 0;
            for (int p = 0; p < PLAYERS; p++)
                if (p != u->self && peer_online(u, p)) online++;
            if (online < u->n_boot)
                for (int b = 0; b < u->n_boot; b++) { udp_hello_to(u, &u->boot[b]); hellos++; }
        }

        /* ---- 2. receive: truths + gossip land in the tables ------------- */
        udp_pump(u, arrived, remote_mask, our_hash, &desyncs);

        /* ---- 3. commit boundary: first frame missing any KNOWN peer's
         *      truth (never-heard peers are predicted through — join
         *      anytime; dead peers expire via PEER_TIMEOUT) -------------- */
        while (commit_ptr < FRAMES_RUN) {
            int missing = 0;
            for (uint32_t p = 0; p < PLAYERS && !missing; p++) {
                if (p == (uint32_t)u->self) continue;
                if (peer_online(u, (int)p) &&
                    !arrived[(size_t)p * FRAMES_RUN + commit_ptr]) missing = 1;
            }
            if (missing) break;
            commit_ptr++;
        }

        /* ---- 4. dirty scan (identical to lilanet.c) --------------------- */
        uint32_t first_dirty = UINT32_MAX;
        {
            uint32_t scan_from = head > MAX_DELAY + 2 ? head - (MAX_DELAY + 2) : 0;
            for (uint32_t fr = scan_from; fr < head && fr < FRAMES_RUN; fr++) {
                if (!simulated[fr]) continue;
                uint32_t truth_mask = 0;
                int missing = 0;
                for (uint32_t p = 0; p < PLAYERS; p++) {
                    if (p == (uint32_t)u->self) continue;
                    if (arrived[(size_t)p * FRAMES_RUN + fr])
                        truth_mask |= remote_mask[(size_t)p * FRAMES_RUN + fr];
                    else if (peer_online(u, (int)p)) missing = 1;
                }
                if (missing) continue;
                if (sim_remote[fr] != truth_mask) { first_dirty = fr; break; }
                if (was_pred[fr]) { was_pred[fr] = 0; skipped_correct++; }
            }
        }

        if (head >= FRAMES_RUN && commit_ptr >= FRAMES_RUN) break;

        if (first_dirty != UINT32_MAX) {
            /* ---- ROLLBACK: identical restore + resim. No per-frame oracle
             *      here — determinism carries identical inputs to identical
             *      state, and the gossip cross-check is the alarm. -------- */
            int rb = -1;
            for (int i = 0; i < RING; i++)
                if (ring_valid[i] && ring_frame[i] < first_dirty)
                    if (rb < 0 || ring_frame[i] > ring_frame[rb]) rb = i;

            uint64_t t0 = now_ns();
            uint32_t from_f;
            if (rb >= 0) {
                int32_t rf = lila_delta_load(base, snap_sz,
                                    deltas + (size_t)rb * dmax, dlen[rb]);
                if (rf < 0) { fprintf(stderr, "FATAL: delta restore failed\n"); return 1; }
                from_f = (uint32_t)rf;
            } else {
                if (lila_snapshot_load(base, snap_sz) < 0) {
                    fprintf(stderr, "FATAL: base restore failed\n"); return 1;
                }
                from_f = 0;
            }
            rollbacks++;

            for (uint32_t fr = from_f; fr < head; fr++) {
                uint32_t mask = local_input(fr);      /* local: always truth */
                uint32_t rmask = 0;
                for (uint32_t p = 0; p < PLAYERS; p++) {
                    if (p == (uint32_t)u->self) continue;
                    if (arrived[(size_t)p * FRAMES_RUN + fr])
                        rmask |= remote_mask[(size_t)p * FRAMES_RUN + fr];
                }
                mask |= rmask;
                lila_input_set(mask);
                lila_frame();
                lila_audio_fill(pcm, 735);
                sim_remote[fr] = rmask;
                int truth_upto = fr < commit_ptr;
                was_pred[fr] = truth_upto ? 0 : 1;
                if (truth_upto) our_hash[fr] = lila_state_hash(fr);
                int slot = fr % RING;
                dlen[slot] = lila_delta_save(base, snap_sz,
                                             deltas + (size_t)slot * dmax, dmax);
                ring_frame[slot] = fr;
                ring_valid[slot] = (uint8_t)truth_upto;
            }
            double dt = (double)(now_ns() - t0);
            rb_ns_total += dt;
            if (dt > rb_ns_max) rb_ns_max = dt;
            resim_frames += head - from_f;
            continue;                    /* re-evaluate deliveries on the restored timeline */
        }

        /* ---- 5. advance (identical to lilanet.c) ------------------------ */
        if (head < FRAMES_RUN && (int32_t)(u->tick - head) >= (int32_t)sim_lag + 1) {
            uint32_t mask = local_input(head);
            uint32_t rmask = 0;
            for (uint32_t p = 0; p < PLAYERS; p++) {
                if (p == (uint32_t)u->self) continue;
                if (arrived[(size_t)p * FRAMES_RUN + head])
                    rmask |= remote_mask[(size_t)p * FRAMES_RUN + head];
            }
            mask |= rmask;
            lila_input_set(mask);
            lila_frame();
            lila_audio_fill(pcm, 735);
            sim_remote[head] = rmask;
            int truth_upto = head < commit_ptr;
            was_pred[head] = truth_upto ? 0 : 1;
            if (truth_upto) our_hash[head] = lila_state_hash(head);
            else predicted++;
            simulated[head] = 1;
            int slot = head % RING;
            dlen[slot] = lila_delta_save(base, snap_sz,
                                         deltas + (size_t)slot * dmax, dmax);
            ring_frame[slot] = head;
            ring_valid[slot] = (uint8_t)truth_upto;
            head++;
        }

        /* ---- 6. hash gossip: newest committed frame, once per period ---- */
        if (commit_ptr > 0 && last_gossiped < commit_ptr - 1) {
            last_gossiped = commit_ptr - 1;
            if (our_hash[last_gossiped])
                udp_send_hash(u, last_gossiped, our_hash[last_gossiped]);
        }
    }

    /* ---------------- report ---------------- */
    uint64_t t_all = now_ns() - t0_all;
    int configured_online = 0;
    for (int p = 0; p < PLAYERS; p++)
        if (p != u->self && peer_online(u, p)) configured_online++;
    uint64_t lost = 0;
    for (uint32_t p = 0; p < PLAYERS; p++) {
        if (p == (uint32_t)u->self) continue;
        if (!peer_online(u, (int)p)) { lost += FRAMES_RUN; continue; }
        for (uint32_t fr = 0; fr < FRAMES_RUN; fr++)
            if (!arrived[(size_t)p * FRAMES_RUN + fr]) lost++;
    }

    printf("\n== lilanet_udp [slot %d]: rollback client, %u frames (%.0fs), lag %u ==\n",
           u->self, FRAMES_RUN, FRAMES_RUN / 60.0, sim_lag);
    printf("peers:             %d online of %d configured (%llu hellos sent)\n",
           configured_online, u->n_boot, (unsigned long long)hellos);
    printf("predicted frames:  %llu (%.1f%% ran ahead on remote guesses)\n",
           (unsigned long long)predicted, 100.0 * predicted / FRAMES_RUN);
    printf("free rollbacks:    %llu predictions that arrived correct (cost 0)\n",
           (unsigned long long)skipped_correct);
    printf("rollbacks:         %llu events, %llu frames re-simulated\n",
           (unsigned long long)rollbacks, (unsigned long long)resim_frames);
    if (rollbacks)
        printf("rollback cost:     mean %.3f ms / worst %.3f ms (restore + resim + hash)\n",
               rb_ns_total / (double)rollbacks / 1e6, rb_ns_max / 1e6);
    printf("divergences:       %llu (hash-gossip cross-check%s)\n",
           (unsigned long long)desyncs, desyncs ? " — INVESTIGATE" : ": clean");
    printf("wire:              %llu datagrams sent, %llu received; "
           "%llu player-frames of input never arrived (predicted through)\n",
           (unsigned long long)u->sent, (unsigned long long)u->recvd,
           (unsigned long long)lost);
    printf("whole run:         %.1f ms wall for %.0fs of play at 60 Hz pacing\n",
           (double)t_all / 1e6, FRAMES_RUN / 60.0);

    free(arrived); free(remote_mask); free(simulated); free(was_pred);
    free(sim_remote); free(our_hash); free(base); free(deltas);
    return desyncs == 0 ? 0 : 1;
}

/* ---------------- main ----------------
 * usage: lilanet_udp <game.libyte> <local_port> <player_slot> \
 *                    [peer.host:port ...] [--lag N]
 * Exactly one process per player slot; every process lists every OTHER
 * player's host:port. Run the referee harness against these. */

int main(int argc, char **argv) {
    if (argc < 4) {
        fprintf(stderr, "usage: %s <game.libyte> <local_port> <player_slot> "
                        "[peer.host:port ...] [--lag N]\n", argv[0]);
        return 2;
    }
    uint32_t sim_lag = 4;                     /* the broadband client default */
    int self = atoi(argv[3]);
    if (self < 0 || self >= PLAYERS) {
        fprintf(stderr, "player slot must be 0..%d\n", PLAYERS - 1);
        return 2;
    }

    FILE *f = fopen(argv[1], "rb");
    if (!f) { perror("open cartridge"); return 1; }
    fseek(f, 0, SEEK_END);
    long len = ftell(f);
    fseek(f, 0, SEEK_SET);
    uint8_t *blob = malloc((size_t)len);
    if (fread(blob, 1, (size_t)len, f) != (size_t)len) { perror("read"); return 1; }
    fclose(f);

    udp_t u;
    memset(&u, 0, sizeof u);
    u.sock = -1;
    u.self = self;

    for (int a = 4; a < argc; a++) {
        if (strcmp(argv[a], "--lag") == 0) {
            if (a + 1 < argc) sim_lag = (uint32_t)atoi(argv[++a]);
            continue;
        }
        if (u.n_boot >= PLAYERS) { fprintf(stderr, "too many peers (max %d)\n", PLAYERS - 1); return 2; }
        if (parse_endpoint(argv[a], &u.boot[u.n_boot]) != 0) {
            fprintf(stderr, "bad endpoint '%s' (host:port)\n", argv[a]);
            return 2;
        }
        u.n_boot++;
    }

    struct sockaddr_in me;
    memset(&me, 0, sizeof me);
    me.sin_family = AF_INET;
    me.sin_addr.s_addr = htonl(INADDR_ANY);
    me.sin_port = htons((uint16_t)atoi(argv[2]));
    u.sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (u.sock < 0) { perror("socket"); return 1; }
    if (bind(u.sock, (struct sockaddr *)&me, sizeof me) != 0) { perror("bind"); return 1; }

    if (lila_init(blob, len) != 0) {
        fprintf(stderr, "lila_init failed: %d\n", lila_last_error());
        return 1;
    }
    printf("lilanet_udp: slot %d on :%d — %s (abi %d, engine %d), lag %u frame(s)\n",
           u.self, atoi(argv[2]), argv[1], lila_abi_version(), lila_engine_version(),
           sim_lag);

    int rc = run_client(&u, sim_lag);
    free(blob);
    close(u.sock);
    return rc;
}
