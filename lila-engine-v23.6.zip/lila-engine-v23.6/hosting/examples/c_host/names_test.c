// v20 ABI-4 reflection smoke: load a reflection cartridge, dump names.
#include <stdio.h>
#include <string.h>
#include "lila.h"

int main(int argc, char **argv) {
    if (argc < 2) { fprintf(stderr, "usage: names_test <game.libyte>\n"); return 2; }
    FILE *f = fopen(argv[1], "rb");
    if (!f) { perror("open"); return 2; }
    static unsigned char buf[1 << 20];
    size_t n = fread(buf, 1, sizeof buf, f);
    fclose(f);

    if (lila_init(buf, (int)n) != 0) {
        fprintf(stderr, "lila_init failed: %d\n", lila_last_error());
        return 1;
    }
    printf("abi=%d engine=%d mem_mb=%d\n", lila_abi_version(), lila_engine_version(), lila_mem_mb());
    printf("entities=%d tfs=%d pools=%d\n",
           lila_entity_types(), lila_tf_count(), lila_pool_count());



    char name[256];
    for (int t = 0; t < lila_entity_types(); t++) {
        int len = lila_name(0, t, 0, name, sizeof name);
        if (len >= 0) { name[len < 255 ? len : 255] = 0; printf("entity[%d]=%s\n", t, name); }
    }
    for (int tf = 0; tf < lila_tf_count() && tf < 8; tf++) {
        int len = lila_name(1, tf, 0, name, sizeof name);
        if (len >= 0) { name[len < 255 ? len : 255] = 0; printf("tf[%d]=%s\n", tf, name); }
    }
    for (int p = 0; p < lila_pool_count(); p++) {
        int len = lila_name(3, p, 0, name, sizeof name);
        if (len >= 0) {
            name[len < 255 ? len : 255] = 0;
            printf("pool[%d]=%s cap=%d len=%d\n", p, name, lila_pool_cap(p), lila_pool_len(p));
        }
        for (int fl = 0; fl < 4; fl++) {
            int flen = lila_name(4, p, fl, name, sizeof name);
            if (flen >= 0) { name[flen < 255 ? flen : 255] = 0; printf("  .%s\n", name); }
        }
    }
    return 0;
}
