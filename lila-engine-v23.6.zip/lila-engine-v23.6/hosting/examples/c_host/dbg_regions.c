/* dbg_regions.c — where do delta words actually live? */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include "lila.h"

#define SPF 735

static uint32_t input_for(uint32_t f) {
    uint32_t m = 0;
    switch ((f / 30) % 4) {
        case 0: m |= 1; break; case 1: m |= 2; break;
        case 2: m |= 4; break; default: m |= 8; break;
    }
    if (f % 18 == 0) m |= 16;
    return m;
}

int main(int argc, char **argv) {
    size_t bl; uint8_t *blob = malloc(1 << 20);
    FILE *f = fopen(argv[1], "rb");
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    if (fread(blob, 1, n, f) != (size_t)n) return 2; bl = n; fclose(f);
    if (lila_init(blob, bl)) return 1;

    const size_t ssz = lila_snapshot_size();
    uint8_t *base = malloc(ssz), *delta = malloc(lila_delta_max());
    int16_t pcm[SPF];

    for (uint32_t fr = 0; fr < 100; fr++) {
        lila_input_set(input_for(fr)); lila_frame(); lila_audio_fill(pcm, SPF);
    }
    lila_snapshot_save(base, ssz);

    /* 2-frame delta */
    for (uint32_t fr = 100; fr < 102; fr++) {
        lila_input_set(input_for(fr)); lila_frame(); lila_audio_fill(pcm, SPF);
    }
    size_t dn = lila_delta_save(base, ssz, delta, lila_delta_max());
    printf("2-frame delta: %zu B\n", dn);
    uint32_t nreg = delta[12] | (delta[13] << 8) | ((uint32_t)delta[14] << 16) | ((uint32_t)delta[15] << 24);
    size_t off = 32;
    printf("  regions: %u\n", nreg);
    for (uint32_t i = 0; i < nreg && i < 40; i++) {
        uint32_t start = delta[off] | (delta[off+1] << 8) | ((uint32_t)delta[off+2] << 16) | ((uint32_t)delta[off+3] << 24);
        uint32_t count = delta[off+4] | (delta[off+5] << 8) | ((uint32_t)delta[off+6] << 16) | ((uint32_t)delta[off+7] << 24);
        printf("    word[%u..%u) bytes [%#x..%#x) count=%u\n",
               start, start + count, start * 4, (start + count) * 4, count);
        off += 8 + (size_t)count * 4;
    }

    /* mirror hostopt_test exactly: base + 60f + delta restore + 40f replay
     * + history start + 2 frames — then measure the ring-style delta */
    for (uint32_t fr = 100; fr < 160; fr++) {
        lila_input_set(input_for(fr)); lila_frame(); lila_audio_fill(pcm, SPF);
    }
    uint8_t *d2 = malloc(lila_delta_max());
    size_t dn2 = lila_delta_save(base, ssz, d2, lila_delta_max());
    printf("test-mirror 60f delta: %zu B\n", dn2);
    printf("delta_load -> %d\n", lila_delta_load(base, ssz, d2, dn2));
    for (uint32_t fr = 160; fr < 200; fr++) {
        lila_input_set(input_for(fr)); lila_frame(); lila_audio_fill(pcm, SPF);
    }
    printf("tick now %u\n", lila_tick());
    lila_history_start(512);
    uint8_t *ringbase = malloc(ssz);
    lila_snapshot_save(ringbase, ssz);   /* what key@abs0 SHOULD contain */
    for (uint32_t fr = 200; fr < 202; fr++) {
        lila_input_set(input_for(fr)); lila_frame(); lila_audio_fill(pcm, SPF);
    }
    /* delta of current vs the state at tick 200 (the key) */
    dn2 = lila_delta_save(ringbase, ssz, d2, lila_delta_max());
    printf("ring-style 2-frame delta: %zu B\n", dn2);
    /* and WITHOUT audio pulls (what the ring actually sees if audio were
     * skipped — it shouldn't be, the test pulls every frame) */
    lila_history_seek(201);
    for (uint32_t fr = 200; fr < 202; fr++) {
        lila_input_set(input_for(fr)); lila_frame();
        if (fr == 200) lila_audio_fill(pcm, SPF);   /* skip one pull */
    }
    dn2 = lila_delta_save(ringbase, ssz, d2, lila_delta_max());
    printf("no-audio-pull 2-frame delta: %zu B  (audio phase skipped = churn)\n", dn2);
    return 0;
}
