/* ============================================================================
 * hostopt_test — verifies the v17.2 host services against the hash chain:
 *
 *   1. BATCHES  — batch table covers every vert exactly once; grouped
 *                 verts are a multiset-equal permutation of the raw stream;
 *                 batches are in first-appearance (painter) order; within
 *                 a batch the verts keep original order (additive-blend
 *                 correctness).
 *   2. MANIFEST — sprite table is exposed with sane contents.
 *   3. DELTAS   — full save @100, delta @160 (vs base), restore:
 *                 the engine state hash must equal the recorded chain
 *                 value for frame 160. Chain of deltas also verified.
 *   4. HISTORY  — run 3000 frames recording every hash; seek to scattered
 *                 past frames; after each seek the hash matches and the
 *                 timeline replays identically. External snapshot_load
 *                 (host rollback) must reset the ring, not corrupt it.
 *   5. NEGATIVES — corrupt magics rejected; seek to unbuffered frames -1.
 *
 * Exit code 0 = all green. Any FAIL line = abort.
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "lila.h"

#define SPF 735
#define MAXF 4096

static int failures = 0;
#define CHECK(cond, ...) do { \
    if (!(cond)) { printf("FAIL: " __VA_ARGS__); printf("  (%s:%d)\n", __FILE__, __LINE__); \
                   if (++failures > 5) exit(1); } \
} while (0)

static uint32_t input_for(uint32_t f) {
    uint32_t m = 0;
    switch ((f / 30) % 4) {
        case 0: m |= 0x1; break; case 1: m |= 0x2; break;
        case 2: m |= 0x4; break; default: m |= 0x8; break;
    }
    if (f % 18 == 0) m |= 0x10;
    return m;
}

static uint8_t *read_file(const char *p, size_t *n) {
    FILE *f = fopen(p, "rb");
    if (!f) { fprintf(stderr, "open %s\n", p); exit(2); }
    fseek(f, 0, SEEK_END); long l = ftell(f); fseek(f, 0, SEEK_SET);
    uint8_t *b = malloc(l); if (fread(b, 1, l, f) != (size_t)l) exit(2); fclose(f);
    *n = l; return b;
}

/* FNV-1a over one 14B vert — multiset check by sum of hashes */
static uint64_t vert_hash(const uint8_t *v) {
    uint64_t h = 1469598103934665603ull;
    for (int i = 0; i < 14; i++) { h ^= v[i]; h *= 1099511628211ull; }
    return h;
}

int main(int argc, char **argv) {
    if (argc < 2) { fprintf(stderr, "usage: hostopt_test <game.libyte>\n"); return 2; }
    size_t bl; uint8_t *blob = read_file(argv[1], &bl);
    if (lila_init(blob, bl) != 0) { printf("init failed err=%d\n", lila_last_error()); return 1; }
    printf("boot abi=%d engine=%d\n", lila_abi_version(), lila_engine_version());
    CHECK(lila_abi_version() >= 2, "ABI >= 2 required, got %d", lila_abi_version());

    static uint64_t hashes[MAXF];
    static int16_t pcm[SPF];
    const size_t ssz = lila_snapshot_size();
    uint8_t *base = malloc(ssz);

    /* ---------------- run to 100 frames (steady state) ---------------- */
    for (uint32_t f = 0; f < 100; f++) {
        lila_input_set(input_for(f)); lila_frame(); lila_audio_fill(pcm, SPF);
        if (f < MAXF) hashes[f] = lila_state_hash(f);
    }

    /* ================= 1. BATCHES ================= */
    {
        int32_t nb = 0;
        const LilaBatch *bs = lila_stream_batches(&nb);
        const int32_t n = lila_stream_count();
        const uint8_t *raw = lila_stream_ptr();
        const uint8_t *sorted = lila_stream_sorted_ptr();
        printf("batches: %d verts -> %d batches\n", n, nb);
        CHECK(nb > 0, "expected batches, got 0 (stream has %d verts)", n);

        uint32_t cover = 0;
        uint64_t sum_sorted = 0, sum_raw = 0;
        uint16_t prev_tok = 0;
        int first_seen[65536]; memset(first_seen, 0xFF, sizeof first_seen);
        int order_ok = 1, stable_ok = 1;
        for (int32_t b = 0; b < nb; b++) {
            cover += bs[b].count;
            /* tokens within a batch must all equal the batch token */
            for (uint32_t k = 0; k < bs[b].count; k++) {
                uint16_t t = (uint16_t)(sorted[(bs[b].first + k) * 14 + 12] |
                                       (sorted[(bs[b].first + k) * 14 + 13] << 8));
                if (t != bs[b].token) stable_ok = 0;
                if (k > 0 && t != prev_tok) stable_ok = 0;
                prev_tok = t;
                sum_sorted += vert_hash(sorted + (size_t)(bs[b].first + k) * 14);
            }
            /* first-appearance order: this token must not have appeared before */
            if (first_seen[bs[b].token] != -1) order_ok = 0;
            first_seen[bs[b].token] = b;
        }
        for (int32_t i = 0; i < n; i++) sum_raw += vert_hash(raw + (size_t)i * 14);
        CHECK(cover == (uint32_t)n, "batches cover %u of %d verts", cover, n);
        CHECK(sum_sorted == sum_raw, "sorted stream is NOT a permutation of raw");
        CHECK(order_ok, "batches not in first-appearance order");
        CHECK(stable_ok, "verts within a batch are not the same token");
        printf("  cover=%u/%d  multiset=%s  painter-order=%s  stable=%s\n",
               cover, n, sum_sorted == sum_raw ? "OK" : "BAD",
               order_ok ? "OK" : "BAD", stable_ok ? "OK" : "BAD");
    }

    /* ================= 2. MANIFEST ================= */
    {
        const int32_t ns = lila_sprite_count();
        printf("manifest: %d sprites\n", ns);
        CHECK(ns > 0, "no sprites exposed");
        for (int32_t i = 0; i < ns; i++) {
            const int32_t nv = lila_sprite_vert_count((uint32_t)i);
            const uint8_t *v = lila_sprite_verts((uint32_t)i);
            CHECK(nv >= 3 && nv <= 128, "sprite %d vert count %d", i, nv);
            CHECK(v != NULL, "sprite %d verts NULL", i);
            /* first vert's rgba must be nonzero (fill/grad color) */
            uint32_t rgba = (uint32_t)v[8] | ((uint32_t)v[9] << 8) |
                            ((uint32_t)v[10] << 16) | ((uint32_t)v[11] << 24);
            CHECK(rgba != 0, "sprite %d vert0 rgba == 0", i);
            printf("  sprite %d: %d verts, vert0 rgba=%08X\n", i, nv, rgba);
        }
        CHECK(lila_sprite_vert_count(9999) == -1, "OOB sprite not rejected");
    }

    /* ================= 3. DELTAS ================= */
    {
        /* snapshot semantics: an image taken when tick()==S restores a state
         * where frames 0..S-1 have run; the matching recorded hash (taken
         * after frame S-1 ran) is hashes[S-1] == lila_state_hash(S-1). */
        CHECK(lila_snapshot_save(base, ssz) == 0, "base save");
        const uint32_t f_base = lila_tick();          /* == 100 */
        for (uint32_t f = f_base; f < 160; f++) {      /* 60 frames */
            lila_input_set(input_for(f)); lila_frame(); lila_audio_fill(pcm, SPF);
            if (f < MAXF) hashes[f] = lila_state_hash(f);
        }
        uint8_t *delta = malloc(lila_delta_max());
        const size_t dn = lila_delta_save(base, ssz, delta, lila_delta_max());
        printf("delta: %zu B for %u frames (vs %zuB full, %.2f%%)\n",
               dn, 160 - f_base, ssz, 100.0 * (double)dn / (double)ssz);
        CHECK(dn > 32 && dn < ssz / 4, "delta size %zu implausible", dn);

        /* run ahead 40 more frames (engine now way past 160) */
        for (uint32_t f = 160; f < 200; f++) {
            lila_input_set(input_for(f)); lila_frame(); lila_audio_fill(pcm, SPF);
            if (f < MAXF) hashes[f] = lila_state_hash(f);
        }
        const int32_t rf = lila_delta_load(base, ssz, delta, dn);
        CHECK(rf == 160, "delta load frame %d (want 160)", rf);
        CHECK(lila_tick() == 160, "tick after delta load %u != 160", lila_tick());
        CHECK(lila_state_hash(rf - 1) == hashes[rf - 1],
              "POST-DELTA HASH MISMATCH: %016llx vs %016llx",
              (unsigned long long)lila_state_hash(rf - 1),
              (unsigned long long)hashes[rf - 1]);
        printf("  restore @tick=%d: hash %016llx == recorded  [OK]\n",
               rf, (unsigned long long)lila_state_hash(rf - 1));

        /* replay the tail: chain must stay identical */
        uint32_t bad = 0;
        for (uint32_t f = 160; f < 200; f++) {
            lila_input_set(input_for(f)); lila_frame(); lila_audio_fill(pcm, SPF);
            if (lila_state_hash(f) != hashes[f]) bad++;
        }
        CHECK(bad == 0, "tail replay after delta load diverged (%u)", bad);
        printf("  tail replayed 40 frames clean\n");

        /* negative: corrupt magic */
        delta[0] ^= 0xFF;
        CHECK(lila_delta_load(base, ssz, delta, dn) == -1, "corrupt delta accepted");
        delta[0] ^= 0xFF;
        free(delta);
    }

    /* ================= 4. HISTORY RING ================= */
    {
        CHECK(lila_history_start(512) == 512, "history start");
        CHECK(lila_history_frames() == 0, "history not empty at start");
        /* rebuild a clean recorded timeline: 1200 frames from current point */
        const uint32_t f0 = lila_tick();
        for (uint32_t f = f0; f < f0 + 1200; f++) {
            lila_input_set(input_for(f)); lila_frame(); lila_audio_fill(pcm, SPF);
            if (f < MAXF) hashes[f] = lila_state_hash(f);
        }
        CHECK(lila_history_frames() >= 448 && lila_history_frames() <= 512, "ring fill %d out of [448,512]", lila_history_frames());
        const int32_t hb = lila_history_begin();
        printf("history: 512 buffered, oldest frame %d (ran to %u)\n", hb, lila_tick());
        CHECK(hb >= 0, "history begin -1");

        /* seek to scattered buffered frames; each must hash-match and
         * replay identically through the end */
        const uint32_t targets[4] = {
            (uint32_t)hb, (uint32_t)hb + 300,
            (uint32_t)(lila_tick() - 1), (uint32_t)(lila_tick() - 200),
        };
        for (int t = 0; t < 4; t++) {
            const int32_t rf = lila_history_seek(targets[t]);
            CHECK(rf == (int32_t)targets[t], "seek(%u) -> %d", targets[t], rf);
            CHECK(lila_tick() == targets[t], "tick after seek %u != %u",
                  lila_tick(), targets[t]);
            /* state with counter X == frames 0..X-1 done == hash(X-1) */
            CHECK(lila_state_hash(targets[t] - 1) == hashes[targets[t] - 1],
                  "SEEK HASH MISMATCH @tick=%u", targets[t]);
            /* replay to the end: the whole tail must reproduce */
            uint32_t bad = 0;
            for (uint32_t f = targets[t]; f < f0 + 1200; f++) {
                lila_input_set(input_for(f)); lila_frame(); lila_audio_fill(pcm, SPF);
                if (lila_state_hash(f) != hashes[f]) { bad++; if (bad > 3) break; }
            }
            CHECK(bad == 0, "replay after seek diverged (%u frames)", bad);
            printf("  seek(tick=%u) hash OK, tail replayed %u frames clean\n",
                   targets[t], f0 + 1200 - targets[t]);
        }

        /* external rollback (host snapshot_load) must reset the ring, and
         * the post-restore determinism must hold: restore the SAME image
         * twice, run the same frame twice, hashes must match each other */
        uint8_t *snap = malloc(ssz);
        CHECK(lila_snapshot_save(snap, ssz) == 0, "ext save");
        for (int i = 0; i < 30; i++) { lila_input_set(input_for(9000+i)); lila_frame(); lila_audio_fill(pcm, SPF); }
        CHECK(lila_snapshot_load(snap, ssz) >= 0, "ext load");
        const uint32_t fnow = lila_tick();
        uint64_t run[2];
        for (int r = 0; r < 2; r++) {
            CHECK(lila_snapshot_load(snap, ssz) >= 0, "ext load r%d", r);
            lila_input_set(input_for(fnow)); lila_frame(); lila_audio_fill(pcm, SPF);
            run[r] = lila_state_hash(fnow);
            /* jump back to the saved state again for the next round */
            CHECK(lila_snapshot_load(snap, ssz) >= 0, "ext reload r%d", r);
        }
        CHECK(run[0] == run[1], "post-rollback determinism broken: %016llx vs %016llx",
              (unsigned long long)run[0], (unsigned long long)run[1]);
        printf("  external snapshot_load: ring reset, double-restore hash %016llx stable\n",
               (unsigned long long)run[0]);
        free(snap);

        /* negative: unbuffered frame */
        CHECK(lila_history_seek(0) == -1, "seek to frame 0 accepted");
        lila_history_stop();
    }

    printf(failures == 0 ? "ALL HOSTOPT TESTS PASSED\n" : "%d FAILURES\n", failures);
    free(base); free(blob);
    return failures == 0 ? 0 : 1;
}
