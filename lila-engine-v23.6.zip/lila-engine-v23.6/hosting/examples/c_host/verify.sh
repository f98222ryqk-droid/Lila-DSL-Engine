#!/usr/bin/env bash
# ============================================================================
# verify.sh — the Host SDK proof, one command.
#
# What it proves (all must be green or the script fails):
#   1. liblila_c builds (shared + static) from the same runtime the runner uses
#   2. c_host replays a runner-recorded LIR1 movie through the C ABI:
#      300/300 hash chain + snapshot rollback roundtrip
#   3. the C host's audio path is BYTE-IDENTICAL to the native runner's WAV
#   4. v23: lilac --emit-bridges generates LilaInterop.h, the C host compiles
#      it, and the pointer-overlay ABI holds: layout hash match, in-place
#      lane scatter, install refusal on stale layouts, tick_pipeline +
#      spawn_from, and a 60/60 hash chain identical with/without overlays
#
# Usage: hosting/examples/c_host/verify.sh        (from anywhere)
# ============================================================================
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$HERE/../../.." && pwd)"
RUNTIME="$ROOT/runtime"
DEMO="$ROOT/demo"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

# zig: env override > toolchain dir > PATH (fail loudly)
if [[ -n "${ZIG:-}" ]]; then :
elif [[ -x "$HOME/.zigtool/zig" ]]; then ZIG="$HOME/.zigtool/zig"
elif command -v zig >/dev/null 2>&1; then ZIG="$(command -v zig)"
else echo "ERROR: zig not found (set ZIG= or install to ~/.zigtool)"; exit 1; fi
echo "zig: $ZIG"

# lilac: build if the binary is missing (the compiler is untouched by the SDK)
LILAC="$ROOT/compiler/target/release/lilac"
if [[ ! -x "$LILAC" ]]; then
  echo "== building lilac (rust, release) =="
  (cd "$ROOT/compiler" && cargo build --release)
fi

# 1. build the host library (same engine core as the runner)
#    -lc is REQUIRED: the VM state is threadlocal, and without libc Zig
#    emits its freestanding TLS model — which segfaults inside a glibc
#    process (the runner gets away with it only because zig build-exe owns
#    the whole process). With -lc the lib uses proper ELF TLS + pthreads,
#    i.e. exactly what a Unity P/Invoke or Unreal module link expects.
echo "== building liblila_c (.so + PIC .a, ReleaseFast) =="
cd "$RUNTIME"
"$ZIG" build-lib src/lila_c.zig -dynamic -O ReleaseFast -lc -femit-bin=liblila_c.so
"$ZIG" build-lib src/lila_c.zig -O ReleaseFast -lc -fPIC -femit-bin=liblila_c.a

# 2. build the C host against the static lib
echo "== building c_host (cc) =="
cc -O2 -Wall -Wextra -I "$ROOT/hosting/include" \
   "$HERE/main.c" "$RUNTIME/liblila_c.a" -lm -pthread -o "$WORK/c_host"

# 3. compile the demo game + record a movie with the native runner
echo "== compiling demo17 + recording a movie with the native runner =="
"$LILAC" build "$DEMO/demo17.lila" -o "$WORK/game.libyte"
"$ZIG" build-exe src/runner.zig -O ReleaseSafe -femit-bin="$WORK/runner"
cd "$WORK"
./runner game.libyte --frames 300 --record movie.lir >runner.log 2>&1
echo "   (runner log tail: $(tail -n 1 runner.log))"

# 4. replay through the C ABI — hash chain + rollback
echo "== c_host: replay + rollback through liblila_c =="
"$WORK/c_host" game.libyte movie.lir host.wav | tee c_host.log

# 5. audio path byte-compare
echo "== byte-compare: runner game.wav vs c_host host.wav =="
cmp game.wav host.wav
echo "   game.wav == host.wav (byte-identical)"

# 6. v23 pointer-overlay proof: generated bridges + zero-copy ABI through cc
#    (the v23 fixture: deterministic spawns + every lane kind, so the C test
#     can assert exact lane values; demo17 emit above proved generation works
#     on the golden game)
echo "== v23: emit bridges + overlay ABI (overlay_test) =="
"$LILAC" build "$DEMO/demo17.lila" -o "$WORK/game2.libyte" --emit-bridges "$WORK" | grep bridges
"$LILAC" build "$RUNTIME/src/test_v23_fixture.lila" -o "$WORK/v23.libyte" --emit-bridges "$WORK" | grep bridges
cc -O2 -Wall -Wextra -I "$ROOT/hosting/include" -I "$WORK" \
   "$HERE/overlay_test.c" "$RUNTIME/liblila_c.a" -lm -pthread -o "$WORK/overlay_test"
"$WORK/overlay_test" "$WORK/v23.libyte"

echo ""
echo "VERDICT: PASS — the C ABI reproduces the native timeline bit-for-bit."
echo "         (Unity P/Invoke and Unreal module links call this same ABI.)"
