// ============================================================================
// overlay_test.c — v23 POINTER-OVERLAY ABI proof, in the C host's compiler.
// ============================================================================
//
// Compiled by verify.sh against the LilaInterop.h generated from
// runtime/src/test_v23_fixture.lila (--emit-bridges) and linked against the
// same static liblila_c.a the c_host movie replay uses.
//
// The generated structs ARE the test data:
//   - compiling this file proves the C layout (static asserts inside the
//     generated header: exact sizes + every lane offset)
//   - lila_overlay_layout_hash() must equal LILA_INTEROP_LAYOUT_HASH
//   - 5 frames of lila_overlay_tick() must land every lane at the exact
//     value the fixture computes (fixed->f32 exact, s16/f32/int lanes)
//   - lila_overlay_spawn_from() fed a designated-initializer C struct must
//     be lila_field_write/lila_f_to_q-identical (checked via lila_field_read)
//   - the 5-frame wyhash chain must be IDENTICAL with/without overlays
//   - the one-call lila_tick_pipeline() must retarget + tick + flush
// ============================================================================

#include "lila.h"
#include "LilaInterop.h"

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define FRAMES 5

int main(int argc, char **argv)
{
    if (argc < 2) { fprintf(stderr, "usage: overlay_test <test_v23_fixture.libyte>\n"); return 2; }

    /* ---- load cartridge ---- */
    FILE *f = fopen(argv[1], "rb");
    if (!f) { perror("open cartridge"); return 1; }
    static uint8_t blob[256 * 1024];
    size_t len = fread(blob, 1, sizeof blob, f);
    fclose(f);
    if (lila_init(blob, len) != 0) {
        fprintf(stderr, "lila_init failed rc=%d\n", lila_last_error());
        return 1;
    }
    printf("overlay_test: abi=%d engine=%d, %d entity types\n",
           lila_abi_version(), lila_engine_version(), lila_entity_types());

    /* ---- 1. the layout hash pin (runtime vs generated header) ---- */
    assert(lila_overlay_layout_hash() == LILA_INTEROP_LAYOUT_HASH);
    assert(lila_entity_types() == LILA_INTEROP_TYPES);
    /* the emitted static asserts already proved the C sizes; now the
     * runtime's own row math must agree with them */
    assert(lila_overlay_row_bytes(LILA_DRONE_TYPE) == LILA_DRONE_ROW_BYTES);
    assert(lila_overlay_row_bytes(LILA_SPARK_TYPE) == LILA_SPARK_ROW_BYTES);
    printf("overlay_test: layout hash 0x%08X + row sizes match LilaInterop.h\n",
           (unsigned)LILA_INTEROP_LAYOUT_HASH);

    /* ---- 2. install; refuse a stale hash ---- */
    static LilaDroneRow drones[8];
    memset(drones, 0, sizeof drones);
    assert(lila_overlay_install(LILA_DRONE_TYPE, (uint8_t *)drones,
                                sizeof drones[0], 8,
                                LILA_INTEROP_LAYOUT_HASH) == 0);
    assert(lila_overlay_install(LILA_DRONE_TYPE, (uint8_t *)drones,
                                sizeof drones[0], 8, 0xDEADBEEFu) == -2);
    printf("overlay_test: install ok, stale hash refused (-2)\n");

    /* ---- 3. 5 frames with the flush riding along ---- */
    static uint64_t chain_a[FRAMES];
    static int16_t pcm[735];
    for (int fr = 0; fr < FRAMES; fr++) {
        lila_input_set(0);
        lila_overlay_tick();
        lila_audio_fill(pcm, 735);
        chain_a[fr] = lila_state_hash((uint32_t)fr);
    }

    /* ---- 4. every lane, at the exact fixture values ----
     * drone 0: x=10.0 y=20.0 vx=0.5 vy=1.5 heat=-300 wf=1.5f kind=5 armed=1;
     * per frame x += vx happens in update AND in v7 auto-integration
     * (x += 1.0/frame, y += 3.0/frame — deliberately twice-integrated). */
    assert(drones[0].lila_meta & 1u);
    assert(((drones[0].lila_meta >> 4) & 0xFFFu) == (uint32_t)lila_gen(0, 0));
    assert(drones[0].x == 15.0f);
    assert(drones[0].y == 35.0f);
    assert(drones[0].vx == 0.5f);
    assert(drones[0].vy == 1.5f);
    assert(drones[0].heat == -300);
    assert(drones[0].hp == 9);
    assert(drones[0].wf == 1.5f);
    assert(drones[0].kind == 5);
    assert(drones[0].armed == 1);
    assert(drones[0].spin == 0);
    /* drone 1 (defaults): x=30.0 vx=0.25 -> 30 + 5*0.5 */
    assert(drones[1].x == 32.5f);
    assert(drones[1].hp == 9);
    assert(lila_overlay_written(LILA_DRONE_TYPE) == 2);
    printf("overlay_test: all lanes exact (fixed->f32, s16, u8/u3/bool/ang, f32 bits)\n");

    /* ---- 5. spawn_from: a designated-initializer C struct goes in,
     *          lila_field_write-identical values come out ---- */
    LilaDroneRow src = { .x = 64.0f, .y = -8.5f, .vx = 0.5f, .vy = 0.25f,
                         .heat = -1234, .hp = 77, .wf = 3.25f,
                         .kind = 5, .armed = 1, .spin = 4321 };
    assert(lila_overlay_spawn_from(LILA_DRONE_TYPE, (const uint8_t *)&src, 1) == 1);
    /* registry order (fixture): tf 0..9 = x,y,vx,vy,heat,hp,wf,kind,armed,spin */
    int32_t idx = lila_next_live(0, 0);
    idx = lila_next_live(0, (uint32_t)idx + 1);
    idx = lila_next_live(0, (uint32_t)idx + 1); /* slot 2 = the spawn_from row */
    assert(idx == 2);
    const uint32_t h = lila_make_handle((uint32_t)lila_gen(0, 2), 2);
    assert(lila_field_read(0, h) == 16384);   /* x: 64.0 * 256, truncated */
    assert(lila_field_read(1, h) == -2176);  /* y: -8.5 * 256 */
    assert(lila_field_read(2, h) == 128);    /* vx */
    assert(lila_field_read(3, h) == 64);     /* vy */
    assert(lila_field_read(4, h) == -1234);  /* heat */
    assert(lila_field_read(5, h) == 77);     /* hp */
    assert(lila_field_read(6, h) == (int32_t)0x40500000); /* wf: 3.25f bits */
    assert(lila_field_read(7, h) == 5);      /* kind */
    assert(lila_field_read(8, h) == 1);       /* armed */
    assert(lila_field_read(9, h) == 4321);    /* spin */
    printf("overlay_test: spawn_from quantizes exactly like lila_f_to_q\n");

    /* ---- 6. the determinism pin: same 5 frames, clean boot, no overlays ---- */
    assert(lila_init(blob, len) == 0);
    static uint64_t chain_b[FRAMES];
    for (int fr = 0; fr < FRAMES; fr++) {
        lila_input_set(0);
        lila_frame();
        lila_audio_fill(pcm, 735);
        chain_b[fr] = lila_state_hash((uint32_t)fr);
    }
    for (int fr = 0; fr < FRAMES; fr++) assert(chain_a[fr] == chain_b[fr]);
    printf("overlay_test: %d/%d hash chain identical with/without overlays\n",
           FRAMES, FRAMES);

    /* ---- 7. the one-call pipeline (run B is now 5 frames in: x=15.0) ---- */
    static LilaDroneRow fresh[8];
    memset(fresh, 0, sizeof fresh);
    lila_input_set(0);
    lila_tick_pipeline((uint8_t *)fresh, 8); /* retarget type 0 + frame + flush */
    assert(fresh[0].lila_meta & 1u);
    assert(fresh[0].x == 16.0f); /* one more frame of += 1.0 */
    assert(lila_overlay_written(LILA_DRONE_TYPE) == 2);
    printf("overlay_test: tick_pipeline retarget + tick + flush ok\n");

    printf("overlay_test: PASS\n");
    return 0;
}
