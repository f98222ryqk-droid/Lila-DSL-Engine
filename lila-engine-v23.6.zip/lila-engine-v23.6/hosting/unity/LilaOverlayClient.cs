// ============================================================================
// LilaOverlayClient.cs — v23 the zero-GC Unity host (skeleton)
// ============================================================================
//
// THE C# GARBAGE COLLECTOR NEVER SEES A SINGLE ROW.
//
//   - the entity rows live in a NativeArray<LilaDroneRow> with
//     Allocator.Persistent — Unity's UNMANAGED heap, not the managed one
//   - the raw hardware pointer is pinned once and fed straight down to the
//     Zig runtime: lila_overlay_install(...) at boot, then
//     lila_tick_pipeline(ptr, count) per frame
//   - LILA scatters the live dense SoA rows into that memory IN PLACE:
//     zero allocation, zero marshalling, zero per-field P/Invoke calls
//   - reading a row for presentation is a plain struct copy off the native
//     heap — no object graphs, no 16-byte object headers, no GC spikes
//
// Requirements:
//   1. lila_c.dll/.so in Assets/Plugins (see LilaBridge.cs header)
//   2. LilaInterop.cs + LilaBridge.cs in the assembly
//   3. "Allow unsafe Code" on the asmdef (Player Settings for the default
//      assembly)
//
// The row type below (LilaDroneRow) is whatever YOUR game generated —
// regenerate LilaInterop.cs whenever the schema changes; the layout hash
// refuses a stale pair loudly (install returns -2, Validate() throws).
//
// Hot-swap note: gameplay lives in the .libyte — rebuild it with lilac
// (milliseconds) and call HotSwapCartridge(); Unity never recompiles.
// ============================================================================

using System;
using System.Runtime.InteropServices;
using Unity.Collections;
using Unity.Collections.LowLevel.Unsafe;
using UnityEngine;
using Lila;

[RequireComponent(typeof(AudioSource))]
public class LilaOverlayClient : MonoBehaviour
{
    [Tooltip("Your game's compiled .libyte (binary TextAsset)")]
    public TextAsset cartridge;

    [Tooltip("Bits: 0=left 1=right 2=up 3=fire (mirror of the demo's key layout)")]
    public KeyCode left = KeyCode.LeftArrow;
    public KeyCode right = KeyCode.RightArrow;
    public KeyCode up = KeyCode.UpArrow;
    public KeyCode fire = KeyCode.Space;

    [Tooltip("Hot-swap in this .libyte at runtime (no Unity recompile)")]
    public TextAsset hotSwapCartridge;

    const float TickHz = 60f;
    const int SamplesPerFrame = 44100 / 60; // 735 — keep EXACT (hash chain)

    // THE MIRROR SURFACE — unmanaged heap, invisible to the GC.
    NativeArray<LilaDroneRow> _rows;

    float _accumulator;
    uint _frame;
    readonly short[] _pcm = new short[SamplesPerFrame];
    // ---- audio ring: produced at 60Hz, drained by OnAudioFilterRead ----
    // Power-of-two length so the cursors can wrap by MASKING (see below).
    const int RingLen = 8192;                 // >= 735*8 samples of slack
    const int RingMask = RingLen - 1;
    readonly float[] _audioRing = new float[RingLen];
    long _ringW, _ringR;

    unsafe void Awake()
    {
        if (cartridge == null) { Debug.LogError("LilaOverlayClient: no cartridge"); enabled = false; return; }

        var bytes = cartridge.bytes;
        if (LilaBridge.lila_init(bytes, (UIntPtr)bytes.Length) != 0)
        {
            Debug.LogError($"lila_init failed rc={LilaBridge.lila_last_error()}");
            enabled = false; return;
        }

        // Drift is an exception, not a Heisenbug: this throws when the
        // generated file is stale (schema changed, files not regenerated).
        LilaInteropLayout.Validate();

        int rowBytes = LilaBridge.lila_overlay_row_bytes((uint)DroneInfo.Type);
        if (rowBytes != DroneInfo.RowBytes || rowBytes != Marshal.SizeOf(typeof(LilaDroneRow)))
        {
            Debug.LogError($"LILA interop drift: runtime says {rowBytes}B, generated header says {DroneInfo.RowBytes}B — regenerate LilaInterop.cs");
            enabled = false; return;
        }

        // ---- the one pinned pointer the whole game runs through ----
        _rows = new NativeArray<LilaDroneRow>(DroneInfo.MaxLive,
                                               Allocator.Persistent,
                                               NativeArrayOptions.ClearMemory);
        byte* p = (byte*)NativeArrayUnsafeUtility.GetUnsafeBufferPointerWithoutChecks(_rows);
        int rc = LilaBridge.lila_overlay_install((uint)DroneInfo.Type, p,
                                                  (uint)rowBytes, (uint)_rows.Length,
                                                  LilaInteropLayout.LayoutHash);
        if (rc != 0)
        {
            Debug.LogError($"lila_overlay_install rc={rc} (-2 = stale LilaInterop.cs)");
            enabled = false; return;
        }

        Debug.Log($"LILA overlay booted: {_rows.Length} rows x {rowBytes}B, " +
                  $"layout 0x{LilaInteropLayout.LayoutHash:X8}, " +
                  $"abi={LilaBridge.lila_abi_version()} engine={LilaBridge.lila_engine_version()}");
    }

    void Update()
    {
        // fixed 60Hz accumulator — sim time never depends on render fps,
        // GC hitches or hot-swap stalls
        _accumulator += Time.deltaTime;
        int steps = 0;
        while (_accumulator >= 1f / TickHz && steps < 5)
        {
            StepOneFrame();
            _accumulator -= 1f / TickHz;
            steps++;
        }
        if (steps == 5) _accumulator = 0f; // stall, don't fast-forward

        if (Input.GetKeyDown(KeyCode.F6) && hotSwapCartridge != null)
            HotSwapCartridge(hotSwapCartridge);
    }

    unsafe void StepOneFrame()
    {
        uint mask = 0;
        if (Input.GetKey(left)) mask |= 1u << 0;
        if (Input.GetKey(right)) mask |= 1u << 1;
        if (Input.GetKey(up)) mask |= 1u << 2;
        if (Input.GetKey(fire)) mask |= 1u << 3;

        LilaBridge.lila_input_set(mask); // BEFORE the frame

        // ---- THE ZERO-COPY PIPELINE -------------------------------------
        // The unmanaged hardware address of the C# data array, blasted
        // down to Zig: one tick, then the live SoA rows land in _rows'
        // memory in place. The GC tracks none of it.
        byte* p = (byte*)NativeArrayUnsafeUtility.GetUnsafeBufferPointerWithoutChecks(_rows);
        LilaBridge.lila_tick_pipeline(p, (uint)_rows.Length);

        ulong written = LilaBridge.lila_audio_fill(_pcm, (UIntPtr)SamplesPerFrame);
        if ((int)written == SamplesPerFrame)
            for (int i = 0; i < SamplesPerFrame; i++)
            {
                if (_ringW - _ringR >= RingLen) _ringR++;   // full: drop oldest
                _audioRing[_ringW & RingMask] = _pcm[i] / 32768f;
                _ringW++;
            }

        _frame++;
    }

    /// <summary>Presentation example: read a row straight off the native
    /// heap (a struct copy — no allocation, no GC). Check lila_meta bit0
    /// before trusting the lanes: dead rows keep their last bytes.</summary>
    bool TryGetRow(int slot, out LilaDroneRow row)
    {
        if (slot < 0 || slot >= _rows.Length) { row = default; return false; }
        row = _rows[slot];
        return (row.lila_meta & 1u) != 0u;
    }

    /// <summary>Rebuild gameplay WITHOUT recompiling Unity: flash a fresh
    /// .libyte into the running process. Entity + globals state survives a
    /// matching schema; the overlay reinstalls against the new layout.</summary>
    unsafe void HotSwapCartridge(TextAsset next)
    {
        var bytes = next.bytes;
        int preserved = LilaBridge.lila_hot_swap(bytes, (UIntPtr)bytes.Length);

        int rowBytes = LilaBridge.lila_overlay_row_bytes((uint)DroneInfo.Type);
        byte* p = (byte*)NativeArrayUnsafeUtility.GetUnsafeBufferPointerWithoutChecks(_rows);
        int rc = (rowBytes == DroneInfo.RowBytes)
            ? LilaBridge.lila_overlay_install((uint)DroneInfo.Type, p, (uint)rowBytes,
                                               (uint)_rows.Length, LilaInteropLayout.LayoutHash)
            : -2;
        Debug.Log($"LILA hot-swap: state {(preserved == 1 ? "PRESERVED" : "re-init")}, overlay rc={rc}");
        if (rc != 0) Debug.LogError("Layout changed: regenerate LilaInterop.cs and let Unity recompile once — the engine refused the stale layout.");
    }

    // The audio source should have a silent looping clip attached so Unity
    // keeps calling this. Presentation only — the SIMULATION's audio pull
    // above is what's hash-relevant.
    //
    // data[] is INTERLEAVED (frames of `channels` floats) while the engine
    // mixes mono: each ring sample is duplicated to every channel of its
    // frame. Cursors are long and wrap by masking — int cursors overflow
    // after ~2^31 samples (~15h at 44100Hz) and `%` on a negative int
    // returns a negative index.
    void OnAudioFilterRead(float[] data, int channels)
    {
        if (channels <= 0) return;
        int frames = data.Length / channels;
        for (int f = 0; f < frames; f++)
        {
            float s = 0f;
            if (_ringR < _ringW) { s = _audioRing[_ringR & RingMask]; _ringR++; }
            int o = f * channels;
            for (int ch = 0; ch < channels; ch++) data[o + ch] = s;
        }
        if (_ringW - _ringR > _audioRing.Length / 2) _ringW = _ringR = 0; // resync after stalls
    }

    unsafe void OnDestroy()
    {
        if (_rows.IsCreated) _rows.Dispose();
    }
}
