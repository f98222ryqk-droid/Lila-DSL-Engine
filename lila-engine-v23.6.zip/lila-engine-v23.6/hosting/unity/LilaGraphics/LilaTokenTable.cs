// ============================================================================
// LilaTokenTable.cs — the manifest's runtime face (v18 FORGE)
// ============================================================================
// One ScriptableObject produced by LilaManifestImporter. It is THE token
// interpretation layer: the cartridge keeps emitting abstract
// "sprite token at position with tint"; this table says what that MEANS on
// this host build — quad, mesh, or a cosmetic particle burst. Re-forging
// the game (HD textures, mesh swaps, FX) means re-importing this table,
// not touching a single simulation byte.
// ============================================================================

using System.Collections.Generic;
using UnityEngine;

public class LilaTokenTable : ScriptableObject
{
    public enum TexKind { Quad, Fx, Light, Decal }
    public enum MeshKind { Mesh, Quad }

    [System.Serializable]
    public class TexEntry
    {
        public string name;
        public int spriteAtom = -1;   // the cartridge's atom id (#name)
        public int spriteIndex = -1;  // position in the sprite table (path B)
        public Texture2D texture;
        public string renderKind = "quad";
    }

    [System.Serializable]
    public class MeshEntry
    {
        public string entity;        // entity type name in the cartridge
        public Mesh mesh;            // FGM1 forged: 12B/vert, meshlets baked
        public string renderKind = "mesh";
        public int meshletCount;     // for cluster culling / indirect draws
    }

    [System.Serializable]
    public class FxEntry
    {
        public string name;
        public int spriteAtom;       // drawing this sprite token => EMIT, not draw
        public int burst;
        public int lifeMin, lifeMax; // frames at 60Hz
        public int gravQ8;           // Q24.8 px/frame^2, Q8 scale (256 = 1.0)
        public int spreadQ8;          // Q8 radians (256 = 1 rad)
    }

    public List<TexEntry> textures = new List<TexEntry>();
    public List<MeshEntry> meshes = new List<MeshEntry>();
    public List<FxEntry> fx = new List<FxEntry>();

    // atom -> fx lookup (hot path; built lazily)
    [System.NonSerialized] Dictionary<int, FxEntry> _fxByAtom;
    [System.NonSerialized] Dictionary<int, TexEntry> _texByAtom;

    public FxEntry FxForAtom(int atom)
    {
        if (_fxByAtom == null)
        {
            _fxByAtom = new Dictionary<int, FxEntry>();
            foreach (var f in fx) _fxByAtom[f.spriteAtom] = f;
        }
        return _fxByAtom.TryGetValue(atom, out var f) ? f : null;
    }

    public TexEntry TexForAtom(int atom)
    {
        if (_texByAtom == null)
        {
            _texByAtom = new Dictionary<int, TexEntry>();
            foreach (var t in textures) if (t.spriteAtom >= 0) _texByAtom[t.spriteAtom] = t;
        }
        return _texByAtom.TryGetValue(atom, out var t) ? t : null;
    }

    public MeshEntry MeshForEntity(string entity)
    {
        foreach (var m in meshes) if (m.entity == entity) return m;
        return null;
    }
}
