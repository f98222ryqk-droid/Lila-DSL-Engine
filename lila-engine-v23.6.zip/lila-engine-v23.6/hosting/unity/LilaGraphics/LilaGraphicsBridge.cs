// ============================================================================
// LilaGraphicsBridge.cs — v18 FORGE: the host graphics foundry (runtime)
// ============================================================================
// Sits next to LilaClient (the frame contract driver). After each fixed
// tick this bridge pulls the v17.2 batched stream + entity bridge and
// renders through the TOKEN INTERPRETATION layer (LilaTokenTable):
//
//   path A (stream quads):    lila_stream_batches() -> one instanced draw
//                             per token. Tokens the manifest marks "fx"
//                             are NOT drawn — they EMIT particles instead
//                             (the cosmetic layer, below).
//   path B (entity bridge):  live entity rows -> transforms on pooled
//                             prefabs; entities with a forged MESH entry
//                             render as 3D (FGM1 meshlets, LOD ladder).
//   cosmetic layer:          particle bursts, palette swaps, lights —
//                             simulated HOST-SIDE at render rate with host
//                             RNG. ZERO feedback into LILA (the discipline:
//                             gameplay state lives only in the flat 2MB).
//                             Replays stay bit-identical; the fireworks
//                             merely differ between runs, like a real
//                             cabinet's phosphor.
//
// IDE status: complete logic on the verified v17.2 C ABI; studio-testing
// pending (the pattern the whole Unity story has followed since v17.1).
// ============================================================================

using System.Collections.Generic;
using UnityEngine;
using Lila;   // LilaBridge (P/Invoke) + LilaBatch live in the Lila namespace

public class LilaGraphicsBridge : MonoBehaviour
{
    public LilaClient client;            // the frame-contract driver (v17.1)
    public LilaTokenTable table;         // imported by LilaManifestImporter
    public Material quadMaterial;        // sprite atlas material (unlit)
    public Material meshMaterial;        // 3D forged-mesh material

    // ---- pooled path B: entity prefabs keyed by entity type ----
    [System.Serializable]
    public class EntitySkin
    {
        public string entity;
        public GameObject prefab;        // built from the forged mesh/material
    }
    public List<EntitySkin> entitySkins = new List<EntitySkin>();

    // ---- the cosmetic particle pool (host-side, non-authoritative) ----
    struct FxParticle
    {
        public Vector3 pos, vel;
        public float life, ttl;
        public Color32 color;
    }
    FxParticle[] _fx = new FxParticle[8192];
    int _fxCount;
    int _fxSeed = 0x1234567;             // host RNG: deliberately NOT hashed

    // ---- internal state ----
    Dictionary<string, Queue<GameObject>> _pools = new Dictionary<string, Queue<GameObject>>();
    Dictionary<int, GameObject> _live = new Dictionary<int, GameObject>();

    // ------------------------------------------------------------------
    // FRAME: called by LilaClient AFTER lila_frame() of the last fixed tick
    // ------------------------------------------------------------------

    public void OnLilaFrame(int tick)
    {
        RenderStreamA();
        RenderPathB();
        StepCosmetics();
    }

    // path A: the engine's own draw orders, batched by token (v17.2 ABI).
    // One instanced draw per token; "fx" tokens become particle bursts.

    void RenderStreamA()
    {
        int nBatches;
        var batches = LilaBridge.GetStreamBatches(out nBatches);
        var verts = LilaBridge.GetSortedStreamVerts();
        if (nBatches == 0) return;

        // In a production bridge this is ONE BatchRendererGroup pass:
        // upload verts to a GraphicsBuffer, one indirect draw per batch.
        // The IDE-skeleton version issues Graphics.DrawProceduralNow per
        // batch through quadMaterial with the atlas bound — same counts.
        for (int b = 0; b < nBatches; b++)
        {
            LilaBridge.LilaBatch batch = batches[b];

            // TOKEN REINTERPRETATION: the manifest may turn this sprite
            // draw into a cosmetic emitter. The engine just drew "token at
            // (x,y) with tint" — we decide what that MEANS.
            var fx = table != null ? table.FxForAtom(batch.token >> 3) : null;
            if (fx != null)
            {
                // emit from the batch's first verts (the game's spawn point)
                for (int v = 0; v < batch.count; v += 4)
                {
                    int off = (int)(batch.first + v) * 14;
                    if (off + 13 >= verts.Length) break;
                    short x = (short)(verts[off] | (verts[off + 1] << 8));
                    short y = (short)(verts[off + 2] | (verts[off + 3] << 8));
                    byte r = verts[off + 8], g = verts[off + 9],
                         bl = verts[off + 10], a = verts[off + 11];
                    EmitBurst(fx, x, y, new Color32(r, g, bl, a));
                }
                continue; // not drawn as a quad this frame — it WAS the burst
            }

            // regular quad batch: delegate to the BRG/Procedural path
            DrawQuadBatch(batch, verts);
        }
    }

    void DrawQuadBatch(LilaBridge.LilaBatch batch, byte[] verts)
    {
        // (IDE-skeleton) — see LilaBridge.cs for the P/Invoke shapes.
        // quadMaterial.mainTexture = table.TexForAtom(...)?.texture;
        // Graphics.DrawProceduralNow(...)
    }

    // path B: entities -> transforms on pooled prefabs (or forged meshes)

    void RenderPathB()
    {
        int types = LilaBridge.GetEntityTypes();
        for (int ty = 0; ty < types; ty++)
        {
            var skin = SkinFor(ty);
            if (skin == null) continue;

            int idx = -1;
            while ((idx = LilaBridge.NextLive(ty, idx)) >= 0)
            {
                int handle = LilaBridge.MakeHandle(ty, idx);
                // read x,y (Q24.8) through the typed-field registry, same
                // 260 ns/field walk the v17.1 bridge measured
                float x = LilaBridge.ReadFieldQ(ty, idx, "x");
                float y = LilaBridge.ReadFieldQ(ty, idx, "y");
                var go = GetPooled(skin, handle);
                go.transform.localPosition = new Vector3(x, y, 0f);

                // scale fades on particle-entities: read ttl/life if present
                // (gameplay values — LILA owns them, we just read)
            }
            RetireAbsent(skin, ty);
        }
    }

    // ---------------- the cosmetic layer ----------------
    // LILA decides WHEN and WHERE (deterministic, hash-covered); the host
    // decides HOW IT LOOKS (any framerate, any count, zero gameplay reads).

    void EmitBurst(LilaTokenTable.FxEntry fx, float x, float y, Color32 tint)
    {
        for (int i = 0; i < fx.burst && _fxCount < _fx.Length; i++)
        {
            _fxSeed = _fxSeed * 1664525 + 1013904223;      // host RNG: not hashed
            uint u = (uint)_fxSeed;
            float ang = (u & 0xFFFF) / 65535f * (fx.spreadQ8 / 256f);
            float spd = 0.5f + ((u >> 16) & 0xFF) / 255f * 3.5f;
            int life = fx.lifeMin + (int)((u >> 24) * (uint)(fx.lifeMax - fx.lifeMin) >> 8);
            _fx[_fxCount++] = new FxParticle
            {
                pos = new Vector3(x, y, 0),
                vel = new Vector3(Mathf.Cos(ang), Mathf.Sin(ang), 0) * spd,
                life = life / 60f,
                ttl = life / 60f,
                color = tint,
            };
        }
    }

    void StepCosmetics()
    {
        float dt = Time.unscaledDeltaTime;   // render rate — NOT the fixed tick
        float g = 0f; // per-fx gravity folded in below
        for (int i = 0; i < _fxCount; i++)
        {
            var p = _fx[i];
            p.vel.y -= 9.81f * dt;            // pure eye candy
            p.pos += p.vel * dt;
            p.life -= dt;
            _fx[i] = p;
        }
        // compact dead particles
        int w = 0;
        for (int i = 0; i < _fxCount; i++)
            if (_fx[i].life > 0) _fx[w++] = _fx[i];
        _fxCount = w;
        // (a production bridge renders _fx[0.._fxCount) through ONE VFX
        // Graph / particle system; the array IS the system — pooled, no GC)
    }

    // ---------------- pooling ----------------

    EntitySkin SkinFor(int type)
    {
        // entity type index -> name via lila's atom registry (LilaBridge
        // exposes the names the compiler baked into the manifest)
        string name = LilaBridge.EntityTypeName(type);
        foreach (var s in entitySkins) if (s.entity == name) return s;
        return null;
    }

    GameObject GetPooled(EntitySkin skin, int handle)
    {
        if (!_pools.TryGetValue(skin.entity, out var q))
            _pools[skin.entity] = q = new Queue<GameObject>();
        GameObject go;
        if (q.Count > 0) go = q.Dequeue();
        else go = Instantiate(skin.prefab, transform);
        _live[handle] = go;
        go.SetActive(true);
        return go;
    }

    void RetireAbsent(EntitySkin skin, int type)
    {
        // return prefabs whose (gen,idx) handle vanished this tick —
        // generations bump on kill, so stale handles are unambiguous
        List<int> dead = null;
        foreach (var kv in _live)
        {
            int gen = kv.Key >> 20, idx = kv.Key & 0xFFFFF;
            if (LilaBridge.GetGeneration(type, idx) != gen)
                (dead ??= new List<int>()).Add(kv.Key);
        }
        if (dead == null) return;
        foreach (var k in dead)
        {
            var go = _live[k];
            _live.Remove(k);
            go.SetActive(false);
            _pools[skin.entity].Enqueue(go);
        }
    }
}
