// ============================================================================
// LilaManifestImporter.cs — editor importer: .lilamanifest -> LilaTokenTable
// ============================================================================
//
// FORGE.md "Host consumption": the forge writes game.lilamanifest (the JSON
// decisions lockfile; schema emitted by compiler/src/forge — see
// demo/game.lilamanifest / demo/demo19.lilamanifest) next to game.forgepack.
// This importer turns that JSON into the runtime face LilaGraphicsBridge.cs
// consumes: a LilaTokenTable (ScriptableObject) whose TexEntry / MeshEntry /
// FxEntry lists carry the sprite_atom / sprite_index / meshlet / fx numbers
// that bind host assets to cartridge tokens.
//
// HOW IT WORKS (deliberately the boring, robust shape):
//   - an AssetPostprocessor.OnPostprocessAllAssets hook (NOT a custom
//     AssetImporter): the manifest is data, not a source asset — the table
//     lands as a SIBLING .asset ("game.lilamanifest" -> "game.asset") and
//     survives re-imports with its Texture2D/Mesh bindings intact.
//   - JsonUtility + [Serializable] DTOs whose field names MATCH THE JSON
//     KEYS exactly (snake_case — JsonUtility does no case mapping; unknown
//     manifest keys such as "audio"/"tables"/"shaders"/"usage" are ignored).
//   - VERIFIED against the compiler's writer: the fields below cover every
//     key the two demo manifests emit for textures/meshes/fx — the sections
//     the token table consumes.
//
// HONEST SCOPE NOTE: FORGE.md also promises "forgepack -> exact-format
// Texture2D/Mesh assets, sha256 verified". That half (decoding palette8 /
// BC7 / PGX tiles and FGM1 meshlets out of the BINARY .forgepack) is NOT in
// this file — texture/mesh slots are imported EMPTY and previously assigned
// references are carried across re-imports by name. Wire the pack decoder
// in here (or a sibling LilaForgepackImporter) at the studio pass.
//
// Editor-only twice over: this file lives under an "Editor/" folder AND is
// wrapped in #if UNITY_EDITOR, so it cannot leak into a player build either
// way.
// ============================================================================

#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

public sealed class LilaManifestImporter : AssetPostprocessor
{
    public const string ManifestExt = ".lilamanifest";

    // ------------------------------------------------------------------
    // DTOs — [Serializable], field names == manifest JSON keys (snake_case)
    // ------------------------------------------------------------------

    [Serializable]
    sealed class RenderDto { public string kind; }   // "render": {"kind":"quad"}

    [Serializable]
    sealed class TexDto
    {
        public string name;
        public int sprite_atom = -1;   // the cartridge's atom id (#name)
        public int sprite_index = -1;  // position in the sprite table (path B)
        public RenderDto render;
    }

    [Serializable]
    sealed class MeshDto
    {
        public string entity;          // entity type name in the cartridge
        public int verts;
        public int tris;
        public int meshlets;
        public int lods;
        public RenderDto render;
    }

    [Serializable]
    sealed class FxDto
    {
        public string name;
        public int sprite_atom;        // drawing this token => EMIT, not draw
        public int burst;
        public int life_min, life_max; // frames at 60Hz
        public int grav_q8;            // Q24.8 px/frame^2
        public int spread_q8;          // Q8 radians
        public RenderDto render;
    }

    [Serializable]
    sealed class ManifestDto
    {
        public int forge;
        public string card;
        public string libyte_sha256;
        public string forgepack_sha256;
        public TexDto[] textures;
        public MeshDto[] meshes;
        public FxDto[] fx;
    }

    // ------------------------------------------------------------------
    // The hook: import every freshly (re)imported .lilamanifest
    // ------------------------------------------------------------------

    static void OnPostprocessAllAssets(string[] importedAssets, string[] deletedAssets,
                                       string[] movedAssets, string[] movedFromAssetPaths)
    {
        foreach (string path in importedAssets)
            if (path.EndsWith(ManifestExt, StringComparison.OrdinalIgnoreCase))
                Import(path);
    }

    [MenuItem("Assets/LILA: Reimport Manifest")]
    static void ReimportSelected()
    {
        foreach (UnityEngine.Object obj in Selection.objects)
        {
            string path = AssetDatabase.GetAssetPath(obj);
            if (!string.IsNullOrEmpty(path) &&
                path.EndsWith(ManifestExt, StringComparison.OrdinalIgnoreCase))
                Import(path);
        }
    }

    // ------------------------------------------------------------------
    // JSON -> LilaTokenTable (sibling .asset, bindings preserved on update)
    // ------------------------------------------------------------------

    static void Import(string manifestPath)
    {
        ManifestDto m;
        try
        {
            m = JsonUtility.FromJson<ManifestDto>(File.ReadAllText(manifestPath));
        }
        catch (Exception e)
        {
            Debug.LogError($"LilaManifestImporter: cannot parse {manifestPath}: {e.Message}");
            return;
        }
        if (m == null || (m.textures == null && m.meshes == null && m.fx == null))
        {
            Debug.LogError($"LilaManifestImporter: {manifestPath} has no textures/meshes/fx sections — is this a forge manifest?");
            return;
        }

        string tablePath = Path.ChangeExtension(manifestPath, ".asset");
        var table = AssetDatabase.LoadAssetAtPath<LilaTokenTable>(tablePath);
        bool fresh = table == null;
        if (fresh && File.Exists(tablePath))
        {
            Debug.LogError($"LilaManifestImporter: {tablePath} exists but is not a LilaTokenTable — move or delete it, then reimport.");
            return;
        }
        if (fresh) table = ScriptableObject.CreateInstance<LilaTokenTable>();

        // Snapshot the OLD texture bindings by name so a re-import never
        // orphans a manually assigned Texture2D (the forgepack decoder that
        // would fill these automatically is future work — see header).
        var boundTex = new Dictionary<string, Texture2D>();
        if (!fresh)
            foreach (var old in table.textures)
                if (old != null && old.texture != null)
                    boundTex[old.name] = old.texture;

        table.textures.Clear();
        if (m.textures != null)
            foreach (var t in m.textures)
            {
                table.textures.Add(new LilaTokenTable.TexEntry
                {
                    name = t.name,
                    spriteAtom = t.sprite_atom,
                    spriteIndex = t.sprite_index,
                    renderKind = KindOr(t.render, "quad"),
                    texture = boundTex.TryGetValue(t.name, out var tex) ? tex : null,
                });
            }

        table.meshes.Clear();
        if (m.meshes != null)
            foreach (var mm in m.meshes)
            {
                table.meshes.Add(new LilaTokenTable.MeshEntry
                {
                    entity = mm.entity,
                    mesh = null,   // FGM1 meshlet decoding: future work (see header)
                    renderKind = KindOr(mm.render, "mesh"),
                    meshletCount = mm.meshlets,
                });
            }

        table.fx.Clear();
        if (m.fx != null)
            foreach (var f in m.fx)
            {
                table.fx.Add(new LilaTokenTable.FxEntry
                {
                    name = f.name,
                    spriteAtom = f.sprite_atom,
                    burst = f.burst,
                    lifeMin = f.life_min,
                    lifeMax = f.life_max,
                    gravQ8 = f.grav_q8,
                    spreadQ8 = f.spread_q8,
                });
            }

        if (fresh)
        {
            AssetDatabase.CreateAsset(table, tablePath);
            Debug.Log($"LilaManifestImporter: created {tablePath} " +
                      $"({table.textures.Count} textures, {table.meshes.Count} meshes, {table.fx.Count} fx) " +
                      $"from {Path.GetFileName(manifestPath)}");
        }
        else
        {
            EditorUtility.SetDirty(table);
            Debug.Log($"LilaManifestImporter: updated {tablePath} " +
                      $"({table.textures.Count} textures, {table.meshes.Count} meshes, {table.fx.Count} fx)");
        }
    }

    static string KindOr(RenderDto r, string fallback) =>
        (r != null && !string.IsNullOrEmpty(r.kind)) ? r.kind : fallback;
}
#endif
