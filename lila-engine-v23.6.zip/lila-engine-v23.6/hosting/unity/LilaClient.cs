// ============================================================================
// LilaClient.cs — minimal Unity host: fixed-tick loop, input, snapshots.
// ============================================================================
//
// SKELETON STATUS: the ABI this calls is fully verified (see
// hosting/examples/c_host — 300/300 hash chain, byte-identical audio). The
// Unity-side glue below follows Unity's documented APIs but was NOT
// compiled in the engine repo (no Unity there). Treat it as a reviewed
// starting point, not a finished asset.
//
// The frame contract (identical to the C host):
//     input_set(mask); frame(); audio_fill(pcm, 735); state_hash(f);
//
// What this component demonstrates:
//   - deterministic 60Hz accumulator loop (catch-up capped: a long stall
//     slows the game rather than fast-forwarding it through huge inputs)
//   - input bits from Unity's Input Manager axes/keys (bit 0..3 like demo)
//   - F5 / F9: instant save-state + load-state (a 2MB memcpy — try THAT
//     with scene serialization)
//   - F10: hash-chain spot check against a recorded frame list (optional)
//   - SRAM persistence hook (hi-scores survive restarts, battery-style)
//
// Rendering: see INTEGRATION.md paths A (decode the 14B stream) and B
// (walk entity tables, drive your own prefabs). The entity walking calls
// are all in LilaBridge; LilaEntityView.cs in this folder sketches B.
// ============================================================================

using System;
using System.IO;
using UnityEngine;
using Lila;

[RequireComponent(typeof(AudioSource))]
public class LilaClient : MonoBehaviour
{
    [Tooltip("Your game's compiled .libyte (binary, include as a TextAsset)")]
    public TextAsset cartridge;

    [Tooltip("Bits: 0=left 1=right 2=up 3=fire (mirror of the demo's key layout)")]
    public KeyCode left = KeyCode.LeftArrow;
    public KeyCode right = KeyCode.RightArrow;
    public KeyCode up = KeyCode.UpArrow;
    public KeyCode fire = KeyCode.Space;

    const float TickHz = 60f;
    const int SamplesPerFrame = 44100 / 60; // 735 — keep EXACT (hash chain)

    float _accumulator;
    uint _frame;
    byte[] _snapshot;             // F5/F9 save state (2MB)
    readonly short[] _pcm = new short[SamplesPerFrame];

    // ---- audio ring: produced at 60Hz, drained by OnAudioFilterRead ----
    // Power-of-two length so the cursors can wrap by MASKING (see below).
    const int RingLen = 8192;                 // >= 735*8 samples of slack
    const int RingMask = RingLen - 1;
    readonly float[] _audioRing = new float[RingLen];
    long _ringW, _ringR;

    void Awake()
    {
        if (cartridge == null) { Debug.LogError("LilaClient: no cartridge assigned"); enabled = false; return; }
        var bytes = cartridge.bytes;
        int rc = LilaBridge.lila_init(bytes, (UIntPtr)bytes.Length);
        if (rc != 0)
        {
            Debug.LogError($"lila_init failed rc={rc} last={LilaBridge.lila_last_error()}");
            enabled = false; return;
        }
        _snapshot = new byte[(int)LilaBridge.lila_snapshot_size()];
        Debug.Log($"LILA booted: {LilaBridge.lila_screen_w()}x{LilaBridge.lila_screen_h()} screen, " +
                  $"{LilaBridge.lila_tf_count()} fields, {LilaBridge.lila_entity_types()} entity types");
        // SRAM: copy a previously persisted block BEFORE init... here init
        // already ran, so persist-on-quit + restore-before-boot instead:
        // see LoadSram()/SaveSram() and call them around scene transitions.
    }

    void Update()
    {
        // fixed-timestep accumulator: simulation time never depends on
        // render fps or GC hitches — only on input at frame boundaries.
        _accumulator += Time.deltaTime;
        int steps = 0;
        while (_accumulator >= 1f / TickHz && steps < 5)
        {
            StepOneFrame();
            _accumulator -= 1f / TickHz;
            steps++;
        }
        if (steps == 5) _accumulator = 0f; // stall, don't fast-forward

        if (Input.GetKeyDown(KeyCode.F5))
        {
            int rc = LilaBridge.lila_snapshot_save(_snapshot, (UIntPtr)_snapshot.Length);
            Debug.Log(rc == 0 ? $"saved state @ frame {_frame} ({_snapshot.Length / 1024}KB memcpy)" : "save failed");
        }
        if (Input.GetKeyDown(KeyCode.F9) && _snapshot != null)
        {
            int f = LilaBridge.lila_snapshot_load(_snapshot, (UIntPtr)_snapshot.Length);
            if (f >= 0) { _frame = (uint)f; Debug.Log($"loaded state @ frame {f}"); }
        }
    }

    void StepOneFrame()
    {
        uint mask = 0;
        if (Input.GetKey(left)) mask |= 1u << 0;
        if (Input.GetKey(right)) mask |= 1u << 1;
        if (Input.GetKey(up)) mask |= 1u << 2;
        if (Input.GetKey(fire)) mask |= 1u << 3;

        LilaBridge.lila_input_set(mask);                    // BEFORE
        LilaBridge.lila_frame();                             // one tick
        ulong written = LilaBridge.lila_audio_fill(_pcm, (UIntPtr)SamplesPerFrame);
        if ((int)written == SamplesPerFrame)                 // one frame of audio
            for (int i = 0; i < SamplesPerFrame; i++)        // into the ring
            {
                if (_ringW - _ringR >= RingLen) _ringR++;    // full: drop oldest
                _audioRing[_ringW & RingMask] = _pcm[i] / 32768f;
                _ringW++;
            }

        _frame++;                                            // AFTER: hash if you want
        // ulong h = LilaBridge.lila_state_hash(_frame - 1); // — compare vs movie
    }

    // The audio source should have a silent looping clip attached so Unity
    // keeps calling this. Drift control: if the ring runs dry we output
    // silence; if it runs full we drop oldest — presentation only, the
    // SIMULATION's audio pull above is what's hash-relevant.
    //
    // data[] is INTERLEAVED (frames of `channels` floats) while the engine
    // mixes mono: each ring sample is duplicated to every channel of its
    // frame. Cursors are long and wrap by masking — int cursors overflow
    // after ~2^31 samples (~15h at 44100Hz) and `%` on a negative int
    // returns a negative index.
    void OnAudioFilterRead(float[] data, int channels)
    {
        if (channels <= 0) return;
        int frames = data.Length / channels;
        for (int f = 0; f < frames; f++)
        {
            float s = 0f;
            if (_ringR < _ringW) { s = _audioRing[_ringR & RingMask]; _ringR++; }
            int o = f * channels;
            for (int ch = 0; ch < channels; ch++) data[o + ch] = s;
        }
        if (_ringW - _ringR > _audioRing.Length / 2) _ringW = _ringR = 0; // resync after stalls
    }

    void OnApplicationQuit()
    {
        // persist SRAM (hi-scores) next to the save data
        byte[] sram = new byte[(int)LilaBridge.lila_sram_size()];
        System.Runtime.InteropServices.Marshal.Copy(LilaBridge.lila_sram_ptr(), sram, 0, sram.Length);
        File.WriteAllBytes(Path.Combine(Application.persistentDataPath, "lila_sram.bin"), sram);
    }
}
