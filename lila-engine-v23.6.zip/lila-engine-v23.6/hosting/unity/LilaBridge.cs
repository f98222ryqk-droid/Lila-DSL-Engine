// ============================================================================
// LilaBridge.cs — Unity P/Invoke wrapper for liblila_c (the LILA console).
// ============================================================================
//
// 1:1 mirror of hosting/include/lila.h — the ABI verified end-to-end by
// hosting/examples/c_host/verify.sh (300/300 hash chain, byte-identical
// audio, snapshot rollback). If you keep the marshalling this thin, your
// Unity build simulates bit-identically to the native runner's movies.
//
// Setup:
//   1. Build the library:  zig build-lib src/lila_c.zig -dynamic -O
//      ReleaseFast -lc -target x86_64-windows-gnu   (or x86_64-linux for
//      Standalone Linux / Editor-on-Linux; aarch64-linux for Android)
//   2. Copy lila_c.dll next to your built player / into Assets/Plugins
//      (x86_64). The exact folder Unity expects depends on your version:
//      Assets/Plugins/x86_64/lila_c.dll with "x86_64" + "Windows" in the
//      plugin inspector; lila_c.so with "Linux" + x86_64; and so on.
//   3. This file: no Unity API dependency — safe in any assembly.
// ============================================================================

using System;
using System.Runtime.InteropServices;

namespace Lila
{
    internal static class LilaBridge
    {
        const string Lib = "lila_c";

        // ---------------- identity ----------------
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int  lila_abi_version();
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int  lila_engine_version();

        // ---------------- lifecycle ----------------
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int  lila_init(byte[] blob, UIntPtr len);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int  lila_hot_swap(byte[] blob, UIntPtr len);

        // ---------------- the frame ----------------
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern void lila_frame();
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern uint lila_tick();

        // ---------------- input ----------------
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern void   lila_input_set(uint mask);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern uint   lila_input_get();

        // ---------------- determinism primitives ----------------
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern ulong lila_state_hash(uint frame);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern UIntPtr lila_snapshot_size();
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int    lila_snapshot_save(byte[] dst, UIntPtr len);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int    lila_snapshot_load(byte[] src, UIntPtr len);

        // ---------------- memory bridge ----------------
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern IntPtr lila_mem_ptr();
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern UIntPtr lila_mem_size();
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int    lila_read32(uint engineAddr);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern void   lila_write32(uint engineAddr, int v);

        // Q24.8 conversion — at the RENDER boundary only.
        internal static float QToF(int q) { return q / 256f; }
        internal static int  FToQ(float f) { return (int)(f * 256f); }

        // ---------------- render stream (path A) ----------------
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern IntPtr lila_stream_ptr();
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int    lila_stream_count();

        // ---------------- v17.2 batched feed (path A+, instancing) ----------------
        // Raw pointer returns — the wrappers at the bottom marshal them into
        // arrays. *out_count == 0 -> no batches this frame, use the raw
        // stream (lila_stream_ptr above).
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern IntPtr lila_stream_batches(out int outCount);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern IntPtr lila_stream_sorted_ptr();

        // ---------------- audio ----------------
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern UIntPtr lila_audio_fill(short[] dst, UIntPtr samples);

        // ---------------- entity bridge (path B) ----------------
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int    lila_entity_types();
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int    lila_entity_count(uint type);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int    lila_live_ents();

        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int    lila_tf_count();
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int    lila_tf_ent(uint tf);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int    lila_tf_off(uint tf);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int    lila_tf_bits(uint tf);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int    lila_tf_vt(uint tf);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int    lila_tf_cold(uint tf);

        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int    lila_next_live(uint type, uint fromIdx);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int    lila_gen(uint type, uint idx);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern uint   lila_make_handle(uint gen, uint idx);

        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int    lila_field_read(uint tf, uint handle);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern void   lila_field_write(uint tf, uint handle, int v);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int    lila_global_read(uint tf);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern void   lila_global_write(uint tf, int v);

        // ---------------- SRAM persistence ----------------
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern IntPtr lila_sram_ptr();
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern UIntPtr lila_sram_size();
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int    lila_sram_dirty();

        // ---------------- build profile + diagnostics ----------------
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int lila_cap_types();
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int lila_cap_ent();
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int lila_cap_verts();
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int lila_cap_instr();
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int lila_screen_w();
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int lila_screen_h();
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int lila_world_w();
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int lila_world_h();
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int lila_last_error();
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int lila_stream_dropped();
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int lila_spawn_denied();

        // ---------------- v19 ABI 3: execution-as-data (forged tables) ----------------
        // Install AFTER LilaInit, BEFORE the first frame. Pass the same
        // forgepack bytes the graphics importer reads. Returns the number of
        // tables baked (negative = pack does not match this cartridge).
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int lila_tables_install(byte[] pack, ulong len);

        // Telemetry (diagnostics only — outside the hashed memory).
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern void lila_tables_stats(out ulong hits, out ulong misses, out ulong spotChecks, out ulong mismatches, out uint active);

        // ---------------- v20 / ABI 4: pools, reflection, memory tiers ----------------
        // Reflection labels (game { reflection: true } ships the names
        // trailer). kind: 0=entity 1=field 2=fn 3=pool 4=pool field.
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int lila_name(byte kind, uint a, uint b, byte[] outBuf, uint cap);

        // Dynamic pools (List<T> analog). lila_pool_len reads the LIVE row
        // count straight from the flat image (snapshot/rollback free).
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int lila_pool_count();
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int lila_pool_cap(int pool);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int lila_pool_len(int pool);

        // This engine build's flat-image size in MB (the memory tier).
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int lila_mem_mb();

        // ---------------- v23 / ABI 5: pointer overlays (zero-copy) ----------------
        // Pair with the GENERATED LilaInterop.cs (lilac build
        // --emit-bridges): pack(1) row structs + LilaInteropLayout.Validate()
        // + the layout hash. The pointer imports need "Allow unsafe code"
        // on the assembly (asmdef checkbox) — see LilaOverlayClient.cs.

        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern uint lila_overlay_layout_hash();
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int  lila_overlay_row_bytes(uint type);

        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal unsafe static extern int  lila_overlay_install(uint type, byte* ptr, uint stride, uint cap, uint layoutHash);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern void lila_overlay_flush();
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern void lila_overlay_tick();
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal unsafe static extern void lila_tick_pipeline(byte* hostPtr, uint entityCount);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal static extern int  lila_overlay_written(uint type);
        [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)] internal unsafe static extern int  lila_overlay_spawn_from(uint type, byte* ptr, uint count);

        // ====================================================================
        // Host-friendly wrappers — the face LilaGraphicsBridge.cs calls.
        // Thin copies off the raw lila_* imports; READ-ONLY presentation
        // boundary: nothing here writes simulation state.
        // ====================================================================

        // One batch per distinct token, batches in FIRST-APPEARANCE order —
        // the runtime's own v17.2 counting sort (hostopt.zig). Rendering
        // these batches in order is pixel-identical to the raw stream.
        [StructLayout(LayoutKind.Sequential)]
        internal struct LilaBatch
        {
            internal ushort token;   // domain token (sprite/text/... index)
            internal ushort _pad;
            internal uint first;     // first vert in the SORTED stream
            internal uint count;     // verts in this batch
        }                            // 12 bytes == hostopt.CBatch (extern struct)

        internal const int VertBytes = 14; // i16 x, i16 y, u16 uv, u32 rgba, u16 token

        // Reusable name buffer for the reflection calls below. Unity hosts
        // drive these from the main thread only — hence no locking.
        static readonly byte[] _nameBuf = new byte[64];

        /// <summary>The frame's stream grouped by token. nBatches == 0 means
        /// "no batches" (empty frame or pathological token soup) — fall back
        /// to the raw stream exactly as lila.h documents.</summary>
        internal static LilaBatch[] GetStreamBatches(out int nBatches)
        {
            IntPtr p = lila_stream_batches(out nBatches);
            if (p == IntPtr.Zero || nBatches <= 0) { nBatches = 0; return Array.Empty<LilaBatch>(); }
            var batches = new LilaBatch[nBatches];
            int size = Marshal.SizeOf<LilaBatch>();      // 12
            for (int i = 0; i < nBatches; i++)
                batches[i] = Marshal.PtrToStructure<LilaBatch>(IntPtr.Add(p, i * size));
            return batches;
        }

        /// <summary>The SORTED stream: lila_stream_count() verts of 14 bytes,
        /// grouped by token (batch.first indexes THIS array). One copy per
        /// frame; little-endian fields, same layout as the raw stream.</summary>
        internal static byte[] GetSortedStreamVerts()
        {
            int n = lila_stream_count();
            IntPtr p = lila_stream_sorted_ptr();
            if (n <= 0 || p == IntPtr.Zero) return Array.Empty<byte>();
            var verts = new byte[n * VertBytes];
            Marshal.Copy(p, verts, 0, verts.Length);
            return verts;
        }

        /// <summary>Entity type count (raw passthrough, kept for symmetry).</summary>
        internal static int GetEntityTypes() { return lila_entity_types(); }

        /// <summary>Next live slot of a type strictly after fromIdx; seed
        /// with -1, terminates at -1. (lila_next_live is INCLUSIVE of `from`,
        /// hence the +1 — the same walk LilaEntityView.cs does by hand.)</summary>
        internal static int NextLive(int type, int fromIdx)
        {
            if (type < 0 || fromIdx < -1) return -1;
            return lila_next_live((uint)type, (uint)(fromIdx + 1));
        }

        /// <summary>Stable identity for the entity at (type, idx): the slot's
        /// CURRENT generation packed lila-style (gen&lt;&lt;20)|idx. Generations
        /// bump on kill, so a stale key can never alias a respawned slot.</summary>
        internal static int MakeHandle(int type, int idx)
        {
            if (type < 0 || idx < 0) return -1;
            int gen = lila_gen((uint)type, (uint)idx);
            if (gen < 0) return -1;
            return (int)lila_make_handle((uint)gen, (uint)idx);
        }

        /// <summary>Slot generation of (type, idx); -1 = bad type/slot.
        /// RetireAbsent compares this against the generation baked in a
        /// handle to detect kills.</summary>
        internal static int GetGeneration(int type, int idx)
        {
            return (type < 0 || idx < 0) ? -1 : lila_gen((uint)type, (uint)idx);
        }

        /// <summary>Read a Q24.8 entity field BY NAME through the typed-field
        /// registry (names come from `game { reflection: true }`; without
        /// them this returns 0 — the caller renders at the origin). The
        /// per-call registry walk is the ~260ns path the v17.1 bridge
        /// measured; deliberately NOT cached so a hot-swapped cartridge
        /// with a changed schema can never read a stale field id.</summary>
        internal static float ReadFieldQ(int type, int idx, string fieldName)
        {
            if (type < 0 || idx < 0 || string.IsNullOrEmpty(fieldName)) return 0f;
            int gen = lila_gen((uint)type, (uint)idx);
            if (gen < 0) return 0f;
            uint handle = lila_make_handle((uint)gen, (uint)idx);
            int n = lila_tf_count();
            for (int tf = 0; tf < n; tf++)
            {
                if (lila_tf_ent((uint)tf) != type) continue;
                if (!TfNameIs((uint)tf, fieldName)) continue;
                int v = lila_field_read((uint)tf, handle);
                // vt 0 = fixed Q24.8 (the games' hot fields); anything else
                // (int lanes, f32 bits) passes through raw — QToF is for the
                // fixed domain only (lila.h determinism rule 1).
                return lila_tf_vt((uint)tf) == 0 ? QToF(v) : v;
            }
            return 0f; // unknown field name
        }

        /// <summary>Reflection name of an entity type (lila_name kind 0),
        /// e.g. "Enemy" — null when the cartridge shipped without reflection
        /// names (then SkinFor matches nothing and path B renders nothing;
        /// that is the honest fallback, not a crash).</summary>
        internal static string EntityTypeName(int type)
        {
            if (type < 0) return null;
            int len = lila_name(0, (uint)type, 0, _nameBuf, (uint)_nameBuf.Length);
            if (len < 0) return null;
            int n = Math.Min(len, _nameBuf.Length - 1); // truncated copy is NUL-safe
            return System.Text.Encoding.UTF8.GetString(_nameBuf, 0, n);
        }

        /// <summary>Does typed-field tf carry exactly this name? (lila_name
        /// kind 1, a=tf). ASCII compare — reflection names are identifiers.</summary>
        static bool TfNameIs(uint tf, string want)
        {
            int len = lila_name(1, tf, 0, _nameBuf, (uint)_nameBuf.Length);
            if (len < 0 || len != want.Length || len > _nameBuf.Length - 1) return false;
            for (int i = 0; i < len; i++)
                if (_nameBuf[i] != (byte)want[i]) return false;
            return true;
        }
    }
}
