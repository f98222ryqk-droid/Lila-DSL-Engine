/* lila_aot_diff_dbg.c — diagnostic twin of lila_aot_diff.c.
 *
 * Same two-pass protocol (pass1 pure interpreter, pass2 AOT-installed),
 * but instead of only hashing, it SNAPSHOTS the full 2MB engine image at
 * a chosen frame from BOTH passes and byte-diffs them. Output: the list
 * of differing ranges (offset .. offset+len, first bytes) — the region
 * map of lila.h/core.zig turns that into "which engine structure lied".
 *
 * Usage: lila_aot_diff_dbg <game.libyte> <frames> <snapshot_frame>
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#ifdef LILA_AOT_LLVM
#include "lila_aot_runtime.h"
extern LilaFn lila_aot_table[LILA_AOT_TABLE_N];
void lila_aot_init(void);
#else
#include "lila_aot.h"
#endif

int32_t lila_init(const uint8_t *blob, size_t len);
void    lila_frame(void);
void    lila_input_set(uint32_t mask);
uint64_t lila_state_hash(uint32_t fr);
int32_t lila_snapshot_save(uint8_t *dst, size_t len);
size_t  lila_snapshot_size(void);
uint8_t *lila_sram_ptr(void);
uintptr_t lila_sram_size(void);

static void reset_sram(void) {
    uint8_t *p = lila_sram_ptr();
    size_t n = (size_t)lila_sram_size();
    if (p && n) memset(p, 0, n);  /* battery block survives init — see lila_aot_diff.c */
}

static void run_pass(int install_aot, uint32_t frames, uint32_t snap_at,
                     unsigned long long *hashes, uint8_t *snap) {
    size_t ss = lila_snapshot_size();
    static uint8_t buf[2 * 1024 * 1024 + 64];
    if (install_aot) {
#ifdef LILA_AOT_LLVM
        lila_aot_init();
#endif
        lila_aot_install(lila_aot_table, (uint32_t)(sizeof(lila_aot_table) / sizeof(lila_aot_table[0])));
    } else {
        lila_aot_uninstall();
    }
    for (uint32_t f = 0; f < frames; f++) {
        uint32_t mask = ((f / 7) % 2 ? 1u : 0u) | ((f / 13) % 2 ? 2u : 0u) | 4u;
        lila_input_set(mask);
        lila_frame();
        hashes[f] = lila_state_hash(f);
        if (f == snap_at && snap) {
            if (lila_snapshot_save(buf, ss) == 0) memcpy(snap, buf, ss);
            else fprintf(stderr, "snapshot_save FAILED at frame %u\n", f);
        }
    }
}

int main(int argc, char **argv) {
    if (argc < 4) { fprintf(stderr, "usage: %s <cart> <frames> <snap_frame>\n", argv[0]); return 2; }
    const char *cart_path = argv[1];
    uint32_t frames = (uint32_t)atoi(argv[2]);
    uint32_t snap_at = (uint32_t)atoi(argv[3]);

    FILE *fp = fopen(cart_path, "rb");
    if (!fp) { fprintf(stderr, "cannot open %s\n", cart_path); return 2; }
    static unsigned char cart[1 << 20];
    size_t len = fread(cart, 1, sizeof(cart), fp);
    fclose(fp);

    static unsigned long long h1[4096], h2[4096];
    size_t ss = lila_snapshot_size();
    static uint8_t im1[2 * 1024 * 1024 + 64], im2[2 * 1024 * 1024 + 64];

    reset_sram();
    if (lila_init(cart, len) != 0) { fprintf(stderr, "init1 failed\n"); return 2; }
    run_pass(0, frames, snap_at, h1, im1);
    printf("interp snap@%u hash %016llx\n", snap_at, h1[snap_at]);

    reset_sram();
    if (lila_init(cart, len) != 0) { fprintf(stderr, "init2 failed\n"); return 2; }
    run_pass(1, frames, snap_at, h2, im2);
    printf("aot    snap@%u hash %016llx\n", snap_at, h2[snap_at]);

    /* per-frame mismatch list: bisect the divergence point */
    for (uint32_t f = 0; f < frames; f++) {
        if (h1[f] != h2[f]) { printf("first hash mismatch at frame %u\n", f); break; }
    }

    /* byte-diff the two images: header is 44 bytes, then the flat mem */
    size_t n = ss;
    size_t i = 0;
    int ranges = 0;
    while (i < n) {
        if (im1[i] != im2[i]) {
            size_t j = i;
            while (j < n && im1[j] != im2[j]) j++;
            printf("DIFF range 0x%06zX..0x%06zX (%zu bytes):", i, j - 1, j - i);
            for (size_t k = i; k < j && k < i + 8; k++)
                printf(" %02x/%02x", im1[k], im2[k]);
            printf("%s\n", (j - i) > 8 ? " ..." : "");
            i = j;
            ranges++;
            if (ranges > 40) { printf("... (more ranges suppressed)\n"); break; }
        } else i++;
    }
    if (ranges == 0) printf("images identical at frame %u (hash divergence must come from host scalars)\n", snap_at);
    return ranges != 0;
}
