//! ============================================================================
//! LILA v20 — COROUTINE STATES (Unity coroutines / C# async-await, LILA way)
//! ============================================================================
//!
//!     fn update(e: Enemy) {
//!         state spawn { spawn Drone { x: 32.0 };  wait(30); }
//!         state hunt   { if (dist_nearest(e.x, e.y, Player) < 48.0) { -> attack; } }
//!         state attack { e.fuse -= 1;  if (e.fuse == 0) { -> spawn; } }
//!     }
//!
//! Lowered HERE — before the checker — into plain v1-era statements:
//!
//!   * the entity grows two synthesized fields: `st: u8 = 0` (state*16 +
//!     phase) and `wt: u16 = 0` (pending wait frames)
//!   * the fn body becomes `switch (e.st) { ... }` with one arm per
//!     (state, phase); `wait(n)` splits the body at that point: the tail
//!     becomes the next phase, entered under `if (wt != 0) { wt -= 1;
//!     return; }`
//!   * `-> name` becomes `e.st = name_idx*16; e.wt = 0; return;`
//!   * `default:` enters state 1 (phase 0) at the NEXT frame
//!
//! SEMANTICS (documented contract): state bodies are PER-FRAME RE-ENTERING
//! (exactly like the entity update they live in — a state IS the update's
//! current segment). `wait(n)` suspends exactly n frames and resumes after
//! the wait; the phase chain then loops its last segment every frame until
//! a transition. Zero new opcodes, zero runtime bytes beyond the two fields
//! — the whole coroutine machinery compiles to a switch.

use crate::ast::*;

/// Entry: lower every state-machine update fn. Returns report rows.
/// After this no Stmt::State / Wait / GotoState remains anywhere.
pub fn expand(prog: &mut Program) -> Result<Vec<(String, String)>, String> {
    let mut rows = Vec::new();
    let mut used_entities: std::collections::HashSet<String> = std::collections::HashSet::new();

    for fi in 0..prog.fns.len() {
        let has_states = body_has_state(&prog.fns[fi].body);
        if !has_states {
            // still reject stray wait/-> in stateless fns
            if let Some(e) = find_stray(&prog.fns[fi].body) {
                return Err(format!("line {}: {} (state blocks only exist inside `fn update(e: T)`)",
                    prog.fns[fi].line, e));
            }
            continue;
        }
        let line = prog.fns[fi].line;
        let fname = prog.fns[fi].name.clone();
        // placement: exactly update(e: T)
        if fname != "update" || prog.fns[fi].params.len() != 1 {
            return Err(format!("line {}: state blocks are only allowed in `fn update(e: T)` (found fn '{}')",
                line, fname));
        }
        let ent_name = match &prog.fns[fi].params[0].1 {
            Ty::Entity(n) => n.clone(),
            _ => return Err(format!("line {}: update must take an entity param to drive states", line)),
        };
        // the ACTUAL parameter name — the synthesized field writes and the
        // switch scrutinee must reference it (`e` was a hardcoded bug for
        // fns that named their param anything else)
        let self_name = prog.fns[fi].params[0].0.clone();
        let ei = prog.entities.iter().position(|e| e.name == ent_name)
            .ok_or_else(|| format!("line {}: unknown entity '{}'", line, ent_name))?;
        {
            let ed = &prog.entities[ei];
            if let Some(fsm) = &ed.fsm {
                return Err(format!("line {}: entity '{}' already drives fsm '{}' — one state system per entity (drop the fsm: or the state blocks)",
                    line, ent_name, fsm));
            }
            for r in ["st", "wt"] {
                if ed.fields.iter().any(|f| f.name == r) {
                    return Err(format!("line {}: entity '{}' field '{}' is reserved for state machines (rename yours)",
                        line, ent_name, r));
                }
                if ed.arrs.iter().any(|a| a.name == r) {
                    return Err(format!("line {}: entity '{}' array '{}' is reserved for state machines",
                        line, ent_name, r));
                }
            }
        }
        if !used_entities.insert(ent_name.clone()) {
            return Err(format!("line {}: entity '{}' already has a state-machine update fn", line, ent_name));
        }

        // collect states in declaration order
        let mut states: Vec<(String, Vec<Stmt>)> = Vec::new();
        for s in &prog.fns[fi].body {
            // v23.2 SPANS: look through the positional wrapper — a state
            // block is still a state block.
            let s = s.inner();
            match s {
                Stmt::State(name, body) => {
                    if states.iter().any(|(n, _)| n == name) {
                        return Err(format!("line {}: duplicate state '{}' in fn '{}'", line, name, fname));
                    }
                    states.push((name.clone(), body.clone()));
                }
                other => {
                    return Err(format!("line {}: only `state` blocks may appear in a state-driven update fn (found {:?})",
                        line, stmt_kind(other)));
                }
            }
        }
        if states.len() > 15 {
            return Err(format!("line {}: {} states declared (max 15 — st is u8: state*16 + phase)",
                line, states.len()));
        }
        let state_idx = |n: &str| -> Result<usize, String> {
            states.iter().position(|(sn, _)| sn == n)
                .ok_or_else(|| format!("line {}: unknown state '{}' (declared here: {})",
                    line, n, states.iter().map(|(sn, _)| sn.as_str()).collect::<Vec<_>>().join(", ")))
        };

        // synthesize the fields (BEFORE the user's fields? after — order
        // only affects bit layout, keep user fields first for readability)
        prog.entities[ei].fields.push(FieldDecl {
            name: "st".into(), ty: Ty::UInt(8),
            default_int: Some(0), default_fix: None, default_bool: None, cold: false,
        });
        prog.entities[ei].fields.push(FieldDecl {
            name: "wt".into(), ty: Ty::UInt(16),
            default_int: Some(0), default_fix: None, default_bool: None, cold: false,
        });

        // build the switch arms
        let self_ref = || Expr::Ident(self_name.clone());
        let mut arms: Vec<(Vec<(i64, bool)>, Vec<Stmt>)> = Vec::new();
        let default_body: Vec<Stmt> = vec![
            // st == 0 (or out of range): enter state 1 phase 0 next frame
            Stmt::Assign(
                Expr::Field(Box::new(Expr::Ident(self_name.to_string())), "st".into()),
                AssignOp::Set,
                Expr::IntLit(16),
            ),
            Stmt::Return(None),
        ];
        for (si, (sname, sbody)) in states.iter().enumerate() {
            let sidx = (si + 1) as i64;
            // split the body into phases at top-level waits
            let mut phases: Vec<Vec<Stmt>> = vec![Vec::new()];
            for st in sbody {
                // v23.2 SPANS: look through the positional wrapper (a wrapped
                // wait still splits phases; a wrapped goto still lowers).
                let st = st.inner();
                match st {
                    Stmt::Wait(n) => {
                        phases.push(Vec::new());
                        // the wait itself becomes the tail of the CURRENT phase
                        let phase_tail = phases.len() - 2;
                        phases[phase_tail].push(Stmt::Assign(
                            Expr::Field(Box::new(Expr::Ident(self_name.to_string())), "wt".into()),
                            AssignOp::Set, (*n).clone(),
                        ));
                        phases[phase_tail].push(Stmt::Assign(
                            Expr::Field(Box::new(Expr::Ident(self_name.to_string())), "st".into()),
                            AssignOp::Set,
                            Expr::IntLit(((sidx * 16) + phase_tail as i64 + 1) as u32),
                        ));
                        phases[phase_tail].push(Stmt::Return(None));
                    }
                    other => {
                        if stmt_has_wait_or_goto_err(other)? {
                            return Err(format!("line {}: wait(); must be a direct child of a state block (not nested in if/while/for)",
                                line));
                        }
                        let mut lowered = Vec::new();
                        lower_gotos(other, &state_idx, line, &self_name, &mut lowered)?;
                        for l in lowered { phases.last_mut().unwrap().push(l); }
                    }
                }
            }
            if phases.len() > 16 {
                return Err(format!("line {}: state '{}' needs {} phases (max 16 — st is u8)",
                    line, sname, phases.len()));
            }
            for (pi, body) in phases.into_iter().enumerate() {
                let mut arm = Vec::new();
                if pi > 0 {
                    // phase entered via wait: the countdown guard
                    arm.push(Stmt::If(
                        Expr::Binary(BinOp::Ne,
                            Box::new(Expr::Field(Box::new(self_ref()), "wt".into())),
                            Box::new(Expr::IntLit(0))),
                        vec![
                            Stmt::Assign(
                                Expr::Field(Box::new(Expr::Ident(self_name.to_string())), "wt".into()),
                                AssignOp::Sub, Expr::IntLit(1),
                            ),
                            Stmt::Return(None),
                        ],
                        vec![],
                    ));
                }
                arm.extend(body);
                arms.push(((vec![((sidx * 16) + pi as i64, false)]), arm));
            }
        }
        // default (st == 0) rides as the switch default
        let new_body = vec![Stmt::Switch(
            Expr::Field(Box::new(Expr::Ident(self_name.to_string())), "st".into()),
            arms,
            Some(default_body),
        )];
        rows.push((
            format!("states {}", ent_name),
            format!("{} states, {} phases — coroutines compiled to a switch (fields: st u8 + wt u16)",
                states.len(), prog.fns[fi].body.len().max(1)),
        ));
        prog.fns[fi].body = new_body;
    }
    Ok(rows)
}

/// Rewrite `-> name` into field writes + return, at any nesting depth.
/// A GotoState SPLICES into three statements, so lowering is block-level.
fn lower_block(b: &[Stmt], state_idx: &dyn Fn(&str) -> Result<usize, String>, line: u32, self_name: &str) -> Result<Vec<Stmt>, String> {
    let mut out = Vec::new();
    for s in b {
        lower_gotos(s, state_idx, line, self_name, &mut out)?;
    }
    Ok(out)
}

fn lower_gotos(s: &Stmt, state_idx: &dyn Fn(&str) -> Result<usize, String>, line: u32, self_name: &str, out: &mut Vec<Stmt>) -> Result<(), String> {
    // v23.2 SPANS: look through the positional wrapper — a wrapped goto
    // still lowers (missing this would silently DROP the goto).
    let s = s.inner();
    match s {
        Stmt::GotoState(name) => {
            let ti = state_idx(name).map_err(|e| format!("line {}: {}", line, e))?;
            out.push(Stmt::Assign(
                Expr::Field(Box::new(Expr::Ident(self_name.to_string())), "st".into()),
                AssignOp::Set,
                Expr::IntLit((((ti as i64) + 1) * 16) as u32),
            ));
            out.push(Stmt::Assign(
                Expr::Field(Box::new(Expr::Ident(self_name.to_string())), "wt".into()),
                AssignOp::Set, Expr::IntLit(0),
            ));
            out.push(Stmt::Return(None));
            Ok(())
        }
        Stmt::If(c, a, b) => {
            out.push(Stmt::If(c.clone(),
                lower_block(a, state_idx, line, self_name)?,
                lower_block(b, state_idx, line, self_name)?));
            Ok(())
        }
        Stmt::While(c, b) => {
            out.push(Stmt::While(c.clone(), lower_block(b, state_idx, line, self_name)?));
            Ok(())
        }
        Stmt::For(v, t, b) => {
            out.push(Stmt::For(v.clone(), t.clone(), lower_block(b, state_idx, line, self_name)?));
            Ok(())
        }
        Stmt::ForNum(v, f, t, b) => {
            out.push(Stmt::ForNum(v.clone(), f.clone(), t.clone(), lower_block(b, state_idx, line, self_name)?));
            Ok(())
        }
        Stmt::Switch(x, arms, d) => {
            let mut new_arms = Vec::new();
            for (l, b) in arms {
                new_arms.push((l.clone(), lower_block(b, state_idx, line, self_name)?));
            }
            let nd = match d {
                Some(b) => Some(lower_block(b, state_idx, line, self_name)?),
                None => None,
            };
            out.push(Stmt::Switch(x.clone(), new_arms, nd));
            Ok(())
        }
        other => { out.push(other.clone()); Ok(()) }
    }
}

fn stmt_has_wait_or_goto_err(s: &Stmt) -> Result<bool, String> {
    // v23.2 SPANS: positional wrapper — look through.
    if let Stmt::At { inner, .. } = s {
        return stmt_has_wait_or_goto_err(inner);
    }
    Ok(match s {
        Stmt::Wait(_) => true,
        Stmt::State(_, _) => true, // no nested states
        Stmt::If(_, a, b) => a.iter().any(|x| stmt_has_wait_or_goto_err(x).unwrap_or(false))
            || b.iter().any(|x| stmt_has_wait_or_goto_err(x).unwrap_or(false)),
        Stmt::While(_, b) => b.iter().any(|x| stmt_has_wait_or_goto_err(x).unwrap_or(false)),
        Stmt::For(_, _, b) => b.iter().any(|x| stmt_has_wait_or_goto_err(x).unwrap_or(false)),
        Stmt::ForNum(_, _, _, b) => b.iter().any(|x| stmt_has_wait_or_goto_err(x).unwrap_or(false)),
        Stmt::Switch(_, arms, d) => arms.iter().any(|(_, b)| b.iter().any(|x| stmt_has_wait_or_goto_err(x).unwrap_or(false)))
            || d.as_ref().map_or(false, |b| b.iter().any(|x| stmt_has_wait_or_goto_err(x).unwrap_or(false))),
        _ => false,
    })
}

fn body_has_state(b: &[Stmt]) -> bool {
    b.iter().any(|s| matches!(s.inner(), Stmt::State(_, _)))
}

fn find_stray(b: &[Stmt]) -> Option<String> {
    for s in b {
        // v23.2 SPANS: look through the positional wrapper (a wrapped wait
        // is still a stray wait).
        let s = s.inner();
        match s {
            Stmt::Wait(_) => return Some("wait(); outside a state block".into()),
            Stmt::GotoState(_) => return Some("-> transition outside a state block".into()),
            Stmt::If(_, a, b) => {
                if let Some(e) = find_stray(a) { return Some(e); }
                if let Some(e) = find_stray(b) { return Some(e); }
            }
            Stmt::While(_, b) | Stmt::For(_, _, b) => {
                if let Some(e) = find_stray(b) { return Some(e); }
            }
            Stmt::ForNum(_, _, _, b) => {
                if let Some(e) = find_stray(b) { return Some(e); }
            }
            Stmt::Switch(_, arms, d) => {
                for (_, body) in arms { if let Some(e) = find_stray(body) { return Some(e); } }
                if let Some(d) = d { if let Some(e) = find_stray(d) { return Some(e); } }
            }
            _ => {}
        }
    }
    None
}

fn stmt_kind(s: &Stmt) -> &'static str {
    match s {
        // v23.2 SPANS: unwrap the positional wrapper for the real name.
        Stmt::At { inner, .. } => stmt_kind(inner),
        Stmt::Let(..) => "let",
        Stmt::Assign(..) => "assignment",
        Stmt::If(..) => "if",
        Stmt::While(..) => "while",
        Stmt::For(..) => "for",
        Stmt::ForNum(..) => "for-num",
        Stmt::Spawn(..) => "spawn",
        _ => "statement",
    }
}
