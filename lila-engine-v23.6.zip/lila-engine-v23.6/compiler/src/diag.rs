//! LILA diagnostics: position formatting + rustc-style rendering.
//!
//! The pipeline threads `Result<T, String>` — every error message carries a
//! position prefix in one of two shapes:
//!   "lex error at line L:COL: ..."        (lexer)
//!   "parse error at line L:COL: ..."      (parser — position of the token
//!                                          that broke the parse)
//!   "line L:COL: ..."                     (checker/codegen — statement site)
//!   "internal: ..."                       (compiler invariant violated —
//!                                          a bug, not a user error)
//! `render()` turns any positioned message into an excerpt with a caret
//! pointing at the column, so `lilac build` failures read like a real
//! toolchain's, not a bare one-liner.

/// Internal invariant message — these are compiler bugs, never user errors.
pub fn internal(msg: &str) -> String {
    format!("internal: {} (this is a lilac bug — please report it)", msg)
}

/// One parsed position from an error message, if present.
fn parse_pos(err: &str) -> Option<(u32, u32)> {
    // accept "line L:C" anywhere in the message; the specific prefixes
    // ("lex error at line ...", "parse error at line ...", "line ...") all
    // funnel into the same capture
    let idx = err.find("line ")?;
    let rest = &err[idx + 5..];
    let mut it = rest.splitn(2, ':');
    let line: u32 = it.next()?.parse().ok()?;
    let col_part = it.next()?.trim_start();
    let col: u32 = col_part.split(|c: char| !c.is_ascii_digit()).next()?.parse().ok()?;
    Some((line, col))
}

/// Render an error against the source text: the message line plus the
/// offending source line with a caret at the column. Falls back to the bare
/// message when no position or the line is out of range (e.g. internal
/// errors, IO errors).
pub fn render(src: &str, err: &str) -> String {
    // v23.2 ERROR RECOVERY: a multi-error report ("...\n\nline L:C: ...")
    // renders one caret block per error, like rustc's batched output.
    if err.contains("\n\nline ") {
        let mut parts: Vec<&str> = err.split("\n\n").collect();
        // a trailing "(N parse errors total...)" footnote rides the last
        // block untouched
        let footnote = if parts.last().map_or(false, |p| p.contains("parse errors total")) {
            parts.pop()
        } else {
            None
        };
        let mut out = parts.iter()
            .map(|seg| render(src, seg))
            .collect::<Vec<_>>()
            .join("\n");
        if let Some(f) = footnote { out.push('\n'); out.push_str(f); }
        return out;
    }
    let Some((line, col)) = parse_pos(err) else {
        return err.to_string();
    };
    let Some((i, text)) = src.lines().enumerate().find(|(i, _)| *i + 1 == line as usize) else {
        return format!("{}\n  --> line {} (beyond end of source)", err, line);
    };
    let _ = i;
    // clamp the caret to the line's printable width
    let width = text.chars().count().max(1);
    let col_idx = (col.saturating_sub(1) as usize).min(width - 1);
    let indent: String = " ".repeat(col_idx);
    // one line of context above (when it exists), like rustc
    let prev = if line > 1 {
        src.lines().nth(line as usize - 2).map(|p| format!("   {} | {}\n", line - 1, p)).unwrap_or_default()
    } else {
        String::new()
    };
    format!(
        "{}\n{}   {} | {}\n   {} | {}^",
        err,
        prev,
        line,
        text,
        line,
        indent
    )
}

// ============================================================================
// v23.2 — CURRENT STATEMENT POSITION (threadlocal)
// ============================================================================
//
// The checker reports ~300 error messages shaped "line {f.line}: ...".
// Historically f.line is the FUNCTION's first line, so every semantic error
// inside a fn body pointed at the fn declaration — the single worst
// diagnostic-quality defect in the toolchain (the fixpoint: the AST carried
// no per-statement position).
//
// Rather than re-thread a `pos` parameter through every checker signature,
// the parser now wraps each statement in `Stmt::At { line, col, inner }`,
// `check_block` publishes the enclosing statement's position into this
// threadlocal slot before checking it, and the error sites render
// `cur_pos()` — statement-accurate "line L:C" prefixes that `render()`
// turns into carets. Single-threaded by construction (one compile job).
//
// Position tracking is METADATA: when no statement is active (decl-level
// checks, fn-signature errors) the slot falls back to (0, 0) and callers
// that genuinely mean the fn keep using f.line.

use std::cell::Cell;

thread_local! {
    static CUR_POS: Cell<(u32, u32)> = const { Cell::new((0, 0)) };
}

/// Publish the position of the statement about to be checked/codegen'd.
pub fn set_pos(line: u32, col: u32) {
    CUR_POS.with(|p| p.set((line, col)));
}

/// Position prefix for checker/codegen error messages: "line L:C", or the
/// bare fallback "line L" when no statement position was published (col 0).
pub fn cur_pos() -> String {
    let (l, c) = CUR_POS.with(|p| p.get());
    if c == 0 { format!("{}", l) } else { format!("{}:{}", l, c) }
}

/// The current statement's line only (for contexts that keep the historic
/// one-number shape).
pub fn cur_line() -> u32 {
    CUR_POS.with(|p| p.get()).0
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn positioned_message_roundtrip() {
        let m = "line 3:7: bad thing";
        assert_eq!(parse_pos(&m), Some((3, 7)));
    }

    #[test]
    fn render_places_caret() {
        let src = "fn update() {\n    px = ;\n}";
        let out = render(src, "line 2:9: expected expression");
        assert!(out.contains("    px = ;"));
        assert!(out.contains("^"));
        assert!(out.contains("line 2:9"));
    }

    #[test]
    fn render_plain_errors_untouched() {
        assert_eq!(render("src", "cannot read 'x'"), "cannot read 'x'");
        assert!(render("src", &internal("boom")).starts_with("internal:"));
    }

    #[test]
    fn lexer_shaped_positions_parse() {
        assert_eq!(parse_pos("lex error at line 12:5: nope"), Some((12, 5)));
        assert_eq!(parse_pos("parse error at line 4:2: expected RParen"), Some((4, 2)));
    }
}

// ---------------- v17: multi-file diagnostics ----------------

use crate::include::Source;

/// Render an error against a MULTI-FILE source: positions "line L:C" in the
/// message are GLOBAL (spliced) lines — resolve them through the source's
/// line map to the real (file, local line), rewrite the message, and pull
/// the excerpt from the right file. Falls back to plain `render` when the
/// project has no includes (single file: the map is the identity).
pub fn render_with_files(src: &Source, err: &str) -> String {
    if src.files.len() <= 1 {
        return render(&src.text, err);
    }
    let Some((line, col)) = parse_pos(err) else {
        return err.to_string();
    };
    let li = if line >= 1 { (line - 1) as usize } else { usize::MAX };
    let Some(&(file_idx, local_line)) = src.line_map.get(li) else {
        return render(&src.text, err);
    };
    let file = &src.files[file_idx as usize];
    // rewrite the position in the message: the FIRST "line L" occurrence
    let pos_str = format!("line {}:", line);
    let rewritten = match err.find(&pos_str) {
        Some(i) => {
            let mut out = err[..i].to_string();
            out.push_str(&format!("{}:{}:", short_name(&file.path), local_line));
            out.push_str(&err[i + pos_str.len()..]);
            out
        }
        None => err.to_string(),
    };
    // excerpt from the real file
    let Some((i, text)) = file.text.lines().enumerate().find(|(i, _)| *i + 1 == local_line as usize) else {
        return format!("{}\n  --> {} line {} (beyond end of file)", rewritten, file.path, local_line);
    };
    let _ = i;
    let width = text.chars().count().max(1);
    let col_idx = (col.saturating_sub(1) as usize).min(width - 1);
    let indent: String = " ".repeat(col_idx);
    let prev = if local_line > 1 {
        file.text.lines().nth(local_line as usize - 2)
            .map(|p| format!("   {} | {}\n", local_line - 1, p)).unwrap_or_default()
    } else {
        String::new()
    };
    format!(
        "{}\n{}   {} | {}\n   {} | {}^",
        rewritten,
        prev,
        local_line,
        text,
        local_line,
        indent
    )
}

fn short_name(path: &str) -> String {
    path.rsplit('/').next().unwrap_or(path).to_string()
}

#[cfg(test)]
mod multi_tests {
    use super::*;
    use crate::include::FileSrc;

    #[test]
    fn multi_file_rewrite() {
        let src = Source {
            text: String::new(),
            files: vec![
                FileSrc { path: "main.lila".into(), text: "a\nb\nc".into() },
                FileSrc { path: "lib.lila".into(), text: "x\npx = ;\ny".into() },
            ],
            line_map: vec![(0, 1), (0, 2), (1, 1), (1, 2), (1, 3), (0, 3)],
        };
        let out = render_with_files(&src, "parse error at line 4:9: expected expression (found Semi)");
        assert!(out.contains("lib.lila:2:9"), "{}", out);
        assert!(out.contains("px = ;"), "{}", out);
        assert!(!out.contains("line 4"), "{}", out);
    }
}
