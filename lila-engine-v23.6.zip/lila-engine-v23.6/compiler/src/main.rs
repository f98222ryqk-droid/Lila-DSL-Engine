//! lilac — the LILA compiler CLI.
//! subcommands: build, disasm, watch, shader, wavfit
//!
//! v8 OPTIMIZER PIPELINE (all of it DEV-TIME — the player never runs any of
//! this; the runtime executes only the finished math baked into the .libyte):
//!
//!   [lex/parse] -> [AUDIO: .wav -> O(1) f(t) fits] -> [checker]
//!     -> opt::ranges  (minimum bit-width synthesis, `optimize: true`)
//!     -> opt::soa     (cache-line SoA repack + Zig comptime manifest)
//!     -> opt::physics (Chebyshev guards + Galois 32-lane collision masks)
//!     -> opt::fsm     (bit-plane transition tables + branchless expansion)
//!     -> [codegen] -> [huffman + .libyte v3]
//!
//! LEGACY CONTRACT: a game that uses NONE of the new features (no
//! `optimize: true`, no `fsm` blocks, no `sfx ... from:`) takes NO passes and
//! produces byte-identical .libyte output to the pre-optimizer compiler.

mod lexer;
mod include;
mod ast;
mod parser;
mod checker;
mod codegen;
mod huffman;
mod libyte;
mod disasm;
mod diag;
mod opt;
mod states;
mod synth;
mod gameplay;
mod dreamtrace;
mod forge;

use std::time::Instant;

fn read_source(path: &str) -> Result<String, String> {
    std::fs::read_to_string(path).map_err(|e| format!("cannot read '{}': {}", path, e))
}

/// Value of a `flag value` CLI argument. The old code indexed
/// `args[i + 1]` unchecked — `lilac build x.lila -o` as the last argument
/// PANICKED with "index out of bounds". Now it's a usage error.
fn flag_value(args: &[String], flag: &str) -> Result<Option<String>, String> {
    match args.iter().position(|a| a == flag) {
        Some(i) => {
            if i + 1 >= args.len() {
                return Err(format!("flag {} needs a value (it was the last argument)", flag));
            }
            Ok(Some(args[i + 1].clone()))
        }
        None => Ok(None),
    }
}

#[derive(Debug)]
pub struct BuildReport {
    pub source_bytes: usize,
    pub libyte_bytes: usize,
    pub libyte: Vec<u8>,
    pub code_uncompressed: usize,
    pub code_huffman: usize,
    pub opt: opt::OptReport,
    /// file format version emitted (1, 2 or 3)
    pub version: u16,
    /// v19: the cartridge fn table in WIRE ORDER — (name, nparams). Index i
    /// here IS fn_idx i in the cartridge records (codegen emits ctx.fns in
    /// order; libyte writes the records in that same order). FORGE's table
    /// promotion relies on this identity.
    pub fn_table: Vec<(String, u8)>,
    /// v23: --emit-bridges report (pointer-overlay layouts written to disk)
    pub interop: Option<forge::interop::InteropReport>,
    /// v23.5 ABI v2: optional AOT artifacts emitted from the SAME Code that
    /// was packed above — the AOT view and the shipped cartridge can never
    /// drift again (the old `lilac aot` re-ran a SHORTER pipeline).
    pub aot: Option<AotArtifacts>,
    /// v23.6: fns whose CHECKER-INFERRED return type is f64 — the tables
    /// baker must skip them (the probe stores only ret_val; an f64 return
    /// parks a (lo, hi) pair). AST-only forge can't see inferred types.
    pub f64_ret_fns: Vec<String>,
}

/// AOT backend output, produced from the post-optimizer Code.
#[derive(Debug)]
pub struct AotArtifacts {
    pub header: String,
    pub source: String,
    /// LLVM backend: the .ll text (None for the C backend)
    pub ir: Option<String>,
    pub fns_compiled: usize,
    pub fns_skipped: usize,
    pub ops_lowered: usize,
}

/// One full compile: source text -> .libyte bytes. The optimizer passes run
/// here, gated on the game's opt-in flags (see the module doc).
/// `base_dir` resolves asset paths (`sfx ... from:`) relative to the SOURCE
/// file, so builds work from any working directory.
#[cfg_attr(not(test), allow(dead_code))] // v17: kept for the inline test suites
/// v23.2 ERROR RECOVERY: the parser records every syntax error it can
/// recover from; this drains them as one rendered report. A non-empty list
/// means the AST is PARTIAL — the caller must stop before checking/codegen.
fn drain_parse_errors(p: &parser::Parser) -> Result<(), String> {
    if p.errors.is_empty() { return Ok(()); }
    let mut joined = String::new();
    for (i, e) in p.errors.iter().enumerate() {
        if i > 0 { joined.push_str("\n\n"); }
        joined.push_str(e);
    }
    joined.push_str(&format!("\n({} parse errors total — fix these before semantic checks run)", p.errors.len()));
    Err(joined)
}

fn compile_to_libyte(src: &str, zig_opt_path: Option<&str>, base_dir: Option<&str>) -> Result<(Vec<u8>, BuildReport), String> {
    let source = include::Source {
        text: src.to_string(),
        files: vec![include::FileSrc { path: String::new(), text: src.to_string() }],
        line_map: Vec::new(),
    };
    compile_source(&source, zig_opt_path, base_dir, None, None)
}

/// v17: the real entry — a (possibly multi-file) Source. Single-file callers
/// wrap a string through compile_to_libyte above.
/// The optimizer pipeline, SHARED by `build`, `aot` and `aot-llvm`.
///
/// v23.5 ABI v2 fix: the AOT verbs previously ran tier purity ONLY — while
/// `lilac build` ran the full optimizer. For `optimize: true` games the SoA
/// repack (and friends) REORDER the schema and remap typed-field indices,
/// so the packed cartridge the interpreter executes disagreed with the
/// in-memory stream the C/IR emitters baked — the AOT wrote the right
/// values into the WRONG fields (the fixture differential caught it).
/// Running the identical passes here makes the AOT view the same stream
/// the packer ships. Deterministic passes: same source in, same stream out.
fn run_opt_passes(
    ctx: &mut checker::Ctx,
    zig_opt_path: Option<&str>,
) -> Result<(opt::OptReport, Vec<Vec<u8>>, Vec<Vec<u16>>), String> {
    let mut report = opt::OptReport::default();
    let mut fsm_tables: Vec<Vec<u8>> = Vec::new();

    // ---- SUBSYSTEM 0: TIER PURITY FIXPOINT ----
    // Runs unconditionally so the report is always available and every game
    // exercises the pass. The report is stashed on Ctx so each subsequent
    // opt pass can consult it via `ctx.tier_purity_ctx`.
    {
        let tp = opt::tier::compute_tier_purity(ctx);
        ctx.tier_purity_ctx = Some(tp.clone());
        report.tier_purity = Some(tp);
    }

    if ctx.game.optimize {
        // [1a] minimum bit-width synthesis over every assignment site
        let r = opt::ranges::narrow(ctx);
        report.narrowed = r.narrowed;

        // [1b] access-density SoA reorder + zero-hole repack + comptime manifest
        let r = opt::soa::synthesize(ctx, zig_opt_path);
        report.row_bytes_saved = r.row_bytes_saved;
        report.hot_segments = r.hot_segments;

        // [3] physics: Chebyshev guards + Galois 32-lane collision masks
        let r = opt::physics::rewrite(ctx);
        report.physics = r.rewrites;

        // [6] superoptimization: conditional assignment diamonds and
        // cond-moves -> single branchless SEL data edges
        report.sel_moves = opt::select::rewrite(ctx);

        // [7] static arena & lifetime synthesis
        match opt::arena::synthesize(ctx) {
            Ok(a) => {
                report.arena = a.rows.iter().map(|r| {
                    (r.entity.clone(), r.proven, r.capacity, r.dynamic)
                }).collect();
                report.arena_bytes = a.entity_region_bytes;
            }
            Err(e) => return Err(e),
        }

        // [8] graph-theory schedule proof
        let s = opt::arena::schedule_proof(ctx);
        report.schedule = Some((s.systems, s.raw_edges, s.war_pairs));
    }

    if !ctx.fsms.is_empty() {
        // [5] AI: bake bit-plane transition tables + expand fsm_step
        let r = opt::fsm::expand(ctx);
        report.fsms = r.report;
        fsm_tables = r.tables;
    }

    // [10] compile-proven parallel systems
    let mut par_plan: Vec<Vec<u16>> = Vec::new();
    if ctx.game.optimize {
        let plan = opt::arena::parallel_groups(ctx);
        let members: usize = plan.groups.iter().map(|g| g.len()).sum();
        if !plan.groups.is_empty() {
            report.parallel = Some((members, plan.groups.len()));
            par_plan = plan.groups.iter()
                .map(|g| g.iter().map(|&fi| fi as u16).collect())
                .collect();
        }
    }

    Ok((report, fsm_tables, par_plan))
}

fn compile_source(source: &include::Source, zig_opt_path: Option<&str>, base_dir: Option<&str>, bridges: Option<&str>, aot: Option<(&str, &str)>) -> Result<(Vec<u8>, BuildReport), String> {
    let src: &str = &source.text;
    let (toks, atom_names) = lexer::Lexer::new(src).tokenize()?;
    let mut p = parser::Parser::new(toks, atom_names);
    let mut prog = p.parse_program()?;
    drain_parse_errors(&p)?; // v23.2: report EVERY syntax error, not the first
    let atom_names = std::mem::take(&mut p.atom_names);

    // ---- v10 LANGUAGE SYNTHESIS (before checking) — prefabs + particles
    // + v20 mixins lower to plain entities/fns; the rest of the pipeline
    // never knows. v20: UNCONDITIONAL — the old condition skipped expand
    // for prefab-only/no-particles games, leaving `from` unresolved.
    let synth_rows: Vec<(String, String)> = synth::expand(&mut prog, &atom_names, base_dir.unwrap_or("."))?;

    // ---- v20 COROUTINE STATES: lower state/wait/-> into switch + fields
    // (pure sugar — the checker, codegen and runtime never see them)
    let state_rows = states::expand(&mut prog)?;
    let mut synth_rows = synth_rows;
    synth_rows.extend(state_rows);

    // ---- v21 GAMEPLAY FUNDAMENTALS: timers (every), collide, body physics
    // and levels — all lowered to plain AST before the checker (the v10
    // synth doctrine: the runtime never knows they existed).
    let gp_rows = gameplay::expand(&mut prog)?;
    synth_rows.extend(gp_rows);

    // ---- SUBSYSTEM 4 (audio): fit every `sfx #x { from: "y.wav" }` NOW, at
    // build time. The .wav is a dev asset: it never ships, and the runtime
    // only ever sees the fitted O(1) synthesis parameters in the bytecode.
    let mut fitted_audio: std::collections::HashMap<u16, opt::audio::FittedSfx> =
        std::collections::HashMap::new();
    let mut audio_rows: Vec<(String, String, f32)> = Vec::new();
    for sd in &prog.sfx {
        if let Some(path) = &sd.from {
            let name = atom_names.get(sd.atom as usize)
                .map(|s| s.as_str()).unwrap_or("sfx").to_string();
            // asset paths are relative to the SOURCE file (then CWD)
            let resolved: String = {
                let cand = match base_dir {
                    Some(d) if !d.is_empty() => format!("{}/{}", d, path),
                    _ => path.clone(),
                };
                if std::path::Path::new(&cand).exists() { cand } else { path.clone() }
            };
            let bytes = std::fs::read(&resolved)
                .map_err(|e| format!("sfx #{}: cannot read '{}': {}", name, resolved, e))?;
            let pcm = opt::audio::parse_wav(&bytes)
                .map_err(|e| format!("sfx #{} ({}): {}", name, resolved, e))?;
            let fit = opt::audio::fit(&name, &pcm)
                .map_err(|e| format!("sfx #{} ({}): {}", name, resolved, e))?;
            if fit.residual > 0.6 {
                eprintln!("warning: sfx #{}: fit residual {:.1}% is high — the baked f(t) will be a loose approximation of '{}'",
                    name, fit.residual * 100.0, resolved);
            }
            audio_rows.push((name, fit.equation.clone(), fit.residual));
            fitted_audio.insert(sd.atom, fit);
        }
    }

    let mut ctx = checker::check(&prog, atom_names, &fitted_audio)?;

    // ---- OPT PASSES (shared with the aot/aot-llvm verbs — see run_opt_passes) ----
    let (mut report, fsm_tables, par_plan) = run_opt_passes(&mut ctx, zig_opt_path)?;

    // ---- v23 BRIDGE EMITTER (--emit-bridges): pointer-overlay layouts ----
    // Derived from the FINAL post-SoA Ctx — the same field order and bit
    // offsets the .libyte schema carries — so the host's LilaInterop.h /
    // LilaInterop.cs can never disagree with the cartridge (a stale pair
    // fails the host's static asserts AND lila_overlay_install's hash).
    let interop = match bridges {
        Some(dir) => Some(forge::interop::emit(&ctx, dir)?),
        None => None,
    };

    report.audio = audio_rows;
    report.synth = synth_rows;

    let code = codegen::gen(&ctx)?;

    // ---- v23.5 AOT EMIT (same Code that is packed below — zero drift) ----
    let aot_out = match aot {
        Some(("c", _)) => {
            let tp = ctx.tier_purity_ctx.clone()
                .ok_or_else(|| "internal: tier purity missing after opt passes".to_string())?;
            let o = opt::cbackend::emit(&ctx, &code, &tp);
            Some(AotArtifacts {
                header: o.header, source: o.source, ir: None,
                fns_compiled: o.fns_compiled, fns_skipped: o.fns_skipped,
                ops_lowered: o.ops_lowered,
            })
        }
        Some(("llvm", _)) => {
            let tp = ctx.tier_purity_ctx.clone()
                .ok_or_else(|| "internal: tier purity missing after opt passes".to_string())?;
            let o = opt::llvm_backend::emit(&ctx, &code, &tp);
            Some(AotArtifacts {
                header: String::new(), source: String::new(),
                ir: Some(o.ir),
                fns_compiled: o.fns_compiled, fns_skipped: o.fns_skipped,
                ops_lowered: 0,
            })
        }
        Some((b, _)) => return Err(format!("unknown AOT backend '{}'", b)),
        None => None,
    };

    let res = libyte::emit(&ctx, &code, &fsm_tables, &par_plan);
    let n = res.bytes.len();
    let out_bytes = res.bytes.clone();
    let fn_table: Vec<(String, u8)> =
        ctx.fns.iter().map(|f| (f.name.clone(), f.params.len() as u8)).collect();
    let f64_ret_fns: Vec<String> = ctx.fns.iter()
        .filter(|f| f.ret == Some(crate::checker::VT::F64))
        .map(|f| f.name.clone())
        .collect();
    Ok((out_bytes, BuildReport {
        source_bytes: src.len(),
        libyte_bytes: n,
        libyte: res.bytes.clone(),
        code_uncompressed: res.code_uncompressed,
        code_huffman: res.code_packed,
        opt: {
            let mut r = report;
            if res.text_uncompressed > 0 {
                r.text_pack = Some((res.text_uncompressed, res.text_packed));
            }
            r
        },
        version: libyte::emitted_version(&ctx, &fsm_tables, !par_plan.is_empty(), Some(&code)),
        fn_table,
        interop,
        aot: aot_out,
        f64_ret_fns,
    }))
}

fn print_build_report(report: &BuildReport) {
    let ratio = if report.code_uncompressed > 0 {
        100.0 - (report.code_huffman as f64 / report.code_uncompressed as f64 * 100.0)
    } else { 0.0 };
    println!("  code: {} B raw -> {} B huffman ({:.1}% smaller)",
        report.code_uncompressed, report.code_huffman, ratio);
    report.opt.print();
    if let Some(b) = &report.interop {
        println!("  bridges: LilaInterop.h + LilaInterop.cs ({} types, {} lanes, layout 0x{:08X})",
            b.types, b.lanes, b.hash);
    }
    if let Ok(b) = disasm::budget(&report.libyte) {
        print!("{}", b);
    }
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.len() < 2 {
        eprintln!("usage: lilac <build|disasm|watch|shader|wavfit|forge|aot|aot-llvm> [args]");
        std::process::exit(2);
    }
    match args[1].as_str() {
        "build" => {
            if args.len() < 3 {
                eprintln!("usage: lilac build <input.lila> [-o output.libyte] [--emit-zig-opt path.zig] [--emit-bridges [dir]]");
                std::process::exit(2);
            }
            let in_path = &args[2];
            let out_path = flag_value(&args, "-o").unwrap_or_else(|e| {
                eprintln!("error: {}", e);
                std::process::exit(2);
            }).unwrap_or_else(|| {
                    let stem = in_path.trim_end_matches(".lila");
                    format!("{}.libyte", stem)
                });
            let zig_opt = flag_value(&args, "--emit-zig-opt").unwrap_or_else(|e| {
                eprintln!("error: {}", e);
                std::process::exit(2);
            });
            // v23: --emit-bridges [dir] — the value is OPTIONAL (defaults to
            // the output directory). Emits LilaInterop.h + LilaInterop.cs:
            // pack(1) row structs matching the cartridge's final SoA layout,
            // with static asserts and the FNV layout hash.
            let bridges = match args.iter().position(|a| a == "--emit-bridges") {
                Some(i) => {
                    let dir = args.get(i + 1)
                        .filter(|v| !v.starts_with('-'))
                        .cloned()
                        .unwrap_or_else(|| {
                            std::path::Path::new(&out_path).parent()
                                .map(|p| p.to_string_lossy().into_owned())
                                .filter(|p| !p.is_empty())
                                .unwrap_or_else(|| ".".to_string())
                        });
                    Some(dir)
                }
                None => None,
            };
            let t0 = Instant::now();
            let source = match include::load(std::path::Path::new(in_path)) {
                Ok(s) => s,
                Err(e) => { eprintln!("error: {}", e); std::process::exit(1); }
            };
            let base_dir = std::path::Path::new(in_path).parent()
                .map(|p| p.to_string_lossy().into_owned());
            match compile_source(&source, zig_opt.as_deref(), base_dir.as_deref(), bridges.as_deref(), None) {
                Ok((bytes, report)) => {
                    let ms = t0.elapsed().as_secs_f64() * 1000.0;
                    if let Err(e) = std::fs::write(&out_path, &bytes) {
                        eprintln!("error: cannot write '{}': {}", out_path, e);
                        std::process::exit(1);
                    }
                    println!("{} -> {} ({} bytes, v{}, {:.2} ms){}",
                        in_path, out_path, bytes.len(), report.version, ms,
                        if source.files.len() > 1 {
                            format!(" [{} files]", source.files.len())
                        } else { String::new() });
                    print_build_report(&report);
                }
                Err(e) => {
                    eprintln!("error: {}", diag::render_with_files(&source, &e));
                    std::process::exit(1);
                }
            }
        }
        "watch" => {
            if args.len() < 3 {
                eprintln!("usage: lilac watch <input.lila> [-o output.libyte]");
                std::process::exit(2);
            }
            let in_path = args[2].clone();
            let out_path = flag_value(&args, "-o").unwrap_or_else(|e| {
                eprintln!("error: {}", e);
                std::process::exit(2);
            }).unwrap_or_else(|| {
                    let stem = in_path.trim_end_matches(".lila");
                    format!("{}.libyte", stem)
                });
            let mut last_sig: u64 = 0;
            println!("lilac watch: {} -> {} (Ctrl-C to stop)", in_path, out_path);
            let base_dir = std::path::Path::new(&in_path).parent()
                .map(|p| p.to_string_lossy().into_owned());
            loop {
                // v17: the project is the ROOT plus every included file —
                // all of them are hashed, so editing a library rebuilds.
                let source = match include::load(std::path::Path::new(&in_path)) {
                    Ok(s) => s,
                    Err(_) => {
                        std::thread::sleep(std::time::Duration::from_millis(50));
                        continue;
                    }
                };
                // fnv-1a change detect over every file's bytes
                let mut h: u64 = 1469598103934665603;
                for f in &source.files {
                    for b in f.path.bytes() {
                        h ^= b as u64;
                        h = h.wrapping_mul(1099511628211);
                    }
                    for b in f.text.bytes() {
                        h ^= b as u64;
                        h = h.wrapping_mul(1099511628211);
                    }
                }
                if h != last_sig {
                    if last_sig != 0 {
                        let t0 = Instant::now();
                        match compile_source(&source, None, base_dir.as_deref(), None, None) {
                            Ok((bytes, _report)) => {
                                if let Err(e) = std::fs::write(&out_path, &bytes) {
                                    eprintln!("error: cannot write '{}': {}", out_path, e);
                                } else {
                                    let ms = t0.elapsed().as_secs_f64() * 1000.0;
                                    println!("rebuilt {} ({}B, {:.2} ms, {} files) -> {}",
                                        in_path, bytes.len(), ms, source.files.len(), out_path);
                                }
                            }
                            Err(e) => eprintln!("error: {} (keeping last good build)", diag::render_with_files(&source, &e)),
                        }
                    } else {
                        // initial build
                        let t0 = Instant::now();
                        match compile_source(&source, None, base_dir.as_deref(), None, None) {
                            Ok((bytes, _)) => {
                                let _ = std::fs::write(&out_path, &bytes);
                                let ms = t0.elapsed().as_secs_f64() * 1000.0;
                                println!("initial build {} ({}B, {:.2} ms, {} files)",
                                    in_path, bytes.len(), ms, source.files.len());
                            }
                            Err(e) => eprintln!("error: {}", diag::render_with_files(&source, &e)),
                        }
                    }
                    last_sig = h;
                }
                std::thread::sleep(std::time::Duration::from_millis(50));
            }
        }
        "disasm" => {
            if args.len() < 3 {
                eprintln!("usage: lilac disasm <file.libyte>");
                std::process::exit(2);
            }
            let bytes = match std::fs::read(&args[2]) {
                Ok(b) => b,
                Err(e) => { eprintln!("error: cannot read '{}': {}", args[2], e); std::process::exit(1); }
            };
            match disasm::disasm(&bytes) {
                Ok(text) => print!("{}", text),
                Err(e) => { eprintln!("error: {}", e); std::process::exit(1); }
            }
        }
        // ---- v20 DREAMTRACE: branch evidence from self-play ----
        // (the .dreammap is written by: runner <game.libyte> --dream <spec.dream>)
        "dreamtrace" => {
            if args.len() < 4 {
                eprintln!("usage: lilac dreamtrace <game.libyte> <map.dreammap>");
                eprintln!("  (the .dreammap is written by: runner <game.libyte> --dream <spec.dream>)");
                std::process::exit(2);
            }
            let cart = match std::fs::read(&args[2]) {
                Ok(b) => b,
                Err(e) => { eprintln!("error: cannot read '{}': {}", args[2], e); std::process::exit(1); }
            };
            let map = match std::fs::read(&args[3]) {
                Ok(b) => b,
                Err(e) => { eprintln!("error: cannot read '{}': {}", args[3], e); std::process::exit(1); }
            };
            match dreamtrace::report(&cart, &map) {
                Ok(text) => print!("{}", text),
                Err(e) => { eprintln!("error: {}", e); std::process::exit(1); }
            }
        }
        // ---- SUBSYSTEM 2 CLI: SDF -> branchless WGSL sphere tracers ----
        "shader" => {
            if args.len() < 3 {
                eprintln!("usage: lilac shader <input.lila> [-o outdir]");
                std::process::exit(2);
            }
            let in_path = &args[2];
            let out_dir = flag_value(&args, "-o").unwrap_or_else(|e| {
                eprintln!("error: {}", e);
                std::process::exit(2);
            }).unwrap_or_else(|| ".".to_string());
            let src = match read_source(in_path) {
                Ok(s) => s,
                Err(e) => { eprintln!("error: {}", e); std::process::exit(1); }
            };
            match shader_verb(&src, &out_dir) {
                Ok(n) => println!("{}: {} shader(s) synthesized + naga-validated -> {}", in_path, n, out_dir),
                Err(e) => { eprintln!("error: {}", e); std::process::exit(1); }
            }
        }
        // ---- v23 AOT CLI: lower Tier-0 fns to C source ----
        "aot" => {
            if args.len() < 3 {
                eprintln!("usage: lilac aot <input.lila> [-o outdir]");
                eprintln!("       emits lila_aot.h + lila_aot.c in outdir (default: .)");
                std::process::exit(2);
            }
            let in_path = &args[2];
            let out_dir = flag_value(&args, "-o").unwrap_or_else(|e| {
                eprintln!("error: {}", e);
                std::process::exit(2);
            }).unwrap_or_else(|| ".".to_string());
            match aot_verb(in_path, &out_dir) {
                Ok((compiled, skipped, ops, cart)) => {
                    // v23.5: write the cart BUILT BY THE SAME COMPILATION —
                    // the differential contract requires the AOT code and the
                    // packed stream to come from one pipeline.
                    let cart_path = format!("{}/game.libyte", out_dir);
                    if let Err(e) = std::fs::write(&cart_path, &cart) {
                        eprintln!("error: cannot write {}: {}", cart_path, e);
                        std::process::exit(1);
                    }
                    println!("{}: AOT C backend -> {}/", in_path, out_dir);
                    println!("  lila_aot.h + lila_aot.c + game.libyte (same pipeline)");
                    println!("  Tier-0 fns compiled: {} (skipped {} Tier-1)", compiled, skipped);
                    println!("  opcodes lowered: {} (rest fall back to interpreter)", ops);
                    println!("  compile with: cc -O2 -c {}/lila_aot.c -o lila_aot.o", out_dir);
                }
                Err(e) => { eprintln!("error: {}", e); std::process::exit(1); }
            }
        }
        // ---- v23 AOT-LLVM CLI: lower Tier-0 fns to LLVM IR ----
        "aot-llvm" => {
            if args.len() < 3 {
                eprintln!("usage: lilac aot-llvm <input.lila> [-o outdir]");
                eprintln!("       emits lila_aot.ll in outdir (default: .)");
                eprintln!("       compile with: clang -O2 -c lila_aot.ll -o lila_aot.o");
                std::process::exit(2);
            }
            let in_path = &args[2];
            let out_dir = flag_value(&args, "-o").unwrap_or_else(|e| {
                eprintln!("error: {}", e);
                std::process::exit(2);
            }).unwrap_or_else(|| ".".to_string());
            match aot_llvm_verb(in_path, &out_dir) {
                Ok((compiled, skipped, cart)) => {
                    let cart_path = format!("{}/game.libyte", out_dir);
                    if let Err(e) = std::fs::write(&cart_path, &cart) {
                        eprintln!("error: cannot write {}: {}", cart_path, e);
                        std::process::exit(1);
                    }
                    println!("{}: AOT LLVM IR -> {}/lila_aot.ll", in_path, out_dir);
                    println!("  game.libyte written from the same pipeline");
                    println!("  Tier-0 fns compiled: {} (skipped {} Tier-1)", compiled, skipped);
                    println!("  compile with: clang -O2 -c {}/lila_aot.ll -o lila_aot.o", out_dir);
                }
                Err(e) => { eprintln!("error: {}", e); std::process::exit(1); }
            }
        }
        // ---- SUBSYSTEM 4 CLI: fit one .wav and print the recovered program ----
        "wavfit" => {
            if args.len() < 3 {
                eprintln!("usage: lilac wavfit <file.wav>");
                std::process::exit(2);
            }
            let bytes = match std::fs::read(&args[2]) {
                Ok(b) => b,
                Err(e) => { eprintln!("error: cannot read '{}': {}", args[2], e); std::process::exit(1); }
            };
            match opt::audio::parse_wav(&bytes).and_then(|pcm| opt::audio::fit(&args[2], &pcm)) {
                Ok(fit) => {
                    let (kind, desc) = match &fit.model {
                        opt::audio::FittedModel::Fm(p) => ("FM", format!(
                            "f0={}Hz sweep={:+}Hz/s ratio={:.3} index={:.2} decay={} vol={} noise={}",
                            p.f0, p.sweep, p.ratio_q4 as f32 / 16.0, p.index_q4 as f32 / 16.0,
                            p.decay, p.vol, p.noise)),
                        opt::audio::FittedModel::Add(p) => ("ADD", format!(
                            "f0={}Hz decay={} vol={} partials={}",
                            p.f0, p.decay, p.vol,
                            p.partials.iter().map(|(r, a, _)| format!("{:.3}x{}", *r as f32 / 64.0, a))
                                .collect::<Vec<_>>().join(","))),
                    };
                    println!("{}: {} voice (residual {:.1}%)", args[2], kind, fit.residual * 100.0);
                    println!("  equation: {}", fit.equation);
                    println!("  params:   {}", desc);
                }
                Err(e) => { eprintln!("error: {}", e); std::process::exit(1); }
            }
        }
        // v18 FORGE — the whole-game optimizer verb.
        "forge" => {
            if args.len() < 3 {
                eprintln!("usage: lilac forge <input.lila> [--assets mapping.lilaforge] [--corpus dir-or-file] [--card desktop|mobile|cloud_min] [-o outdir]");
                std::process::exit(2);
            }
            let in_path = &args[2];
            let card_name = flag_value(&args, "--card").unwrap_or_else(|e| {
                eprintln!("error: {}", e); std::process::exit(2);
            }).unwrap_or_else(|| "desktop".to_string());
            let card = match forge::PlatformCard::get(&card_name) {
                Ok(c) => c,
                Err(e) => { eprintln!("error: {}", e); std::process::exit(2); }
            };
            let source = match include::load(std::path::Path::new(in_path)) {
                Ok(s) => s,
                Err(e) => { eprintln!("error: {}", e); std::process::exit(1); }
            };
            let base_dir = std::path::Path::new(in_path).parent()
                .map(|p| p.to_string_lossy().into_owned())
                .unwrap_or_default();
            // compile for the cartridge bytes (hash-stamped into the manifest)
            let (libyte, build) = match compile_source(&source, None, Some(&base_dir), None, None) {
                Ok(r) => r,
                Err(e) => { eprintln!("error: {}", diag::render_with_files(&source, &e)); std::process::exit(1); }
            };
            // parse (again — 2ms) for the atom/usage view FORGE needs
            let (toks, atom_names) = match lexer::Lexer::new(&source.text).tokenize() {
                Ok(r) => r,
                Err(e) => { eprintln!("error: {}", diag::render_with_files(&source, &e)); std::process::exit(1); }
            };
            let mut p = parser::Parser::new(toks, atom_names);
            let mut prog = match p.parse_program() {
                Ok(pr) => pr,
                Err(e) => { eprintln!("error: {}", diag::render_with_files(&source, &e)); std::process::exit(1); }
            };
            let atom_names = std::mem::take(&mut p.atom_names);
            if !prog.entities.iter().any(|e| e.from.is_some()) || !prog.particles.is_empty() {
                if let Err(e) = synth::expand(&mut prog, &atom_names, ".") {
                    eprintln!("error: {}", diag::render_with_files(&source, &e));
                    std::process::exit(1);
                }
            }
            // side-car mapping (default: assets.lilaforge next to the source)
            let assets_path = flag_value(&args, "--assets").unwrap_or_else(|e| {
                eprintln!("error: {}", e); std::process::exit(2);
            }).unwrap_or_else(|| format!("{}/assets.lilaforge", base_dir));;
            let mapping_text = match std::fs::read_to_string(&assets_path) {
                Ok(t) => t,
                Err(e) => { eprintln!("error: cannot read '{}': {}", assets_path, e); std::process::exit(1); }
            };
            // corpus: a directory of LIR1 movies or a single file
            let corpus_paths: Vec<String> = match flag_value(&args, "--corpus") {
                Ok(Some(c)) => {
                    let meta = std::fs::metadata(&c);
                    match meta {
                        Ok(m) if m.is_dir() => {
                            let mut v: Vec<String> = std::fs::read_dir(&c)
                                .map_err(|e| e.to_string()).unwrap()
                                .filter_map(|e| e.ok())
                                .map(|e| e.path().to_string_lossy().into_owned())
                                .collect();
                            v.sort();
                            v
                        }
                        _ => vec![c],
                    }
                }
                _ => Vec::new(),
            };
            let corpus_movies: Vec<Vec<u8>> = corpus_paths
                .iter()
                .filter_map(|p| std::fs::read(p).ok())
                .collect();
            // v19: empirical argument domains (MINE1, produced by the runner
            // with --mine; see forge/tables.rs for the loop)
            let mine_bytes: Option<Vec<u8>> = match flag_value(&args, "--mine-file") {
                Ok(Some(p)) => match std::fs::read(&p) {
                    Ok(b) => Some(b),
                    Err(e) => { eprintln!("error: cannot read '{}': {}", p, e); std::process::exit(1); }
                },
                Ok(None) => None,
                Err(e) => { eprintln!("error: {}", e); std::process::exit(2); }
            };
            let base = std::path::Path::new(&base_dir);
            let t0 = Instant::now();
            if std::env::var("LILAC_DEBUG_FN_TABLE").is_ok() {
                eprintln!("fn_table ({}): {:?}", build.fn_table.len(), build.fn_table.iter().take(8).collect::<Vec<_>>());
                eprintln!("prog.fns: {:?}", prog.fns.iter().map(|f| f.name.as_str()).take(8).collect::<Vec<_>>());
            }
            let out = match forge::run(&prog, &atom_names, &libyte, &mapping_text, &corpus_movies, base, &card, &build.fn_table, mine_bytes.as_deref(), &build.f64_ret_fns) {
                Ok(o) => o,
                Err(e) => { eprintln!("forge error: {}", e); std::process::exit(1); }
            };
            let outdir = flag_value(&args, "-o").unwrap_or_else(|e| {
                eprintln!("error: {}", e); std::process::exit(2);
            }).unwrap_or_else(|| if base_dir.is_empty() { ".".to_string() } else { base_dir.clone() });
            let mf = format!("{}/game.lilamanifest", outdir);
            let pf = format!("{}/game.forgepack", outdir);
            if let Err(e) = std::fs::write(&mf, &out.manifest) {
                eprintln!("error: cannot write '{}': {}", mf, e); std::process::exit(1);
            }
            if let Err(e) = std::fs::write(&pf, &out.forgepack) {
                eprintln!("error: cannot write '{}': {}", pf, e); std::process::exit(1);
            }
            let ms = t0.elapsed().as_secs_f64() * 1000.0;
            println!("forge: {} [{:.2} ms]", in_path, ms);
            out.report.print(&card);
            println!("  wrote {} + {}", mf, pf);
            // v19: the mining list — fn indices for the runner's --mine pass
            let ml = format!("{}/game.minelist", outdir);
            let ml_text: String = out.minelist.iter().map(|i| format!("{}\n", i)).collect();
            if let Err(e) = std::fs::write(&ml, ml_text) {
                eprintln!("error: cannot write '{}': {}", ml, e);
                std::process::exit(1);
            }
            if !out.minelist.is_empty() {
                println!("  wrote {} ({} fns to mine: runner game.libyte --replay movie.lir --mine game.minelist --mine-out game.mine)",
                    ml, out.minelist.len());
            }
        }
        other => {
            eprintln!("unknown subcommand '{}'", other);
            std::process::exit(2);
        }
    }
}

/// The `shader` verb: parse, fold + consolidate every `sdf` block, emit the
/// branchless WGSL tracers, naga-validate each one, write the artifacts.
/// A broken shader is a BROKEN BUILD — validation happens before success.
fn shader_verb(src: &str, out_dir: &str) -> Result<usize, String> {
    let (toks, atom_names) = lexer::Lexer::new(src).tokenize()?;
    let mut p = parser::Parser::new(toks, atom_names);
    let prog = p.parse_program()?;
    drain_parse_errors(&p)?; // v23.2: every syntax error in one round
    if prog.sdfs.is_empty() {
        return Err("no `sdf #name { ... }` blocks in this source".into());
    }
    std::fs::create_dir_all(out_dir)
        .map_err(|e| format!("cannot create '{}': {}", out_dir, e))?;
    let mut count = 0usize;
    for sd in &prog.sdfs {
        // passes 2-3: symbolic fold + smin consolidation (see opt/sdf.rs docs)
        let root = opt::sdf::fold(sd.root.clone());
        let root = opt::sdf::prune(root);
        let (root, blends_saved) = opt::sdf::consolidate(root);
        let decl = opt::sdf::SdfDecl { root, ..sd.clone() };
        let out = opt::wgsl::emit(&decl);

        // pass 6: validate BEFORE reporting success
        opt::wgsl::validate_wgsl(&out.main_wgsl, &decl.name)?;
        if let Some(hud) = &out.hud_wgsl {
            opt::wgsl::validate_wgsl(hud, &format!("{}_hud", decl.name))?;
        }

        let main_path = format!("{}/{}.wgsl", out_dir, decl.name);
        std::fs::write(&main_path, &out.main_wgsl)
            .map_err(|e| format!("cannot write '{}': {}", main_path, e))?;
        println!("  sdf #{}: {} nodes, {} blends consolidated -> {}",
            decl.name, opt::sdf::node_count(&decl.root), blends_saved, main_path);
        if let Some(hud) = &out.hud_wgsl {
            let hud_path = format!("{}/{}_hud.wgsl", out_dir, decl.name);
            std::fs::write(&hud_path, hud)
                .map_err(|e| format!("cannot write '{}': {}", hud_path, e))?;
            println!("  sdf #{}_hud: specialized screen-space variant (no march loop)", decl.name);
        }
        count += 1;
    }
    Ok(count)
}

// ============================================================================
// v23 AOT CLI VERB — `lilac aot <input.lila> [-o outdir]`
// ============================================================================
//
// Lowers Tier-0-pure functions to C source code via opt::cbackend.
// The C output can be compiled with any C compiler and linked with the
// LILA runtime. This is Step 3 of the tiered-compilation roadmap (the
// portable precursor to an LLVM IR backend).
//
// See opt/cbackend.rs for the full design.

fn aot_verb(in_path: &str, out_dir: &str) -> Result<(usize, usize, usize, Vec<u8>), String> {
    // v23.5 ABI v2: the FULL build pipeline (includes, audio fitting, the
    // optimizer, DCE, packing) runs ONCE — the C output AND the shipped
    // .libyte come from the SAME Code, so the AOT view can never drift from
    // the packed stream the interpreter executes.
    let source = include::load(std::path::Path::new(in_path))
        .map_err(|e| format!("{}", e))?;
    let base_dir = std::path::Path::new(in_path).parent()
        .map(|p| p.to_string_lossy().into_owned());
    let (bytes, report) = compile_source(&source, None, base_dir.as_deref(), None, Some(("c", out_dir)))?;
    let aot = report.aot.as_ref()
        .ok_or_else(|| "internal: AOT artifacts missing".to_string())?;
    std::fs::create_dir_all(out_dir)
        .map_err(|e| format!("cannot create '{}': {}", out_dir, e))?;
    std::fs::write(format!("{}/lila_aot.h", out_dir), &aot.header)
        .map_err(|e| format!("cannot write header: {}", e))?;
    std::fs::write(format!("{}/lila_aot.c", out_dir), &aot.source)
        .map_err(|e| format!("cannot write source: {}", e))?;
    Ok((aot.fns_compiled, aot.fns_skipped, aot.ops_lowered, bytes))
}

// ============================================================================
// v23 AOT-LLVM CLI VERB — `lilac aot-llvm <input.lila> [-o outdir]`
// ============================================================================
//
// Lowers Tier-0-pure functions to textual LLVM IR via opt::llvm_backend.
// The IR can be compiled with `clang -c` or `llc` and linked with the
// LILA runtime. This is Step 4 of the tiered-compilation roadmap —
// supersedes the C backend for users who want LLVM's optimization.
//
// See opt/llvm_backend.rs for the full design.

fn aot_llvm_verb(in_path: &str, out_dir: &str) -> Result<(usize, usize, Vec<u8>), String> {
    // v23.5 ABI v2: same single-pipeline contract as `lilac aot` — the IR is
    // emitted from the exact Code the .libyte was packed from.
    let source = include::load(std::path::Path::new(in_path))
        .map_err(|e| format!("{}", e))?;
    let base_dir = std::path::Path::new(in_path).parent()
        .map(|p| p.to_string_lossy().into_owned());
    let (bytes, report) = compile_source(&source, None, base_dir.as_deref(), None, Some(("llvm", out_dir)))?;
    let aot = report.aot.as_ref()
        .ok_or_else(|| "internal: AOT artifacts missing".to_string())?;
    std::fs::create_dir_all(out_dir)
        .map_err(|e| format!("cannot create '{}': {}", out_dir, e))?;
    let ir = aot.ir.clone().ok_or_else(|| "internal: IR missing".to_string())?;
    std::fs::write(format!("{}/lila_aot.ll", out_dir), ir)
        .map_err(|e| format!("cannot write IR: {}", e))?;
    Ok((aot.fns_compiled, aot.fns_skipped, bytes))
}

// ============================ v11 TESTS ============================

#[cfg(test)]
mod v11_tests {
    use super::*;

    /// Global + entity arrays, indexed reads/writes (incl. compound), alen,
    /// cam3/draw3d/proj3 — the whole v11 surface compiles end to end, emits
    /// a v3 file with the arrays flag, and disasm round-trips the new ops.
    #[test]
    fn arrays_and_3d_compile_end_to_end() {
        let src = r#"
game { title: "t"  width: 256  height: 256  wrap: false }
global {
    tick: u = 0
    arr fixed[1800] terr
    arr fixed[108] cube
}
entity Orb {
    x: fixed
    ti: u8
    arr fixed[8] tx
}
fn init() {
    let i = 0;
    while (i < 10) {
        terr[i * 3] = fixed(i);
        terr[i * 3 + 1] = fixed(i) * 0.5;
        terr[i * 3 + 2] = sin(ang(int(fixed(i)) * 4)) * 1.2;
        i += 1;
    }
    cube[0] = -1.0;
    cube[1] = 0.5 + 0.5;
    cube[1] += 0.25;
    let h = terr[0] + cube[0];
    cube[2] = h;
    spawn Orb { ti: 2 };
}
fn update() {
    tick += 1;
    cam3(0.0, -10.0, 4.0, 0, -130);
}
fn update(o: Orb) {
    o.x = sin(ang(tick)) * 2.0;
    o.tx[o.ti] = o.x;
    o.ti += 1;
    o.x = o.tx[0] + o.tx[o.ti];
}
fn draw() {
    draw3d(terr, alen(terr) / 3 - 300 + 300, 0.0, 0.0, 0.0, 0, 0x2E7D4FCC);
    draw3d(cube, 36, 0.0, 0.0, 3.0, ang(tick * 5), 0xE07030D8);
    for (o: Orb) {
        let s = proj3(o.x, 0.0, 1.0);
        if (projok()) {
            draw(#p, projx(), projy(), 0, s * 0.16, 0xFFE0B0FF);
        }
    }
    draw_text(#t1, 8, 8, 0xFFFFFFCC);
}
scene { #play: idle_scene }
fn idle_scene() {
}
sprite #p (4) {
    poly [ -4, 0, 0, -4, 4, 0, 0, 4 ] fill: 0xFFD080 add: true
}
text { #t1: "V11" }
"#;
        let (bytes, report) = compile_to_libyte(src, None, None).expect("compiles");
        assert_eq!(report.version, 3, "arrays force v3");
        // flags bit3 (arrays) must be set: header = "LIBY"(4) + ver u16 + flags u16
        let flags = u16::from_le_bytes([bytes[6], bytes[7]]);
        assert_eq!(flags & 8, 8, "arrays flag set");
        assert!(bytes.len() > 100);
        // disasm round-trips the new opcodes
        let text = crate::disasm::disasm(&bytes).expect("disasm");
        for op in ["LD_GARR", "ST_GARR", "LD_EARR", "ST_EARR", "DUP", "CAM3", "PROJ3", "PROJ_X", "DRAW3D"] {
            assert!(text.contains(op), "disasm must name {op}");
        }
    }

    /// The compile-time bounds PROOF: literal indices outside 0..cap are
    /// build errors — the Lila replacement for runtime bound traps.
    #[test]
    fn array_literal_out_of_bounds_is_a_build_error() {
        let src = r#"
game { title: "t"  width: 64  height: 64 }
global { arr u8[4] g }
fn init() { g[4] = 1; }
"#;
        let err = compile_to_libyte(src, None, None).unwrap_err();
        assert!(err.contains("out of bounds"), "got: {err}");
    }

    /// Dynamic indices are legal (the runtime wraps them — mask|mod, the
    /// same trap-free contract as SRAM slots); a NEGATIVE literal is folded
    /// by the parser and caught by the compile-time proof.
    #[test]
    fn array_negative_literal_index_rejected() {
        let src = r#"
game { title: "t"  width: 64  height: 64 }
global { arr u8[4] g }
fn init() { let i = 0; g[i] = 1; g[-1] = 2; }
"#;
        let err = compile_to_libyte(src, None, None).unwrap_err();
        assert!(err.contains("out of bounds"), "got: {err}");
    }

    /// draw3d is a draw-pass statement and its budget/capacity are proven.
    #[test]
    fn draw3d_placement_and_budget_enforced() {
        let base = |body: &str| format!(r#"
game {{ title: "t"  width: 64  height: 64 }}
global {{ arr fixed[36] mesh }}
fn draw() {{ {body} }}
"#);
        // >768 verts
        let err = compile_to_libyte(&base("draw3d(mesh, 900, 0.0, 0.0, 0.0, 0, 0xFF0000FF);"), None, None).unwrap_err();
        assert!(err.contains("768"), "got: {err}");
        // verts*3 > cells
        let err = compile_to_libyte(&base("draw3d(mesh, 13, 0.0, 0.0, 0.0, 0, 0xFF0000FF);"), None, None).unwrap_err();
        assert!(err.contains("x 3 cells"), "got: {err}");
        // update-pass placement
        let src = r#"
game { title: "t"  width: 64  height: 64 }
global { arr fixed[36] mesh }
fn update() { draw3d(mesh, 12, 0.0, 0.0, 0.0, 0, 0xFF0000FF); }
"#;
        let err = compile_to_libyte(src, None, None).unwrap_err();
        assert!(err.contains("draw-pass"), "got: {err}");
    }

    /// Entity arrays need the handle prefix; bare names stay global-only.
    #[test]
    fn entity_array_scoping() {
        let ok = r#"
game { title: "t"  width: 64  height: 64 }
global { arr u8[4] g }
entity E { v: u8  arr u8[8] t }
fn update(e: E) { e.t[e.v] = g[0]; e.v = e.t[1]; }
"#;
        assert!(compile_to_libyte(ok, None, None).is_ok());
        let bad = r#"
game { title: "t"  width: 64  height: 64 }
entity E { v: u8  arr u8[8] t }
fn update(e: E) { t[0] = 1; }
"#;
        let err = compile_to_libyte(bad, None, None).unwrap_err();
        assert!(err.contains("unknown global array"), "got: {err}");
    }

    /// The LEGACY CONTRACT at the language level: games using none of the
    /// new surface still emit v1 (and v2 for capacity/world), never v3.
    #[test]
    fn legacy_games_keep_their_version() {
        let v1 = r#"
game { title: "t"  width: 64  height: 64 }
entity E { x: fixed  y: fixed }
fn init() { spawn E { }; }
fn update() { }
fn draw() { }
scene { #s: idle }
fn idle() { }
"#;
        let (_, rep) = compile_to_libyte(v1, None, None).expect("compiles");
        assert_eq!(rep.version, 1);
        let v2 = v1.replace("height: 64 }", "height: 64  capacity { entities: 32 } }");
        let (_, rep) = compile_to_libyte(&v2, None, None).expect("compiles");
        assert_eq!(rep.version, 2);
    }

    /// Regression: the fixed<->int scale chain that overflowed Interval::mul
    /// (i64 wrap) in opt::ranges must compile under optimize:true.
    #[test]
    fn ranges_interval_mul_handles_widened_chains() {
        let src = r#"
game { title: "t"  width: 512  height: 512  wrap: false  optimize: true }
global { arr fixed[64] m }
fn init() {
    let i = 0;
    while (i < 8) {
        let x = fixed(i * 64 - 256);
        m[i * 3] = x;
        m[i * 3 + 1] = sin(ang(int(x) * 4)) * 1.2 + cos(ang(int(x) * 4)) * 0.9;
        m[i * 3 + 2] = fixed(i) * -2.0;
        i += 1;
    }
}
fn update() { cam3(0.0, -10.0, 4.0, 0, -130); }
fn draw() { draw3d(m, 8, 0.0, 0.0, 0.0, 0, 0x2E7D4FCC); }
"#;
        let (_, _) = compile_to_libyte(src, None, None).expect("optimize:true path must not panic");
    }

}

// ============================ v12 TESTS ============================

#[cfg(test)]
mod v12_tests {
    use super::*;

    /// ARTICULATED 3D end to end: quat_aa/qmul/m4qt/m4mul/skinv pose a
    /// 2-bone rig in update(), draw3di submits an indexed mesh in draw().
    /// Emits a v3 file and disasm round-trips every new opcode.
    #[test]
    fn articulated_3d_compiles_end_to_end() {
        let src = r#"
game { title: "t"  width: 256  height: 256  wrap: false }
global {
    tick: u = 0
    arr fixed[24] verts
    arr u8[24] idx
    arr fixed[16] wm0
    arr fixed[16] wm1
    arr fixed[16] lm
    arr fixed[4] lq
    arr fixed[8] bind
}
fn init() {
    let v = 0;
    while (v < 8) {
        bind[v * 3] = fixed(v) * 0.1;
        bind[v * 3 + 1] = 0.0;
        bind[v * 3 + 2] = fixed(v) * 0.2;
        v += 1;
    }
    idx[0] = 0; idx[1] = 1; idx[2] = 2;
    idx[3] = 0; idx[4] = 2; idx[5] = 3;
    idx[6] = 4; idx[7] = 5; idx[8] = 6;
    idx[9] = 4; idx[10] = 6; idx[11] = 7;
    goto(#play);
}
scene { #play: idle }
fn idle() { }
fn update() {
    tick += 1;
    cam3(0.0, -8.0, 3.0, 0, -220);
    quat_aa(lq, 0, 0.0, 0.0, 1.0, ang(tick * 4));
    m4qt(wm0, 0, lq, 0, 0.0, 0.0, 0.0);
    quat_aa(lq, 0, 1.0, 0.0, 0.0, ang(tick * 7));
    m4qt(lm, 0, lq, 0, 0.0, 0.0, 1.5);
    m4mul(wm1, 0, wm0, 0, lm, 0);
    let v = 0;
    while (v < 4) {
        skinv(verts, v * 3, wm0, 0, bind[v * 3], bind[v * 3 + 1], bind[v * 3 + 2]);
        v += 1;
    }
    while (v < 8) {
        skinv(verts, v * 3, wm1, 0, bind[v * 3], bind[v * 3 + 1], bind[v * 3 + 2]);
        v += 1;
    }
}
fn draw() {
    draw3di(verts, 8, idx, 12, 0.0, 0.0, 0.0, 0, 0xE07030D8);
}
"#;
        let (bytes, rep) = compile_to_libyte(src, None, None).expect("compiles");
        assert_eq!(rep.version, 3, "arrays force v3");
        let text = crate::disasm::disasm(&bytes).expect("disasm");
        for op in ["QUAT_AA", "Q_MUL", "M4_QT", "M4_MUL", "SKIN3", "DRAW3DI"] {
            if op == "Q_MUL" { continue; } // not in this game
            assert!(text.contains(op), "disasm must name {op}");
        }
        // compose a qmul too
        let src2 = src.replace("m4mul(wm1, 0, wm0, 0, lm, 0);",
            "qmul(lq, 0, lq, 0, lq, 0); m4mul(wm1, 0, wm0, 0, lm, 0);");
        let (bytes2, _) = compile_to_libyte(&src2, None, None).expect("compiles");
        let text2 = crate::disasm::disasm(&bytes2).expect("disasm");
        assert!(text2.contains("Q_MUL"), "disasm must name Q_MUL");
    }

    /// Articulation statements are GAMEPLAY state: banned in draw fns.
    /// draw3di is the inverse: draw-pass only.
    #[test]
    fn articulation_placement_enforced() {
        let base = |body: &str| format!(r#"
game {{ title: "t"  width: 64  height: 64 }}
global {{
    arr fixed[16] m
    arr fixed[4] q
    arr fixed[24] v
    arr u8[12] ix
}}
fn init() {{ }}
fn update() {{ cam3(0.0, -8.0, 3.0, 0, -220); }}
fn draw() {{ {body} }}
"#);
        let err = compile_to_libyte(&base("skinv(v, 0, m, 0, 0.0, 0.0, 0.0);"), None, None).unwrap_err();
        assert!(err.contains("not allowed in draw fns"), "got: {err}");
        let err = compile_to_libyte(&base("quat_aa(q, 0, 0.0, 0.0, 1.0, 128);"), None, None).unwrap_err();
        assert!(err.contains("not allowed in draw fns"), "got: {err}");
        // draw3di in update = rejected
        let upd = r#"
game { title: "t"  width: 64  height: 64 }
global { arr fixed[24] v  arr u8[12] ix }
fn init() { }
fn update() { draw3di(v, 8, ix, 12, 0.0, 0.0, 0.0, 0, 0xFF0000FF); }
"#;
        let err = compile_to_libyte(upd, None, None).unwrap_err();
        assert!(err.contains("draw-pass statement"), "got: {err}");
    }

    /// Negative: entity arrays rejected for rig storage; literal offsets
    /// bounds-proven; index counts must be triples; the two buffers must
    /// differ; budget enforcement matches draw3d.
    #[test]
    fn articulation_type_and_budget_errors() {
        let ent_arr = r#"
game { title: "t"  width: 64  height: 64 }
entity W { arr fixed[4] q }
global { arr fixed[16] m }
fn init() { }
fn update(w: W) { quat_aa(w.q, 0, 0.0, 0.0, 1.0, 128); }
"#;
        let err = compile_to_libyte(ent_arr, None, None).unwrap_err();
        assert!(err.contains("not a global array"), "got: {err}");

        let off_over = r#"
game { title: "t"  width: 64  height: 64 }
global { arr fixed[8] m  arr fixed[4] q }
fn init() { }
fn update() { m4qt(m, 0, q, 2, 0.0, 0.0, 0.0); }
"#;
        let err = compile_to_libyte(off_over, None, None).unwrap_err();
        assert!(err.contains("holds only"), "got: {err}");

        let off_over2 = r#"
game { title: "t"  width: 64  height: 64 }
global { arr fixed[20] m }
fn init() { }
fn update() { m4mul(m, 16, m, 0, m, 0); }
"#;
        let err = compile_to_libyte(off_over2, None, None).unwrap_err();
        assert!(err.contains("holds only"), "got: {err}");

        let bad_ni = r#"
game { title: "t"  width: 64  height: 64 }
global { arr fixed[24] v  arr u8[7] ix }
fn init() { }
fn update() { cam3(0.0, -8.0, 3.0, 0, -220); }
fn draw() { draw3di(v, 8, ix, 7, 0.0, 0.0, 0.0, 0, 0xFF0000FF); }
"#;
        let err = compile_to_libyte(bad_ni, None, None).unwrap_err();
        assert!(err.contains("multiple of 3"), "got: {err}");

        let same_buf = r#"
game { title: "t"  width: 64  height: 64 }
global { arr fixed[24] v }
fn init() { }
fn update() { cam3(0.0, -8.0, 3.0, 0, -220); }
fn draw() { draw3di(v, 8, v, 12, 0.0, 0.0, 0.0, 0, 0xFF0000FF); }
"#;
        let err = compile_to_libyte(same_buf, None, None).unwrap_err();
        assert!(err.contains("different arrays"), "got: {err}");

        let over_budget = r#"
game { title: "t"  width: 64  height: 64 }
global { arr fixed[2400] v  arr u8[12] ix }
fn init() { }
fn update() { cam3(0.0, -8.0, 3.0, 0, -220); }
fn draw() { draw3di(v, 900, ix, 12, 0.0, 0.0, 0.0, 0, 0xFF0000FF); }
"#;
        let err = compile_to_libyte(over_budget, None, None).unwrap_err();
        assert!(err.contains("budget"), "got: {err}");
    }

    /// optimize:true pipeline must not panic on the articulation surface
    /// (the arena r/w pass now tracks array traffic through Index too).
    #[test]
    fn articulation_under_optimize() {
        let src = r#"
game { title: "t"  width: 512  height: 512  wrap: false  optimize: true }
global {
    arr fixed[24] v
    arr u8[12] ix
    arr fixed[32] wm
    arr fixed[4] lq
}
fn init() { }
fn update() {
    cam3(0.0, -8.0, 3.0, 0, -220);
    quat_aa(lq, 0, 0.0, 0.0, 1.0, ang(17));
    m4qt(wm, 0, lq, 0, 0.0, 0.0, 1.0);
    let k = 0;
    while (k < 8) {
        skinv(v, k * 3, wm, 0, fixed(k), 0.0, 0.0);
        k += 1;
    }
}
fn draw() { draw3di(v, 8, ix, 12, 0.0, 0.0, 0.0, 0, 0xE07030D8); }
"#;
        let (_, _) = compile_to_libyte(src, None, None).expect("optimize:true articulation must compile");
    }

    /// v12 LOUD LIMIT (regression): a fn needing more local slots than the
    /// VM frame holds is a BUILD ERROR, not a silent miscompile — stores
    /// past the limit used to drop, hanging loops at runtime.
    #[test]
    fn locals_over_frame_limit_is_a_build_error() {
        let mut decls = String::new();
        let mut body = String::new();
        for i in 0..40 {
            decls.push_str(&format!("    let v{i} = {i};\n"));
        }
        // keep a loop alive after the locals so the old bug would hang it
        body.push_str(&decls);
        body.push_str("    let k = 0;\n    while (k < 4) { k += 1; }\n");
        let src = format!(
            "game {{ title: \"t\"  width: 64  height: 64 }}\nfn init() {{\n{body}}}\n"
        );
        let err = compile_to_libyte(&src, None, None).unwrap_err();
        assert!(err.contains("local slots"), "got: {err}");
        // 24 locals is inside the 32-slot frame and compiles fine
        let mut body2 = String::new();
        for i in 0..24 {
            body2.push_str(&format!("    let w{i} = {i};\n"));
        }
        body2.push_str("    let k = 0;\n    while (k < 4) { k += 1; }\n");
        let src2 = format!(
            "game {{ title: \"t\"  width: 64  height: 64 }}\nfn init() {{\n{body2}}}\n"
        );
        let (_, _) = compile_to_libyte(&src2, None, None).expect("24 locals must compile");
    }

    /// v13 RANGE SOUNDNESS (regression): a compound increment on global
    /// state persists across frames, so its domain is unbounded within the
    /// declared width. The fixpoint walk used to "prove" max=16 (16 unroll
    /// rounds) and narrowed a u16 frame counter to 5 bits — found by LILA
    /// DRIVE where the day/night cycle wrapped every 32 frames.
    #[test]
    fn compound_increment_never_narrows_global_width() {
        let src = r#"
game { title: "t"  width: 64  height: 64  optimize: true }
global { tick: u16 = 0  score: u16 = 0 }
fn init() { goto(#play); }
scene { #play: idle }
fn idle() { }
fn update() {
    tick += 1;
    if (tick % 60 == 0) { score += 10; }
}
fn draw() { }
"#;
        let (_, report) = compile_to_libyte(src, None, None).expect("must compile");
        for (name, _from, to) in &report.opt.narrowed {
            assert!(name != "global.tick", "tick += 1 must never narrow (got u{})", to);
        }
    }

    /// v13 GLOBALS BLOCK GUARD (regression): globals live in the 128-byte
    /// register-free page-0 gap 0x80..0x100. Before the guard, a game with
    /// more than 1024 bits of globals silently overran the shake/cam3/proj
    /// registers and corrupted the engine (zeroed shake decay -> overflow
    /// panic). The build must fail loudly with the numbers.
    #[test]
    fn globals_block_overflow_is_a_build_error() {
        // 48 fixed globals = 1536 bits > 1024 — over the block
        let mut decls = String::new();
        for i in 0..48 {
            decls.push_str(&format!("    g{i}: fixed = 0.0
"));
        }
        let src = format!(
            "game {{ title: \"t\"  width: 64  height: 64 }}\nglobal {{\n{decls}}}\nfn init() {{ }}\n"
        );
        let err = compile_to_libyte(&src, None, None).unwrap_err();
        assert!(err.contains("globals block overflow"), "got: {err}");
        // 30 fixed globals = 960 bits — fits, compiles fine
        let mut decls2 = String::new();
        for i in 0..30 {
            decls2.push_str(&format!("    h{i}: fixed = 0.0\n"));
        }
        let src2 = format!(
            "game {{ title: \"t\"  width: 64  height: 64 }}\nglobal {{\n{decls2}}}\nfn init() {{ }}\n"
        );
        let (_, _) = compile_to_libyte(&src2, None, None).expect("960 bits of globals must fit");
    }
}

#[cfg(test)]
mod v17_tests {
    use super::*;

    fn compile(src: &str) -> Result<(Vec<u8>, BuildReport), String> {
        compile_to_libyte(src, None, None)
    }

    // ---------------- return values + calls in expressions ----------------

    #[test]
    fn valued_helpers_compile_and_emit_ret_v() {
        let (bytes, report) = compile(r#"
global { a: fixed = 1.0  b: fixed = 2.0  r: fixed = 0.0 }
fn sum2(x: fixed, y: fixed) { return x + y; }
fn sum3(x: fixed, y: fixed, z: fixed) { return x + y + z; }
fn init() { }
fn update() {
  r = sum2(a, b) + sum3(a, b, 1.0);
  r = sum2(r, 0.5);
}
"#).expect("compiles");
        assert_eq!(report.version, 4, "RET_V/RET_GET force the v4 format");
        assert!(bytes.len() > 40);
    }

    #[test]
    fn return_type_inference_and_mixed_widening() {
        // int returns + one fixed return -> the fn is Fixed (int widens)
        let (_, r) = compile(r#"
global { r: fixed = 0.0 }
fn mixed(x: fixed) { if (x > 1.0) { return 5; } return 2.5; }
fn init() { }
fn update() { r = mixed(r); }
"#).expect("compiles");
        assert_eq!(r.version, 4);
    }

    #[test]
    fn void_fn_in_expression_is_an_error() {
        let err = compile(r#"
global { r: fixed = 0.0 }
fn nothing() { }
fn init() { }
fn update() { r = nothing(); }
"#).unwrap_err();
        assert!(err.contains("returns no value"), "{}", err);
    }

    #[test]
    fn auto_run_fns_cannot_return_values() {
        let err = compile(r#"
global { r: fixed = 0.0 }
fn init() { }
fn update() { return 5; }
"#).unwrap_err();
        assert!(err.contains("auto-run"), "{}", err);
    }

    #[test]
    fn forward_and_mutual_valued_calls_infer() {
        // update (declared first) calls a helper declared last; the helper
        // calls another helper — the fixpoint must resolve all of them
        compile(r#"
global { r: fixed = 0.0  n: u8 = 3 }
fn init() { }
fn update() { r = base() + one(); }
fn base() { return 1.0; }
fn one() { return base() + 1.0; }
"#).expect("compiles");
    }

    #[test]
    fn recursive_return_cycle_is_rejected() {
        let err = compile(r#"
global { r: fixed = 0.0 }
fn init() { }
fn update() { r = loopy(); }
fn loopy() { return loopy(); }
"#).unwrap_err();
        assert!(err.contains("return") || err.contains("cycle"), "{}", err);
    }

    #[test]
    fn inconsistent_return_types_rejected() {
        let err = compile(r#"
global { r: fixed = 0.0 }
fn init() { }
fn update() { r = 1.0; }
fn bad(x: fixed) { if (x > 1.0) { return true; } return 1.0; }
"#).unwrap_err();
        assert!(err.contains("inconsistent"), "{}", err);
    }

    // ---------------- ternary / switch / loops ----------------

    #[test]
    fn ternary_parses_types_and_compiles() {
        let (_, r) = compile(r#"
global { r: fixed = 0.0  n: u8 = 3 }
fn init() { }
fn update() {
  r = n > 2 ? 1.5 : 0.25;
  r = (n > 2 ? 1 : 2) + (r > 1.0 ? 1.0 : 0.0);
}
"#).expect("compiles");
        // ternary alone lowers to JZ/JMP on EXISTING opcodes -> stays v3
        // (n is a global + the u8 globals make this a v2/v3 file... just
        // assert it compiled)
        assert!(r.version >= 1);
    }

    #[test]
    fn ternary_arm_mismatch_rejected() {
        let err = compile(r#"
global { r: fixed = 0.0  n: u8 = 3 }
fn init() { }
fn update() { r = n > 2 ? 1.0 : true; }
"#).unwrap_err();
        assert!(err.contains("ternary"), "{}", err);
    }

    #[test]
    fn switch_compiles_with_labels_and_default() {
        let (_, _) = compile(r#"
entity Drone { x: fixed  y: fixed  vx: fixed  vy: fixed  state: u2 = 0 }
global { n: u8 = 0 }
fn init() { }
fn update(e: Drone) {
  switch (e.state) {
    0: { e.vx = 1.0; }
    1 | 2: { e.vx = -1.0; }
    default: { e.vx = 0.0; }
  }
}
"#).expect("compiles");
    }

    #[test]
    fn switch_fixed_labels_match_fixed_scrutinee() {
        compile(r#"
global { r: fixed = 1.0  n: u8 = 0 }
fn init() { }
fn update() {
  switch (r) {
    0.5: { n = 1; }
    1.0: { n = 2; }
    2: { n = 3; }        // int label against fixed scrutinee: widens
  }
}
"#).expect("compiles");
    }

    #[test]
    fn switch_fixed_label_against_int_scrutinee_rejected() {
        let err = compile(r#"
global { n: u8 = 0 }
fn init() { }
fn update() {
  switch (n) {
    0.5: { n = 1; }
  }
}
"#).unwrap_err();
        assert!(err.contains("fixed literal"), "{}", err);
    }

    #[test]
    fn numeric_for_and_break_continue_compile() {
        compile(r#"
global { n: u8 = 0  m: u8 = 0  total: u8 = 0 }
fn init() { }
fn update() {
  for (i: 0..8) {
    if (i == 3) { break; }
    if (i == 1) { continue; }
    total += 1;
  }
  let k = 2;
  for (j: k..10) { m += 1; }
}
"#).expect("compiles");
    }

    #[test]
    fn break_outside_loop_rejected() {
        let err = compile(r#"
global { n: u8 = 0 }
fn init() { }
fn update() { break; }
"#).unwrap_err();
        assert!(err.contains("outside a loop"), "{}", err);
    }

    #[test]
    fn numeric_for_bounds_must_be_int() {
        let err = compile(r#"
global { r: fixed = 1.0  n: u8 = 0 }
fn init() { }
fn update() { for (i: 0.0..r) { n += 1; } }
"#).unwrap_err();
        assert!(err.contains("must be int"), "{}", err);
    }

    // ---------------- scalar builtins ----------------

    #[test]
    fn math_builtins_compile_and_type() {
        compile(r#"
global { r: fixed = 0.0  n: u8 = 5 }
fn init() { }
fn update() {
  r = min(r, 1.0);
  r = max(r, 0.0);
  r = abs(0.0 - r);
  r = clamp(r, 0.0, 1.0);
  r = lerp(r, 2.0, 0.5);
  n = min(n, 3);
  r = min(1, 2.5);      // mixed: fixed result
}
"#).expect("compiles");
    }

    // ---------------- 2-D arrays ----------------

    #[test]
    fn two_d_arrays_compile_and_access() {
        let (_, r) = compile(r#"
global { arr u8[8][8] grid  n: u8 = 0 }
fn init() {
  grid[2][3] = 1;
  grid[0][0] = 2;
}
fn update() { n = grid[2][3] + grid[0][0]; }
"#).expect("compiles");
        assert_eq!(r.version, 3, "2-D arrays ride the existing v3 arrays schema");
    }

    #[test]
    fn two_d_literal_oob_proven_per_axis() {
        let err = compile(r#"
global { arr u8[8][8] grid }
fn init() { grid[4][8] = 1; }
"#).unwrap_err();
        assert!(err.contains("out of bounds 0..8"), "{}", err);
    }

    #[test]
    fn two_d_wrong_arity_rejected() {
        let err = compile(r#"
global { arr u8[8][8] grid }
fn init() { grid[4] = 1; }
"#).unwrap_err();
        assert!(err.contains("takes 2 index(es)"), "{}", err);
    }

    // ---------------- input edges + dist_nearest + m4look ----------------

    #[test]
    fn key_edges_force_v4() {
        let (_, r) = compile(r#"
key { #fire }
global { n: u8 = 0 }
fn init() { }
fn update() { if (key_pressed(#fire)) { n += 1; } if (key_released(#fire)) { n -= 1; } }
"#).expect("compiles");
        assert_eq!(r.version, 4, "KEY_EDGE forces v4");
    }

    #[test]
    fn dist_nearest_requires_x_y_fields() {
        let err = compile(r#"
entity Ghost { hp: u8 = 1 }
global { n: u8 = 0 }
fn init() { }
fn update() { if (dist_nearest(0.0, 0.0, Ghost) < 10.0) { n = 1; } }
"#).unwrap_err();
        assert!(err.contains("'x' and 'y'"), "{}", err);
    }

    #[test]
    fn m4look_compiles() {
        compile(r#"
global { arr fixed[40] m }
fn init() { }
fn update() { m4look(m, 0, 0.0, 0.0, 10.0, 5.0, 5.0, 0.0); }
"#).expect("compiles");
    }

    // ---------------- draw-fn discipline (transitive) ----------------

    #[test]
    fn draw_fns_reject_unsafe_helper_calls() {
        let err = compile(r#"
entity Rock { x: fixed  y: fixed }
fn spawn_rock() { spawn Rock { x: 0.0, y: 0.0 }; }
fn init() { }
fn draw() { call spawn_rock(); }
"#).unwrap_err();
        assert!(err.contains("not draw-safe"), "{}", err);
    }

    #[test]
    fn draw_fns_reject_unsafe_helper_calls_in_expr_position() {
        // v23.1 REGRESSION: the draw-safety fixpoint's hand-rolled walker
        // only visited Stmt::CallStmt, so a spawning helper called in
        // EXPRESSION position smuggled past it. `call f();` was caught;
        // `let d = f();` was not.
        let err = compile(r#"
entity Rock { x: fixed  y: fixed }
fn spawn_and_count() { spawn Rock { x: 0.0, y: 0.0 }; return 1; }
fn init() { }
fn draw() { let d = spawn_and_count(); }
"#).unwrap_err();
        assert!(err.contains("not draw-safe"), "{}", err);
    }

    #[test]
    fn tier_purity_demotes_f64_via_expression_call() {
        // v23.1 REGRESSION (upgraded): the tier purity fixpoint missed
        // Expr::Call, so a fn calling an f64-using helper inside an
        // EXPRESSION was never demoted — optimizer gates could fire on
        // f64 code. Now f64 works end to end, and the fixpoint must demote
        // BOTH the helper (direct F64Lit) and the caller (viral through
        // the expression call).
        let (bytes, report) = compile(r#"
global { d: f64  r: fixed = 0.0 }
fn f64helper() { d = d * 2.0d; return 1; }
fn init() { r = f64helper() + 1; }
"#).expect("f64 arithmetic compiles end to end");
        assert!(!bytes.is_empty());
        let tiers = &report.opt.tier_purity.as_ref().expect("tier report").tiers;
        assert_eq!(tiers[0], crate::opt::tier::Tier::Tier1, "f64helper (direct f64 use) must be Tier-1");
        assert_eq!(tiers[1], crate::opt::tier::Tier::Tier1, "init (expression call into f64 helper) must be virally demoted");
    }

    #[test]
    fn draw_fns_accept_pure_helper_calls() {
        compile(r#"
global { r: fixed = 1.0 }
fn bump(x: fixed) { return x + 1.0; }
fn init() { }
fn draw() { r = bump(r); }
"#).expect("compiles");
    }

    // ---------------- includes ----------------

    #[test]
    fn include_splices_and_maps_lines() {
        let dir = std::env::temp_dir().join("lila_v17_inc");
        let _ = std::fs::create_dir_all(&dir);
        std::fs::write(dir.join("lib.lila"), "global { q: u8 = 7 }\n").unwrap();
        std::fs::write(dir.join("main.lila"), "fn init() { }\ninclude \"lib.lila\"\nfn update() { q += 1; }\n").unwrap();
        let source = include::load(&dir.join("main.lila")).expect("loads");
        assert_eq!(source.files.len(), 2);
        let out = compile_source(&source, None, None, None, None).expect("compiles with the spliced global");
        assert!(out.0.len() > 20);
    }

    #[test]
    fn include_cycle_is_an_error() {
        let dir = std::env::temp_dir().join("lila_v17_cycle");
        let _ = std::fs::create_dir_all(&dir);
        std::fs::write(dir.join("a.lila"), "include \"b.lila\"\n").unwrap();
        std::fs::write(dir.join("b.lila"), "include \"a.lila\"\n").unwrap();
        let err = include::load(&dir.join("a.lila")).unwrap_err();
        assert!(err.contains("cycle"), "{}", err);
    }

    // ---------------- legacy contract ----------------

    #[test]
    fn legacy_features_stay_v1_v3() {
        // no new opcodes anywhere -> the emitted version is exactly what
        // v16 would have chosen for the same content
        let (_, r) = compile("fn init() { }\n").expect("compiles");
        assert_eq!(r.version, 1);
        let (_, r) = compile("game { width: 512 height: 512 }\nfn init() { }\n").expect("compiles");
        assert_eq!(r.version, 1);
        let (_, r) = compile(r#"
global { arr fixed[4] a }
fn init() { a[0] = 1.0; }
"#).expect("compiles");
        assert_eq!(r.version, 3);
    }
}

#[cfg(test)]
mod v20_tests {
    use super::*;

    fn compile(src: &str) -> Result<(Vec<u8>, BuildReport), String> {
        compile_to_libyte(src, None, None)
    }

    // ---------------- mixins (C++ composition / Unity components) ----------------

    #[test]
    fn mixin_splices_fields_and_keeps_legacy_version() {
        // `use movable` brings x/y/vx/vy in — the checker sees a flat list,
        // the auto-integration pairs still fire (x/vx magic names), and the
        // file stays a v3-format cartridge (no new opcodes exist).
        let (_, r) = compile(r#"
game { title: "m"  width: 64  height: 64 }
mixin movable { x: fixed  y: fixed  vx: fixed  vy: fixed }
entity Enemy { use movable, hp: u8 = 3 }
fn init() { spawn Enemy { x: 4.0, vx: 0.5 }; }
fn update(e: Enemy) { e.x += 1.0; }
"#).expect("compiles");
        assert_eq!(r.version, 1, "pure sugar — v1 cartridge, zero new opcodes");
    }

    #[test]
    fn mixin_composition_and_disjointness() {
        // mixins may compose mixins; overlapping fields are loud errors.
        let (_, _) = compile(r#"
mixin pos { x: fixed  y: fixed }
mixin body { use pos, mass: u8 = 1 }
entity Ship { use body, hp: u8 = 5 }
fn init() { spawn Ship { x: 1.0 }; }
"#).expect("composed mixin compiles");

        let err = compile(r#"
mixin a { v: fixed }
mixin b { v: fixed }
entity Ship { use a, use b }
fn init() { }
"#).expect_err("duplicate field across mixins must fail");
        assert!(err.contains("provided twice"), "{}", err);

        let err = compile(r#"
mixin a { v: fixed }
entity Ship { use a, v: fixed }
fn init() { }
"#).expect_err("entity field shadowing a mixin field must fail");
        assert!(err.contains("already provided"), "{}", err);

        let err = compile(r#"
mixin a { use b }
mixin b { use a }
entity Ship { use a }
fn init() { }
"#).expect_err("mixin cycles must fail");
        assert!(err.contains("cycle"), "{}", err);
    }

    // ---------------- where (LINQ Where) ----------------

    #[test]
    fn where_filters_entity_and_numeric_loops() {
        let (_, r) = compile(r#"
global { hits: u16 = 0  total: u16 = 0 }
entity Rock { x: fixed  y: fixed  hp: u4 = 2 }
fn init() { for (r: Rock) where (r.hp < 2) { hits += 1; } }
fn update() {
  for (i: 0..10) where (i % 2 == 0) { total += 1; }
}
"#).expect("compiles");
        assert_eq!(r.version, 1, "pure guard sugar — v1 cartridge");
    }

    // ---------------- the v20 expand() fix ----------------

    #[test]
    fn prefab_only_games_expand_prefabs() {
        // v19 bug: `expand` was skipped for prefab-only/no-particles games,
        // leaving `from` unresolved. v20 calls it unconditionally.
        let (_, _) = compile(r#"
entity Drone { x: fixed  hp: u4 = 3 }
entity FastDrone from Drone { hp: u4 = 1 }
fn init() { spawn FastDrone { x: 1.0 }; }
"#).expect("prefab-only game must compile (parent fields merged)");
    }
}

#[cfg(test)]

// ============================================================================
// v23.2 STRUCTS — user records, flattened to transparent-memory fields
// ============================================================================

mod v232_struct_tests {
    use super::*;

    fn compile(src: &str) -> Result<(Vec<u8>, BuildReport), String> {
        compile_to_libyte(src, None, None)
    }

    #[test]
    fn struct_global_array_and_entity_flatten_end_to_end() {
        let (bytes, report) = compile(r#"
game { title: "S"  width: 64  height: 64 }
sprite #dot (3) { poly [ -1,-1, 1,-1, 1,1, -1,1 ] fill: 0x66CCFF }
struct Vec3 { x: fixed  y: fixed  z: fixed }
struct Strike { dmg: u8  px: fixed }
entity Ship { pos: Vec3  hp: u8 = 9 }
global { origin: Vec3
         arr Vec3[8] path
         arr Strike[4] hits
         total: u16 = 0 }
fn init() {
    origin.x = 1.5;
    origin.y = 2.25;
    origin.z = -3;
    path[0].x = origin.x;
    path[0].y = origin.y + 1;
    hits[1].dmg = 42;
    hits[1].px = origin.x * 2;
    spawn Ship;
}
fn update() {
    for (s: Ship) {
        s.pos.x = origin.x;
        s.pos.y = path[0].y;
        s.pos.z = path[0].z + origin.z;
        if s.pos.x > 0 { total = total + 1; }
    }
}
fn draw() {
    for (s: Ship) { draw(#dot, s.pos.x, s.pos.y, 0, 256, 0xFFFFFFFF); }
}
"#).expect("structs compile end to end");
        // the synthesis report row proves the lowering ran; the disasm
        // proves the flat fields exist as ordinary typed fields
        assert!(report.opt.synth.iter().any(|(k, d)| k == "structs" && d.contains("2 struct")),
            "synth report row: {:?}", report.opt.synth);
        let text = crate::disasm::disasm(&bytes).expect("disasm");
        assert!(text.contains("entities=1"), "disasm sanity");
        assert!(text.contains("tf["), "typed fields present");
    }

    #[test]
    fn record_copies_expand_per_field() {
        let (bytes, _r) = compile(r#"
game { title: "S"  width: 64  height: 64 }
struct V { a: u8  b: u8 }
global { v1: V  v2: V   arr V[4] pa   arr V[4] pb }
fn init() {
    v1.a = 3; v1.b = 4;
    v2 = v1;             // record -> record
    pa[0] = v1;          // record -> element
    v2 = pa[1];          // element -> record
    pb[2] = pa[3];       // element -> element
}
fn update() { }
"#).expect("record copies compile");
        let text = crate::disasm::disasm(&bytes).expect("disasm");
        // four copies x two fields = 8 scalar assignments; "ST_G " (with the
        // trailing space) counts global stores without matching ST_GARR
        let st_count = text.matches("ST_G ").count();
        assert!(st_count >= 6, "per-field copy assignments emitted (got {} ST_G)", st_count);
        assert!(text.contains("ST_GARR"), "element copies target the flattened arrays");
    }

    #[test]
    fn struct_errors_are_loud_and_positioned() {
        // unknown struct name: an undeclared ident in field position reads
        // as an entity ref (shared namespace) — the error must hint at the
        // struct path so the fix is discoverable
        let e = compile(r#"
game { title: "S"  width: 64  height: 64 }
global { v: Nope }
fn update() { }
"#).unwrap_err();
        assert!(e.contains("entity refs cannot be stored fields") && e.contains("declare `struct Nope"), "{}", e);
        // nested struct
        let e = compile(r#"
game { title: "S"  width: 64  height: 64 }
struct A { x: u8 }
struct B { a: A }
fn update() { }
"#).unwrap_err();
        assert!(e.contains("nested structs are not supported"), "{}", e);
        // missing field
        let e = compile(r#"
game { title: "S"  width: 64  height: 64 }
struct A { x: u8 }
global { v: A }
fn update() { v.q = 1; }
"#).unwrap_err();
        assert!(e.contains("has no field 'q'"), "{}", e);
        // whole-record value use
        let e = compile(r#"
game { title: "S"  width: 64  height: 64 }
struct A { x: u8 }
global { v: A   q: u8 = 0 }
fn update() { q = v; }
"#).unwrap_err();
        assert!(e.contains("does not produce a value"), "{}", e);
        // struct param
        let e = compile(r#"
game { title: "S"  width: 64  height: 64 }
struct A { x: u8 }
fn f(p: A) { }
fn update() { }
"#).unwrap_err();
        assert!(e.contains("struct-typed parameters are not supported"), "{}", e);
    }

    fn source_from(text: &str, path: &std::path::Path) -> crate::include::Source {
        let n = text.lines().count() + 1;
        crate::include::Source {
            text: text.to_string(),
            files: vec![crate::include::FileSrc { path: path.display().to_string(), text: text.to_string() }],
            line_map: (1..=n as u32).map(|l| (0u16, l)).collect(),
        }
    }

    #[test]
    fn mesh_import_bakes_cells_v6_wire() {
        // write a tiny OBJ next to a temp source; compile_source resolves
        // relative to the source's directory
        let dir = std::env::temp_dir().join(format!("lila_mesh_test_{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        std::fs::write(dir.join("pyr.obj"), r#"
# pyramid, z-up
v 0.0 0.0 150.0
v 64.0 -64.0 0.0
v 64.0 64.0 0.0
v -64.0 64.0 0.0
v -64.0 -64.0 0.0
f 1 3 2
f 1 4 3
f 1 5 4
f 1 2 5
f 2 3 4
f 2 4 5
"#).unwrap();
        let src_path = dir.join("g.lila");
        std::fs::write(&src_path, r#"
game { title: "M"  width: 64  height: 64 }
mesh cube from "pyr.obj" scale 1.0;
global { i: u16 = 0 }
fn init() { i = 0; }
fn draw() { draw3d(cube, 6, 0.0, 0.0, 0.0, 0, 0xFF66CCFF); }
"#).unwrap();
        let text = std::fs::read_to_string(&src_path).unwrap();
        let source = source_from(&text, &src_path);
        let (bytes, report) = compile_source(&source, None, Some(dir.to_str().unwrap()), None, None)
            .expect("mesh import compiles");
        assert!(report.opt.synth.iter().any(|(k, d)| k == "mesh" && d.contains("6 tris, 108 cells") && d.contains("baked v6")),
            "mesh report row: {:?}", report.opt.synth);
        // v23.5: the filler fn is GONE (zero instructions for the mesh);
        // the cart is wire v6 and the quantized Q24.8 cells ride the baked
        // trailer verbatim (150.0 * 1.0 -> 150, -64.0 -> -64, little-endian).
        let d = crate::disasm::disasm(&bytes).unwrap();
        assert!(!d.contains("__mesh_cube"), "no generated filler fn in v6");
        let ver = u16::from_le_bytes([bytes[4], bytes[5]]);
        assert_eq!(ver, 6, "mesh carts emit the v6 baked cold-data format");
        for cell in [150i32, -64i32, 64] {
            let le = cell.to_le_bytes();
            assert!(bytes.windows(4).any(|w| w == le), "cell {} missing from baked trailer", cell);
        }
        // cleanup
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn mesh_import_errors_are_loud() {
        let dir = std::env::temp_dir().join(format!("lila_mesh_err_{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        // missing file
        std::fs::write(dir.join("g.lila"), r#"
game { title: "M"  width: 64  height: 64 }
mesh cube from "nope.obj";
fn init() { }
fn update() { }
"#).unwrap();
        let text = std::fs::read_to_string(dir.join("g.lila")).unwrap();
        let source = source_from(&text, &dir.join("g.lila"));
        let e = compile_source(&source, None, Some(dir.to_str().unwrap()), None, None).unwrap_err();
        assert!(e.contains("cannot read"), "{}", e);
        // face index out of range
        std::fs::write(dir.join("bad.obj"), "v 0 0 0\nv 1 0 0\nv 0 1 0\nf 1 2 9\n").unwrap();
        std::fs::write(dir.join("g2.lila"), r#"
game { title: "M"  width: 64  height: 64 }
mesh cube from "bad.obj";
fn init() { }
fn update() { }
"#).unwrap();
        let text2 = std::fs::read_to_string(dir.join("g2.lila")).unwrap();
        let source2 = source_from(&text2, &dir.join("g2.lila"));
        let e2 = compile_source(&source2, None, Some(dir.to_str().unwrap()), None, None).unwrap_err();
        assert!(e2.contains("out of range"), "{}", e2);
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn struct_initializer_rejected_with_guidance() {
        let e = compile(r#"
game { title: "S"  width: 64  height: 64 }
struct A { x: u8 }
global { v: A = 3 }
fn update() { }
"#).unwrap_err();
        assert!(e.contains("cannot have an initializer"), "{}", e);
    }
}

mod v231_tests {
    use super::*;

    fn compile(src: &str) -> Result<(Vec<u8>, BuildReport), String> {
        compile_to_libyte(src, None, None)
    }

    // ---------------- f64: arithmetic, conversions, storage ----------------

    #[test]
    fn f64_arithmetic_compiles_and_emits_f64_ops() {
        let (bytes, report) = compile(r#"
global { acc: f64  flag: fixed  ic: fixed  r: fixed = 0.0 }
fn init() { }
fn update() {
  acc = f64(3) * 2.5d;
  acc = acc + 0.5d;
  acc = acc * -1.0d;
  flag = fixed(acc);
  ic = int(f64(1000) / 8.0d);
  if acc > 0.0d { r = 1.0; }
  if fsqrt(16.0d) == 4.0d { ic = ic + 1; }
}
"#).expect("f64 arithmetic compiles end to end");
        assert_eq!(report.version, 5, "F64 opcodes (>0x9A) force the v5 format");
        let text = crate::disasm::disasm(&bytes).expect("disasm");
        for op in ["F64_ADD", "F64_MUL", "F64_DIV", "F64_GT", "I2F64", "F642FIX", "F642I", "F64_SQRT", "F64_EQ"] {
            assert!(text.contains(op), "disasm must contain {}", op);
        }
    }

    #[test]
    fn f64_stores_to_globals_and_entity_fields() {
        let (bytes, _r) = compile(r#"
global { g: f64 }
entity P { acc: f64  tag: fixed }
fn init() {
  g = 1.25d;
  spawn P { acc: 2.5d, tag: 7 };
}
fn update() { for (p: P) { p.acc = p.acc + g; } }
"#).expect("f64 globals + entity fields compile");
        let text = crate::disasm::disasm(&bytes).expect("disasm");
        assert!(text.contains("F64_ADD"), "entity f64 compound add");
    }

    #[test]
    fn f64_strict_mixing_rejected() {
        let err = compile(r#"
global { a: f64  b: fixed = 1.0 }
fn init() { a = a + b; }
"#).unwrap_err();
        assert!(err.contains("mix with nothing"), "{}", err);
    }

    #[test]
    fn f64_gates_are_loud() {
        // v23.6: the LAST TWO f64 gates are LIFTED — pool fields and returns
        // compile end-to-end (see f64_pool_fields_and_returns_supported).
        // vec4 pool fields stay loud (the multi-cell lane machinery exists
        // only for f64; the overlay generators have no vec4 lane).
        let e2 = compile(r#"
global { }
pool T (8) { v: vec4fixed }
fn init() { }
"#).unwrap_err();
        assert!(e2.contains("not supported in pools"), "{}", e2);
        // fixed/bool defaults on an f64 pool field are a type error
        let e2c = compile(r#"
global { }
pool T (8) { v: f64 = 1.0 }
fn init() { }
"#).unwrap_err();
        assert!(e2c.contains("fixed/bool default on an f64 field"), "{}", e2c);
        // an f64 fn cannot unify a bool return with an f64 return
        let e2b = compile(r#"
global { c: bool  g: f64 }
fn pick() { if (c) { return 1.0d; } return c; }
fn init() { let x = pick(); }
"#).unwrap_err();
        assert!(e2b.contains("inconsistent types"), "{}", e2b);
        // ternary
        let e4 = compile(r#"
global { a: f64  c: bool  b: fixed }
fn init() { b = fixed(c ? a : 2.0d); }
"#).unwrap_err();
        assert!(e4.contains("ternary on f64"), "{}", e4);
    }

    #[test]
    fn f64_pool_fields_and_returns_supported() {
        // v23.6 GATE LIFTS end-to-end: a pool with an f64 field (default +
        // spawn init + read/write), and an f64-return fn called in an
        // expression (RET_V64/RET_GET64 in the stream). Both carts are v6.
        let (bytes, _report) = compile(r#"
global { acc: f64 = 2.5d }
pool T (8) { v: f64 = 1.5d  tag: u8 = 3 }
fn acc2(x: f64) { acc = acc + x; return acc; }
fn init() {
  push T { v: 4.0d, tag: 1 };
}
fn update() {
  for (t: T) { t.v = acc2(t.v); }
}
"#).expect("f64 pool fields + returns compile");
        let text = crate::disasm::disasm(&bytes).expect("disasm");
        assert!(text.contains("RET_V64"), "f64 return parks the pair");
        assert!(text.contains("RET_GET64"), "f64 call fetches the pair");
        let (_b2, rep2) = compile(r#"
global { }
pool W (4) { v: f64 }
fn init() { }
"#).expect("wide pool compiles");
        assert_eq!(rep2.version, 6, "wide pool fields force the v6 wire");
    }

    #[test]
    fn f64_arrays_and_params_supported() {
        // v23.5: array elements + fn params — the two lifted gates. Compile
        // end-to-end and check the wire carries the wide-array schema byte.
        let (bytes, _report) = compile(r#"
global { acc: f64  arr f64[8] xs }
fn put(i: u16, v: f64) { xs[i] = v; }
fn init() {
  call put(0, 1.5d);
  xs[1] = acc + 2.25d;
}
"#).expect("f64 arrays + params compile");
        // v6 wire: the arrays schema carries the width byte (2 for f64)
        let ver = u16::from_le_bytes([bytes[4], bytes[5]]);
        assert_eq!(ver, 6, "f64 arrays force the v6 wire (elem-width byte)");
    }

    // ---------------- vec4: u8 lanes (first-class) + fixed immediates ------

    #[test]
    fn vec4u8_works_end_to_end() {
        let (bytes, _r) = compile(r#"
global { c1: fixed  sv: vec4u8 }
fn init() { }
fn update() {
  let v = v4u(10, 20, 30, 40);
  let w = v4u(1, 2, 3, 4);
  let s = v4uadd(v, w);
  sv = s;
  sv += v4u(1, 1, 1, 1);
  c1 = v4ux(sv) * 1000000 + v4uy(sv) * 10000 + v4uz(sv) * 100 + v4uw(sv);
}
"#).expect("vec4u8 compiles end to end");
        let text = crate::disasm::disasm(&bytes).expect("disasm");
        for op in ["VEC4U_PACK", "VEC4U_ADD", "VEC4U_UNPACK"] {
            assert!(text.contains(op), "disasm must contain {}", op);
        }
    }

    #[test]
    fn vec4fixed_immediate_math_compiles() {
        let (bytes, _r) = compile(r#"
global { d: fixed = 0.0 }
fn init() { }
fn update() {
  d = v4fdot(v4f(1.0, 0.0, 0.0, 0.0), v4f(2.0, 3.0, 4.0, 5.0));
}
"#).expect("vec4fixed immediate math compiles");
        let text = crate::disasm::disasm(&bytes).expect("disasm");
        assert!(text.contains("VEC4F_DOT"), "{}", text.len());
    }

    #[test]
    fn vec4f_cannot_be_stored_or_passed() {
        let e1 = compile(r#"
global { v: vec4fixed }
fn init() { v = v4f(1.0, 0.0, 0.0, 0.0); }
"#).unwrap_err();
        assert!(e1.contains("stack-immediate"), "{}", e1);
        let e2 = compile("fn f(v: vec4fixed) { }\nfn init() { }").unwrap_err();
        assert!(e2.contains("4-cell params"), "{}", e2);
    }

    // ---------------- try/catch/throw: real lowering ----------------

    #[test]
    fn try_catch_throw_lower_to_handler_opcodes() {
        let (bytes, report) = compile(r#"
global { r: fixed  e: fixed }
fn risky(x: fixed) { if x > 10.0 { throw 42; } return x + 1.0; }
fn init() { }
fn update() {
  r = 0; e = 0;
  try { r = risky(5); r = risky(99); r = r + 1000; } catch (err) { e = err; }
}
"#).expect("try/catch compiles end to end");
        assert_eq!(report.version, 5, "TRY/THROW (>0x9A) force v5");
        let text = crate::disasm::disasm(&bytes).expect("disasm");
        for op in ["TRY", "TRY_END", "THROW"] {
            assert!(text.contains(op), "disasm must contain {}", op);
        }
    }

    #[test]
    fn nested_try_catches_compiles() {
        compile(r#"
global { e: fixed }
fn init() { }
fn update() {
  try {
    try { throw 1; } catch (inner) { throw inner + 10; }
  } catch (outer) { e = outer; }
}
"#).expect("nested try compiles (handler stack is LIFO)");
    }

    #[test]
    fn break_out_of_try_unwinds_the_handler() {
        let (bytes, _r) = compile(r#"
global { n: fixed }
fn init() { }
fn update() {
  for (i: 0..10) {
    try { if i == 3 { break; } throw 7; } catch (err) { n = n + err; }
  }
}
"#).expect("break across a try boundary compiles (codegen emits TRY_END unwind)");
        let text = crate::disasm::disasm(&bytes).expect("disasm");
        // the break path must carry one TRY_END per try it unwinds past
        assert!(text.contains("TRY_END"), "break must unwind the handler");
    }

    #[test]
    fn throw_requires_int_and_try_needs_catch() {
        let e1 = compile(r#"
global { }
fn init() { throw 1.5; }
"#).unwrap_err();
        assert!(e1.contains("int error code"), "{}", e1);
        let e2 = compile(r#"
fn init() { try { } }
"#).unwrap_err();
        assert!(e2.contains("catch"), "{}", e2);
    }

    #[test]
    fn suspension_inside_try_rejected_loudly() {
        let e1 = compile(r#"
entity B { t: u8 }
fn init() { }
fn update(b: B) {
  try { wait(30); } catch (err) { }
}
"#).unwrap_err();
        assert!(e1.contains("abandon the exception handler"), "{}", e1);
    }

    // ---------------- thread<T>: the honest gate ----------------

    #[test]
    fn thread_type_rejected_loudly() {
        let e = compile("fn f(t: thread<main>) { }\nfn init() { }").unwrap_err();
        assert!(e.contains("reserved for a future version"), "{}", e);
    }
}
