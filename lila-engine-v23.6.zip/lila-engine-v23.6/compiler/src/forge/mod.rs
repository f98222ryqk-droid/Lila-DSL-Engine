//! ============================================================================
//! FORGE — THE WHOLE-GAME OPTIMIZER (v18)
//! ============================================================================
//!
//!    ┌────────────────────────  FORGE  ────────────────────────────┐
//!    │  everything the game is: source, sprites, meshes, textures,  │
//!    │  sounds, recorded playtests — ONE analysis->decide->verify    │
//!    │  ->emit machine. Same discipline for every resource class:    │
//!    │  measure the residual, print it, demote when it exceeds the   │
//!    │  platform card's budget.                                      │
//!    └───────────────────────────────────────────────────────────────┘
//!
//!   lilac build   : v17 pipeline (bit widths, SoA, FSM planes, physics
//!                   rewrites, arena budgets) — cartridge untouched by
//!                   FORGE, so cartridges stay byte-identical.
//!   lilac forge   : NEW. Compiles the game (for the atom/usage view +
//!                   hash stamping), reads the side-car asset mapping and
//!                   the replay corpus, then emits:
//!
//!     game.forgepack    binary, zero-parse-cost sections: texture
//!                       payloads, palette banks, SDF/normal derivations,
//!                       FGM1 meshes, ADPCM audio.
//!     game.lilamanifest JSON, the DECISIONS LOCKFILE: every asset's
//!                       chosen format, measured residual, usage bounds
//!                       and render interpretation (quad/mesh/fx/light),
//!                       plus corpus digest + libyte SHA-256. Hosts
//!                       verify everything against it.
//!
//!   The manifest is the token interpretation layer: the same cartridge
//!   can be re-forged (HD textures, mesh swaps, palette banks, FX) without
//!   touching a single simulation byte — the hash chain could not care
//!   less what the television looks like.

pub mod audio;
pub mod corpus;
pub mod img;
pub mod interop;
pub mod logic;
pub mod mesh;
pub mod pgx;
pub mod tables;
pub mod texture;
pub mod wgslpgo;

use crate::ast::Program;
use std::collections::BTreeMap;
use std::path::Path;

// ---------------- platform cards ----------------

#[derive(Debug, Clone)]
pub struct PlatformCard {
    pub name: &'static str,
    pub tex: texture::TexPolicy,
    pub mesh: mesh::MeshPolicy,
    pub audio: audio::AudioPolicy,
}

impl PlatformCard {
    pub fn get(name: &str) -> Result<PlatformCard, String> {
        match name {
            "desktop" | "" => Ok(PlatformCard::desktop()),
            "mobile" => Ok(PlatformCard::mobile()),
            "cloud_min" | "cloud-min" => Ok(PlatformCard::cloud_min()),
            other => Err(format!(
                "unknown card '{}' (want desktop | mobile | cloud_min)",
                other
            )),
        }
    }

    /// Desktop/console: BC7 available, generous budgets.
    pub fn desktop() -> PlatformCard {
        PlatformCard {
            name: "desktop",
            tex: texture::TexPolicy {
                max_dim: 2048,
                host_block: Some("bc7"),
                tolerance: 8,
                want_sdf: true,
                want_normal: true,
                gradient_min: 0.995,
                usage: None,
            },
            mesh: mesh::MeshPolicy::default(),
            audio: audio::AudioPolicy::default(),
        }
    }

    /// Mobile/Quest-class: ASTC 6x6, tighter pixel budgets, 1024px ceiling.
    pub fn mobile() -> PlatformCard {
        PlatformCard {
            name: "mobile",
            tex: texture::TexPolicy {
                max_dim: 1024,
                host_block: Some("astc-6x6"),
                tolerance: 6,
                want_sdf: true,
                want_normal: false, // no per-pixel lights on low tier
                gradient_min: 0.99,
                usage: None,
            },
            mesh: mesh::MeshPolicy {
                max_err_px: 0.75,
                usage_dist: 4.0,
                vfov_deg: 60.0,
                screen_h: 720.0,
                lod_max_err_px: 4.0,
            },
            audio: audio::AudioPolicy { synth_max_residual: 0.4, adpcm_min_snr_db: 22.0, hrm_min_snr_db: 20.0, hrm_max_partials: 16 },
        }
    }

    /// The 2-core cloud reference box (same class as the bench suite):
    /// conservative ceilings, no host block compression, raw formats.
    pub fn cloud_min() -> PlatformCard {
        PlatformCard {
            name: "cloud_min",
            tex: texture::TexPolicy {
                max_dim: 1024,
                host_block: None,
                tolerance: 4,
                want_sdf: false,
                want_normal: false,
                gradient_min: 0.998,
                usage: None,
            },
            mesh: mesh::MeshPolicy {
                max_err_px: 0.35,
                usage_dist: 5.0,
                vfov_deg: 60.0,
                screen_h: 1080.0,
                lod_max_err_px: 3.0,
            },
            audio: audio::AudioPolicy { synth_max_residual: 0.3, adpcm_min_snr_db: 26.0, hrm_min_snr_db: 20.0, hrm_max_partials: 16 },
        }
    }
}

// ---------------- SHA-256 (manifest integrity pinning) ----------------

/// Hand-rolled SHA-256 — hosts verify forgepack integrity with their own
/// stdlib (System.Security.Cryptography / FSHA256) against this field.
pub fn sha256(bytes: &[u8]) -> String {
    const K: [u32; 64] = [
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4,
        0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe,
        0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f,
        0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
        0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b,
        0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116,
        0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7,
        0xc67178f2,
    ];
    let mut h: [u32; 8] = [
        0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab,
        0x5be0cd19,
    ];
    let bitlen = (bytes.len() as u64).wrapping_mul(8);
    let mut msg = bytes.to_vec();
    msg.push(0x80);
    while msg.len() % 64 != 56 {
        msg.push(0);
    }
    msg.extend_from_slice(&bitlen.to_be_bytes());
    for chunk in msg.chunks(64) {
        let mut w = [0u32; 64];
        for i in 0..16 {
            w[i] = u32::from_be_bytes([
                chunk[i * 4],
                chunk[i * 4 + 1],
                chunk[i * 4 + 2],
                chunk[i * 4 + 3],
            ]);
        }
        for i in 16..64 {
            let s0 = w[i - 15].rotate_right(7) ^ w[i - 15].rotate_right(18) ^ (w[i - 15] >> 3);
            let s1 = w[i - 2].rotate_right(17) ^ w[i - 2].rotate_right(19) ^ (w[i - 2] >> 10);
            w[i] = w[i - 16]
                .wrapping_add(s0)
                .wrapping_add(w[i - 7])
                .wrapping_add(s1);
        }
        let (mut a, mut b, mut c, mut d, mut e, mut f, mut g, mut hh) =
            (h[0], h[1], h[2], h[3], h[4], h[5], h[6], h[7]);
        for i in 0..64 {
            let s1 = e.rotate_right(6) ^ e.rotate_right(11) ^ e.rotate_right(25);
            let ch = (e & f) ^ ((!e) & g);
            let t1 = hh
                .wrapping_add(s1)
                .wrapping_add(ch)
                .wrapping_add(K[i])
                .wrapping_add(w[i]);
            let s0 = a.rotate_right(2) ^ a.rotate_right(13) ^ a.rotate_right(22);
            let maj = (a & b) ^ (a & c) ^ (b & c);
            let t2 = s0.wrapping_add(maj);
            hh = g;
            g = f;
            f = e;
            e = d.wrapping_add(t1);
            d = c;
            c = b;
            b = a;
            a = t1.wrapping_add(t2);
        }
        h[0] = h[0].wrapping_add(a);
        h[1] = h[1].wrapping_add(b);
        h[2] = h[2].wrapping_add(c);
        h[3] = h[3].wrapping_add(d);
        h[4] = h[4].wrapping_add(e);
        h[5] = h[5].wrapping_add(f);
        h[6] = h[6].wrapping_add(g);
        h[7] = h[7].wrapping_add(hh);
    }
    h.iter().map(|v| format!("{:08x}", v)).collect()
}

// ---------------- tiny pretty-JSON emitter (hand-rolled, zero deps) ---------

pub struct Json {
    s: String,
    depth: usize,
}

impl Json {
    pub fn new() -> Json {
        Json { s: String::new(), depth: 0 }
    }
    fn pad(&mut self) {
        for _ in 0..self.depth {
            self.s.push_str("  ");
        }
    }
    pub fn obj(&mut self, key: &str) {
        self.pad();
        self.s.push_str(&format!("\"{}\": {{\n", esc(key)));
        self.depth += 1;
    }
    pub fn arr(&mut self, key: &str) {
        self.pad();
        self.s.push_str(&format!("\"{}\": [\n", esc(key)));
        self.depth += 1;
    }
    /// anonymous object — the element form inside arrays
    pub fn obj_anon(&mut self) {
        self.pad();
        self.s.push_str("{\n");
        self.depth += 1;
    }
    pub fn end_obj(&mut self) {
        self.depth -= 1;
        // JSON forbids trailing commas: strip the last member's comma first
        while self.s.ends_with('\n') || self.s.ends_with(',') || self.s.ends_with(' ') {
            self.s.pop();
        }
        self.s.push('\n');
        self.pad();
        self.s.push_str("},\n");
    }
    pub fn end_arr(&mut self) {
        self.depth -= 1;
        while self.s.ends_with('\n') || self.s.ends_with(',') || self.s.ends_with(' ') {
            self.s.pop();
        }
        self.s.push('\n');
        self.pad();
        self.s.push_str("],\n");
    }
    pub fn str(&mut self, key: &str, val: &str) {
        self.pad();
        self.s.push_str(&format!("\"{}\": \"{}\",\n", esc(key), esc(val)));
    }
    pub fn num(&mut self, key: &str, val: i64) {
        self.pad();
        self.s.push_str(&format!("\"{}\": {},\n", esc(key), val));
    }
    pub fn fnum(&mut self, key: &str, val: f32) {
        self.pad();
        self.s.push_str(&format!("\"{}\": {:.4},\n", esc(key), val));
    }
    pub fn raw(&mut self, key: &str, val: &str) {
        self.pad();
        self.s.push_str(&format!("\"{}\": {},\n", esc(key), val));
    }
    pub fn into_string(mut self) -> String {
        // strip the root's trailing comma (JSON forbids it)
        while self.s.ends_with('\n') || self.s.ends_with(',') || self.s.ends_with(' ') {
            self.s.pop();
        }
        self.s.push('\n');
        self.s
    }
}

fn esc(s: &str) -> String {
    let mut o = String::with_capacity(s.len() + 8);
    for c in s.chars() {
        match c {
            '"' => o.push_str("\\\""),
            '\\' => o.push_str("\\\\"),
            '\n' => o.push_str("\\n"),
            c => o.push(c),
        }
    }
    o
}

// ---------------- asset mapping side-car ----------------

#[derive(Debug, Clone, PartialEq)]
pub enum MapEntry {
    /// sprite #name = path [w h] (texture for the sprite's path-B rendering;
    /// the optional trailing dims are a per-sprite usage override)
    Sprite { name: String, path: String, usage: Option<(u32, u32)> },
    /// mesh EntityName = path (OBJ; entity renders via the bridge as 3D)
    Mesh { entity: String, path: String },
    /// texture name = path [w h] (standalone; optional usage override)
    Texture { name: String, path: String, usage: Option<(u32, u32)> },
    /// sfx #name = path (re-decide: synth fit vs ADPCM by card)
    Sfx { name: String, path: String },
    /// fx #name = burst=N,life=A-B,grav=G (cosmetic emitter rule)
    Fx { name: String, burst: u32, life: (u32, u32), grav: i32, spread_q8: u32 },
}

pub fn parse_mapping(text: &str) -> Result<Vec<MapEntry>, String> {
    let mut out = Vec::new();
    for (ln, line) in text.lines().enumerate() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') || line.starts_with("//") {
            continue;
        }
        let bad = |what: &str| format!("mapping line {}: {}", ln + 1, what);
        let (key, val) = line
            .split_once('=')
            .ok_or_else(|| bad("want `key = value`"))?;
        let key = key.trim();
        let val = val.trim();
        if let Some(rest) = key.strip_prefix("sprite ") {
            let name = rest.trim().trim_start_matches('#').trim().to_string();
            // optional trailing "W H" usage override after the path
            let mut it = val.split_whitespace();
            let path = it.next().unwrap_or("").to_string();
            let usage = match (it.next(), it.next()) {
                (Some(w), Some(h)) => Some((
                    w.parse::<u32>().map_err(|_| bad("bad usage w"))?,
                    h.parse::<u32>().map_err(|_| bad("bad usage h"))?,
                )),
                _ => None,
            };
            out.push(MapEntry::Sprite { name, path, usage });
        } else if let Some(rest) = key.strip_prefix("mesh ") {
            out.push(MapEntry::Mesh { entity: rest.trim().to_string(), path: val.into() });
        } else if let Some(rest) = key.strip_prefix("texture ") {
            // optional trailing "W H" usage override after the path
            let mut it = val.split_whitespace();
            let path = it.next().unwrap_or("").to_string();
            let usage = match (it.next(), it.next()) {
                (Some(w), Some(h)) => {
                    Some((w.parse::<u32>().map_err(|_| bad("bad usage w"))?,
                         h.parse::<u32>().map_err(|_| bad("bad usage h"))?))
                }
                _ => None,
            };
            out.push(MapEntry::Texture { name: rest.trim().to_string(), path, usage });
        } else if let Some(rest) = key.strip_prefix("sfx ") {
            out.push(MapEntry::Sfx { name: rest.trim().trim_start_matches('#').trim().to_string(), path: val.into() });
        } else if let Some(rest) = key.strip_prefix("fx ") {
            // fx #name = burst=600,life=8-40,grav=600,spread=3.5(q8)
            let name = rest.trim().trim_start_matches('#').trim().to_string();
            let mut burst = 128u32;
            let mut life = (16u32, 32u32);
            let mut grav = 0i32;
            let mut spread_q8 = 512u32;
            for kv in val.split(',') {
                let (k, v) = kv.trim().split_once('=').ok_or_else(|| bad("want k=v pairs"))?;
                match k.trim() {
                    "burst" => burst = v.trim().parse().map_err(|_| bad("bad burst"))?,
                    "life" => {
                        let (a, b) = v.trim().split_once('-').ok_or_else(|| bad("life=A-B"))?;
                        life = (
                            a.trim().parse().map_err(|_| bad("bad life a"))?,
                            b.trim().parse().map_err(|_| bad("bad life b"))?,
                        );
                    }
                    "grav" => grav = v.trim().parse().map_err(|_| bad("bad grav"))?,
                    "spread" => {
                        spread_q8 = (v.trim().parse::<f32>().map_err(|_| bad("bad spread"))? * 256.0) as u32;
                    }
                    _ => return Err(bad("unknown fx key")),
                }
            }
            out.push(MapEntry::Fx { name, burst, life, grav, spread_q8 });
        } else {
            return Err(bad("key must start with sprite | mesh | texture | sfx | fx"));
        }
    }
    Ok(out)
}

// ---------------- forgepack ----------------

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct PackSection {
    pub tag: [u8; 4],
    pub index: u32,
    pub len: u32,
}

/// Forgepack writer: "FGP1", u32 count, directory of (tag, index, len),
/// then payloads in directory order. Hosts slice by directory — zero
/// parsing, pure offsets.
#[derive(Default)]
pub struct Forgepack {
    pub dir: Vec<PackSection>,
    pub data: Vec<u8>,
}

impl Forgepack {
    pub fn push(&mut self, tag: &[u8; 4], index: u32, payload: &[u8]) {
        self.dir.push(PackSection { tag: *tag, index, len: payload.len() as u32 });
        self.data.extend_from_slice(payload);
    }
    pub fn emit(&self) -> Vec<u8> {
        let mut o = Vec::with_capacity(8 + self.dir.len() * 12 + self.data.len());
        o.extend_from_slice(b"FGP1");
        o.extend_from_slice(&(self.dir.len() as u32).to_le_bytes());
        for s in &self.dir {
            o.extend_from_slice(&s.tag);
            o.extend_from_slice(&s.index.to_le_bytes());
            o.extend_from_slice(&s.len.to_le_bytes());
        }
        o.extend_from_slice(&self.data);
        o
    }
}

// ---------------- the forge report (print-your-work tradition) ----------------

#[derive(Default)]
pub struct ForgeReport {
    pub textures: Vec<texture::ForgedTexture>,
    pub meshes: Vec<mesh::ForgedMesh>,
    pub audio: Vec<(String, audio::AudioDecision, audio::AudioFacts)>,
    pub table_candidates: Vec<logic::TableCandidate>,
    /// v19: the REAL table plan (purity-proofed, domain-resolved, TBL1-ready)
    pub tables: Vec<tables::TablePlan>,
    /// v19: shader march-count proofs (STEPS = measured, not guessed)
    pub shaders: Vec<wgslpgo::WgslPgo>,
    pub entity_mix: Vec<logic::EntityMix>,
    pub corpus: Option<corpus::CorpusStats>,
    pub libyte_bytes: usize,
    pub forgepack_bytes: usize,
}

impl ForgeReport {
    pub fn print(&self, card: &PlatformCard) {
        println!("  forge [card: {}]:", card.name);
        let mut tex_bytes = 0usize;
        let mut tex_src = 0usize;
        for t in &self.textures {
            tex_bytes += t.bytes();
            tex_src += t.source_bytes();
            match &t.format {
                texture::TexFormat::Gradient => println!(
                    "    texture {} ({}x{}): procedural gradient — payload 0B (4 corner texels, GPU bilinear regenerates any resolution){}",
                    t.name, t.facts.w, t.facts.h,
                    if t.sdf.is_some() || t.normal.is_some() { " + derivations" } else { "" }
                ),
                texture::TexFormat::Palette(bits) => println!(
                    "    texture {} ({}x{}): {} uniques -> palette{} ({}B) residual max {} mean {:.2}",
                    t.name, t.w, t.h, t.facts.unique_colors, bits, t.bytes(), t.residual.max, t.residual.mean
                ),
                texture::TexFormat::Pgx => {
                    if let Some(b) = &t.pgx {
                        println!(
                            "    texture {} ({}x{}): PGX — {} flat colors -> {} rect quads ({}B) — texture eliminated, pixel-exact",
                            t.name, t.w, t.h, b.palette.len(), b.rects.len(), t.bytes()
                        )
                    }
                }
                texture::TexFormat::HostBlock(d) => println!(
                    "    texture {} ({}x{}): -> {} (host transcode), pre-quant residual max {}",
                    t.name, t.w, t.h, d, t.residual.max
                ),
                other => println!(
                    "    texture {} ({}x{}): {:?} ({}B) residual max {} mean {:.2}",
                    t.name, t.w, t.h, other, t.bytes(), t.residual.max, t.residual.mean
                ),
            }
            if t.sdf.is_some() {
                println!("      + SDF {}x{} (smooth zoom / 2D shadows / outlines)", t.w, t.h);
            }
            if t.normal.is_some() {
                println!("      + normal map (host dynamic lights on a flat sprite)");
            }
            for n in &t.notes {
                println!("      - {}", n);
            }
        }
        if !self.textures.is_empty() {
            println!(
                "    textures total: {}B shipped vs {}B source ({:.1}%)",
                tex_bytes,
                tex_src,
                100.0 - tex_bytes as f64 / tex_src.max(1) as f64 * 100.0
            );
        }
        for m in &self.meshes {
            println!(
                "    mesh {}: {} verts -> {} welded ({}B packed, {}B/v), {} tris in {} meshlets, ACMR {:.2} -> {:.2}",
                m.name,
                m.src_verts,
                m.packed.len() / mesh::VERT_BYTES,
                m.packed.len(),
                mesh::VERT_BYTES,
                m.indices.len() / 3,
                m.meshlets.len(),
                m.acmr_before,
                m.acmr_after
            );
            println!(
                "      quantized: {} (max err {:.4} world, normal err {:.2} deg), {} LOD levels",
                m.quantized, m.max_pos_err, m.max_normal_err_deg, m.lods.len()
            );
        }
        for (name, d, facts) in &self.audio {
            match d {
                audio::AudioDecision::Synth { residual, .. } => println!(
                    "    sfx {}: synth program (residual {:.1}%) — {}B sample RAM saved, {:.2}s source trimmed to fit",
                    name, residual * 100.0, facts.samples * 2, facts.seconds
                ),
                audio::AudioDecision::Harmonic { bytes, snr_db, partials, f0, .. } => println!(
                    "    sfx {}: HRM harmonic voice — {}B partial table (f0 {:.1} Hz, {} partials, SNR {:.1} dB) — a sustained tone as data, not samples",
                    name, bytes, f0, partials, snr_db
                ),
                audio::AudioDecision::Adpcm { bytes, snr_db, loop_len } => println!(
                    "    sfx {}: IMA ADPCM {}B (4:1, SNR {:.1} dB){}",
                    name, bytes, snr_db,
                    loop_len.map(|l| format!(", loop candidate {:.0} ms", l as f32 / 44.1)).unwrap_or_default()
                ),
                audio::AudioDecision::Pcm16 { bytes, reason } => println!(
                    "    sfx {}: RAW PCM16 {}B — {} (flagged, not silent)",
                    name, bytes, reason
                ),
            }
        }
        if !self.table_candidates.is_empty() {
            println!("    logic: {} pure-fn candidates (v18 report):", self.table_candidates.len());
            for c in self.table_candidates.iter().take(6) {
                println!("      fn {}({}) — {} entries precomputable", c.name, c.params.join(", "), c.entries);
            }
        }
        if !self.tables.is_empty() {
            println!("    tables (v19 execution-as-data):");
            for t in &self.tables {
                match &t.status {
                    tables::TableStatus::Promoted { spot_verify } => println!(
                        "      fn {} [{}] {} entries {} — calls become loads{}",
                        t.name, t.fn_idx, t.entries,
                        if t.n_args == 2 {
                            format!("[{}..{}]x[{}..{}]", t.lo[0], t.hi[0], t.lo[1], t.hi[1])
                        } else {
                            format!("[{}..{}]", t.lo[0], t.hi[0])
                        },
                        if *spot_verify { " (spot-verified on first hits)" } else { "" }
                    ),
                    tables::TableStatus::NeedsMine => println!(
                        "      fn {} [{}] pure + valued — mine the corpus to promote (--mine-file)",
                        t.name, t.fn_idx
                    ),
                    tables::TableStatus::Skipped(why) => println!(
                        "      fn {} [{}] skipped: {}", t.name, t.fn_idx, why
                    ),
                }
            }
        }
        if !self.shaders.is_empty() {
            println!("    shaders (v19 march-count PGO):");
            for s in &self.shaders {
                println!(
                    "      sdf {}: {} steps (max settling {} over {} rays, {} diffs) — measured, not guessed",
                    s.name, s.steps, s.max_required, s.rays, s.diffs
                );
            }
        }
        for e in &self.entity_mix {
            println!(
                "    entity {}: {} fields{} — mesh-ready",
                e.name,
                e.fields,
                e.fsm.as_ref().map(|f| format!(", fsm {}", f)).unwrap_or_default()
            );
        }
        if let Some(c) = &self.corpus {
            println!(
                "    corpus: {} movies, {} frames ({:.0}s), input coverage {}/32 bits, {} distinct masks, digest {:016x}",
                c.movies, c.total_frames, c.total_seconds, c.input_bits_used, c.distinct_masks, c.digest
            );
        }
        println!(
            "    game.lilamanifest + game.forgepack: {}B + {}B — cartridge unchanged ({}B)",
            self.libyte_bytes, self.forgepack_bytes, self.libyte_bytes
        );
    }
}

// ---------------- the verb ----------------

pub struct ForgeOutput {
    pub manifest: String,
    pub forgepack: Vec<u8>,
    pub report: ForgeReport,
    /// v19: fn indices worth runtime mining (pure + valued, arity 1-2).
    /// One index per line — the runner's --mine list consumes this file.
    pub minelist: Vec<u16>,
}

#[allow(clippy::too_many_arguments)]
pub fn run(
    prog: &Program,
    atom_names: &[String],
    libyte: &[u8],
    mapping_text: &str,
    corpus_movies: &[Vec<u8>],
    base_dir: &Path,
    card: &PlatformCard,
    fn_table: &[(String, u8)],
    mine_file: Option<&[u8]>,
    f64_ret_fns: &[String],
) -> Result<ForgeOutput, String> {
    let mapping = parse_mapping(mapping_text)?;
    let usage = logic::mine_usage(prog);

    // corpus
    let mut movies = Vec::new();
    for (i, m) in corpus_movies.iter().enumerate() {
        movies.push(corpus::parse_movie(m).map_err(|e| format!("corpus[{}]: {}", i, e))?);
    }
    let cstats = if movies.is_empty() { None } else { Some(corpus::stats(&movies)) };

    // resolve atom ids by name
    let atom_id = |name: &str| -> Option<u16> {
        atom_names.iter().position(|n| n == name).map(|i| i as u16)
    };
    let sprite_index_of_atom = |atom: u16| -> Option<usize> {
        prog.sprites.iter().position(|s| s.atom == atom)
    };

    let mut report = ForgeReport::default();
    let mut pack = Forgepack::default();
    let mut tex_i = 0u32;
    let mut mesh_i = 0u32;
    let mut aud_i = 0u32;
    let mut manifest = Json::new();
    manifest.raw(
        "forge",
        "1",
    );
    manifest.raw("card", &format!("\"{}\"", card.name));
    manifest.str("libyte_sha256", &sha256(libyte));
    if let Some(c) = &cstats {
        manifest.obj("corpus");
        manifest.num("movies", c.movies as i64);
        manifest.num("frames", c.total_frames as i64);
        manifest.fnum("seconds", c.total_seconds);
        manifest.num("input_bits_used", c.input_bits_used as i64);
        manifest.fnum("input_coverage", c.input_coverage);
        manifest.num("distinct_masks", c.distinct_masks as i64);
        manifest.str("digest", &format!("{:016x}", c.digest));
        manifest.end_obj();
    }
    manifest.arr("textures");
    for entry in &mapping {
        let path = base_dir.join(match entry {
            MapEntry::Sprite { path, .. } => path,
            MapEntry::Texture { path, .. } => path,
            _ => continue,
        });
        let (name, sprite_atom, usage_override) = match entry {
            MapEntry::Sprite { name, usage, .. } => {
                let atom = atom_id(name).ok_or(format!("sprite #{} not found", name))?;
                (name.clone(), Some(atom), *usage)
            }
            MapEntry::Texture { name, usage, .. } => (name.clone(), None, *usage),
            _ => unreachable!(),
        };
        let bytes = std::fs::read(&path).map_err(|e| format!("{}: {}", path.display(), e))?;
        let surface = img::decode(&bytes)
            .map_err(|e| format!("{}: {}", path.display(), e))?;
        let mut policy = card.tex.clone();
        if let Some(u) = usage_override {
            policy.usage = Some(u);
        } else if let Some(atom) = sprite_atom {
            // usage mining: this sprite's conservative on-screen ceiling
            policy.usage = usage.sprite.get(&atom).copied();
        }
        let tex = texture::forge_texture(&name, &surface, &policy)?;
        // forgepack sections
        let fmt_tag: [u8; 4] = match &tex.format {
            texture::TexFormat::Palette(_) => *b"PALT",
            texture::TexFormat::R8 => *b"TR08",
            texture::TexFormat::A8 => *b"TA08",
            texture::TexFormat::Rgb565 => *b"T565",
            texture::TexFormat::Rgba32 => *b"TRGB",
            texture::TexFormat::Gradient => *b"TGRD",
            texture::TexFormat::HostBlock(_) => *b"THST",
            // PGX's payload self-contains w/h (it is a complete section)
            texture::TexFormat::Pgx => *b"PGX1",
        };
        if !tex.data.is_empty() {
            if matches!(tex.format, texture::TexFormat::Pgx) {
                // complete section, no w/h wrapper
                pack.push(&fmt_tag, tex_i, &tex.data);
            } else {
                let mut payload = vec![];
                payload.extend_from_slice(&tex.w.to_le_bytes());
                payload.extend_from_slice(&tex.h.to_le_bytes());
                payload.extend_from_slice(&tex.data);
                pack.push(&fmt_tag, tex_i, &payload);
            }
            tex_i += 1;
        }
        if let Some(pal) = &tex.palette {
            let mut payload = vec![];
            payload.extend_from_slice(&(pal.len() as u32).to_le_bytes());
            for c in pal {
                payload.extend_from_slice(c);
            }
            pack.push(b"BANK", tex_i, &payload);
        }
        if let Some(sdf) = &tex.sdf {
            let mut payload = vec![];
            payload.extend_from_slice(&tex.w.to_le_bytes());
            payload.extend_from_slice(&tex.h.to_le_bytes());
            payload.extend_from_slice(sdf);
            pack.push(b"TSDF", tex_i, &payload);
        }
        if let Some(nrm) = &tex.normal {
            let mut payload = vec![];
            payload.extend_from_slice(&tex.w.to_le_bytes());
            payload.extend_from_slice(&tex.h.to_le_bytes());
            payload.extend_from_slice(nrm);
            pack.push(b"TNRM", tex_i, &payload);
        }
        // manifest entry
        manifest.obj_anon();
        manifest.str("name", &tex.name);
        if let Some(a) = sprite_atom {
            manifest.num("sprite_atom", a as i64);
            if let Some(si) = sprite_index_of_atom(a) {
                manifest.num("sprite_index", si as i64);
            }
        }
        let fmt_name = match &tex.format {
            texture::TexFormat::Palette(b) => format!("palette{}", b),
            texture::TexFormat::R8 => "r8".into(),
            texture::TexFormat::A8 => "a8".into(),
            texture::TexFormat::Rgb565 => "rgb565".into(),
            texture::TexFormat::Rgba32 => "rgba32".into(),
            texture::TexFormat::Gradient => "gradient".into(),
            texture::TexFormat::HostBlock(d) => format!("host:{}", d),
            texture::TexFormat::Pgx => "pgx".into(),
        };
        manifest.str("format", &fmt_name);
        manifest.num("w", tex.w as i64);
        manifest.num("h", tex.h as i64);
        manifest.num("bytes", tex.bytes() as i64);
        manifest.num("source_bytes", tex.source_bytes() as i64);
        manifest.num("residual_max", tex.residual.max as i64);
        manifest.fnum("residual_mean", tex.residual.mean);
        if let Some(u) = policy.usage {
            manifest.num("usage_w", u.0 as i64);
            manifest.num("usage_h", u.1 as i64);
        }
        if tex.sdf.is_some() {
            manifest.raw("sdf", "true");
        }
        if tex.normal.is_some() {
            manifest.raw("normal", "true");
        }
        if let Some(b) = &tex.pgx {
            manifest.num("pgx_rects", b.rects.len() as i64);
            manifest.num("pgx_colors", b.palette.len() as i64);
        }
        manifest.raw(
            "render",
            &format!(
                "{{\"kind\":\"{}\"}}",
                if tex.pgx.is_some() {
                    "pgx"
                } else if sprite_atom.is_some() {
                    "quad"
                } else {
                    "texture"
                }
            ),
        );
        manifest.end_obj();
        report.textures.push(tex);
    }
    manifest.end_arr();

    manifest.arr("meshes");
    for entry in &mapping {
        let MapEntry::Mesh { entity, path } = entry else { continue };
        let full = base_dir.join(path);
        let text = std::fs::read_to_string(&full).map_err(|e| format!("{}: {}", full.display(), e))?;
        let m = mesh::parse_obj(&text).map_err(|e| format!("{}: {}", full.display(), e))?;
        let forged = mesh::forge_mesh(entity, &m, &card.mesh)?;
        let blob = mesh::emit(&forged);
        pack.push(b"MESH", mesh_i, &blob);
        manifest.obj_anon();
        manifest.str("entity", &forged.name);
        manifest.num("verts", (forged.packed.len() / mesh::VERT_BYTES) as i64);
        manifest.num("tris", (forged.indices.len() / 3) as i64);
        manifest.num("src_verts", forged.src_verts as i64);
        manifest.num("meshlets", forged.meshlets.len() as i64);
        manifest.num("lods", forged.lods.len() as i64);
        manifest.fnum("acmr_before", forged.acmr_before);
        manifest.fnum("acmr_after", forged.acmr_after);
        manifest.fnum("max_pos_err", forged.max_pos_err);
        manifest.fnum("max_normal_err_deg", forged.max_normal_err_deg);
        manifest.raw("quantized", if forged.quantized { "true" } else { "false" });
        manifest.raw("render", "{\"kind\":\"mesh\"}");
        manifest.end_obj();
        report.meshes.push(forged);
        mesh_i += 1;
    }
    manifest.end_arr();

    manifest.arr("audio");
    for entry in &mapping {
        let MapEntry::Sfx { name, path } = entry else { continue };
        let full = base_dir.join(path);
        let bytes = std::fs::read(&full).map_err(|e| format!("{}: {}", full.display(), e))?;
        let (decision, facts) = audio::forge_audio(name, &bytes, &card.audio)?;
        // v19: the harmonic voice ships as an HRM1 section (a ~60B partial
        // table, infinite sustain — the sustained-tone gap ADPCM used to eat)
        if let audio::AudioDecision::Harmonic { .. } = &decision {
            let pcm = crate::opt::audio::parse_wav(&bytes)?;
            let keep_from = facts.lead_silence.min(pcm.samples.len().saturating_sub(1));
            let keep_to = pcm.samples.len().saturating_sub(facts.tail_silence);
            let trimmed = &pcm.samples[keep_from.max(0)..keep_to.max(0)];
            if let Some(v) = audio::fit_harmonic(trimmed, pcm.sr, card.audio.hrm_max_partials) {
                pack.push(b"HRM1", aud_i, &audio::emit_harmonic(&v, pcm.sr));
            }
        }
        if let audio::AudioDecision::Adpcm { .. } = &decision {
            // bank the encoded sample (re-encode to attach loop facts)
            let pcm = crate::opt::audio::parse_wav(&bytes)?;
            let keep_from = facts.lead_silence.min(pcm.samples.len().saturating_sub(1));
            let keep_to = pcm.samples.len().saturating_sub(facts.tail_silence);
            let to_i16 = |v: f32| (v.clamp(-1.0, 1.0) * 32767.0).round() as i16;
            let pcm16: Vec<i16> = pcm.samples[keep_from..keep_to].iter().map(|&v| to_i16(v)).collect();
            let enc = audio::adpcm_encode(&pcm16);
            let mut payload = vec![];
            payload.extend_from_slice(&(pcm.sr.to_le_bytes()));
            payload.extend_from_slice(&(pcm16.len() as u32).to_le_bytes());
            payload.extend_from_slice(&facts.loop_len.unwrap_or(0).to_le_bytes());
            payload.extend_from_slice(&enc);
            pack.push(b"ADPC", aud_i, &payload);
        }
        manifest.obj_anon();
        manifest.str("name", name);
        let (kind, note) = match &decision {
            audio::AudioDecision::Synth { residual, .. } => {
                ("synth", format!("residual {:.1}%", residual * 100.0))
            }
            audio::AudioDecision::Harmonic { snr_db, partials, f0, .. } => {
                ("harmonic", format!("f0 {:.1} Hz, {} partials, SNR {:.1} dB", f0, partials, snr_db))
            }
            audio::AudioDecision::Adpcm { snr_db, .. } => ("adpcm", format!("SNR {:.1} dB", snr_db)),
            audio::AudioDecision::Pcm16 { reason, .. } => ("pcm16", reason.clone()),
        };
        manifest.str("decision", kind);
        manifest.str("note", &note);
        manifest.fnum("seconds", facts.seconds);
        if facts.loop_len.is_some() {
            manifest.raw("loop", "true");
        }
        manifest.end_obj();
        report.audio.push((name.clone(), decision, facts));
        aud_i += 1;
    }
    manifest.end_arr();

    // fx rules (token reinterpretation — the cosmetic layer's contract)
    manifest.arr("fx");
    for entry in &mapping {
        let MapEntry::Fx { name, burst, life, grav, spread_q8 } = entry else { continue };
        let Some(atom) = atom_id(name) else { continue };
        manifest.obj_anon();
        manifest.str("name", name);
        manifest.num("sprite_atom", atom as i64);
        manifest.num("burst", *burst as i64);
        manifest.num("life_min", life.0 as i64);
        manifest.num("life_max", life.1 as i64);
        manifest.num("grav_q8", *grav as i64);
        manifest.num("spread_q8", *spread_q8 as i64);
        manifest.raw("render", "{\"kind\":\"fx\"}");
        manifest.end_obj();
    }
    manifest.end_arr();

    // ---- v19 TABLES: execution becomes data ----
    // purity fixpoint + domains (mined if available) + TBL1 pack sections.
    // The pack carries DECISIONS (domains, ~20B); the VM bakes VALUES at
    // install by running the real fn once per entry. No second implementation.
    let mine = match mine_file {
        Some(bytes) => Some(tables::parse_mine(bytes)?),
        None => None,
    };
    let table_plan = tables::plan(prog, fn_table, mine.as_ref(), f64_ret_fns);
    let minelist = tables::minelist(prog, fn_table);
    let mut tbl_i = 0u32;
    manifest.arr("tables");
    for t in &table_plan {
        if let tables::TableStatus::Promoted { .. } = t.status {
            pack.push(b"TBL1", tbl_i, &t.payload);
            tbl_i += 1;
        }
        manifest.obj_anon();
        manifest.str("fn", &t.name);
        manifest.num("fn_idx", t.fn_idx as i64);
        manifest.num("args", t.n_args as i64);
        match &t.status {
            tables::TableStatus::Promoted { spot_verify } => {
                manifest.str("decision", "table");
                manifest.num("entries", t.entries as i64);
                manifest.num("lo0", t.lo[0] as i64);
                manifest.num("hi0", t.hi[0] as i64);
                if t.n_args == 2 {
                    manifest.num("lo1", t.lo[1] as i64);
                    manifest.num("hi1", t.hi[1] as i64);
                }
                manifest.raw("spot_verify", if *spot_verify { "true" } else { "false" });
                manifest.str(
                    "note",
                    "domains shipped; the VM bakes values at install (bake = execution of the real fn)",
                );
            }
            tables::TableStatus::NeedsMine => {
                manifest.str("decision", "needs-mine");
            }
            tables::TableStatus::Skipped(why) => {
                manifest.str("decision", "skipped");
                manifest.str("note", why);
            }
        }
        manifest.end_obj();
    }
    manifest.end_arr();

    // ---- v19 SHADER PGO: the march loop trip count becomes a measured
    // constant. The camera is a pure function of time; time is corpus-
    // recorded; so the exact ray set is known. March it on the CPU with the
    // same math, prove the settling count, emit the specialized WGSL (still
    // naga-validated — a broken shader breaks the forge).
    let corpus_seconds = cstats.as_ref().map(|c| c.total_seconds).unwrap_or(0.0);
    let mut shader_i = 0u32;
    let mut shader_pgo = Vec::new();
    manifest.arr("shaders");
    for sd in &prog.sdfs {
        let root = crate::opt::sdf::fold(sd.root.clone());
        let root = crate::opt::sdf::prune(root);
        let (root, _blends) = crate::opt::sdf::consolidate(root);
        let decl = crate::opt::sdf::SdfDecl { root, ..sd.clone() };
        let pgo = wgslpgo::specialize(&decl, corpus_seconds);
        let out = crate::opt::wgsl::emit_with_steps(&decl, pgo.steps);
        crate::opt::wgsl::validate_wgsl(&out.main_wgsl, &decl.name)?;
        if let Some(hud) = &out.hud_wgsl {
            crate::opt::wgsl::validate_wgsl(hud, &format!("{}_hud", decl.name))?;
        }
        pack.push(b"WGSL", shader_i, out.main_wgsl.as_bytes());
        if let Some(hud) = &out.hud_wgsl {
            pack.push(b"WSHD", shader_i, hud.as_bytes());
        }
        manifest.obj_anon();
        manifest.str("name", &pgo.name);
        manifest.num("steps", pgo.steps as i64);
        manifest.num("max_required", pgo.max_required as i64);
        manifest.num("rays", pgo.rays as i64);
        manifest.num("diffs", pgo.diffs as i64);
        manifest.raw("verified", if pgo.diffs == 0 { "true" } else { "false" });
        manifest.str(
            "note",
            "march trip count measured over the corpus camera path (CPU-marched, reference-verified)",
        );
        manifest.end_obj();
        shader_pgo.push(pgo);
        shader_i += 1;
    }
    manifest.end_arr();

    // logic + usage sections
    let candidates = logic::table_candidates(prog);
    let mix = logic::entity_mix(prog);
    manifest.arr("table_candidates");
    for c in &candidates {
        manifest.obj_anon();
        manifest.str("fn", &c.name);
        manifest.num("entries", c.entries as i64);
        manifest.end_obj();
    }
    manifest.end_arr();
    manifest.obj("usage");
    let mut sorted: BTreeMap<u16, (u32, u32)> = BTreeMap::new();
    for (k, v) in &usage.sprite {
        sorted.insert(*k, *v);
    }
    for (atom, (w, h)) in &sorted {
        manifest.raw(
            &atom.to_string(),
            &format!("[{}, {}]", w, h),
        );
    }
    manifest.end_obj();

    report.table_candidates = candidates;
    report.tables = table_plan;
    report.shaders = shader_pgo;
    report.entity_mix = mix;
    report.corpus = cstats;
    report.libyte_bytes = libyte.len();
    report.forgepack_bytes = pack.data.len();

    // forgepack sha256 pins the manifest to the bytes
    let pack_bytes = pack.emit();
    manifest.str("forgepack_sha256", &sha256(&pack_bytes));
    let m = manifest.into_string();
    // wrap in the root object (hosts parse with stdlib JSON)
    let m = format!("{{\n{}}}", m.trim_end());
    Ok(ForgeOutput { manifest: m, forgepack: pack_bytes, report, minelist })
}

// ---------------- tests ----------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sha256_known_vectors() {
        assert_eq!(
            sha256(b""),
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        );
        assert_eq!(
            sha256(b"abc"),
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        );
        assert_eq!(
            sha256(b"The quick brown fox jumps over the lazy dog"),
            "d7a8fbb307d7809469ca9abcb0082e4f8d5651e46d3cdb762d02d0bf37c9e592"
        );
    }

    #[test]
    fn mapping_parses_all_kinds() {
        let m = parse_mapping(
            "# comment\nsprite #ship = art/ship.qoi\nmesh Drone = art/drone.obj\n\
             texture bg = art/bg.qoi 512 288\nsfx #boom = art/boom.wav\n\
             fx #spark = burst=600,life=8-40,grav=600,spread=3.5\n",
        )
        .unwrap();
        assert_eq!(m.len(), 5);
        assert!(matches!(&m[0], MapEntry::Sprite { name, .. } if name == "ship"));
        assert!(matches!(&m[1], MapEntry::Mesh { entity, .. } if entity == "Drone"));
        assert!(matches!(&m[2], MapEntry::Texture { usage: Some((512, 288)), .. }));
        assert!(matches!(&m[3], MapEntry::Sfx { name, .. } if name == "boom"));
        assert!(matches!(&m[4], MapEntry::Fx { burst: 600, life: (8, 40), grav: 600, .. }));
    }

    #[test]
    fn mapping_rejects_garbage() {
        assert!(parse_mapping("ship = x").is_err());
        assert!(parse_mapping("fx #x = life=8").is_err()); // life=A-B
    }

    #[test]
    fn forgepack_layout() {
        let mut p = Forgepack::default();
        p.push(b"TEXA", 0, &[1, 2, 3]);
        p.push(b"MESH", 1, &[4]);
        let b = p.emit();
        assert_eq!(&b[0..4], b"FGP1");
        assert_eq!(u32::from_le_bytes([b[4], b[5], b[6], b[7]]), 2);
        // directory: 12B each, payloads after
        assert_eq!(b[8 + 12 + 12..], [1, 2, 3, 4]);
    }

    #[test]
    fn cards_exist() {
        assert!(PlatformCard::get("desktop").is_ok());
        assert!(PlatformCard::get("mobile").is_ok());
        assert!(PlatformCard::get("cloud_min").is_ok());
        assert!(PlatformCard::get("wat").is_err());
    }
}
