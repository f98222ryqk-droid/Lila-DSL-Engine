//! ============================================================================
//! FORGE — SUBSYSTEM A1: IMAGE DECODE (zero-dependency asset ingestion)
//! ============================================================================
//!
//! FORGE eats whatever raster format the artist already has on disk and
//! never asks for a codec library. The player never sees any of this —
//! decode happens ONCE at `lilac forge` time; what ships is the emitted
//! forgepack (already in the decided optimal layout).
//!
//! Supported inputs (anything else converts losslessly with one command):
//!   .qoi  — "Quite OK Image" (qoif): the build-artifact format, channel-
//!            honest, hashable. `ffmpeg -i in.png out.qoi`
//!   .bmp  — 24-bit BGR and 32-bit BGRA, BI_RGB, bottom-up or top-down
//!   .ppm  — P6 raw RGB
//!
//! Everything decodes into `Surface` (RGBA8888, row-major). All analysis,
//! quantization and verification in the rest of FORGE works on Surface only.
//!
//! Byte-greed discipline: decoders are total — malformed input is an Err,
//! never a panic; truncation is detected; dimensions are sanity-capped at
//! 16384 so a corrupt header cannot OOM the build machine.

/// RGBA8888 image, row-major, 4 bytes per pixel.
#[derive(Debug, Clone, PartialEq)]
pub struct Surface {
    pub w: u32,
    pub h: u32,
    /// len == (w * h * 4) as usize — enforced by constructor
    pub rgba: Vec<u8>,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Px {
    pub r: u8,
    pub g: u8,
    pub b: u8,
    pub a: u8,
}

impl Surface {
    pub fn new(w: u32, h: u32) -> Surface {
        Surface { w, h, rgba: vec![0; (w as usize) * (h as usize) * 4] }
    }

    pub fn from_rgba(w: u32, h: u32, rgba: Vec<u8>) -> Result<Surface, String> {
        if rgba.len() != (w as usize) * (h as usize) * 4 {
            return Err(format!(
                "surface size mismatch: {} bytes for {}x{} (need {})",
                rgba.len(),
                w,
                h,
                (w as usize) * (h as usize) * 4
            ));
        }
        Ok(Surface { w, h, rgba })
    }

    #[inline]
    pub fn px(&self, x: u32, y: u32) -> Px {
        let i = ((y as usize * self.w as usize) + x as usize) * 4;
        Px { r: self.rgba[i], g: self.rgba[i + 1], b: self.rgba[i + 2], a: self.rgba[i + 3] }
    }

    #[inline]
    pub fn set_px(&mut self, x: u32, y: u32, p: Px) {
        let i = ((y as usize * self.w as usize) + x as usize) * 4;
        self.rgba[i] = p.r;
        self.rgba[i + 1] = p.g;
        self.rgba[i + 2] = p.b;
        self.rgba[i + 3] = p.a;
    }

    /// Box downsample by an exact integer factor (>= 1). Deterministic:
    /// summing order is scan order. Used by the usage-mining path when a
    /// 1024px source is only ever drawn 64px wide — the RESOLUTION IS THE
    /// COMPRESSION (see texture.rs decide()).
    pub fn downsample(&self, fx: u32, fy: u32) -> Result<Surface, String> {
        if fx == 0 || fy == 0 {
            return Err("downsample factor must be >= 1".into());
        }
        if fx == 1 && fy == 1 {
            return Ok(self.clone());
        }
        let nw = self.w / fx;
        let nh = self.h / fy;
        if nw == 0 || nh == 0 {
            return Err(format!("downsample {}x{} destroys {}x{}", fx, fy, self.w, self.h));
        }
        let mut out = Surface::new(nw, nh);
        for y in 0..nh {
            for x in 0..nw {
                let (mut r, mut g, mut b, mut a, mut n) = (0u32, 0u32, 0u32, 0u32, 0u32);
                for sy in 0..fy {
                    for sx in 0..fx {
                        let p = self.px(x * fx + sx, y * fy + sy);
                        r += p.r as u32;
                        g += p.g as u32;
                        b += p.b as u32;
                        a += p.a as u32;
                        n += 1;
                    }
                }
                out.set_px(
                    x,
                    y,
                    Px {
                        r: (r / n) as u8,
                        g: (g / n) as u8,
                        b: (b / n) as u8,
                        a: (a / n) as u8,
                    },
                );
            }
        }
        Ok(out)
    }

    /// Flip vertically (BMP bottom-up rows arrive inverted).
    pub fn flip_y(&mut self) {
        let w = self.w as usize;
        let h = self.h as usize;
        let mut y0 = 0usize;
        let mut y1 = h.wrapping_sub(1);
        while y0 < y1 {
            for x in 0..w {
                let a = (y0 * w + x) * 4;
                let b = (y1 * w + x) * 4;
                for k in 0..4 {
                    self.rgba.swap(a + k, b + k);
                }
            }
            y0 += 1;
            y1 -= 1;
        }
    }
}

const MAX_DIM: u32 = 16384;

fn check_dims(w: u32, h: u32) -> Result<(), String> {
    if w == 0 || h == 0 || w > MAX_DIM || h > MAX_DIM {
        return Err(format!("image dimensions {}x{} out of range (1..={})", w, h, MAX_DIM));
    }
    if (w as u64) * (h as u64) > (1 << 30) {
        return Err(format!("image {}x{} exceeds 1Gi pixels", w, h));
    }
    Ok(())
}

/// Decode by content sniffing, not extension (artists rename files).
pub fn decode(bytes: &[u8]) -> Result<Surface, String> {
    if bytes.len() >= 14 && &bytes[0..4] == b"qoif" {
        return decode_qoi(bytes);
    }
    if bytes.len() >= 2 && bytes[0] == b'B' && bytes[1] == b'M' {
        return decode_bmp(bytes);
    }
    if bytes.len() >= 2 && bytes[0] == b'P' && bytes[1] == b'6' {
        return decode_ppm(bytes);
    }
    Err("unknown image format (want qoif / BM / P6)".into())
}

// ---------------- QOI (reference decoder, public-domain format) ----------------

fn decode_qoi(b: &[u8]) -> Result<Surface, String> {
    if b.len() < 22 {
        return Err("qoi: truncated header".into());
    }
    let w = u32::from_be_bytes([b[4], b[5], b[6], b[7]]);
    let h = u32::from_be_bytes([b[8], b[9], b[10], b[11]]);
    let channels = b[12];
    if channels != 3 && channels != 4 {
        return Err(format!("qoi: channels {} (want 3 or 4)", channels));
    }
    check_dims(w, h)?;
    let n = (w as usize) * (h as usize);
    let mut out = Surface::new(w, h);
    let mut index = [[0u8; 4]; 64];
    let mut px = Px { r: 0, g: 0, b: 0, a: 255 };
    let mut i = 14usize;
    let mut written = 0usize;
    let need = |i: usize, n: usize, b: &[u8]| -> Result<(), String> {
        if i + n > b.len() {
            Err("qoi: truncated stream".into())
        } else {
            Ok(())
        }
    };
    while written < n {
        need(i, 1, b)?;
        let b1 = b[i];
        i += 1;
        if b1 == 0xFE {
            need(i, 3, b)?;
            px = Px { r: b[i], g: b[i + 1], b: b[i + 2], a: px.a };
            i += 3;
        } else if b1 == 0xFF {
            need(i, 4, b)?;
            px = Px { r: b[i], g: b[i + 1], b: b[i + 2], a: b[i + 3] };
            i += 4;
        } else {
            let tag = b1 >> 6;
            match tag {
                0 => {
                    let p = index[(b1 & 0x3F) as usize];
                    px = Px { r: p[0], g: p[1], b: p[2], a: p[3] };
                }
                1 => {
                    px = Px {
                        r: px.r.wrapping_add(((b1 >> 4) & 0x03)).wrapping_sub(2),
                        g: px.g.wrapping_add(((b1 >> 2) & 0x03)).wrapping_sub(2),
                        b: px.b.wrapping_add((b1 & 0x03)).wrapping_sub(2),
                        a: px.a,
                    };
                }
                2 => {
                    need(i, 1, b)?;
                    let b2 = b[i];
                    i += 1;
                    let vg = (b1 & 0x3F) as i32 - 32;
                    let dr_dg = ((b2 >> 4) & 0x0F) as i32 - 8;
                    let db_dg = (b2 & 0x0F) as i32 - 8;
                    let g = px.g as i32 + vg;
                    px = Px {
                        r: (px.r as i32 + vg + dr_dg).clamp(0, 255) as u8,
                        g: g.clamp(0, 255) as u8,
                        b: (px.b as i32 + vg + db_dg).clamp(0, 255) as u8,
                        a: px.a,
                    };
                }
                _ => {
                    let run = (b1 & 0x3F) as usize + 1; // spec: stored as run-1
                    if written + run > n {
                        return Err("qoi: bad run".into());
                    }
                    for _ in 0..run {
                        let (x, y) = (written % w as usize, written / w as usize);
                        out.set_px(x as u32, y as u32, px);
                        written += 1;
                    }
                    continue;
                }
            }
        }
        index[((px.r as usize * 3 + px.g as usize * 5 + px.b as usize * 7 + px.a as usize * 11) % 64)] =
            [px.r, px.g, px.b, px.a];
        let (x, y) = (written % w as usize, written / w as usize);
        out.set_px(x as u32, y as u32, px);
        written += 1;
    }
    Ok(out)
}

// ---------------- BMP (24/32-bit BI_RGB, top-down or bottom-up) ----------------

fn decode_bmp(b: &[u8]) -> Result<Surface, String> {
    if b.len() < 54 {
        return Err("bmp: truncated".into());
    }
    let rd_u32 = |o: usize| -> u32 {
        u32::from_le_bytes([b[o], b[o + 1], b[o + 2], b[o + 3]])
    };
    let rd_i32 = |o: usize| -> i32 { rd_u32(o) as i32 };
    let pixel_off = rd_u32(10) as usize;
    let hdr_size = rd_u32(14);
    if !(hdr_size == 40 || hdr_size == 124) {
        return Err(format!("bmp: header size {} unsupported", hdr_size));
    }
    let w = rd_i32(18);
    let h_raw = rd_i32(22);
    let bpp = rd_u32(28) as usize;
    if bpp != 24 && bpp != 32 {
        return Err(format!("bmp: {}bpp unsupported (want 24/32 BI_RGB)", bpp));
    }
    if rd_u32(30) != 0 {
        return Err("bmp: compression != BI_RGB".into());
    }
    if w <= 0 || h_raw == 0 {
        return Err("bmp: degenerate dimensions".into());
    }
    let w = w as u32;
    let flip = h_raw > 0;
    let h = h_raw.unsigned_abs();
    check_dims(w, h)?;
    let mut out = Surface::new(w, h);
    let row_bytes = (((bpp * w as usize) + 31) / 32) * 4;
    let need = (h as usize) * row_bytes;
    if pixel_off + need > b.len() {
        return Err("bmp: pixel data truncated".into());
    }
    for row in 0..h as usize {
        let src_row = if flip { (h as usize - 1 - row) } else { row };
        let base = pixel_off + src_row * row_bytes;
        for x in 0..w as usize {
            let p = base + x * (bpp / 8);
            let (r, g, bl, a) = if bpp == 32 {
                (b[p + 2], b[p + 1], b[p], b[p + 3])
            } else {
                (b[p + 2], b[p + 1], b[p], 255)
            };
            out.set_px(x as u32, row as u32, Px { r, g, b: bl, a });
        }
    }
    Ok(out)
}

// ---------------- PPM P6 ----------------

fn decode_ppm(b: &[u8]) -> Result<Surface, String> {
    let mut i = 2usize; // past "P6"
    let mut fields = [0u32; 3];
    let mut fi = 0usize;
    while fi < 3 {
        // skip whitespace + comments
        while i < b.len() && (b[i] as char).is_whitespace() {
            i += 1;
        }
        if i < b.len() && b[i] == b'#' {
            while i < b.len() && b[i] != b'\n' {
                i += 1;
            }
            continue;
        }
        let start = i;
        while i < b.len() && (b[i] as char).is_ascii_digit() {
            i += 1;
        }
        if start == i {
            return Err("ppm: bad header".into());
        }
        fields[fi] = std::str::from_utf8(&b[start..i])
            .map_err(|_| "ppm: bad header")?
            .parse::<u32>()
            .map_err(|_| "ppm: bad header")?;
        fi += 1;
    }
    i += 1; // exactly one whitespace after maxval
    let (w, h, max) = (fields[0], fields[1], fields[2]);
    check_dims(w, h)?;
    if max == 0 || max > 255 {
        return Err(format!("ppm: maxval {} unsupported", max));
    }
    let need = (w as usize) * (h as usize) * 3;
    if i + need > b.len() {
        return Err("ppm: pixel data truncated".into());
    }
    let mut out = Surface::new(w, h);
    let scale = |v: u8| -> u8 {
        if max == 255 {
            v
        } else {
            ((v as u32 * 255 + max as u32 / 2) / max as u32).min(255) as u8
        }
    };
    for y in 0..h as usize {
        for x in 0..w as usize {
            let p = i + (y * w as usize + x) * 3;
            out.set_px(
                x as u32,
                y as u32,
                Px { r: scale(b[p]), g: scale(b[p + 1]), b: scale(b[p + 2]), a: 255 },
            );
        }
    }
    Ok(out)
}

// ---------------- tests ----------------

#[cfg(test)]
mod tests {
    use super::*;

    /// Tiny reference QOI encoder (test-side) so the decoder can be
    /// round-trip verified without external fixtures.
    fn encode_qoi(s: &Surface) -> Vec<u8> {
        let mut o = Vec::new();
        o.extend_from_slice(b"qoif");
        o.extend_from_slice(&s.w.to_be_bytes());
        o.extend_from_slice(&s.h.to_be_bytes());
        o.push(4); // channels
        o.push(0); // sRGB
        let mut prev = [0u8, 0, 0, 255];
        for y in 0..s.h {
            for x in 0..s.w {
                let p = s.px(x, y);
                let c = [p.r, p.g, p.b, p.a];
                if c == prev {
                    // count a run
                    o.push(0b11_000000);
                    continue; // test encoder: 1-px runs only (decoder handles >1)
                }
                if p.a == prev[3] {
                    let dr = p.r as i16 - prev[0] as i16;
                    let dg = p.g as i16 - prev[1] as i16;
                    let db = p.b as i16 - prev[2] as i16;
                    let (dr2, dg2, db2) = (dr + 2, dg + 2, db + 2);
                    if (0..4).contains(&dr2)
                        && (0..4).contains(&dg2)
                        && (0..4).contains(&db2)
                    {
                        o.push(0b01_000000
                            | ((dr2 as u8) << 4)
                            | ((dg2 as u8) << 2)
                            | (db2 as u8));
                    } else {
                        o.push(0xFE);
                        o.extend_from_slice(&c[..3]);
                    }
                } else {
                    o.push(0xFF);
                    o.extend_from_slice(&c);
                }
                prev = c;
            }
        }
        o.extend_from_slice(&[0, 0, 0, 0, 0, 0, 0, 1]);
        o
    }

    #[test]
    fn qoi_roundtrip() {
        let mut s = Surface::new(9, 5);
        for y in 0..5 {
            for x in 0..9 {
                s.set_px(
                    x,
                    y,
                    Px { r: (x * 28) as u8, g: (y * 51) as u8, b: (x * y * 3) as u8, a: if (x + y) % 2 == 0 { 255 } else { 128 } },
                );
            }
        }
        let enc = encode_qoi(&s);
        let dec = decode_qoi(&enc).unwrap();
        assert_eq!(dec, s);
    }

    #[test]
    fn qoi_rejects_truncated() {
        let mut s = Surface::new(4, 4);
        s.rgba.iter_mut().for_each(|v| *v = 7);
        let enc = encode_qoi(&s);
        assert!(decode_qoi(&enc[..enc.len() - 9]).is_err());
    }

    #[test]
    fn bmp24_bottom_up_roundtrip() {
        // hand-build a 3x2 24-bit bottom-up BMP
        let row = 3 * 3 + 3; // 9 bytes + 3 pad = 12 (word-aligned)
        let mut b = Vec::new();
        b.extend_from_slice(b"BM");
        b.extend_from_slice(&((54 + 2 * row) as u32).to_le_bytes());
        b.extend_from_slice(&[0; 4]);
        b.extend_from_slice(&54u32.to_le_bytes());
        b.extend_from_slice(&40u32.to_le_bytes());
        b.extend_from_slice(&3i32.to_le_bytes());
        b.extend_from_slice(&2i32.to_le_bytes());
        b.extend_from_slice(&1u16.to_le_bytes());
        b.extend_from_slice(&24u16.to_le_bytes());
        b.extend_from_slice(&0u32.to_le_bytes()); // BI_RGB
        b.extend_from_slice(&((row * 2) as u32).to_le_bytes());
        b.extend_from_slice(&[0; 16]);
        // bottom row first (image row 1), then top row (image row 0)
        b.extend_from_slice(&[1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 0, 0]); // row 1: BGR triples
        b.extend_from_slice(&[10, 11, 12, 13, 14, 15, 16, 17, 18, 0, 0, 0]); // row 0
        let s = decode_bmp(&b).unwrap();
        assert_eq!((s.w, s.h), (3, 2));
        assert_eq!(s.px(0, 0), Px { r: 12, g: 11, b: 10, a: 255 });
        assert_eq!(s.px(2, 1), Px { r: 9, g: 8, b: 7, a: 255 });
    }

    #[test]
    fn ppm_roundtrip() {
        let b = b"P6\n# comment\n2 1\n255\n\xAA\xBB\xCC\x01\x02\x03";
        let s = decode_ppm(b).unwrap();
        assert_eq!((s.w, s.h), (2, 1));
        assert_eq!(s.px(0, 0), Px { r: 0xAA, g: 0xBB, b: 0xCC, a: 255 });
        assert_eq!(s.px(1, 0), Px { r: 1, g: 2, b: 3, a: 255 });
    }

    #[test]
    fn downsample_averages() {
        let mut s = Surface::new(2, 2);
        s.set_px(0, 0, Px { r: 255, g: 0, b: 0, a: 255 });
        s.set_px(1, 0, Px { r: 0, g: 255, b: 0, a: 255 });
        s.set_px(0, 1, Px { r: 0, g: 0, b: 255, a: 255 });
        s.set_px(1, 1, Px { r: 10, g: 10, b: 10, a: 40 });
        let d = s.downsample(2, 2).unwrap();
        assert_eq!((d.w, d.h), (1, 1));
        let p = d.px(0, 0);
        assert_eq!(p.r, 66); // (255+0+0+10)/4
        assert_eq!(p.a, 201); // (255*3+40)/4 = 805/4
    }

    #[test]
    fn sniff_dispatches() {
        let s = Surface::new(1, 1);
        let q = encode_qoi(&s);
        assert!(decode(&q).is_ok());
        assert!(decode(b"nope").is_err());
    }
}
