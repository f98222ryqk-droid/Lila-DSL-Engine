//! ============================================================================
//! FORGE — SUBSYSTEM A7 (v19): PGX — the texture becomes geometry
//! ============================================================================
//!
//!   THE CLAIM: an arcade sprite IS a small list of flat-color rectangles.
//!   A 64x64 ship with 6 flat colors is not 4096 texels — it is ~10 rects +
//!   a 6-entry palette. Block compressors (BC7/ASTC) pay 1 byte per pixel to
//!   approximate those flat areas; PGX pays ZERO per pixel and reproduces
//!   them EXACTLY. For hard-edged arcade art this is the theoretical
//!   minimum: not "compressed pixels" but "no pixels at all" — the host
//!   rasterizes the rects as an indexed-quad mesh and the texture unit
//!   never touches the sprite.
//!
//!   HOW (analyze -> decide -> VERIFY, same as every other class):
//!     1. Exact palette (first-appearance order, <= 16 colors, no
//!        quantization — PGX is lossless or it does not ship).
//!     2. Per-color maximal-rectangle cover: greedy scan over the color's
//!        mask, each seed grows right then down (the classic cover).
//!     3. VERIFY by decoding the SHIPPED BYTES back to a surface and
//!        comparing every pixel — exact or demote. The next format in the
//!        chain (palette) takes over, exactly like every other decision.
//!     4. Chosen only when it BEATS the next candidate's byte count — PGX
//!        is not a novelty, it is a size winner or it is nothing.
//!
//!   FORMAT (PGX1 pack section):
//!     u16 w, u16 h, u16 palette_len, palette RGBA32 * len,
//!     u16 rect_count, then per rect: u16 x, u16 y, u16 w, u16 h, u8 color
//!     (7 bytes, no padding — the hosts that care can copy into GPU buffers
//!     with one pass)
//!
//!   HOST RENDERING: quads with palette indices — one instanced draw for
//!   the whole sprite, zero texture binds, zero texel reads. The manifest's
//!   render.kind becomes "pgx".

use super::img::Surface;

pub const MAX_COLORS: usize = 16;
pub const MAX_RECTS: usize = 384;

#[derive(Debug, Clone, PartialEq)]
pub struct PgxRect {
    pub x: u16,
    pub y: u16,
    pub w: u16,
    pub h: u16,
    pub color: u8,
}

#[derive(Debug, Clone, PartialEq)]
pub struct PgxBlob {
    pub palette: Vec<[u8; 4]>,
    pub rects: Vec<PgxRect>,
}

/// Greedy maximal-rectangle cover of a binary mask.
/// Scan row-major; at each uncovered cell grow right while the mask holds,
/// then grow down while the full row segment holds. Marks cells covered.
fn cover_mask(mask: &[bool], w: usize, h: usize, color: u8, out: &mut Vec<PgxRect>) {
    let mut covered = vec![false; w * h];
    for y in 0..h {
        'x: for x in 0..w {
            let i = y * w + x;
            if !mask[i] || covered[i] {
                continue;
            }
            // grow right
            let mut x1 = x;
            while x1 + 1 < w && mask[y * w + x1 + 1] && !covered[y * w + x1 + 1] {
                x1 += 1;
            }
            // grow down while the whole row segment is free & masked
            let seg = x1 - x + 1;
            let mut y1 = y;
            'grow: while y1 + 1 < h {
                for k in 0..seg {
                    let j = (y1 + 1) * w + x + k;
                    if !mask[j] || covered[j] {
                        break 'grow;
                    }
                }
                y1 += 1;
            }
            // commit
            for yy in y..=y1 {
                for xx in x..=x1 {
                    covered[yy * w + xx] = true;
                }
            }
            out.push(PgxRect {
                x: x as u16,
                y: y as u16,
                w: (x1 - x + 1) as u16,
                h: (y1 - y + 1) as u16,
                color,
            });
            // continue the scan (the 'x label lets us skip to the next seed)
            continue 'x;
        }
    }
}

/// Try the PGX promotion on a surface. None when the sprite is not flat-art:
/// more than MAX_COLORS exact colors, or the cover explodes past MAX_RECTS
/// (gradients and photos decompose into thousands of slivers — they belong
/// to the palette/block paths).
pub fn try_cover(s: &Surface) -> Option<PgxBlob> {
    // exact palette, first-appearance order (deterministic)
    let mut palette: Vec<[u8; 4]> = Vec::new();
    let mut idx_of = std::collections::HashMap::new();
    let mut indices = vec![0u8; (s.w * s.h) as usize];
    for i in 0..(s.w * s.h) as usize {
        let x = (i % s.w as usize) as u32;
        let y = (i / s.w as usize) as u32;
        let p = s.px(x, y);
        let key = [p.r, p.g, p.b, p.a];
        let at = match idx_of.get(&key) {
            Some(&at) => at,
            None => {
                let at = palette.len();
                palette.push(key);
                idx_of.insert(key, at);
                at
            }
        };
        indices[i] = at as u8;
    }
    if palette.len() > MAX_COLORS {
        return None;
    }
    let w = s.w as usize;
    let h = s.h as usize;
    let mut rects = Vec::new();
    for c in 0..palette.len() {
        // fully-transparent black pixels are "no quad" — the decoder leaves
        // uncovered pixels at (0,0,0,0), so the background costs ZERO rects
        // (this is the whole point for sprites living on big canvases)
        if palette[c] == [0, 0, 0, 0] {
            continue;
        }
        let mask: Vec<bool> = indices.iter().map(|&i| i == c as u8).collect();
        cover_mask(&mask, w, h, c as u8, &mut rects);
    }
    if rects.len() > MAX_RECTS {
        return None;
    }
    // pixel-exactness is verified by the caller through decode_payload();
    // the greedy cover is exact by construction (each masked cell is covered
    // by its own color's rect exactly once), but we verify anyway — the
    // discipline is the product.
    Some(PgxBlob { palette, rects })
}

/// Bytes the PGX1 section costs (header + palette + rects).
pub fn bytes_of(blob: &PgxBlob) -> usize {
    2 + 2 + 2 + blob.palette.len() * 4 + 2 + blob.rects.len() * 7
}

/// Serialize to the PGX1 section payload.
pub fn emit(blob: &PgxBlob, w: u32, h: u32) -> Vec<u8> {
    let mut o = Vec::with_capacity(bytes_of(blob));
    o.extend_from_slice(&(w as u16).to_le_bytes());
    o.extend_from_slice(&(h as u16).to_le_bytes());
    o.extend_from_slice(&(blob.palette.len() as u16).to_le_bytes());
    for c in &blob.palette {
        o.extend_from_slice(c);
    }
    o.extend_from_slice(&(blob.rects.len() as u16).to_le_bytes());
    for r in &blob.rects {
        o.extend_from_slice(&r.x.to_le_bytes());
        o.extend_from_slice(&r.y.to_le_bytes());
        o.extend_from_slice(&r.w.to_le_bytes());
        o.extend_from_slice(&r.h.to_le_bytes());
        o.push(r.color);
    }
    o
}

/// Decode a PGX1 payload back to a surface (uncovered pixels are transparent
/// black). This is the REFERENCE decoder — the same bytes the host consumes.
pub fn decode_payload(payload: &[u8]) -> Result<Surface, String> {
    let rd16 = |p: usize| -> Result<u16, String> {
        payload
            .get(p..p + 2)
            .map(|b| u16::from_le_bytes([b[0], b[1]]))
            .ok_or_else(|| "pgx: truncated".to_string())
    };
    let w = rd16(0)? as u32;
    let h = rd16(2)? as u32;
    let pal_len = rd16(4)? as usize;
    if payload.len() < 6 + pal_len * 4 + 2 {
        return Err("pgx: truncated palette".into());
    }
    let mut pal = Vec::with_capacity(pal_len);
    for i in 0..pal_len {
        let p = 6 + i * 4;
        pal.push([payload[p], payload[p + 1], payload[p + 2], payload[p + 3]]);
    }
    let mut q = 6 + pal_len * 4;
    let n = rd16(q)? as usize;
    q += 2;
    let mut surf = Surface::new(w, h);
    for _ in 0..n {
        if q + 9 > payload.len() {
            return Err("pgx: truncated rect".into());
        }
        let x = rd16(q)? as u32;
        let y = rd16(q + 2)? as u32;
        let rw = rd16(q + 4)? as u32;
        let rh = rd16(q + 6)? as u32;
        let color = payload[q + 8] as usize;
        q += 9;
        if color >= pal.len() || x + rw > w || y + rh > h {
            return Err("pgx: rect out of bounds or bad color".into());
        }
        let c = pal[color];
        for yy in y..y + rh {
            for xx in x..x + rw {
                let i = (yy * w + xx) as usize * 4;
                surf.rgba[i] = c[0];
                surf.rgba[i + 1] = c[1];
                surf.rgba[i + 2] = c[2];
                surf.rgba[i + 3] = c[3];
            }
        }
    }
    Ok(surf)
}

// ---------------- tests ----------------

#[cfg(test)]
mod tests {
    use super::*;
    use crate::forge::img::Px;

    fn flat_sprite() -> Surface {
        // a 32x24 "ship": hull rect, stripe, two engine dots — flat arcade art
        let mut s = Surface::new(32, 24);
        for y in 10..18 {
            for x in 6..26 {
                s.set_px(x, y, Px { r: 0x66, g: 0xCC, b: 0xFF, a: 255 });
            }
        }
        for y in 12..16 {
            for x in 10..22 {
                s.set_px(x, y, Px { r: 0xFF, g: 0xD7, b: 0x00, a: 255 });
            }
        }
        s.set_px(8, 20, Px { r: 0xFF, g: 0x40, b: 0x40, a: 255 });
        s.set_px(22, 20, Px { r: 0xFF, g: 0x40, b: 0x40, a: 255 });
        s
    }

    #[test]
    fn cover_is_pixel_exact_roundtrip() {
        let s = flat_sprite();
        let blob = try_cover(&s).expect("flat sprite should cover");
        let payload = emit(&blob, s.w, s.h);
        let back = decode_payload(&payload).unwrap();
        assert_eq!(back.w, s.w);
        assert_eq!(back.h, s.h);
        for y in 0..s.h {
            for x in 0..s.w {
                assert_eq!(s.px(x, y), back.px(x, y), "pixel ({},{})", x, y);
            }
        }
    }

    #[test]
    fn flat_sprite_few_rects_tiny_bytes() {
        let s = flat_sprite();
        let blob = try_cover(&s).unwrap();
        // hull is a U around the stripe: greedy splits it (~13) + stripe + 2
        // dots — a realistic arcade silhouette, still small
        assert!(blob.rects.len() <= 18, "got {} rects", blob.rects.len());
        assert_eq!(blob.palette.len(), 4); // blue, yellow, red, transparent
        // PGX bytes vs a palette4 encoding of the same sprite
        let pgx = bytes_of(&blob);
        let pal_bytes = 2 + 2 + 3 * 4 + ((s.w as usize * s.h as usize + 1) / 2); // 4bpp indices
        assert!(pgx < pal_bytes, "pgx {} vs palette {}", pgx, pal_bytes);
        // and vs BC7 (1 byte per pixel): 32x24 = 768
        assert!(pgx < 768);
    }

    #[test]
    fn photo_ish_noise_rejects() {
        // many colors -> None (belongs to the block/palette paths)
        let mut s = Surface::new(64, 64);
        let mut v = 12345u32;
        for y in 0..64 {
            for x in 0..64 {
                v = v.wrapping_mul(1664525).wrapping_add(1013904223);
                s.set_px(x, y, Px {
                    r: (v >> 16) as u8,
                    g: (v >> 8) as u8,
                    b: v as u8,
                    a: 255,
                });
            }
        }
        assert!(try_cover(&s).is_none());
    }

    #[test]
    fn transparent_regions_are_free() {
        // a sprite that is mostly transparency: rects only where pixels are
        let mut s = Surface::new(64, 64);
        for y in 30..34 {
            for x in 2..62 {
                s.set_px(x, y, Px { r: 0, g: 255, b: 0, a: 255 });
            }
        }
        let blob = try_cover(&s).unwrap();
        assert_eq!(blob.rects.len(), 1);
        // header 6 + palette 2x4 (green + transparent) + count 2 + 1 rect x 7
        assert_eq!(bytes_of(&blob), 6 + 8 + 2 + 7);
    }

    #[test]
    fn emit_decode_rejects_truncation() {
        let s = flat_sprite();
        let blob = try_cover(&s).unwrap();
        let payload = emit(&blob, s.w, s.h);
        assert!(decode_payload(&payload[..payload.len() - 1]).is_err());
        assert!(decode_payload(b"nope").is_err());
    }

    #[test]
    fn stripes_stay_reasonable() {
        // 16 vertical stripes = 16 rects — fine for PGX
        let mut s = Surface::new(32, 8);
        for x in 0..32 {
            let c = (x / 2) as u8;
            for y in 0..8 {
                s.set_px(x, y, Px { r: c, g: c, b: c, a: 255 });
            }
        }
        let blob = try_cover(&s).unwrap();
        assert_eq!(blob.rects.len(), 16);
        let back = decode_payload(&emit(&blob, s.w, s.h)).unwrap();
        for y in 0..8 {
            for x in 0..32 {
                assert_eq!(s.px(x, y), back.px(x, y));
            }
        }
    }
}
