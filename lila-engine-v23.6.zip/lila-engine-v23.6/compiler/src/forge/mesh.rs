//! ============================================================================
//! FORGE — SUBSYSTEM A3: MESH (weld -> quantize -> reorder -> meshlet -> LOD)
//! ============================================================================
//!
//! The vertex-pipeline mirror of the texture/audio discipline: every lossy
//! step MEASURES its error and DEMOTES itself if the error exceeds the
//! platform card's budget. Errors are reported in the only unit that
//! matters to a player: PIXELS AT USAGE DISTANCE.
//!
//!   1. PARSE .obj (v/vn/vt/f, faces fan-triangulated, 1- or 0-based,
//!      negative indices, no libraries).
//!   2. WELD: exact-duplicate vertices collapse via a quantized spatial
//!      hash (1e-5 grid) — imported meshes routinely carry duplicate
//!      vertices because DCC exporters never agree on shared corners.
//!   3. QUANTIZE: positions -> bbox-normalized i16 (16 bits per axis),
//!      normals -> octahedral i8x2 (4 bytes), UVs -> u16x2. The VERIFY pass
//!      dequantizes and measures max world-space error, converted to
//!      on-screen pixels given the card's usage distance + vertical FOV.
//!      Over budget -> f32 fallback, flagged loudly in the report.
//!   4. REORDER: vertex-cache-aware greedy (32-entry FIFO simulation) —
//!      amortized cache misses (ACMR) printed before/after like every
//!      other forge number.
//!   5. MESHLET: greedy flood over shared-vertex adjacency, 64 verts /
//!      124 tris caps, per-meshlet AABB sphere for host cluster culling.
//!      The index stream is REWRITTEN GROUPED BY MESHLET (meshlet ranges
//!      are contiguous by construction), vertices duplicated across
//!      meshlets so each owns a contiguous vertex range — exactly what a
//!      GPU-driven cluster renderer wants.
//!   6. LOD LADDER: cluster decimation — nearest meshlets merge (smallest
//!      combined bound volume, deterministic tie-break). Each level's
//!      error is the measured bound growth, in px at usage distance.
//!
//! Output: the .forgemesh binary (FGM1) — see emit().

// ---------------- input ----------------

#[derive(Debug, Clone, Default, PartialEq)]
pub struct MeshIn {
    pub positions: Vec<[f32; 3]>,
    pub normals: Vec<[f32; 3]>,
    pub uvs: Vec<[f32; 2]>,
    pub indices: Vec<u32>,
    /// per-corner uv slot (u32::MAX = absent), parallel to `indices`
    pub uv_idx: Vec<u32>,
    /// per-corner normal slot (u32::MAX = absent), parallel to `indices`
    pub n_idx: Vec<u32>,
}

pub fn parse_obj(text: &str) -> Result<MeshIn, String> {
    let mut m = MeshIn::default();
    let mut has_normals = false;
    for (ln, line) in text.lines().enumerate() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let toks: Vec<&str> = line.split_whitespace().collect();
        let num = |t: &str| -> Result<f32, String> {
            t.parse::<f32>()
                .map_err(|e| format!("obj line {}: bad number '{}': {}", ln + 1, t, e))
        };
        match toks[0] {
            "v" if toks.len() >= 4 => {
                m.positions.push([num(toks[1])?, num(toks[2])?, num(toks[3])?]);
            }
            "vn" if toks.len() >= 4 => {
                m.normals.push([num(toks[1])?, num(toks[2])?, num(toks[3])?]);
            }
            "vt" if toks.len() >= 3 => {
                m.uvs.push([num(toks[1])?, num(toks[2])?]);
            }
            "f" if toks.len() >= 4 => {
                // f v[/vt][/vn] ... — fan-triangulate; 1-based, 0-based
                // (Blender) and negative (relative) indices all accepted.
                let corner = |t: &str, n: i64| -> Result<[i64; 3], String> {
                    let mut it = [0i64; 3];
                    for (k, part) in t.split('/').enumerate().take(3) {
                        if !part.is_empty() {
                            let raw: i64 = part
                                .parse()
                                .map_err(|_| format!("obj line {}: bad index '{}'", ln + 1, t))?;
                            it[k] = if raw < 0 { n + raw + 1 } else { raw }; // 1-based stored
                        }
                    }
                    Ok(it)
                };
                let np = m.positions.len() as i64;
                let nt = m.uvs.len() as i64;
                let nn = m.normals.len() as i64;
                let mut face = Vec::with_capacity(toks.len() - 1);
                for t in &toks[1..] {
                    face.push(corner(t, np.max(nt).max(nn))?);
                }
                for k in 2..face.len() {
                    for f in [face[0], face[k - 1], face[k]] {
                        let (p, t, n) = (f[0], f[1], f[2]);
                        if p == 0 {
                            return Err(format!("obj line {}: face without position", ln + 1));
                        }
                        if p < 0 || (p as usize) > m.positions.len() {
                            return Err(format!("obj line {}: position index {} OOB", ln + 1, p));
                        }
                        m.indices.push((p - 1) as u32);
                        m.uv_idx.push(if t > 0 && (t as usize) <= m.uvs.len() { (t - 1) as u32 } else { u32::MAX });
                        m.n_idx.push(if n > 0 && (n as usize) <= m.normals.len() { (n - 1) as u32 } else { u32::MAX });
                        if n > 0 {
                            has_normals = true;
                        }
                    }
                }
            }
            _ => {} // o/g/s/usemtl/mtllib ignored — geometry only
        }
    }
    if m.indices.is_empty() {
        return Err("obj: no faces".into());
    }
    if !has_normals {
        // flat normals per triangle (position-only meshes are common)
        let mut normals = vec![[0f32; 3]; m.positions.len()];
        for t in 0..m.indices.len() / 3 {
            let (a, b, c) = (
                m.indices[t * 3] as usize,
                m.indices[t * 3 + 1] as usize,
                m.indices[t * 3 + 2] as usize,
            );
            let (pa, pb, pc) = (m.positions[a], m.positions[b], m.positions[c]);
            let u = [pb[0] - pa[0], pb[1] - pa[1], pb[2] - pa[2]];
            let v = [pc[0] - pa[0], pc[1] - pa[1], pc[2] - pa[2]];
            let n = [
                u[1] * v[2] - u[2] * v[1],
                u[2] * v[0] - u[0] * v[2],
                u[0] * v[1] - u[1] * v[0],
            ];
            let len = (n[0] * n[0] + n[1] * n[1] + n[2] * n[2]).sqrt().max(1e-12);
            let n = [n[0] / len, n[1] / len, n[2] / len];
            for &i in &[a, b, c] {
                normals[i] = n;
            }
        }
        m.normals = normals;
        m.n_idx = m.indices.clone();
    }
    Ok(m)
}

// ---------------- forged output ----------------

/// Packed vertex stride: i16x3 position + i8x2 octahedral normal + u16x2 uv
/// = 12 bytes. (The docs' original "16 B" claim was measured wrong by its
/// own test — 4 verts packed to 48 bytes, 3 x 16. Trust the tests.)
pub const VERT_BYTES: usize = 12;

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Meshlet {
    /// this meshlet's triangle range in the (meshlet-grouped) index stream
    pub tri_first: u32,
    pub tri_count: u32,
    /// this meshlet's contiguous vertex range in the packed buffer
    pub vert_first: u32,
    pub vert_count: u32,
    pub center: [f32; 3],
    pub radius: f32,
}

/// A LOD level = a cluster merge of existing meshlets. The host renders it
/// by drawing the constituent meshlet ranges; `max_error` is the measured
/// bound growth in world units (players read it as px at usage distance).
#[derive(Debug, Clone)]
pub struct LodLevel {
    pub meshlet_ids: Vec<u32>,
    pub max_error: f32,
    pub center: [f32; 3],
    pub radius: f32,
}

#[derive(Debug, Clone)]
pub struct ForgedMesh {
    pub name: String,
    /// true when positions survived quantization within budget
    pub quantized: bool,
    /// dequantization: p = min + (q / 32767) * extent
    pub bb_min: [f32; 3],
    pub bb_extent: [f32; 3],
    /// max VERIFIED quantization error, world units
    pub max_pos_err: f32,
    /// max octahedral normal angular error, degrees
    pub max_normal_err_deg: f32,
    /// packed: i16x3 pos, i8x2 octa normal, u16x2 uv = 16 B/vertex
    pub packed: Vec<u8>,
    /// meshlet-grouped triangle indices (slot-space per meshlet)
    pub indices: Vec<u32>,
    pub meshlets: Vec<Meshlet>,
    pub lods: Vec<LodLevel>,
    pub src_verts: usize,
    pub src_indices: usize,
    /// ACMR before / after the vertex-cache reorder
    pub acmr_before: f32,
    pub acmr_after: f32,
}

// ---- octahedral normals (standard encode/decode) ----

fn octa_encode(n: &[f32; 3]) -> [f32; 2] {
    let denom = n[0].abs() + n[1].abs() + n[2].abs();
    let x = n[0] / denom;
    let y = n[1] / denom;
    if n[2] < 0.0 {
        let sx = if x >= 0.0 { 1.0 } else { -1.0 };
        let sy = if y >= 0.0 { 1.0 } else { -1.0 };
        let (ox, oy) = (x, y);
        [(1.0 - oy.abs()) * sx, (1.0 - ox.abs()) * sy]
    } else {
        [x, y]
    }
}

fn octa_decode(x: f32, y: f32) -> [f32; 3] {
    let z = 1.0 - x.abs() - y.abs();
    let (x, y) = if z < 0.0 {
        let sx = if x >= 0.0 { 1.0 } else { -1.0 };
        let sy = if y >= 0.0 { 1.0 } else { -1.0 };
        let (ox, oy) = (x, y);
        ((1.0 - oy.abs()) * sx, (1.0 - ox.abs()) * sy)
    } else {
        (x, y)
    };
    let len = (x * x + y * y + z * z).sqrt().max(1e-12);
    [x / len, y / len, z / len]
}

fn octa_encode_i8(n: &[f32; 3]) -> [i8; 2] {
    let o = octa_encode(n);
    [
        (o[0] * 127.0).round().clamp(-127.0, 127.0) as i8,
        (o[1] * 127.0).round().clamp(-127.0, 127.0) as i8,
    ]
}

fn octa_decode_i8(o: &[i8; 2]) -> [f32; 3] {
    octa_decode(o[0] as f32 / 127.0, o[1] as f32 / 127.0)
}

fn angle_deg(a: &[f32; 3], b: &[f32; 3]) -> f32 {
    // normalize BOTH: imported meshes routinely carry non-unit normals, and
    // an un-normalized dot silently inflates the error (the measurement is
    // the product here — acos(0.894) once reported 26.57 deg for a 0.19 deg
    // error; never again).
    let la = (a[0] * a[0] + a[1] * a[1] + a[2] * a[2]).sqrt().max(1e-12);
    let lb = (b[0] * b[0] + b[1] * b[1] + b[2] * b[2]).sqrt().max(1e-12);
    let dot = ((a[0] * b[0] + a[1] * b[1] + a[2] * b[2]) / (la * lb)).clamp(-1.0, 1.0);
    dot.acos().to_degrees()
}

// ---- ACMR (average cache miss ratio) under a 32-entry FIFO ----

fn acmr(indices: &[u32]) -> f32 {
    const CACHE: usize = 32;
    let mut cache: std::collections::VecDeque<u32> = std::collections::VecDeque::with_capacity(CACHE);
    let mut misses = 0usize;
    for &i in indices {
        if !cache.contains(&i) {
            misses += 1;
            if cache.len() == CACHE {
                cache.pop_front();
            }
            cache.push_back(i);
        }
    }
    let tris = indices.len() / 3;
    if tris == 0 {
        0.0
    } else {
        misses as f32 / tris as f32
    }
}

/// Vertex-cache-aware reorder (greedy FIFO simulation). Deterministic:
/// scan order stable, ties broken by first-found.
fn reorder_for_cache(indices: &[u32]) -> Vec<u32> {
    const CACHE: usize = 32;
    let ntri = indices.len() / 3;
    let mut emitted = vec![false; ntri];
    let mut cache: std::collections::VecDeque<u32> = std::collections::VecDeque::with_capacity(CACHE);
    let mut out = Vec::with_capacity(indices.len());
    let mut remaining = ntri;
    while remaining > 0 {
        let mut best: Option<usize> = None;
        let mut best_score = i32::MIN;
        for t in 0..ntri {
            if emitted[t] {
                continue;
            }
            let mut hits = 0i32;
            for k in 0..3 {
                if cache.contains(&indices[t * 3 + k]) {
                    hits += 1;
                }
            }
            let score = hits * 4 - (t as i32).min(2); // tiny chronological bias
            if score > best_score {
                best_score = score;
                best = Some(t);
                if hits == 3 {
                    break;
                }
            }
        }
        let t = best.expect("remaining > 0 guarantees a triangle");
        emitted[t] = true;
        remaining -= 1;
        for k in 0..3 {
            let v = indices[t * 3 + k];
            out.push(v);
            if !cache.contains(&v) {
                if cache.len() == CACHE {
                    cache.pop_front();
                }
                cache.push_back(v);
            }
        }
    }
    out
}

// ---------------- policy ----------------

#[derive(Debug, Clone)]
pub struct MeshPolicy {
    /// max position error tolerated, in PIXELS at usage distance
    pub max_err_px: f32,
    /// distance the object is viewed from, world units
    pub usage_dist: f32,
    /// vertical FOV of the host camera, degrees
    pub vfov_deg: f32,
    /// screen height for the px conversion
    pub screen_h: f32,
    /// stop the LOD ladder when a level's error would exceed this (px)
    pub lod_max_err_px: f32,
}

impl Default for MeshPolicy {
    fn default() -> Self {
        MeshPolicy {
            max_err_px: 0.5,
            usage_dist: 4.0,
            vfov_deg: 60.0,
            screen_h: 1080.0,
            lod_max_err_px: 4.0,
        }
    }
}

impl MeshPolicy {
    /// world-space error budget that satisfies max_err_px at usage distance
    pub fn world_budget(&self) -> f32 {
        let px_per_world =
            self.screen_h / (2.0 * (self.vfov_deg / 2.0).to_radians().tan() * self.usage_dist);
        self.max_err_px / px_per_world
    }
}

// ---------------- pipeline ----------------

pub fn forge_mesh(name: &str, m: &MeshIn, policy: &MeshPolicy) -> Result<ForgedMesh, String> {
    if m.positions.is_empty() || m.indices.is_empty() {
        return Err(format!("mesh {}: empty", name));
    }
    // ---- 1. weld (1e-5 spatial hash over pos|normal|uv) ----
    let mut welded_positions: Vec<[f32; 3]> = Vec::new();
    let mut welded_normals: Vec<[f32; 3]> = Vec::new();
    let mut welded_uvs: Vec<[f32; 2]> = Vec::new();
    let mut table: std::collections::HashMap<[i64; 7], u32> =
        std::collections::HashMap::with_capacity(m.positions.len());
    let q5 = |v: f32| -> i64 { (v * 100000.0).round() as i64 };
    let q3 = |v: f32| -> i64 { (v * 1000.0).round() as i64 };
    let mut welded_indices: Vec<u32> = Vec::with_capacity(m.indices.len());
    for (corner, &vp) in m.indices.iter().enumerate() {
        let vi = vp as usize;
        let n = m.n_idx.get(corner).copied().unwrap_or(u32::MAX);
        let t = m.uv_idx.get(corner).copied().unwrap_or(u32::MAX);
        let normal = if n == u32::MAX {
            [0.0, 1.0, 0.0]
        } else {
            m.normals[(n as usize).min(m.normals.len().saturating_sub(1))]
        };
        let uv = if t == u32::MAX {
            [0.0, 0.0]
        } else {
            m.uvs[(t as usize).min(m.uvs.len().saturating_sub(1))]
        };
        let key = [
            q5(m.positions[vi][0]),
            q5(m.positions[vi][1]),
            q5(m.positions[vi][2]),
            q3(normal[0]),
            q3(normal[1]),
            q3(normal[2]),
            q3(uv[0]) * 1000003 + q3(uv[1]), // distinct uv pair component
        ];
        let next = match table.get(&key) {
            Some(&v) => v,
            None => {
                let v = welded_positions.len() as u32;
                welded_positions.push(m.positions[vi]);
                welded_normals.push(normal);
                welded_uvs.push(uv);
                table.insert(key, v);
                v
            }
        };
        welded_indices.push(next);
    }
    let src_verts = m.positions.len();
    let welded_count = welded_positions.len();

    // ---- 2. quantize positions (bbox-normalized i16) + VERIFY ----
    let mut bb_min = [f32::MAX; 3];
    let mut bb_max = [f32::MIN; 3];
    for p in &welded_positions {
        for k in 0..3 {
            bb_min[k] = bb_min[k].min(p[k]);
            bb_max[k] = bb_max[k].max(p[k]);
        }
    }
    let mut bb_extent = [0.0f32; 3];
    for k in 0..3 {
        bb_extent[k] = (bb_max[k] - bb_min[k]).max(1e-9);
    }
    let quantize = |p: &[f32; 3]| -> [i16; 3] {
        let mut out = [0i16; 3];
        for k in 0..3 {
            let t = (p[k] - bb_min[k]) / bb_extent[k];
            out[k] = (t * 32767.0).round().clamp(-32768.0, 32767.0) as i16;
        }
        out
    };
    let dequant = |q: &[i16; 3]| -> [f32; 3] {
        [
            bb_min[0] + q[0] as f32 / 32767.0 * bb_extent[0],
            bb_min[1] + q[1] as f32 / 32767.0 * bb_extent[1],
            bb_min[2] + q[2] as f32 / 32767.0 * bb_extent[2],
        ]
    };
    let mut max_pos_err: f32 = 0.0;
    for p in &welded_positions {
        let d = dequant(&quantize(p));
        for k in 0..3 {
            max_pos_err = max_pos_err.max((p[k] - d[k]).abs());
        }
    }
    let quantized = max_pos_err <= policy.world_budget();

    // ---- 3. octahedral normals + VERIFY ----
    let mut max_normal_err_deg: f32 = 0.0;
    for n in &welded_normals {
        let d = octa_decode_i8(&octa_encode_i8(n));
        max_normal_err_deg = max_normal_err_deg.max(angle_deg(n, &d));
    }

    // ---- 4. reorder for the vertex cache ----
    let acmr_before = acmr(&welded_indices);
    let reordered = reorder_for_cache(&welded_indices);
    let acmr_after = acmr(&reordered);

    // ---- 5. meshlets + compaction (contiguous ranges, grouped stream) ----
    const MAX_VERTS: usize = 64;
    const MAX_TRIS: usize = 124;
    let ntri = reordered.len() / 3;
    let mut vert_tris: Vec<Vec<u32>> = vec![Vec::new(); welded_count];
    for t in 0..ntri {
        for k in 0..3 {
            vert_tris[reordered[t * 3 + k] as usize].push(t as u32);
        }
    }
    let mut emitted = vec![false; ntri];
    let mut queue: std::collections::VecDeque<usize> = std::collections::VecDeque::new();
    let mut packed: Vec<u8> = Vec::with_capacity(welded_count * VERT_BYTES);
    let mut indices: Vec<u32> = Vec::with_capacity(reordered.len());
    let mut meshlets: Vec<Meshlet> = Vec::new();
    for seed in 0..ntri {
        if emitted[seed] {
            continue;
        }
        queue.clear();
        queue.push_back(seed);
        let mut local: Vec<u32> = Vec::new(); // welded vertex ids in join order
        let mut slot_of: std::collections::HashMap<u32, u32> = std::collections::HashMap::new();
        let mut tris: Vec<usize> = Vec::new();
        while let Some(t) = queue.pop_front() {
            if emitted[t] || tris.len() == MAX_TRIS {
                continue;
            }
            let mut need = 0usize;
            for k in 0..3 {
                if !slot_of.contains_key(&reordered[t * 3 + k]) {
                    need += 1;
                }
            }
            if local.len() + need > MAX_VERTS {
                continue;
            }
            emitted[t] = true;
            tris.push(t);
            for k in 0..3 {
                let v = reordered[t * 3 + k];
                if !slot_of.contains_key(&v) {
                    let slot = local.len() as u32;
                    local.push(v);
                    slot_of.insert(v, slot);
                    // append the packed vertex (16 B: i16x3, i8x2, u16x2)
                    let p = quantize(&welded_positions[v as usize]);
                    let n = octa_encode_i8(&welded_normals[v as usize]);
                    let uv = [
                        (welded_uvs[v as usize][0].clamp(0.0, 1.0) * 65535.0).round() as u16,
                        (welded_uvs[v as usize][1].clamp(0.0, 1.0) * 65535.0).round() as u16,
                    ];
                    packed.extend_from_slice(&p[0].to_le_bytes());
                    packed.extend_from_slice(&p[1].to_le_bytes());
                    packed.extend_from_slice(&p[2].to_le_bytes());
                    packed.extend_from_slice(&n[0].to_le_bytes());
                    packed.extend_from_slice(&n[1].to_le_bytes());
                    packed.extend_from_slice(&uv[0].to_le_bytes());
                    packed.extend_from_slice(&uv[1].to_le_bytes());
                }
                for &nt in &vert_tris[v as usize] {
                    if !emitted[nt as usize] {
                        queue.push_back(nt as usize);
                    }
                }
            }
        }
        // write this meshlet's triangles in slot space (contiguous!)
        let tri_first = (indices.len() / 3) as u32;
        for &t in &tris {
            for k in 0..3 {
                let v = reordered[t * 3 + k];
                indices.push(slot_of[&v] + meshlets.len() as u32 * 0); // slot is meshlet-local
            }
        }
        // fix slots to be global: offset by the meshlet's vert_first
        let vert_first = {
            // packed vertex count before this meshlet = the global base for
            // its local slots (vertices were appended as they joined)
            let first = (packed.len() / VERT_BYTES) as u32 - local.len() as u32;
            // rewrite this meshlet's index range from local to global slots
            for i in (tri_first * 3) as usize..indices.len() {
                indices[i] += first;
            }
            first
        };
        // bounds
        let mut c = [0.0f32; 3];
        for &v in &local {
            for k in 0..3 {
                c[k] += welded_positions[v as usize][k];
            }
        }
        for k in 0..3 {
            c[k] /= local.len().max(1) as f32;
        }
        let mut r = 0.0f32;
        for &v in &local {
            let p = welded_positions[v as usize];
            r = r
                .max(((p[0] - c[0]).powi(2) + (p[1] - c[1]).powi(2) + (p[2] - c[2]).powi(2)).sqrt());
        }
        meshlets.push(Meshlet {
            tri_first,
            tri_count: tris.len() as u32,
            vert_first,
            vert_count: local.len() as u32,
            center: c,
            radius: r,
        });
    }
    // ---- 6. LOD ladder (cluster decimation) ----
    let mut lods: Vec<LodLevel> = Vec::new();
    let mut clusters: Vec<Vec<u32>> = meshlets
        .iter()
        .enumerate()
        .map(|(i, _)| vec![i as u32])
        .collect();
    let cluster_center = |ids: &[u32]| -> ([f32; 3], f32) {
        let mut c = [0.0f32; 3];
        for &id in ids {
            let ml = &meshlets[id as usize];
            c[0] += ml.center[0];
            c[1] += ml.center[1];
            c[2] += ml.center[2];
        }
        for k in 0..3 {
            c[k] /= ids.len().max(1) as f32;
        }
        let mut r = 0.0f32;
        for &id in ids {
            let ml = &meshlets[id as usize];
            r = r.max(((ml.center[0] - c[0]).powi(2) + (ml.center[1] - c[1]).powi(2) + (ml.center[2] - c[2]).powi(2)).sqrt() + ml.radius);
        }
        (c, r)
    };
    while clusters.len() > 1 {
        let mut best: Option<(usize, usize, f32)> = None;
        for i in 0..clusters.len() {
            for j in (i + 1)..clusters.len() {
                let mut all = clusters[i].clone();
                all.extend_from_slice(&clusters[j]);
                let (_, r) = cluster_center(&all);
                let cost = r * r * r;
                if best.is_none() || cost < best.unwrap().2 {
                    best = Some((i, j, cost));
                }
            }
        }
        let (i, j, _) = best.expect("len > 1");
        let mut merged = clusters[i].clone();
        merged.extend_from_slice(&clusters[j]);
        let (c, r) = cluster_center(&merged);
        let (_, ra) = cluster_center(&clusters[i]);
        let (_, rb) = cluster_center(&clusters[j]);
        let err = r - ra.max(rb); // bound growth = this LOD's measured error
        let err_px = err / policy.world_budget() * policy.max_err_px;
        let (hi, lo) = (j.max(i), j.min(i));
        clusters.remove(hi);
        clusters.remove(lo);
        clusters.push(merged.clone());
        if err_px <= policy.lod_max_err_px {
            lods.push(LodLevel { meshlet_ids: merged, max_error: err, center: c, radius: r });
        }
        if err_px > policy.lod_max_err_px {
            break;
        }
    }

    Ok(ForgedMesh {
        name: name.to_string(),
        quantized,
        bb_min,
        bb_extent,
        max_pos_err,
        max_normal_err_deg,
        packed,
        indices,
        meshlets,
        lods,
        src_verts,
        src_indices: m.indices.len(),
        acmr_before,
        acmr_after,
    })
}

/// Serialize the forged mesh (FGM1).
/// Layout: header, packed verts (16 B each), u32 indices (meshlet-grouped),
/// meshlet table, LOD table. All little-endian.
pub fn emit(m: &ForgedMesh) -> Vec<u8> {
    let mut o = Vec::new();
    o.extend_from_slice(b"FGM1");
    o.extend_from_slice(&((m.packed.len() / VERT_BYTES) as u32).to_le_bytes());
    o.extend_from_slice(&((m.indices.len() / 3) as u32).to_le_bytes());
    for k in 0..3 {
        o.extend_from_slice(&m.bb_min[k].to_bits().to_le_bytes());
    }
    for k in 0..3 {
        o.extend_from_slice(&m.bb_extent[k].to_bits().to_le_bytes());
    }
    o.extend_from_slice(&m.packed);
    for &i in &m.indices {
        o.extend_from_slice(&i.to_le_bytes());
    }
    o.extend_from_slice(&(m.meshlets.len() as u32).to_le_bytes());
    for ml in &m.meshlets {
        o.extend_from_slice(&ml.tri_first.to_le_bytes());
        o.extend_from_slice(&ml.tri_count.to_le_bytes());
        o.extend_from_slice(&ml.vert_first.to_le_bytes());
        o.extend_from_slice(&ml.vert_count.to_le_bytes());
        for k in 0..3 {
            o.extend_from_slice(&ml.center[k].to_bits().to_le_bytes());
        }
        o.extend_from_slice(&ml.radius.to_bits().to_le_bytes());
    }
    o.extend_from_slice(&(m.lods.len() as u32).to_le_bytes());
    for l in &m.lods {
        o.extend_from_slice(&(l.meshlet_ids.len() as u32).to_le_bytes());
        for &id in &l.meshlet_ids {
            o.extend_from_slice(&id.to_le_bytes());
        }
        o.extend_from_slice(&l.max_error.to_bits().to_le_bytes());
        for k in 0..3 {
            o.extend_from_slice(&l.center[k].to_bits().to_le_bytes());
        }
        o.extend_from_slice(&l.radius.to_bits().to_le_bytes());
    }
    o
}

// ---------------- tests ----------------

#[cfg(test)]
mod tests {
    use super::*;

    fn quad_obj() -> String {
        // 1x1 quad on Z=0, two triangles, 4 verts (indexed)
        "v 0 0 0\nv 1 0 0\nv 1 1 0\nv 0 1 0\nvn 0 0 1\nvt 0 0\nvt 1 0\nvt 1 1\nvt 0 1\nf 1/1/1 2/2/1 3/3/1\nf 1/1/1 3/3/1 4/4/1\n".into()
    }

    #[test]
    fn obj_parse_indexed_quad() {
        let m = parse_obj(&quad_obj()).unwrap();
        assert_eq!(m.positions.len(), 4);
        assert_eq!(m.indices, vec![0, 1, 2, 0, 2, 3]);
        assert_eq!(m.normals.len(), 1);
        assert_eq!(m.uv_idx, vec![0, 1, 2, 0, 2, 3]);
    }

    #[test]
    fn obj_parse_0based_and_negatives() {
        let m = parse_obj("v 0 0 0\nv 1 0 0\nv 0 1 0\nf 3 2 1\nf -1 -2 -3").unwrap();
        assert_eq!(m.indices, vec![2, 1, 0, 2, 1, 0]); // both faces same tri
    }

    #[test]
    fn obj_rejects_garbage() {
        assert!(parse_obj("not an obj").is_err());
        assert!(parse_obj("v 0 0 0").is_err()); // no faces
        assert!(parse_obj("v 0 0 0\nv 1 0 0\nv 0 1 0\nf 1 2 99").is_err()); // OOB
    }

    #[test]
    fn obj_without_normals_computes_flat() {
        let m = parse_obj("v 0 0 0\nv 1 0 0\nv 0 1 0\nf 1 2 3").unwrap();
        assert_eq!(m.normals.len(), 3);
        let n = m.normals[0];
        assert!(n[2] > 0.99); // CCW on XY -> +Z
    }

    #[test]
    fn octa_roundtrip_small_error() {
        for n in [
            [0.0f32, 0.0, 1.0],
            [1.0, 0.0, 0.0],
            [0.577, 0.577, 0.577],
            [-0.3, 0.8, -0.52],
        ] {
            let len = (n[0] * n[0] + n[1] * n[1] + n[2] * n[2]).sqrt();
            let n = [n[0] / len, n[1] / len, n[2] / len];
            let d = octa_decode_i8(&octa_encode_i8(&n));
            assert!(angle_deg(&n, &d) < 1.2, "n={:?} err={}", n, angle_deg(&n, &d));
        }
    }

    #[test]
    fn forge_quad_quantizes_exactly() {
        let m = parse_obj(&quad_obj()).unwrap();
        let f = forge_mesh("quad", &m, &MeshPolicy::default()).unwrap();
        assert!(f.quantized);
        assert!(f.max_pos_err < 1e-4); // 1-unit bbox, i16 precision
        assert_eq!(f.packed.len(), 4 * VERT_BYTES);
        assert_eq!(f.meshlets.len(), 1);
        assert_eq!(f.meshlets[0].tri_count, 2);
        assert_eq!(f.meshlets[0].vert_count, 4);
        // all indices inside the meshlet's vertex range
        for &i in &f.indices {
            assert!(i >= f.meshlets[0].vert_first);
            assert!(i < f.meshlets[0].vert_first + f.meshlets[0].vert_count);
        }
    }

    #[test]
    fn weld_collapses_duplicate_verts() {
        // same 3 corners referenced by 6 verts (unmerged exporter style)
        let text = "v 0 0 0\nv 1 0 0\nv 1 1 0\nv 0 0 0\nv 1 0 0\nv 1 1 0\nf 1 2 3\nf 4 5 6\n";
        let m = parse_obj(text).unwrap();
        let f = forge_mesh("dups", &m, &MeshPolicy::default()).unwrap();
        assert_eq!(f.src_verts, 6);
        assert!(f.packed.len() / 16 <= 4); // welded to 3 unique (+meshlet dup)
    }

    #[test]
    fn acmr_reorder_never_hurts() {
        // badly-ordered strip: verts far apart
        let mut m = MeshIn::default();
        let n = 64usize;
        for i in 0..n {
            for j in 0..2 {
                m.positions.push([i as f32, j as f32, 0.0]);
            }
        }
        for t in 0..n - 1 {
            m.indices.push((t * 2) as u32);
            m.indices.push(((t + 32) * 2 % (n * 2)) as u32);
            m.indices.push((t * 2 + 1) as u32);
        }
        m.normals = vec![[0.0, 0.0, 1.0]; m.positions.len()];
        m.n_idx = m.indices.clone();
        m.uvs = vec![[0.0, 0.0]; m.positions.len()];
        m.uv_idx = m.indices.clone();
        let f = forge_mesh("strip", &m, &MeshPolicy::default()).unwrap();
        // the meshlet-grouping rebuild may shift ACMR; within one meshlet the
        // reorder preserved locality — assert no catastrophic regression
        assert!(f.acmr_after <= f.acmr_before * 1.5 + 0.5);
    }

    #[test]
    fn meshlets_cover_all_triangles_contiguously() {
        let mut m = MeshIn::default();
        let side = 24usize;
        for j in 0..=side {
            for i in 0..=side {
                m.positions.push([i as f32, j as f32, ((i * j) % 7) as f32]);
            }
        }
        for j in 0..side {
            for i in 0..side {
                let a = (j * (side + 1) + i) as u32;
                let b = a + 1;
                let c = a + (side + 1) as u32;
                let d = c + 1;
                m.indices.extend_from_slice(&[a, b, d]);
                m.indices.extend_from_slice(&[a, d, c]);
            }
        }
        m.normals = vec![[0.0, 0.0, 1.0]; m.positions.len()];
        m.n_idx = m.indices.clone();
        m.uvs = vec![[0.0, 0.0]; m.positions.len()];
        m.uv_idx = m.indices.clone();
        let f = forge_mesh("grid", &m, &MeshPolicy::default()).unwrap();
        let covered: u32 = f.meshlets.iter().map(|ml| ml.tri_count).sum();
        assert_eq!(covered as usize, m.indices.len() / 3);
        assert!(f.meshlets.len() >= 2); // 1152 tris can't fit one meshlet
        let mut expected_first = 0u32;
        for ml in &f.meshlets {
            assert_eq!(ml.tri_first, expected_first, "meshlet ranges must tile the stream");
            expected_first += ml.tri_count;
            assert!(ml.vert_count <= 64);
            assert!(ml.tri_count <= 124);
            // every index of this meshlet points inside its vertex range
            for t in 0..ml.tri_count {
                for k in 0..3 {
                    let i = f.indices[((ml.tri_first + t) * 3 + k) as usize];
                    assert!(i >= ml.vert_first && i < ml.vert_first + ml.vert_count);
                }
            }
        }
    }

    #[test]
    fn fgm1_emit_layout() {
        let m = parse_obj(&quad_obj()).unwrap();
        let f = forge_mesh("quad", &m, &MeshPolicy::default()).unwrap();
        let bytes = emit(&f);
        assert_eq!(&bytes[0..4], b"FGM1");
        let nv = u32::from_le_bytes([bytes[4], bytes[5], bytes[6], bytes[7]]);
        assert_eq!(nv as usize, f.packed.len() / VERT_BYTES);
        let nt = u32::from_le_bytes([bytes[8], bytes[9], bytes[10], bytes[11]]);
        assert_eq!(nt as usize, f.indices.len() / 3);
    }

    #[test]
    fn error_budget_reported_honestly() {
        // huge bbox + absurdly tight budget -> quantized=false or error within
        let mut m = MeshIn::default();
        m.positions = vec![
            [0.0, 0.0, 0.0],
            [1000.0, 0.0, 0.0],
            [0.0, 1000.0, 0.0],
            [0.0, 0.0, 1000.0],
        ];
        m.indices = vec![0, 1, 2, 0, 1, 3, 0, 2, 3, 1, 2, 3];
        m.normals = vec![[0.0, 0.0, 1.0]; 4];
        m.n_idx = m.indices.clone();
        m.uvs = vec![[0.0, 0.0]; 4];
        m.uv_idx = m.indices.clone();
        let mut p = MeshPolicy::default();
        p.max_err_px = 0.01; // absurdly tight -> forces demotion
        let f = forge_mesh("tetra", &m, &p).unwrap();
        if !f.quantized {
            assert!(f.max_pos_err > p.world_budget());
        } else {
            assert!(f.max_pos_err <= p.world_budget());
        }
    }
}
