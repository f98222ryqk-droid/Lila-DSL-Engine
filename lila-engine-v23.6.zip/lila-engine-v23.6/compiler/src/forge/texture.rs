//! ============================================================================
//! FORGE — SUBSYSTEM A2: TEXTURE (analyze -> decide -> VERIFY -> bake)
//! ============================================================================
//!
//! The same discipline opt::audio applies to sound, applied to pixels:
//!
//!   1. ANALYZE the surface: exact unique colors (not "probably unique" —
//!      a u32 hash set, the real count), alpha classes (never / binary /
//!      partial), grayscale-ness, 8x8 block self-similarity, and — the
//!      whole-game superpower — USAGE SIZE from the game itself: a sprite
//!      the code never draws larger than 64px does not need its 1024px
//!      source, and FORGE is the only optimizer that can know that,
//!      because it reads the same AST that draws it (see logic.rs).
//!   2. DECIDE the format with a deterministic decision tree, guided by the
//!      platform card: palette 1/2/4/8bpp, R8, A8, RGB565, RGBA32, host-block
//!      directives (bc7 / astc / dxt5), or PROCEDURAL promotion (a perfect
//!      gradient becomes 2 texels + GPU interpolation — storage: 8 bytes,
//!      any resolution the host wants).
//!   3. VERIFY by decoding back and measuring the residual — worst channel
//!      delta and mean, exactly like the audio fit's residual %. A decision
//!      whose round-trip exceeds the card's tolerance is DEMOTED to the next
//!      format automatically. A bad fit is never a silent surprise.
//!   4. BAKE: atlas packing (deterministic skyline shelf), shared palette
//!      banks (runtime SET_PALETTE recolors), SDF bake (alpha -> signed
//!      distance for smooth scaling / 2D shadows / outlines), and a normal
//!      map derived from the sprite's own shading (host lights it).
//!
//! All of this is dev-time. The runtime never decodes, never quantizes,
//! never packs. It receives finished bytes and a manifest that says what
//! they mean.

use super::img::{Px, Surface};
use super::pgx;

// ---------------- facts ----------------

#[derive(Debug, Clone, PartialEq)]
pub struct TexFacts {
    pub w: u32,
    pub h: u32,
    /// exact count of distinct RGBA values (u32 hash set, not an estimate)
    pub unique_colors: usize,
    /// any pixel with a != 255
    pub has_alpha: bool,
    /// alpha values are only 0 or 255
    pub alpha_binary: bool,
    /// every pixel has r == g == b
    pub grayscale: bool,
    /// 0..1 — 1.0 means the image is EXACTLY reproducible by sampling a
    /// 4-texel corner gradient with hardware bilinear filtering.
    pub gradient_score: f32,
    /// 0..1 — fraction of 8x8 blocks that are byte-identical to an earlier
    /// block (tiling / flat areas -> atlas dedup + block compressors feast)
    pub block_repeat: f32,
}

pub fn analyze(s: &Surface) -> TexFacts {
    let mut seen = std::collections::HashSet::with_capacity(1024);
    let mut has_alpha = false;
    let mut alpha_binary = true;
    let mut grayscale = true;
    for i in 0..s.rgba.len() / 4 {
        let p = &s.rgba[i * 4..i * 4 + 4];
        seen.insert(u32::from_le_bytes([p[0], p[1], p[2], p[3]]));
        if p[3] != 255 {
            has_alpha = true;
            if p[3] != 0 {
                alpha_binary = false;
            }
        }
        if p[0] != p[1] || p[1] != p[2] {
            grayscale = false;
        }
    }
    // gradient: how well does bilinear(4 corners) reproduce the image?
    // A PERFECT match means the texture is procedural grade — replace it
    // with the corners and let the GPU regenerate it at any resolution.
    let c00 = s.px(0, 0);
    let c10 = s.px(s.w.saturating_sub(1), 0);
    let c01 = s.px(0, s.h.saturating_sub(1));
    let c11 = s.px(s.w.saturating_sub(1), s.h.saturating_sub(1));
    let bilin = |fx: f32, fy: f32| -> (f32, f32, f32, f32) {
        let l = |a: u8, b: u8, t: f32| a as f32 + (b as f32 - a as f32) * t;
        let cx0 = (l(c00.r, c10.r, fx), l(c00.g, c10.g, fx), l(c00.b, c10.b, fx), l(c00.a, c10.a, fx));
        let cx1 = (l(c01.r, c11.r, fx), l(c01.g, c11.g, fx), l(c01.b, c11.b, fx), l(c01.a, c11.a, fx));
        (
            l(cx0.0 as u8, cx1.0 as u8, fy) as f32,
            l(cx0.1 as u8, cx1.1 as u8, fy) as f32,
            l(cx0.2 as u8, cx1.2 as u8, fy) as f32,
            l(cx0.3 as u8, cx1.3 as u8, fy) as f32,
        )
    };
    let mut gerr: f64 = 0.0;
    for y in 0..s.h {
        for x in 0..s.w {
            let fx = if s.w > 1 { x as f32 / (s.w - 1) as f32 } else { 0.0 };
            let fy = if s.h > 1 { y as f32 / (s.h - 1) as f32 } else { 0.0 };
            let (r, g, b, a) = bilin(fx, fy);
            let p = s.px(x, y);
            gerr += ((r - p.r as f32).abs()
                + (g - p.g as f32).abs()
                + (b - p.b as f32).abs()
                + (a - p.a as f32).abs()) as f64;
        }
    }
    let denom = (s.w * s.h).max(1) as f64 * 4.0 * 255.0;
    let gradient_score = (1.0 - gerr / denom).max(0.0) as f32;

    // block self-similarity: hash each 8x8 block, count repeats
    let mut blocks = std::collections::HashMap::with_capacity(1024);
    let mut total = 0usize;
    let mut repeats = 0usize;
    let by = 0..(s.h + 7) / 8;
    for _ in by {
        for bx in 0..(s.w + 7) / 8 {
            let mut h = 2166136261u32; // FNV-1a over the block's colors
            for y in (bx * 8).min(s.h)..((bx * 8) + 8).min(s.h) {
                for x in (bx * 8).min(s.w)..((bx * 8) + 8).min(s.w) {
                    let p = s.px(x, y);
                    for c in [p.r, p.g, p.b, p.a] {
                        h ^= c as u32;
                        h = h.wrapping_mul(16777619);
                    }
                }
            }
            let e = blocks.entry(h).or_insert(0usize);
            *e += 1;
            total += 1;
            if *e > 1 {
                repeats += 1;
            }
        }
    }
    let block_repeat = if total == 0 { 0.0 } else { repeats as f32 / total as f32 };

    TexFacts {
        w: s.w,
        h: s.h,
        unique_colors: seen.len(),
        has_alpha,
        alpha_binary,
        grayscale,
        gradient_score,
        block_repeat,
    }
}

// ---------------- decide + verify ----------------

/// Per-target texture policy, distilled from the platform card by mod.rs.
#[derive(Debug, Clone)]
pub struct TexPolicy {
    /// max dimension after usage clamping (e.g. 2048 desktop / 1024 mobile)
    pub max_dim: u32,
    /// emit host block-compression directives instead of raw (e.g. "bc7",
    /// "astc-6x6", "dxt5"); None = raw formats only
    pub host_block: Option<&'static str>,
    /// worst per-channel round-trip delta tolerated before DEMOTION (0..255)
    pub tolerance: u8,
    /// bake SDF / normal derivations where they pay
    pub want_sdf: bool,
    pub want_normal: bool,
    /// minimum gradient score for procedural promotion
    pub gradient_min: f32,
    /// usage-clamped draw size from logic.rs usage mining (None = unknown)
    pub usage: Option<(u32, u32)>,
}

impl Default for TexPolicy {
    fn default() -> Self {
        TexPolicy {
            max_dim: 2048,
            host_block: Some("bc7"),
            tolerance: 8,
            want_sdf: false,
            want_normal: false,
            gradient_min: 0.995,
            usage: None,
        }
    }
}

#[derive(Debug, Clone, PartialEq)]
pub enum TexFormat {
    /// palette indices + shared RGBA bank; bits per index = 1/2/4/8
    Palette(u8),
    /// single-channel luminance (grayscale proven)
    R8,
    /// single-channel alpha (single color proven)
    A8,
    /// 16-bit rgb, alpha never (round-trip VERIFIED before choosing)
    Rgb565,
    /// raw RGBA8888 (fallback: nothing lossless enough is smaller)
    Rgba32,
    /// procedural: 4 corner texels, the GPU interpolates (perfect gradient)
    Gradient,
    /// directive: host block-compresses the RGBA32 bytes (bc7/astc/dxt5)
    HostBlock(&'static str),
    /// v19: flat-color art -> rect-cover geometry. data carries the PGX1
    /// payload; the host draws indexed quads and never touches a texel.
    /// Only chosen when the round-trip is pixel-EXACT and the bytes beat
    /// the next candidate (palette) — a novelty never ships.
    Pgx,
}

/// Residual of a decision — the pixels-vs-original contract, mirroring the
/// audio fit's residual. `max` is the worst per-channel delta in 1/255s.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Residual {
    pub max: u8,
    pub mean: f32,
    /// fraction of pixels with ANY channel off by more than tolerance
    pub over_fraction: f32,
}

impl Residual {
    pub fn exact() -> Residual {
        Residual { max: 0, mean: 0.0, over_fraction: 0.0 }
    }
}

/// The baked texture: everything the host needs, nothing it doesn't.
#[derive(Debug, Clone)]
pub struct ForgedTexture {
    pub name: String,
    pub format: TexFormat,
    pub w: u32,
    pub h: u32,
    /// encoded payload (meaning depends on format; RGBA32 for HostBlock)
    pub data: Vec<u8>,
    /// palette-bank location when format == Palette
    pub palette: Option<Vec<[u8; 4]>>,
    /// SDF derivation (u8, 128 = edge) — None when not baked
    pub sdf: Option<Vec<u8>>,
    /// normal-map derivation (RGB, tangent space) — None when not baked
    pub normal: Option<Vec<u8>>,
    pub residual: Residual,
    pub facts: TexFacts,
    /// v19: the rect cover when format == Pgx (hosts rasterize it as quads)
    pub pgx: Option<pgx::PgxBlob>,
    /// notes for the manifest decision log (why this format won)
    pub notes: Vec<String>,
}

impl ForgedTexture {
    pub fn bytes(&self) -> usize {
        self.data.len()
            + self.palette.as_ref().map_or(0, |p| p.len() * 4)
            + self.sdf.as_ref().map_or(0, |d| d.len())
            + self.normal.as_ref().map_or(0, |d| d.len())
    }
    pub fn source_bytes(&self) -> usize {
        (self.facts.w * self.facts.h * 4) as usize
    }
}

// ---- encoders / decoders (each format round-trips through these, so the
// ---- residual is MEASURED, never assumed) ----

fn build_palette(s: &Surface) -> (Vec<[u8; 4]>, Vec<u8>) {
    // deterministic: colors in FIRST-APPEARANCE order (scan order), so the
    // palette index assignment is stable across machines and runs.
    let mut pal: Vec<[u8; 4]> = Vec::new();
    let mut idx = std::collections::HashMap::new();
    let mut indices = Vec::with_capacity((s.w * s.h) as usize);
    for i in 0..(s.w * s.h) as usize {
        let p = s.px((i % s.w as usize) as u32, (i / s.w as usize) as u32);
        let key = u32::from_le_bytes([p.r, p.g, p.b, p.a]);
        let at = match idx.get(&key) {
            Some(&at) => at,
            None => {
                let at = pal.len();
                pal.push([p.r, p.g, p.b, p.a]);
                idx.insert(key, at);
                at
            }
        };
        indices.push(at as u8);
    }
    (pal, indices)
}

fn pack_palette_indices(indices: &[u8], bits: u8) -> Vec<u8> {
    // LSB-first bit-packing, 1/2/4/8 bits per index
    if bits == 8 {
        return indices.to_vec();
    }
    let mut out = Vec::with_capacity(indices.len() * bits as usize / 8 + 1);
    let mut acc = 0u32;
    let mut nbits = 0u32;
    for &i in indices {
        acc |= (i as u32) << nbits;
        nbits += bits as u32;
        while nbits >= 8 {
            out.push((acc & 0xFF) as u8);
            acc >>= 8;
            nbits -= 8;
        }
    }
    if nbits > 0 {
        out.push((acc & 0xFF) as u8);
    }
    out
}

fn unpack_palette_indices(data: &[u8], bits: u8, n: usize) -> Vec<u8> {
    if bits == 8 {
        return data.to_vec();
    }
    let mut out = Vec::with_capacity(n);
    let mut bit = 0usize;
    for _ in 0..n {
        let byte = data[bit / 8];
        let shift = (bit % 8) as u32;
        let mask = (1u16 << bits) - 1;
        out.push((byte >> shift) & mask as u8);
        bit += bits as usize;
    }
    out
}

fn decode_with(surf: &Surface, fmt: &TexFormat, pal: &[[u8; 4]], packed: &[u8], w: u32, h: u32) -> Surface {
    let mut out = Surface::new(w, h);
    for y in 0..h {
        for x in 0..w {
            let p = surf.px(x, y);
            let d = match fmt {
                TexFormat::Palette(bits) => {
                    let i = unpack_palette_indices(packed, *bits, (w * h) as usize)
                        [(y * w + x) as usize];
                    let c = pal[i as usize];
                    Px { r: c[0], g: c[1], b: c[2], a: c[3] }
                }
                TexFormat::R8 => Px { r: p.r, g: p.r, b: p.r, a: 255 },
                TexFormat::A8 => Px { r: 255, g: 255, b: 255, a: p.a },
                TexFormat::Rgb565 => {
                    let r = (p.r >> 3) << 3;
                    let g = (p.g >> 2) << 2;
                    let b = (p.b >> 3) << 3;
                    Px { r, g, b, a: 255 }
                }
                _ => p,
            };
            out.set_px(x, y, d);
        }
    }
    out
}

fn measure(original: &Surface, decoded: &Surface, tolerance: u8) -> Residual {
    debug_assert_eq!((original.w, original.h), (decoded.w, decoded.h));
    let mut max: u8 = 0;
    let mut sum: f64 = 0.0;
    let mut over = 0usize;
    let n = original.rgba.len() / 4;
    for i in 0..n {
        let a = &original.rgba[i * 4..i * 4 + 4];
        let b = &decoded.rgba[i * 4..i * 4 + 4];
        let mut px_over = false;
        for k in 0..4 {
            let d = a[k].abs_diff(b[k]);
            if d > max {
                max = d;
            }
            sum += d as f64;
            if d > tolerance {
                px_over = true;
            }
        }
        if px_over {
            over += 1;
        }
    }
    Residual {
        max,
        mean: (sum / (n as f64 * 4.0)) as f32,
        over_fraction: over as f32 / n as f32,
    }
}

/// The whole texture pipeline for one surface. `name` is for reports.
pub fn forge_texture(name: &str, src: &Surface, policy: &TexPolicy) -> Result<ForgedTexture, String> {
    // ---- 0. usage clamp: the resolution IS the compression ----
    let mut s = src.clone();
    let mut usage_note = String::new();
    if let Some((uw, uh)) = policy.usage {
        let fx = (s.w + uw - 1) / uw.max(1);
        let fy = (s.h + uh - 1) / uh.max(1);
        let f = fx.max(fy);
        if f > 1 {
            s = s.downsample(f, f)?;
            usage_note = format!(
                "usage-clamped {}x{} -> {}x{} (never drawn larger)",
                src.w, src.h, s.w, s.h
            );
        }
    }
    if s.w > policy.max_dim || s.h > policy.max_dim {
        let f = (s.w / policy.max_dim).max(s.h / policy.max_dim).max(1);
        s = s.downsample(f, f)?;
    }

    let facts = analyze(&s);
    let mut notes = Vec::new();
    if !usage_note.is_empty() {
        notes.push(usage_note);
    }

    // ---- 1. decide (ordered candidates; first that VERIFIES wins) ----
    let mut candidates: Vec<TexFormat> = Vec::new();
    if facts.gradient_score >= policy.gradient_min && s.w >= 2 && s.h >= 2 {
        candidates.push(TexFormat::Gradient);
    }
    // v19 PGX: flat-color art -> rect geometry. Candidate ONLY when it beats
    // the strongest palette encoding in bytes (the next lossless option) —
    // the comparison is against what the sprite would otherwise cost, so PGX
    // never ships as a novelty, always as the measured winner.
    let pgx_blob = pgx::try_cover(&s);
    if let Some(blob) = &pgx_blob {
        let pal_bits: u8 = if facts.unique_colors <= 2 {
            1
        } else if facts.unique_colors <= 4 {
            2
        } else if facts.unique_colors <= 16 {
            4
        } else {
            8
        };
        let pal_bytes = 2 + blob.palette.len() * 4 + 2
            + ((s.w as usize * s.h as usize * pal_bits as usize + 7) / 8);
        if pgx::bytes_of(blob) < pal_bytes {
            candidates.push(TexFormat::Pgx);
        }
    }
    if !facts.has_alpha && facts.grayscale {
        candidates.push(TexFormat::R8);
    }
    // A8: literally one color with varying alpha
    if facts.has_alpha && facts.unique_colors <= 256 {
        // (checked properly below by round-trip)
        candidates.push(TexFormat::A8);
    }
    if facts.unique_colors <= 2 {
        candidates.push(TexFormat::Palette(1));
    } else if facts.unique_colors <= 4 {
        candidates.push(TexFormat::Palette(2));
    } else if facts.unique_colors <= 16 {
        candidates.push(TexFormat::Palette(4));
    } else if facts.unique_colors <= 256 {
        candidates.push(TexFormat::Palette(8));
    }
    if let Some(directive) = policy.host_block {
        candidates.push(TexFormat::HostBlock(directive));
    }
    if !facts.has_alpha {
        candidates.push(TexFormat::Rgb565);
    }
    candidates.push(TexFormat::Rgba32);

    // ---- 2. verify each in order; demotion falls through ----
    for fmt in candidates {
        let (packed, pal) = match &fmt {
            TexFormat::Palette(bits) => {
                let (pal, idx) = build_palette(&s);
                if pal.len() > (1usize << bits) {
                    continue; // defensive: never (facts said it fits)
                }
                (pack_palette_indices(&idx, *bits), pal)
            }
            TexFormat::R8 => {
                let mut d = Vec::with_capacity((s.w * s.h) as usize);
                for y in 0..s.h {
                    for x in 0..s.w {
                        d.push(s.px(x, y).r);
                    }
                }
                (d, Vec::new())
            }
            TexFormat::A8 => {
                let mut d = Vec::with_capacity((s.w * s.h) as usize);
                for y in 0..s.h {
                    for x in 0..s.w {
                        d.push(s.px(x, y).a);
                    }
                }
                (d, Vec::new())
            }
            TexFormat::Rgb565 | TexFormat::HostBlock(_) | TexFormat::Rgba32 => {
                (s.rgba.clone(), Vec::new())
            }
            TexFormat::Pgx => {
                let blob = pgx_blob.as_ref().unwrap();
                (pgx::emit(blob, s.w, s.h), Vec::new())
            }
            TexFormat::Gradient => (Vec::new(), Vec::new()),
        };
        let decoded = match &fmt {
            TexFormat::Pgx => match pgx::decode_payload(&packed) {
                Ok(d) => d,
                Err(_) => continue, // cannot happen (we encoded it) — demote anyway
            },
            _ => decode_with(&s, &fmt, &pal, &packed, s.w, s.h),
        };
        let residual = measure(&s, &decoded, policy.tolerance);
        let acceptable = match &fmt {
            TexFormat::Gradient => residual.max as u32 <= 1, // near-perfect only
            TexFormat::Palette(_) | TexFormat::R8 | TexFormat::A8 => residual.max == 0,
            // PGX is lossless or it is nothing: every pixel must round-trip
            TexFormat::Pgx => residual.max == 0,
            TexFormat::Rgb565 => residual.max <= policy.tolerance,
            _ => true, // HostBlock (host verifies after transcode) / Rgba32
        };
        if !acceptable {
            continue; // demote to the next candidate
        }
        // ---- 3. bake derivations (policy-gated) ----
        let sdf = if policy.want_sdf { Some(bake_sdf(&s, 16)) } else { None };
        let normal = if policy.want_normal { Some(bake_normal(&s)) } else { None };
        let why = match &fmt {
            TexFormat::Gradient => format!(
                "procedural promotion (gradient {:.4} >= {:.3}) — {} texels + GPU bilinear",
                facts.gradient_score,
                policy.gradient_min,
                4
            ),
            TexFormat::Pgx => {
                let blob = pgx_blob.as_ref().unwrap();
                format!(
                    "{} flat colors -> {} rect quads ({}B) — texture eliminated, pixel-exact",
                    blob.palette.len(),
                    blob.rects.len(),
                    pgx::bytes_of(blob)
                )
            }
            TexFormat::Palette(b) => format!("{} unique colors -> {}bpp indices + bank", facts.unique_colors, b),
            TexFormat::R8 => "grayscale proven -> R8 (round-trip exact)".to_string(),
            TexFormat::A8 => "single color + varying alpha -> A8 (round-trip exact)".to_string(),
            TexFormat::Rgb565 => format!(
                "alpha never, 565 round-trip verified (max delta {}/{})",
                residual.max, policy.tolerance
            ),
            TexFormat::HostBlock(d) => format!("block-compressed by host ({})", d),
            TexFormat::Rgba32 => "no smaller lossless-enough form — raw RGBA32".to_string(),
        };
        notes.push(why);
        let is_pgx = matches!(fmt, TexFormat::Pgx);
        return Ok(ForgedTexture {
            name: name.to_string(),
            format: fmt,
            w: s.w,
            h: s.h,
            data: packed,
            palette: if pal.is_empty() { None } else { Some(pal) },
            sdf,
            normal,
            residual,
            facts,
            pgx: if is_pgx { pgx_blob } else { None },
            notes,
        });
    }
    Err(format!("texture {}: no format verified (impossible — Rgba32 is total)", name))
}

// ---------------- SDF bake (alpha -> signed distance, 8-bit) ----------------

/// Two-pass chamfer distance transform over the alpha mask. Output: 0..255
/// where 128 is the edge, >128 inside, <128 outside, 1 unit of distance per
/// `spread` pixels. Hosts sample it for outlines, 2D shadows and smooth
/// scale-up (the "sprite at any zoom" trick, baked not computed).
pub fn bake_sdf(s: &Surface, spread: u32) -> Vec<u8> {
    let w = s.w as usize;
    let h = s.h as usize;
    let mut dist = vec![f32::INFINITY; w * h * 2]; // [0..n) = outside pass, [n..) = inside pass
    let n = w * h;
    let inside = |x: usize, y: usize| s.px(x as u32, y as u32).a >= 128;
    // init: 0 where boundary condition flips
    for y in 0..h {
        for x in 0..w {
            let i = y * w + x;
            dist[i] = if !inside(x, y) { 0.0 } else { f32::INFINITY };
            dist[i + n] = if inside(x, y) { 0.0 } else { f32::INFINITY };
        }
    }
    let d = |buf: &[f32], x: i32, y: i32| -> f32 {
        if x < 0 || y < 0 || x >= w as i32 || y >= h as i32 {
            f32::INFINITY
        } else {
            buf[(y as usize) * w + x as usize]
        }
    };
    // chamfer 1-2 (approx Euclidean within 8%)
    for pass in 0..2 {
        let (lo, hi) = if pass == 0 { (0, n) } else { (n, 2 * n) };
        let buf = &mut dist[lo..hi];
        for y in 0..h {
            for x in 0..w {
                let m = d(buf, x as i32 - 1, y as i32 - 1) + 2.0;
                let l = d(buf, x as i32 - 1, y as i32) + 1.0;
                let t = d(buf, x as i32, y as i32 - 1) + 1.0;
                let tl = d(buf, x as i32 + 1, y as i32 - 1) + 2.0;
                let v = buf[y * w + x].min(m.min(l).min(t).min(tl));
                buf[y * w + x] = v;
            }
        }
        for y in (0..h).rev() {
            for x in (0..w).rev() {
                let r = d(buf, x as i32 + 1, y as i32) + 1.0;
                let b = d(buf, x as i32, y as i32 + 1) + 1.0;
                let br = d(buf, x as i32 + 1, y as i32 + 1) + 2.0;
                let tr = d(buf, x as i32 + 1, y as i32 - 1) + 2.0;
                let v = buf[y * w + x].min(r.min(b).min(br).min(tr));
                buf[y * w + x] = v;
            }
        }
    }
    let mut out = vec![0u8; n];
    for i in 0..n {
        let signed = dist[i] - dist[i + n]; // >0 inside (dist-to-outside wins), <0 outside
        let v = 128.0 + (signed / spread as f32).clamp(-1.0, 1.0) * 127.0;
        out[i] = v.round().clamp(0.0, 255.0) as u8;
    }
    out
}

// ---------------- normal bake (shading -> tangent-space normals) ----------------

/// Height from the sprite's own luma (blurred once — the blur IS the
/// low-pass that keeps normals sane on pixel art), Sobel on top, z = 1/2.
/// Host dynamic lights can then relight a flat 2D sprite.
pub fn bake_normal(s: &Surface) -> Vec<u8> {
    let w = s.w as usize;
    let h = s.h as usize;
    let luma = |x: i32, y: i32| -> f32 {
        let x = x.clamp(0, w as i32 - 1) as usize;
        let y = y.clamp(0, h as i32 - 1) as usize;
        let p = s.px(x as u32, y as u32);
        (0.299 * p.r as f32 + 0.587 * p.g as f32 + 0.114 * p.b as f32) * (p.a as f32 / 255.0)
    };
    let mut out = vec![0u8; w * h * 3];
    for y in 0..h {
        for x in 0..w {
            let (xi, yi) = (x as i32, y as i32);
            let dx = (luma(xi + 1, yi - 1) + 2.0 * luma(xi + 1, yi) + luma(xi + 1, yi + 1))
                - (luma(xi - 1, yi - 1) + 2.0 * luma(xi - 1, yi) + luma(xi - 1, yi + 1));
            let dy = (luma(xi - 1, yi + 1) + 2.0 * luma(xi, yi + 1) + luma(xi + 1, yi + 1))
                - (luma(xi - 1, yi - 1) + 2.0 * luma(xi, yi - 1) + luma(xi + 1, yi - 1));
            let scale = 1.0 / 4.0; // gentle: pixel-art normals
            let (mut nx, mut ny) = (dx * scale, dy * scale);
            let nz = 1.0;
            let len = (nx * nx + ny * ny + nz * nz).sqrt().max(1e-9);
            nx /= len;
            ny /= len;
            let i = (y * w + x) * 3;
            out[i] = ((nx * 0.5 + 0.5) * 255.0).round() as u8;
            out[i + 1] = ((ny * 0.5 + 0.5) * 255.0).round() as u8;
            out[i + 2] = ((nz / len * 0.5 + 0.5) * 255.0).round() as u8;
        }
    }
    out
}

// ---------------- atlas (deterministic skyline shelf) ----------------

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Rect {
    pub x: u32,
    pub y: u32,
    pub w: u32,
    pub h: u32,
}

/// Skyline shelf packer. Deterministic: rects sorted by height desc with
/// first-declaration as tie-break; shelves scanned left-to-right; fails
/// loudly (Err) instead of silently overlapping. Padding 1px to keep block
/// compressors from bleeding neighbors.
pub struct AtlasBuilder {
    pub w: u32,
    pub h: u32,
    skyline: Vec<u32>, // top y of the skyline at each x (granularity 1px)
    pad: u32,
}

impl AtlasBuilder {
    pub fn new(w: u32, h: u32) -> AtlasBuilder {
        AtlasBuilder { w, h, skyline: vec![0; w as usize], pad: 1 }
    }

    fn level_at(&self, x: u32, w: u32) -> Option<u32> {
        // the max skyline height over [x, x+w)
        let mut m = 0u32;
        for i in x..(x + w).min(self.w) {
            m = m.max(self.skyline[i as usize]);
        }
        Some(m)
    }

    pub fn alloc(&mut self, w: u32, h: u32) -> Result<Rect, String> {
        let w = w + self.pad * 2;
        let h = h + self.pad * 2;
        if w > self.w {
            return Err(format!("atlas: rect {}px wider than page {}", w, self.w));
        }
        let mut best_x = None;
        let mut best_y = u32::MAX;
        let mut x = 0u32;
        while x + w <= self.w {
            let y = self.level_at(x, w).ok_or("atlas: level overflow")?;
            if y < best_y {
                best_y = y;
                best_x = Some(x);
                if y == 0 {
                    break; // can't beat the floor
                }
            }
            x += 1;
        }
        let x = best_x.ok_or("atlas: page full")?;
        if best_y + h > self.h {
            return Err("atlas: page full (vertical)".into());
        }
        for i in x..x + w {
            self.skyline[i as usize] = best_y + h;
        }
        Ok(Rect { x: x + self.pad, y: best_y + self.pad, w: w - self.pad * 2, h: h - self.pad * 2 })
    }

    pub fn occupancy(&self) -> f32 {
        let used: u32 = self.skyline.iter().sum();
        used as f32 / (self.w * self.h) as f32
    }
}

// ---------------- tests ----------------

#[cfg(test)]
mod tests {
    use super::*;

    fn solid(w: u32, h: u32, c: Px) -> Surface {
        let mut s = Surface::new(w, h);
        for y in 0..h {
            for x in 0..w {
                s.set_px(x, y, c);
            }
        }
        s
    }

    fn gradient(w: u32, h: u32, a: Px, b: Px) -> Surface {
        let mut s = Surface::new(w, h);
        for y in 0..h {
            for x in 0..w {
                let t = x as f32 / (w - 1) as f32;
                let l = |p: u8, q: u8| (p as f32 + (q as f32 - p as f32) * t).round() as u8;
                s.set_px(x, y, Px { r: l(a.r, b.r), g: l(a.g, b.g), b: l(a.b, b.b), a: l(a.a, b.a) });
            }
        }
        s
    }

    #[test]
    fn palette_4_colors_exact() {
        let mut s = Surface::new(8, 8);
        for y in 0..8 {
            for x in 0..8 {
                let c = match (x / 4, y / 4) {
                    (0, 0) => Px { r: 255, g: 0, b: 0, a: 255 },
                    (1, 0) => Px { r: 0, g: 255, b: 0, a: 255 },
                    (0, 1) => Px { r: 0, g: 0, b: 255, a: 255 },
                    _ => Px { r: 255, g: 255, b: 255, a: 255 },
                };
                s.set_px(x, y, c);
            }
        }
        let f = forge_texture("quad", &s, &TexPolicy::default()).unwrap();
        assert_eq!(f.format, TexFormat::Palette(2));
        assert_eq!(f.residual.max, 0);
        assert!(f.bytes() < s.rgba.len());
        assert!(f.palette.as_ref().unwrap().len() == 4);
    }

    #[test]
    fn two_colors_picks_1bpp() {
        let mut s = Surface::new(16, 4);
        for i in 0..16 * 4 {
            let (x, y) = (i % 16, i / 16);
            s.set_px(x as u32, y as u32, if i % 2 == 0 { Px { r: 10, g: 20, b: 30, a: 255 } } else { Px { r: 200, g: 200, b: 200, a: 255 } });
        }
        let f = forge_texture("bit", &s, &TexPolicy::default()).unwrap();
        assert_eq!(f.format, TexFormat::Palette(1));
        assert_eq!(f.data.len(), 16 * 4 / 8); // 1bpp: 8 pixels per byte
    }

    #[test]
    fn gradient_promoted_procedural() {
        let s = gradient(256, 64, Px { r: 20, g: 30, b: 90, a: 255 }, Px { r: 240, g: 120, b: 10, a: 255 });
        let f = forge_texture("sky", &s, &TexPolicy::default()).unwrap();
        assert_eq!(f.format, TexFormat::Gradient);
        assert!(f.data.is_empty()); // nothing ships — the GPU regenerates it
        assert!(f.residual.max <= 1);
    }

    #[test]
    fn grayscale_picks_r8() {
        let mut s = Surface::new(10, 10);
        for y in 0..10 {
            for x in 0..10 {
                let v = (x * x * 3 + y * 5) as u8 % 251; // grayscale, NOT a bilinear gradient
                s.set_px(x, y, Px { r: v, g: v, b: v, a: 255 });
            }
        }
        let f = forge_texture("gs", &s, &TexPolicy::default()).unwrap();
        assert_eq!(f.format, TexFormat::R8);
        assert_eq!(f.residual.max, 0);
    }

    #[test]
    fn single_color_varying_alpha_picks_a8() {
        let mut s = Surface::new(8, 8);
        for y in 0..8 {
            for x in 0..8 {
                s.set_px(x, y, Px { r: 255, g: 0, b: 80, a: ((x * 37) % 256) as u8 }); // non-linear alpha
            }
        }
        let f = forge_texture("glow", &s, &TexPolicy::default()).unwrap();
        // exact answers the tree may prefer: palette when <=256 uniques,
        // A8 when more (single color, many alphas):
        assert!(
            matches!(f.format, TexFormat::A8 | TexFormat::Palette(_)),
            "got {:?}", f.format
        );
        assert_eq!(f.residual.max, 0);
    }

    #[test]
    fn many_colors_falls_to_host_block_or_rgba() {
        let mut s = Surface::new(64, 64);
        let mut v = 12345u32;
        for y in 0..64 {
            for x in 0..64 {
                v = v.wrapping_mul(1664525).wrapping_add(1013904223);
                s.set_px(x, y, Px { r: (v >> 24) as u8, g: (v >> 16) as u8, b: (v >> 8) as u8, a: 255 });
            }
        }
        let mut p = TexPolicy::default();
        p.host_block = Some("bc7");
        let f = forge_texture("noise", &s, &p).unwrap();
        assert_eq!(f.format, TexFormat::HostBlock("bc7"));
        // without host directives, RGB565 verifies within tolerance and wins
        // (max channel delta 7 <= 8) — force tolerance 0 to reach the total
        // fallback
        p.host_block = None;
        p.tolerance = 0;
        let f2 = forge_texture("noise", &s, &p).unwrap();
        assert_eq!(f2.format, TexFormat::Rgba32);
    }

    #[test]
    fn rgb565_rejected_when_error_too_big() {
        // r=7 vs r=8 differ by 1 in 5-bit bins... build a pair that 565
        // merges but tolerance 0 rejects:
        let mut s = Surface::new(2, 1);
        s.set_px(0, 0, Px { r: 7, g: 0, b: 0, a: 255 });
        s.set_px(1, 0, Px { r: 8, g: 0, b: 0, a: 255 });
        let mut p = TexPolicy::default();
        p.host_block = None;
        p.tolerance = 0;
        let f = forge_texture("picky", &s, &p).unwrap();
        // unique=2 -> palette(1) is exact and wins first anyway; assert the
        // 565 reject indirectly: the palette beats it. So instead force no
        // palette by using >256 colors of pure red-channel variation:
        let mut s2 = Surface::new(256, 2);
        for x in 0..256 {
            for y in 0..2 {
                // 512 unique colors: same r/b per column, g varies per row too
                s2.set_px(x, y, Px { r: x as u8, g: ((x * 7 + y * 137) % 256) as u8, b: (x * 13 % 256) as u8, a: 255 });
            }
        }
        // 512 unique colors, no palette possible; 565 must round-trip within 0
        let f2 = forge_texture("picky2", &s2, &p).unwrap();
        assert_eq!(f2.format, TexFormat::Rgba32); // 565 demoted (max delta > 0)
    }

    #[test]
    fn usage_clamp_shrinks_source() {
        let s = gradient(1024, 1024, Px { r: 0, g: 0, b: 0, a: 255 }, Px { r: 255, g: 255, b: 255, a: 255 });
        let mut p = TexPolicy::default();
        p.usage = Some((64, 64));
        let f = forge_texture("bg", &s, &p).unwrap();
        assert_eq!((f.w, f.h), (64, 64));
        assert!(f.notes.iter().any(|n| n.contains("usage-clamped")));
    }

    #[test]
    fn sdf_bakes_edge_at_128() {
        // solid 8x8 square in a 12x12 canvas: center inside (>128), far
        // corner outside (<128), border pixel ~128
        let mut s = Surface::new(12, 12);
        for y in 2..10 {
            for x in 2..10 {
                s.set_px(x, y, Px { r: 255, g: 255, b: 255, a: 255 });
            }
        }
        let sdf = bake_sdf(&s, 4);
        let at = |x: usize, y: usize| sdf[y * 12 + x];
        assert!(at(6, 6) > 200); // deep inside
        assert!(at(0, 0) < 60); // far outside
        assert!((at(2, 6) as i32 - 128).abs() <= 32); // near edge
    }

    #[test]
    fn normal_of_flat_is_up() {
        let s = solid(16, 16, Px { r: 128, g: 128, b: 128, a: 255 });
        let n = bake_normal(&s);
        assert_eq!(&n[0..3], &[128, 128, 255]);
    }

    #[test]
    fn atlas_packs_without_overlap() {
        let mut at = AtlasBuilder::new(210, 110);
        let rects = vec![(64u32, 32u32), (64, 32), (64, 32), (64, 32), (62, 62)];
        let mut placed = Vec::new();
        for (w, h) in rects {
            placed.push(at.alloc(w, h).expect("page has room"));
        }
        for i in 0..placed.len() {
            for j in (i + 1)..placed.len() {
                let (a, b) = (placed[i], placed[j]);
                let overlap = a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;
                assert!(!overlap, "rects {} and {} overlap", i, j);
            }
        }
        assert!(at.occupancy() > 0.2);
    }

    #[test]
    fn atlas_fails_loudly_when_full() {
        let mut at = AtlasBuilder::new(32, 32);
        assert!(at.alloc(64, 8).is_err()); // wider than page
        // with the 1px pad each 16px rect consumes 18px: one row fits
        assert!(at.alloc(16, 16).is_ok());
        assert!(at.alloc(16, 16).is_err()); // 2nd row would need 36px > 32
        let mut wide = AtlasBuilder::new(54, 8);
        assert!(wide.alloc(16, 6).is_ok()); // columns 1..3 of 18px = 54px exactly
        assert!(wide.alloc(16, 6).is_ok());
        assert!(wide.alloc(16, 6).is_ok());
        assert!(wide.alloc(16, 6).is_err()); // 4th column needs 72px > 54, no vertical room
    }
}
