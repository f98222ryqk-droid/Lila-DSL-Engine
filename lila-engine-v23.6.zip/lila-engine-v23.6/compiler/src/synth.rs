//! ============================================================================
//! LILA v10 LANGUAGE SYNTHESIS — prefabs + particles, resolved BEFORE check.
//! ============================================================================
//!
//! Two engine-grade authoring features that UE/Unity ship as RUNTIME
//! subsystems, lowered here into plain AST so the checker, codegen, VM and
//! file format never know they existed:
//!
//! 1. PREFAB INHERITANCE (Unity prefab analog)
//!       entity FastDrone from Drone { speed: 2.0  regen: u3 = 1 }
//!    merges the parent's fields (recursively, cycles rejected) under the
//!    child's overrides — same name must keep the parent's type, new names
//!    append. The child's `fsm:` wins if declared, otherwise inherited.
//!    After expansion every entity is flat: inheritance costs ZERO bytes
//!    and ZERO runtime work — it is authoring sugar, compiled away.
//!
//! 2. DECLARATIVE PARTICLES (Niagara/VFX-Graph analog)
//!       particles #boomfx (192) { sprite: #pspark  life: 22  speed: 1.8
//!                                 jitter: 0.5  drag: 0.92  grav: 0.0
//!                                 burst: 12  color: 0xFFB040  fade: true }
//!       emit(#boomfx, ex, ey);          // <- anywhere an update can run
//!    lowers to an ordinary entity type (`boomfx`: x/y/vx/vy/ttl), an
//!    `emit_boomfx` helper (burst spawns with deterministic LCG angle +
//!    speed jitter), an `update(boomfx)` (drag / gravity / ttl / kill) and
//!    a `draw(boomfx)` (sprite with ttl-driven scale + alpha fade).
//!    Everything downstream treats them as hand-written code: SoA packing,
//!    spawn budgets, compiler-emitted integration (particles get the
//!    auto-integration pass for free), draw batching. There is no particle
//!    ENGINE in the runtime — the particle system IS the bytecode.

use crate::ast::*;

/// Entry point: resolve prefab chains, then lower every particles decl.
/// Returns (kind, detail) rows for the build report. After this, no `from`
/// and no `particles` remain in the program.
pub fn expand(prog: &mut Program, atom_names: &[String], base_dir: &str) -> Result<Vec<(String, String)>, String> {
    let mut rows = Vec::new();
    rows.extend(apply_mixins(prog)?);
    rows.extend(resolve_prefabs(prog)?);
    rows.extend(lower_meshes(prog, base_dir)?);
    rows.extend(lower_structs(prog)?);
    rows.extend(lower_particles(prog, atom_names)?);
    Ok(rows)
}

// ============================================================================
// v23.2 MESH IMPORT — Wavefront OBJ -> generated init code
// ============================================================================
//
//     mesh cube from "pyramid.obj" scale 1.0;
//
// lowers to a global `arr fixed[N] cube` (N = triangle_count * 18) whose
// quantized Q24.8 cells ride the v6 BAKED COLD-DATA trailer (v23.5); the
// loader copies them into the GARR plane before init() runs.
//
// The v23.2 lowering generated one constant-indexed ST_GARR per cell (DATA
// AS CODE, ~3 instructions/cell) — the max_instr budget (8192 default)
// capped a single import at roughly 150 triangles and ~450 across a game.
// Baking costs ZERO instructions: the cap is now the GARR plane itself
// (32768 cells = ~1819 tris), enforced loudly by the loader's
// ERR_LIMIT_ARRAYS against the COMBINED plane budget. Old runtimes reject
// v6 carts by version (ERR_VERSION) — the same loud contract as every
// prior wire bump.
//
// Compile-time quantization: cell = round(v * scale_q8 / 256) in Q24.8.
// Same .obj + same compiler version = bit-identical cartridge bytes.

/// One parsed triangle (three OBJ vertex positions).
struct Tri([[f64; 3]; 3]);

fn parse_obj(text: &str, path: &str) -> Result<Vec<Tri>, String> {
    let mut verts: Vec<[f64; 3]> = Vec::new();
    let mut tris: Vec<Tri> = Vec::new();
    for (ln, raw) in text.lines().enumerate() {
        let line = raw.trim();
        if line.is_empty() || line.starts_with('#') { continue; }
        let mut it = line.split_whitespace();
        match it.next() {
            Some("v") => {
                let mut c = [0.0f64; 3];
                for k in 0..3 {
                    let t = it.next().ok_or_else(|| format!("{}:{}: 'v' needs x y z", path, ln + 1))?;
                    c[k] = t.parse::<f64>().map_err(|_| format!("{}:{}: bad vertex coordinate '{}'", path, ln + 1, t))?;
                }
                verts.push(c); // w, if present, is ignored (homogeneous 1.0)
            }
            Some("f") => {
                // gather 1-based corner indices (v or v/vt or v/vt/vn or
                // v//vn; negative = relative)
                let mut idx: Vec<i64> = Vec::new();
                for t in it {
                    let corner = t.split('/').next().unwrap_or("");
                    let i: i64 = corner.parse().map_err(|_| {
                        format!("{}:{}: bad face index '{}'", path, ln + 1, t)
                    })?;
                    let n = verts.len() as i64;
                    let abs = if i > 0 { i - 1 } else { n + i };
                    if abs < 0 || abs >= n {
                        return Err(format!("{}:{}: face index {} out of range ({} vertices so far)", path, ln + 1, i, n));
                    }
                    idx.push(abs);
                }
                if idx.len() < 3 {
                    return Err(format!("{}:{}: face needs at least 3 corners, got {}", path, ln + 1, idx.len()));
                }
                // fan triangulation (convex-polygon OBJ convention)
                for k in 1..idx.len() - 1 {
                    tris.push(Tri([
                        verts[idx[0] as usize],
                        verts[idx[k] as usize],
                        verts[idx[k + 1] as usize],
                    ]));
                }
            }
            _ => {} // vn/vt/o/g/s/usemtl/mtllib and anything else: skipped
        }
    }
    if verts.is_empty() {
        return Err(format!("{}: no 'v' vertices found", path));
    }
    if tris.is_empty() {
        return Err(format!("{}: no 'f' faces found (LILA imports triangle/polygon meshes, not point clouds)", path));
    }
    Ok(tris)
}

/// Q24.8 quantize with round-half-away-from-zero (deterministic, and what
/// the fixed literals in hand-written demos read as).
fn quant_fix(v: f64, scale_q8: i32) -> Result<i32, String> {
    let scaled = v * (scale_q8 as f64) / 256.0;
    let r = scaled.round();
    if !r.is_finite() || r < -(2f64.powi(31)) || r >= 2f64.powi(31) {
        return Err(format!("mesh vertex coordinate {} (scaled {}) overflows Q24.8", v, scaled));
    }
    Ok(r as i32)
}

fn lower_meshes(prog: &mut Program, base_dir: &str) -> Result<Vec<(String, String)>, String> {
    if prog.meshes.is_empty() { return Ok(vec![]); }
    let mut rows = Vec::new();
    for m in prog.meshes.drain(..) {
        // resolve relative to the entry source's directory
        let p = std::path::Path::new(base_dir).join(&m.path);
        let text = std::fs::read_to_string(&p).map_err(|e| {
            format!("line {}: mesh '{}': cannot read '{}': {}", m.line, m.name, p.display(), e)
        })?;
        let tris = parse_obj(&text, m.path.as_str())?;
        let ncells = tris.len() * 18;
        // 32768 = the GARR plane in 4B cells (GARR_BYTES 0x20000). The mesh
        // shares the plane with the game's own arrays; the loader enforces
        // the COMBINED budget loudly (ERR_LIMIT_ARRAYS).
        if ncells > 32768 {
            return Err(format!("line {}: mesh '{}': {} triangles = {} cells exceeds the GARR plane (32768 cells) — split the mesh",
                m.line, m.name, tris.len(), ncells));
        }
        let scale_q8 = m.scale.unwrap_or(256);
        // the global array (plain fixed cells, 1-D)
        prog.garrs.push(ArrDecl {
            name: m.name.clone(),
            elem: Ty::Fixed,
            cap: ncells as u32,
            dims: vec![],
            line: m.line,
        });
        // v23.5: bake the quantized cells — no filler fn, no init calls.
        let mut cells: Vec<i32> = Vec::with_capacity(ncells);
        for t in &tris {
            for vtx in &t.0 {
                for k in 0..3 {
                    let q = quant_fix(vtx[k], scale_q8)
                        .map_err(|e| format!("line {}: mesh '{}': {}", m.line, m.name, e))?;
                    cells.push(q);
                }
            }
        }
        prog.baked.push((m.name.clone(), cells));
        rows.push(("mesh".to_string(), format!("'{}' <- {} ({} tris, {} cells, scale {}, baked v6)",
            m.name, m.path, tris.len(), ncells, scale_q8 as f64 / 256.0)));
    }
    Ok(rows)
}

// ============================================================================
// v23.2 STRUCTS — user records, lowered to flattened transparent-memory
// fields BEFORE the checker runs. The checker/codegen/VM/wire-format never
// see a struct; a struct costs exactly its fields' bytes and nothing else.
// ============================================================================
//
//     struct Vec3 { x: fixed  y: fixed  z: fixed }
//     global { v: Vec3   arr Vec3[64] path }
//     entity Ship { pos: Vec3 }
//
// flattens to:
//     global { v.x: fixed  v.y: fixed  v.z: fixed }
//     global { arr fixed[64] "path.x"  arr fixed[64] "path.y" ... }
//     entity Ship { "pos.x": fixed  "pos.y": fixed  "pos.z": fixed }
//
// and every access rewrites:
//     v.x            -> Ident("v.x")
//     path[i].y      -> Index(Ident("path.y"), i)
//     s.pos.z        -> Field(Ident(s), "pos.z")
//     v2 = v         -> one scalar assignment per field (record copy)
//     path[i] = v    -> per-field element copy
//
// Dotted names CANNOT collide with user identifiers ('.' is not an ident
// character), so the flattening is unambiguous by construction. Locals that
// shadow a struct global suppress the rewrite (sequential let-rebind
// semantics — the checker then reports the access against the local's type,
// exactly what the unlowered program would have meant).

use std::collections::{HashMap, HashSet};

struct StructTable {
    /// struct name -> ordered field (name, ty) list
    fields: HashMap<String, Vec<(String, Ty)>>,
    /// struct-global instances: instance name -> struct name
    ginst: HashMap<String, String>,
    /// struct arrays: array name -> (struct name, dims)
    garr: HashMap<String, (String, Vec<u32>)>,
    /// struct-typed entity fields: (entity name, field name) -> struct name
    efield: HashMap<(String, String), String>,
    /// struct-typed entity ARRAYS: (entity name, arr name) -> (struct, dims)
    earr: HashMap<(String, String), (String, Vec<u32>)>,
}

impl StructTable {
    fn field_types(&self, sname: &str) -> Option<&Vec<(String, Ty)>> {
        self.fields.get(sname)
    }
}

pub fn lower_structs(prog: &mut Program) -> Result<Vec<(String, String)>, String> {
    if prog.structs.is_empty() { return Ok(vec![]); }

    // ---- validate + tabulate the declarations ----
    let mut table = StructTable {
        fields: HashMap::new(),
        ginst: HashMap::new(),
        garr: HashMap::new(),
        efield: HashMap::new(),
        earr: HashMap::new(),
    };
    for sd in &prog.structs {
        let flds: Vec<(String, Ty)> = sd.fields.iter().map(|f| (f.name.clone(), f.ty.clone())).collect();
        table.fields.insert(sd.name.clone(), flds);
    }
    // struct field defaults stay usable: flattened globals keep their
    // FieldDecl defaults (per scalar field), arrays start zeroed as always.

    // pools: struct-typed pool fields are rejected (v1: flatten manually)
    for p in &prog.pools {
        for f in &p.fields {
            if matches!(f.ty, Ty::Struct(_)) {
                return Err(format!("line {}: pool '{}' field '{}': structs in pools are not supported yet — declare the scalar fields directly", p.line, p.name, f.name));
            }
        }
    }

    // ---- flatten struct-typed GLOBALS ----
    let mut new_globals: Vec<FieldDecl> = Vec::new();
    for g in prog.globals.drain(..) {
        if let Ty::Struct(sname) = &g.ty {
            if g.default_int.is_some() || g.default_fix.is_some() || g.default_bool.is_some() {
                return Err(format!("struct global '{}' cannot have an initializer — assign its fields in init()", g.name));
            }
            let flds = table.field_types(sname)
                .ok_or_else(|| format!("global '{}': unknown struct '{}'", g.name, sname))?;
            for (fname, fty) in flds {
                new_globals.push(FieldDecl {
                    name: format!("{}.{}", g.name, fname),
                    ty: fty.clone(),
                    default_int: None, default_fix: None, default_bool: None,
                    cold: g.cold,
                });
            }
            table.ginst.insert(g.name, sname.clone());
        } else {
            new_globals.push(g);
        }
    }
    prog.globals = new_globals;

    // ---- flatten struct-typed GLOBAL ARRAYS ----
    let mut new_garrs: Vec<ArrDecl> = Vec::new();
    for a in prog.garrs.drain(..) {
        if let Ty::Struct(sname) = &a.elem {
            let flds = table.field_types(sname)
                .ok_or_else(|| format!("line {}: array '{}': unknown struct '{}'", a.line, a.name, sname))?;
            for (fname, fty) in flds {
                new_garrs.push(ArrDecl {
                    name: format!("{}.{}", a.name, fname),
                    elem: fty.clone(),
                    cap: a.cap, dims: a.dims.clone(), line: a.line,
                });
            }
            table.garr.insert(a.name, (sname.clone(), a.dims.clone()));
        } else {
            new_garrs.push(a);
        }
    }
    prog.garrs = new_garrs;

    // ---- flatten struct-typed ENTITY FIELDS + ENTITY ARRAYS ----
    for ed in prog.entities.iter_mut() {
        let mut new_fields: Vec<FieldDecl> = Vec::new();
        for f in ed.fields.drain(..) {
            if let Ty::Struct(sname) = &f.ty {
                let flds = table.field_types(sname).ok_or_else(|| {
                    format!("entity '{}' field '{}': unknown struct '{}'", ed.name, f.name, sname)
                })?;
                for (fname, fty) in flds {
                    new_fields.push(FieldDecl {
                        name: format!("{}.{}", f.name, fname),
                        ty: fty.clone(),
                        default_int: f.default_int, default_fix: f.default_fix,
                        default_bool: f.default_bool, cold: f.cold,
                    });
                }
                table.efield.insert((ed.name.clone(), f.name.clone()), sname.clone());
            } else {
                new_fields.push(f);
            }
        }
        ed.fields = new_fields;

        let mut new_arrs: Vec<ArrDecl> = Vec::new();
        for a in ed.arrs.drain(..) {
            if let Ty::Struct(sname) = &a.elem {
                let flds = table.field_types(sname).ok_or_else(|| {
                    format!("line {}: entity '{}' array '{}': unknown struct '{}'", a.line, ed.name, a.name, sname)
                })?;
                for (fname, fty) in flds {
                    new_arrs.push(ArrDecl {
                        name: format!("{}.{}", a.name, fname),
                        elem: fty.clone(),
                        cap: a.cap, dims: a.dims.clone(), line: a.line,
                    });
                }
                table.earr.insert((ed.name.clone(), a.name.clone()), (sname.clone(), a.dims.clone()));
            } else {
                new_arrs.push(a);
            }
        }
        ed.arrs = new_arrs;
    }

    // ---- rewrite every fn body ----
    // Shadow suppression: params + lets that share a struct-global's name.
    let mut locals: HashSet<String> = HashSet::new();
    for f in prog.fns.iter_mut() {
        locals.clear();
        for (pn, pt) in &f.params {
            if matches!(pt, Ty::Struct(_)) {
                return Err(format!("line {}: fn '{}': struct-typed parameters are not supported yet — pass fields or use a global", f.line, f.name));
            }
            locals.insert(pn.clone());
        }
        let body = std::mem::take(&mut f.body);
        f.body = lower_block(body, &mut table, &mut locals)?;
    }

    prog.structs.clear();
    Ok(vec![("structs".to_string(), format!("lowered {} struct declarations to flat fields", table.fields.len()))])
}

// ---------------- expression lowering ----------------

fn struct_array_of<'t>(t: &'t StructTable, name: &str) -> Option<&'t (String, Vec<u32>)> {
    if let Some(x) = t.garr.get(name) { return Some(x); }
    None
}

/// Rewrite an expression's struct accesses. Returns Err for value-position
/// uses of whole structs (they don't produce values — fields do).
fn lower_expr(e: &mut Expr, t: &StructTable, locals: &HashSet<String>) -> Result<(), String> {
    match e {
        Expr::Field(base, fname) => {
            // PATTERN 1: `v.f` — struct global instance (not shadowed).
            if let Expr::Ident(v) = &**base {
                if !locals.contains(v) {
                    if let Some(sname) = t.ginst.get(v) {
                        let flds = t.field_types(sname).unwrap();
                        if !flds.iter().any(|(n, _)| n == fname) {
                            return Err(format!("struct '{}' has no field '{}' (fields: {})",
                                sname, fname, flds.iter().map(|(n, _)| n.as_str()).collect::<Vec<_>>().join(", ")));
                        }
                        *e = Expr::Ident(format!("{}.{}", v, fname));
                        return Ok(());
                    }
                }
            }
            // PATTERN 2: `path[i].f` — struct array element (1-D).
            if let Expr::Index(arr, idx) = &**base {
                if let Expr::Ident(a) = &**arr {
                    if t.garr.contains_key(a) && !locals.contains(a) {
                        let sname = t.garr[a].0.clone();
                        let flds = t.field_types(&sname).unwrap();
                        if !flds.iter().any(|(n, _)| n == fname) {
                            return Err(format!("struct '{}' has no field '{}'", sname, fname));
                        }
                        let mut flat_idx = (**idx).clone();
                        lower_expr(&mut flat_idx, t, locals)?;
                        *e = Expr::Index(Box::new(Expr::Ident(format!("{}.{}", a, fname))), Box::new(flat_idx));
                        return Ok(());
                    }
                }
            }
            // PATTERN 2D: `grid[i][j].f` — struct array element (2-D grid).
            if let Expr::Index(arr2, idx2) = &**base {
                if let Expr::Index(arr1, idx1) = &**arr2 {
                    if let Expr::Ident(a) = &**arr1 {
                        if t.garr.contains_key(a) && !locals.contains(a) {
                            if t.garr[a].1.len() == 2 {
                                let sname = t.garr[a].0.clone();
                                let flds = t.field_types(&sname).unwrap();
                                if !flds.iter().any(|(n, _)| n == fname) {
                                    return Err(format!("struct '{}' has no field '{}'", sname, fname));
                                }
                                let mut i1 = (**idx1).clone();
                                let mut i2 = (**idx2).clone();
                                lower_expr(&mut i1, t, locals)?;
                                lower_expr(&mut i2, t, locals)?;
                                let inner = Expr::Index(Box::new(Expr::Ident(format!("{}.{}", a, fname))), Box::new(i1));
                                *e = Expr::Index(Box::new(inner), Box::new(i2));
                                return Ok(());
                            }
                        }
                    }
                }
            }
            // PATTERN 3: `d.pos.f` — struct-typed ENTITY field. Any entity
            // that owns a struct field named `pos` qualifies; a non-struct
            // `pos` would have been ill-typed before this pass anyway, so
            // the blanket rewrite only ever moves WHERE the error fires.
            if let Expr::Field(inner, sname) = &**base {
                if matches!(&**inner, Expr::Ident(_)) {
                    if t.efield.keys().any(|(_, f)| f == sname) {
                        *e = Expr::Field((*inner).clone(), format!("{}.{}", sname, fname));
                        return Ok(());
                    }
                }
            }
            // PATTERN 4: `d.path[i].f` — struct-typed ENTITY array element.
            if let Expr::Index(arr, idx) = &**base {
                if let Expr::Field(inner, sname) = &**arr {
                    if matches!(&**inner, Expr::Ident(_)) {
                        if t.earr.keys().any(|(_, f)| f == sname) {
                            let mut flat_idx = (**idx).clone();
                            lower_expr(&mut flat_idx, t, locals)?;
                            *e = Expr::Index(
                                Box::new(Expr::Field((*inner).clone(), format!("{}.{}", sname, fname))),
                                Box::new(flat_idx),
                            );
                            return Ok(());
                        }
                    }
                }
            }
            // none of the struct patterns: ordinary field access — recurse.
            lower_expr(base, t, locals)
        }
        Expr::Index(a, idx) => {
            // whole-struct VALUE use (`let q = path[i];`) — reject loudly.
            // (Field/Index bases of struct patterns never reach here: the
            // Field arm rewrites them before recursing.)
            if let Expr::Ident(a_name) = &**a {
                if t.garr.contains_key(a_name) && !locals.contains(a_name) {
                    return Err(format!("array '{}' holds structs, which do not produce values — read a field ('{}[i].x') or copy whole elements with assignment", a_name, a_name));
                }
            }
            lower_expr(a, t, locals)?;
            lower_expr(idx, t, locals)
        }
        Expr::Ident(v) => {
            // whole-struct VALUE use (`let q = v;`) — reject loudly.
            if !locals.contains(v) {
                if let Some(sname) = t.ginst.get(v) {
                    return Err(format!("struct '{}' does not produce a value — read a field ('{}.x') or assign whole records to another '{}' record", sname, v, sname));
                }
            }
            Ok(())
        }
        Expr::Unary(_, a) => lower_expr(a, t, locals),
        Expr::Binary(_, a, b) => {
            lower_expr(a, t, locals)?;
            lower_expr(b, t, locals)
        }
        Expr::Ternary(c, a, b) => {
            lower_expr(c, t, locals)?;
            lower_expr(a, t, locals)?;
            lower_expr(b, t, locals)
        }
        Expr::Call(_, args) | Expr::Intrin(_, _, args, _) => {
            for a in args.iter_mut() { lower_expr(a, t, locals)?; }
            Ok(())
        }
        Expr::IntLit(_) | Expr::FixLit(_) | Expr::F32Lit(_) | Expr::F64Lit(_)
        | Expr::BoolLit(_) | Expr::Atom(_) => Ok(()),
    }
}

// ---------------- statement lowering (with record-copy rewrites) ----------------

/// Is this assignment a WHOLE-RECORD copy? Returns the (dst, src) shape:
///   * Record(Ident dst, Ident src)                v2 = v
///   * RecordElem(dst place, Ident src)            path[i] = v
///   * Record(dst place, Elem(src place))          v = path[i]
///   * RecordElem(dst, Elem(src))                  path2[j] = path[i]
enum CopyShape {
    Records(Expr, Expr),
    RecordElem(Expr, Expr),
    ElemRecord(Expr, Expr),
    ElemElem(Expr, Expr),
}

fn copy_shape(dst: &Expr, src: &Expr, t: &StructTable, locals: &HashSet<String>) -> Option<CopyShape> {
    let is_rec_ident = |e: &Expr| matches!(e, Expr::Ident(v) if t.ginst.contains_key(v) && !locals.contains(v));
    let is_rec_elem = |e: &Expr| matches!(e, Expr::Index(b, _) if matches!(&**b, Expr::Ident(a) if t.garr.contains_key(a) && !locals.contains(a)));
    match (dst, src) {
        (d, s) if is_rec_ident(d) && is_rec_ident(s) => Some(CopyShape::Records(d.clone(), s.clone())),
        (d, s) if is_rec_elem(d) && is_rec_ident(s) => Some(CopyShape::RecordElem(d.clone(), s.clone())),
        (d, s) if is_rec_ident(d) && is_rec_elem(s) => Some(CopyShape::ElemRecord(d.clone(), s.clone())),
        (d, s) if is_rec_elem(d) && is_rec_elem(s) => Some(CopyShape::ElemElem(d.clone(), s.clone())),
        _ => None,
    }
}

/// Rewrite one field access of a whole-record PLACE (ident or element).
fn place_field(place: &Expr, fname: &str, _t: &StructTable, _locals: &HashSet<String>) -> Result<Expr, String> {
    Ok(match place {
        Expr::Ident(v) => Expr::Ident(format!("{}.{}", v, fname)),
        Expr::Index(b, idx) => {
            let Expr::Ident(a) = &**b else { unreachable!("copy_shape validated") };
            Expr::Index(Box::new(Expr::Ident(format!("{}.{}", a, fname))), idx.clone())
        }
        _ => unreachable!("copy_shape validated"),
    })
}

fn lower_block(stmts: Vec<Stmt>, t: &mut StructTable, locals: &mut HashSet<String>) -> Result<Vec<Stmt>, String> {
    let mut out: Vec<Stmt> = Vec::with_capacity(stmts.len());
    for mut s in stmts {
        // unwrap At so scope updates run in source order, re-wrap on emit
        let (line, col, inner) = match s {
            Stmt::At { line, col, inner } => (line, col, *inner),
            other => (0, 0, other),
        };
        let lowered = lower_stmt(inner, t, locals, line, col)?;
        out.extend(lowered);
    }
    Ok(out)
}

fn lower_stmt(s: Stmt, t: &mut StructTable, locals: &mut HashSet<String>, line: u32, col: u32) -> Result<Vec<Stmt>, String> {
    match s {
        Stmt::Let(name, mut e) => {
            lower_expr(&mut e, t, locals)?;
            // let rebinds: a later use targets the LOCAL, so the shadow set
            // gains the name from here on (sequential semantics preserved).
            locals.insert(name.clone());
            Ok(vec![Stmt::At { line, col, inner: Box::new(Stmt::Let(name, e)) }])
        }
        Stmt::Assign(mut target, op, mut val) => {
            if op == crate::ast::AssignOp::Set {
                if let Some(shape) = copy_shape(&target, &val, t, locals) {
                    // whole-record copy: per-field expansion (a compound op
                    // on records is meaningless — fall through to the
                    // expression rewriter, which rejects value-position
                    // structs with a clean message)
                    let flds_src = match &shape {
                        CopyShape::Records(_, s) | CopyShape::RecordElem(_, s) | CopyShape::ElemRecord(_, s) | CopyShape::ElemElem(_, s) => s.clone(),
                    };
                    let _ = flds_src;
                    // determine the struct name once from the DST side
                    let sname = match &target {
                        Expr::Ident(v) if t.ginst.contains_key(v) => t.ginst[v].clone(),
                        Expr::Index(b, _) => match &**b {
                            Expr::Ident(a) if t.garr.contains_key(a) => t.garr[a].0.clone(),
                            _ => unreachable!("copy_shape validated"),
                        },
                        _ => unreachable!("copy_shape validated"),
                    };
                    let flds = t.field_types(&sname).unwrap().clone();
                    let mut out = Vec::with_capacity(flds.len());
                    for (fname, _fty) in &flds {
                        let mut dst_f = place_field(&target, fname, t, locals)?;
                        let mut src_f = place_field(&val, fname, t, locals)?;
                        lower_expr(&mut dst_f, t, locals)?;
                        lower_expr(&mut src_f, t, locals)?;
                        out.push(Stmt::At { line, col, inner: Box::new(Stmt::Assign(dst_f, crate::ast::AssignOp::Set, src_f)) });
                    }
                    return Ok(out);
                }
            }
            lower_expr(&mut target, t, locals)?;
            lower_expr(&mut val, t, locals)?;
            Ok(vec![Stmt::At { line, col, inner: Box::new(Stmt::Assign(target, op, val)) }])
        }
        Stmt::If(mut c, a, b) => {
            lower_expr(&mut c, t, locals)?;
            let a = lower_block(a, t, locals)?;
            let b = lower_block(b, t, locals)?;
            Ok(vec![Stmt::At { line, col, inner: Box::new(Stmt::If(c, a, b)) }])
        }
        Stmt::While(mut c, b) => {
            lower_expr(&mut c, t, locals)?;
            let b = lower_block(b, t, locals)?;
            Ok(vec![Stmt::At { line, col, inner: Box::new(Stmt::While(c, b)) }])
        }
        Stmt::For(v, ty, b) => {
            locals.insert(v.clone());
            let b = lower_block(b, t, locals)?;
            Ok(vec![Stmt::At { line, col, inner: Box::new(Stmt::For(v, ty, b)) }])
        }
        Stmt::ForNum(v, mut a, mut b, body) => {
            lower_expr(&mut a, t, locals)?;
            lower_expr(&mut b, t, locals)?;
            locals.insert(v.clone());
            let body = lower_block(body, t, locals)?;
            Ok(vec![Stmt::At { line, col, inner: Box::new(Stmt::ForNum(v, a, b, body)) }])
        }
        Stmt::ForMask(v, ty, m, b) => {
            locals.insert(v.clone());
            let b = lower_block(b, t, locals)?;
            Ok(vec![Stmt::At { line, col, inner: Box::new(Stmt::ForMask(v, ty, m, b)) }])
        }
        Stmt::Switch(mut scrut, arms, dflt) => {
            lower_expr(&mut scrut, t, locals)?;
            let mut new_arms = Vec::with_capacity(arms.len());
            for (labels, body) in arms {
                new_arms.push((labels, lower_block(body, t, locals)?));
            }
            let dflt = match dflt {
                Some(d) => Some(lower_block(d, t, locals)?),
                None => None,
            };
            Ok(vec![Stmt::At { line, col, inner: Box::new(Stmt::Switch(scrut, new_arms, dflt)) }])
        }
        Stmt::TryCatch { body, catch_var, catch_body } => {
            let body = lower_block(body, t, locals)?;
            locals.insert(catch_var.clone());
            let catch_body = lower_block(catch_body, t, locals)?;
            Ok(vec![Stmt::At { line, col, inner: Box::new(Stmt::TryCatch { body, catch_var, catch_body }) }])
        }
        Stmt::Spawn(ty, mut inits) => {
            // struct-typed spawn inits are rejected (set flattened fields
            // after spawn); everything else rewrites normally
            for (fname, e) in inits.iter_mut() {
                let mut e2 = e.clone();
                lower_expr(&mut e2, t, locals)?;
                *e = e2;
            }
            Ok(vec![Stmt::At { line, col, inner: Box::new(Stmt::Spawn(ty, inits)) }])
        }
        Stmt::State(name, b) => {
            let b = lower_block(b, t, locals)?;
            Ok(vec![Stmt::At { line, col, inner: Box::new(Stmt::State(name, b)) }])
        }
        mut other => {
            // remaining statement shapes: rewrite their expressions in place
            lower_stmt_exprs(&mut other, t, locals)?;
            Ok(vec![if line == 0 && col == 0 { other } else { Stmt::At { line, col, inner: Box::new(other) } }])
        }
    }
}

/// Rewrite the expressions of statements not covered by lower_stmt's
/// structural arms (draw/cam/rig/collections/...). Any variant carrying
/// Exprs gets them rewritten; the rest pass through.
fn lower_stmt_exprs(s: &mut Stmt, t: &StructTable, locals: &HashSet<String>) -> Result<(), String> {
    match s {
        Stmt::Kill(e) | Stmt::PoolRemove(e) | Stmt::Wait(e) | Stmt::Throw(e) => lower_expr(e, t, locals),
        Stmt::Cam3(a, b, c, d, e) => {
            for x in [a, b, c, d, e] { lower_expr(x, t, locals)?; }
            Ok(())
        }
        Stmt::Draw3d { n, x, y, z, yaw, rgba, .. } => {
            for x2 in [n, x, y, z, yaw, rgba] { lower_expr(x2, t, locals)?; }
            Ok(())
        }
        Stmt::Draw3DI { nv, ni, x, y, z, yaw, rgba, .. } => {
            for x2 in [nv, ni, x, y, z, yaw, rgba] { lower_expr(x2, t, locals)?; }
            Ok(())
        }
        Stmt::QuatAA { off, ax, ay, az, ang, .. } => {
            for x in [off, ax, ay, az, ang] { lower_expr(x, t, locals)?; }
            Ok(())
        }
        Stmt::QMul { doff, aoff, boff, .. } | Stmt::M4Mul { doff, aoff, boff, .. } => {
            for x in [doff, aoff, boff] { lower_expr(x, t, locals)?; }
            Ok(())
        }
        Stmt::M4QT { moff, qoff, tx, ty, tz, .. } => {
            for x in [moff, qoff, tx, ty, tz] { lower_expr(x, t, locals)?; }
            Ok(())
        }
        Stmt::SkinV { voff, moff, x, y, z, .. } => {
            for x in [voff, moff, x, y, z] { lower_expr(x, t, locals)?; }
            Ok(())
        }
        Stmt::M4Look { moff, ex, ey, ez, tx, ty, tz, .. } => {
            for x in [moff, ex, ey, ez, tx, ty, tz] { lower_expr(x, t, locals)?; }
            Ok(())
        }
        Stmt::Camera(a, b) | Stmt::Save(a, b) => {
            lower_expr(a, t, locals)?;
            lower_expr(b, t, locals)
        }
        Stmt::Draw(_, a, b, c, d, e) => {
            for x in [a, b, c, d, e] { lower_expr(x, t, locals)?; }
            Ok(())
        }
        Stmt::DrawText(_, a, b, c) => {
            for x in [a, b, c] { lower_expr(x, t, locals)?; }
            Ok(())
        }
        Stmt::DrawNum(a, b, c, d) => {
            for x in [a, b, c, d] { lower_expr(x, t, locals)?; }
            Ok(())
        }
        Stmt::DrawNumZ(a, _, b, c, d) => {
            for x in [a, b, c, d] { lower_expr(x, t, locals)?; }
            Ok(())
        }
        Stmt::CallStmt(_, args) => {
            for a in args.iter_mut() { lower_expr(a, t, locals)?; }
            Ok(())
        }
        Stmt::CallTable(_, k, _) => lower_expr(k, t, locals),
        Stmt::Return(Some(e)) => lower_expr(e, t, locals),
        Stmt::MapPut(_, k, v) => {
            lower_expr(k, t, locals)?;
            lower_expr(v, t, locals)
        }
        Stmt::MapDel(_, k) => lower_expr(k, t, locals),
        Stmt::QPush(_, v) | Stmt::SPush(_, v) | Stmt::AFill(_, v) | Stmt::AShuf(_, v) => lower_expr(v, t, locals),
        Stmt::ACopy(_, _, n) => lower_expr(n, t, locals),
        _ => Ok(()),
    }
}

// ============================================================================
// v20 MIXINS — C++ composition / Unity component analog
// ============================================================================

/// Splice `mixin` field groups into the entities that `use` them.
/// Composition is compile-time only: after this pass no mixin, no `use`
/// remains — the checker, SoA packer and codegen see one flat field list
/// (zero runtime bytes, zero layout surprises). Mixins may compose other
/// mixins; cycles and duplicate field names are loud build errors.
fn apply_mixins(prog: &mut Program) -> Result<Vec<(String, String)>, String> {
    if prog.mixins.is_empty() {
        return Ok(Vec::new());
    }
    // 1. resolve mixin-uses-mixin chains (memoized, cycle-checked).
    let n = prog.mixins.len();
    let mut resolved: Vec<Option<Vec<FieldDecl>>> = vec![None; n];
    for i in 0..n {
        resolve_mixin(prog, i, &mut resolved, &mut Vec::new())?;
    }
    // 2. splice into entities: use-order fields first, then the entity's
    //    own fields (matches reading order). Duplicates are errors — a
    //    mixin is a composition, not an override (that's `from:` prefabs).
    let mut rows = Vec::new();
    for ei in 0..prog.entities.len() {
        if prog.entities[ei].uses.is_empty() {
            continue;
        }
        let uses = prog.entities[ei].uses.clone();
        let mut merged: Vec<FieldDecl> = Vec::new();
        let mut sources: Vec<String> = Vec::new();
        for uname in &uses {
            let mi = prog.mixins.iter().position(|m| &m.name == uname).ok_or_else(|| {
                format!("entity '{}': unknown mixin '{}' (declared later is fine, missing is not)",
                        prog.entities[ei].name, uname)
            })?;
            for f in resolved[mi].clone().unwrap_or_default() {
                if merged.iter().any(|m| m.name == f.name) {
                    return Err(format!(
                        "entity '{}': field '{}' is provided twice by mixins ({}) — composition must be disjoint",
                        prog.entities[ei].name, f.name, uses.join(", ")));
                }
                merged.push(f);
            }
            sources.push(uname.clone());
        }
        for f in prog.entities[ei].fields.clone() {
            if merged.iter().any(|m| m.name == f.name) {
                return Err(format!(
                    "entity '{}': field '{}' already provided by mixin(s) {} — rename it or drop it from the mixin",
                    prog.entities[ei].name, f.name, sources.join(", ")));
            }
            merged.push(f);
        }
        rows.push((
            format!("mixin {}", prog.entities[ei].name),
            format!("{} fields from [{}] — composed away, 0 runtime bytes",
                    merged.len(), sources.join(", ")),
        ));
        prog.entities[ei].fields = merged;
        prog.entities[ei].uses.clear();
    }
    prog.mixins.clear();
    Ok(rows)
}

fn resolve_mixin(
    prog: &Program,
    i: usize,
    memo: &mut Vec<Option<Vec<FieldDecl>>>,
    visiting: &mut Vec<usize>,
) -> Result<Vec<FieldDecl>, String> {
    if let Some(r) = &memo[i] {
        return Ok(r.clone());
    }
    if visiting.contains(&i) {
        return Err(format!("mixin '{}': composes itself (cycle)", prog.mixins[i].name));
    }
    visiting.push(i);
    let mut fields: Vec<FieldDecl> = Vec::new();
    for uname in prog.mixins[i].uses.clone() {
        let mi = prog.mixins.iter().position(|m| m.name == uname).ok_or_else(|| {
            format!("mixin '{}': unknown mixin '{}'", prog.mixins[i].name, uname)
        })?;
        for f in resolve_mixin(prog, mi, memo, visiting)? {
            if fields.iter().any(|x| x.name == f.name) {
                return Err(format!("mixin '{}': field '{}' provided twice", prog.mixins[i].name, f.name));
            }
            fields.push(f);
        }
    }
    visiting.pop();
    for f in prog.mixins[i].fields.clone() {
        if fields.iter().any(|x| x.name == f.name) {
            return Err(format!("mixin '{}': field '{}' provided twice", prog.mixins[i].name, f.name));
        }
        fields.push(f);
    }
    memo[i] = Some(fields.clone());
    Ok(fields)
}

// ============================================================================
// 1. PREFAB INHERITANCE
// ============================================================================

fn resolve_prefabs(prog: &mut Program) -> Result<Vec<(String, String)>, String> {
    let n = prog.entities.len();
    let mut resolved: Vec<Option<(Vec<FieldDecl>, Vec<ArrDecl>, Option<String>)>> = vec![None; n];
    let mut visiting: Vec<usize> = Vec::new();

    for i in 0..n {
        resolve_one(prog, i, &mut resolved, &mut visiting)?;
    }
    // write the merged forms back (from: cleared — nothing downstream sees it)
    let mut rows = Vec::new();
    for (i, r) in resolved.into_iter().enumerate() {
        if let Some((fields, arrs, fsm)) = r {
            if prog.entities[i].from.is_none() {
                continue; // not a prefab (no parent): nothing to report
            }
            let parent = prog.entities[i].from.clone().unwrap_or_default();
            prog.entities[i].fields = fields;
            prog.entities[i].arrs = arrs;
            prog.entities[i].fsm = fsm;
            prog.entities[i].from = None;
            rows.push((
                format!("prefab {}", prog.entities[i].name),
                format!(
                    "{} fields merged from '{}' — inheritance compiled away, 0 runtime bytes",
                    prog.entities[i].fields.len(),
                    parent
                ),
            ));
        }
    }
    Ok(rows)
}

fn resolve_one(
    prog: &mut Program,
    i: usize,
    memo: &mut Vec<Option<(Vec<FieldDecl>, Vec<ArrDecl>, Option<String>)>>,
    visiting: &mut Vec<usize>,
) -> Result<(Vec<FieldDecl>, Vec<ArrDecl>, Option<String>), String> {
    if let Some(r) = &memo[i] {
        return Ok(r.clone());
    }
    let parent_name = prog.entities[i].from.clone();
    let (fields, arrs, fsm) = match parent_name {
        None => (
            prog.entities[i].fields.clone(),
            prog.entities[i].arrs.clone(),
            prog.entities[i].fsm.clone(),
        ),
        Some(pname) => {
            if visiting.contains(&i) {
                return Err(format!(
                    "prefab cycle: entity '{}' inherits through itself",
                    prog.entities[i].name
                ));
            }
            let pi = prog.entities.iter().position(|e| e.name == pname).ok_or_else(|| {
                format!(
                    "entity '{}': unknown prefab parent '{}' (declared later is fine, missing is not)",
                    prog.entities[i].name, pname
                )
            })?;
            visiting.push(i);
            let (mut merged, mut merged_arrs, pfsm) = resolve_one(prog, pi, memo, visiting)?;
            visiting.pop();
            // child fields: same-name = default override (type must match),
            // new names append in child order.
            for f in prog.entities[i].fields.clone() {
                if let Some(p) = merged.iter_mut().find(|p| p.name == f.name) {
                    if std::mem::discriminant(&p.ty) != std::mem::discriminant(&f.ty)
                        || p.ty != f.ty
                    {
                        return Err(format!(
                            "entity '{}': field '{}' must keep parent type {:?} (got {:?})",
                            prog.entities[i].name, f.name, p.ty, f.ty
                        ));
                    }
                    *p = f;
                } else {
                    merged.push(f);
                }
            }
            // v11 ARRAYS: prefab inheritance merges arrays the same way —
            // same (name, elem, cap) = redeclaration is fine, anything else
            // that clashes is a build error (arrays have no defaults to
            // override: capacity IS the type).
            for a in prog.entities[i].arrs.clone() {
                if let Some(p) = merged_arrs.iter_mut().find(|p| p.name == a.name) {
                    if p.elem != a.elem || p.cap != a.cap {
                        return Err(format!(
                            "entity '{}': array '{}' must keep parent type/capacity {:?}[{}] (got {:?}[{}])",
                            prog.entities[i].name, a.name, p.elem, p.cap, a.elem, a.cap
                        ));
                    }
                } else {
                    merged_arrs.push(a);
                }
            }
            (merged, merged_arrs, prog.entities[i].fsm.clone().or(pfsm))
        }
    };
    memo[i] = Some((fields.clone(), arrs.clone(), fsm.clone()));
    Ok((fields, arrs, fsm))
}

// ============================================================================
// 2. DECLARATIVE PARTICLES
// ============================================================================

fn width_for(v: u32) -> u8 {
    let mut w: u8 = 4;
    while w < 16 && (v as u64) >= (1u64 << w) {
        w += 1;
    }
    w
}

fn lower_particles(prog: &mut Program, atom_names: &[String]) -> Result<Vec<(String, String)>, String> {
    let mut rows: Vec<(String, String)> = Vec::new();
    if prog.particles.is_empty() {
        return Ok(rows);
    }
    let mut decls: Vec<(ParticleDecl, String)> = Vec::new();
    for pd in &prog.particles {
        let name = atom_names
            .get(pd.atom as usize)
            .cloned()
            .ok_or_else(|| format!("particles: unknown atom #{}", pd.atom))?;
        if prog.entities.iter().any(|e| e.name == name) {
            return Err(format!(
                "particles #{}: entity '{}' already exists — rename the particle atom",
                name, name
            ));
        }
        decls.push((pd.clone(), name));
    }

    for (pd, name) in decls {
        let f = |s: &str| format!("{}_{}", name, s); // field namer: boomfx_x ...
        let fx = f("x");
        let fy = f("y");
        let fvx = f("vx");
        let fvy = f("vy");
        let ft = f("t");

        // ---- entity: x/y/vx/vy fixed + ttl countdown ----
        prog.entities.push(EntityDecl {
            name: name.clone(),
            fields: vec![
                FieldDecl { name: fx.clone(), ty: Ty::Fixed, default_int: None, default_fix: Some(0), default_bool: None, cold: false },
                FieldDecl { name: fy.clone(), ty: Ty::Fixed, default_int: None, default_fix: Some(0), default_bool: None, cold: false },
                FieldDecl { name: fvx.clone(), ty: Ty::Fixed, default_int: None, default_fix: Some(0), default_bool: None, cold: false },
                FieldDecl { name: fvy.clone(), ty: Ty::Fixed, default_int: None, default_fix: Some(0), default_bool: None, cold: false },
                FieldDecl {
                    name: ft.clone(),
                    ty: Ty::UInt(width_for(pd.life)),
                    default_int: Some(pd.life as i64),
                    default_fix: None,
                    default_bool: None,
                    cold: false,
                },
            ],
            fsm: None,
            from: None,
            max_live_override: Some(pd.cap),
            arrs: Vec::new(),
            uses: Vec::new(), body: None,
        });

        // ---- emit_<name>(ex, ey): burst spawns, deterministic LCG angle ----
        // let i = 0; while (i < burst) {
        //     let a  = rand(4096);
        //     let sp = speed * (256 - rand(jitter));   // Q8: exact speed at jitter 0
        //     spawn <name> { x: ex, y: ey, vx: sin(ang(a))*sp, vy: cos(ang(a))*sp, t: life };
        //     i += 1;
        // }
        let mut loop_body = vec![
            Stmt::Let("a".into(), Expr::Call("rand".into(), vec![Expr::IntLit(4096)])),
            Stmt::Let(
                "sp".into(),
                Expr::Binary(
                    BinOp::Mul,
                    Box::new(Expr::FixLit(pd.speed_fix)),
                    Box::new(Expr::Binary(
                        BinOp::Sub,
                        Box::new(Expr::IntLit(256)),
                        Box::new(Expr::Call("rand".into(), vec![Expr::IntLit(pd.jitter_q8)])),
                    )),
                ),
            ),
            Stmt::Spawn(
                name.clone(),
                vec![
                    (fx.clone(), Expr::Ident("ex".into())),
                    (fy.clone(), Expr::Ident("ey".into())),
                    (
                        fvx.clone(),
                        Expr::Binary(
                            BinOp::Mul,
                            Box::new(Expr::Call(
                                "sin".into(),
                                vec![Expr::Call("ang".into(), vec![Expr::Ident("a".into())])],
                            )),
                            Box::new(Expr::Ident("sp".into())),
                        ),
                    ),
                    (
                        fvy.clone(),
                        Expr::Binary(
                            BinOp::Mul,
                            Box::new(Expr::Call(
                                "cos".into(),
                                vec![Expr::Call("ang".into(), vec![Expr::Ident("a".into())])],
                            )),
                            Box::new(Expr::Ident("sp".into())),
                        ),
                    ),
                    (ft.clone(), Expr::IntLit(pd.life)),
                ],
            ),
            Stmt::Assign(Expr::Ident("i".into()), AssignOp::Add, Expr::IntLit(1)),
        ];
        // jitter: 0 lowers to no rand call at all (constant speed, less code)
        if pd.jitter_q8 == 0 {
            loop_body[1] = Stmt::Let("sp".into(), Expr::FixLit(pd.speed_fix));
        }
        prog.fns.push(FnDecl {
            name: format!("emit_{}", name),
            params: vec![("ex".into(), Ty::Fixed), ("ey".into(), Ty::Fixed)],
            body: vec![
                Stmt::Let("i".into(), Expr::IntLit(0)),
                Stmt::While(
                    Expr::Binary(BinOp::Lt, Box::new(Expr::Ident("i".into())), Box::new(Expr::IntLit(pd.burst))),
                    loop_body,
                ),
                Stmt::Return(None),
            ],
            line: 0, every: None,
        });

        // ---- update(e: name): drag -> gravity -> ttl -> kill ----
        let ef = |s: &str| Expr::Field(Box::new(Expr::Ident("e".into())), s.to_string());
        let mut body: Vec<Stmt> = Vec::new();
        if pd.drag_q8 != 256 {
            // vx *= drag (Q8 multiply — exact no-op at 256, skipped above)
            body.push(Stmt::Assign(
                ef(&fvx),
                AssignOp::Set,
                Expr::Binary(BinOp::Mul, Box::new(ef(&fvx)), Box::new(Expr::IntLit(pd.drag_q8))),
            ));
            let vy = Expr::Binary(BinOp::Mul, Box::new(ef(&fvy)), Box::new(Expr::IntLit(pd.drag_q8)));
            body.push(Stmt::Assign(
                ef(&fvy),
                AssignOp::Set,
                if pd.grav_fix != 0 {
                    Expr::Binary(BinOp::Add, Box::new(vy), Box::new(Expr::FixLit(pd.grav_fix)))
                } else {
                    vy
                },
            ));
        } else if pd.grav_fix != 0 {
            body.push(Stmt::Assign(ef(&fvy), AssignOp::Add, Expr::FixLit(pd.grav_fix)));
        }
        body.push(Stmt::Assign(ef(&ft), AssignOp::Sub, Expr::IntLit(1)));
        body.push(Stmt::If(
            Expr::Binary(BinOp::Eq, Box::new(ef(&ft)), Box::new(Expr::IntLit(0))),
            vec![Stmt::Kill(Expr::Ident("e".into()))],
            vec![],
        ));
        prog.fns.push(FnDecl {
            name: "update".into(),
            params: vec![("e".into(), Ty::Entity(name.clone()))],
            body,
            line: 0, every: None,
        });

        // ---- draw(e: name): sprite, ttl-driven scale + alpha fade ----
        // draw(#sprite, e.x, e.y, ang(0), scale, color | ((t*255)/life)<<24)
        // scale MUST be a FIXED-typed expr: (t * 1.0) / life lowers to
        // mulF(t,256)=t then divF(t,life) = t*256/life Q8 — an int-typed
        // form would get an extra I2F (x256) from the int->fixed widening.
        let scale: Expr = if pd.fade {
            Expr::Binary(
                BinOp::Div,
                Box::new(Expr::Binary(
                    BinOp::Mul,
                    Box::new(ef(&ft)),
                    Box::new(Expr::FixLit(256)),
                )),
                Box::new(Expr::IntLit(pd.life)),
            )
        } else {
            Expr::FixLit(256)
        };
        let rgba: Expr = if pd.fade {
            Expr::Binary(
                BinOp::Or,
                Box::new(Expr::IntLit(pd.color)),
                Box::new(Expr::Binary(
                    BinOp::Shl,
                    Box::new(Expr::Binary(
                        BinOp::Div,
                        Box::new(Expr::Binary(
                            BinOp::Mul,
                            Box::new(ef(&ft)),
                            Box::new(Expr::IntLit(255)),
                        )),
                        Box::new(Expr::IntLit(pd.life)),
                    )),
                    Box::new(Expr::IntLit(24)),
                )),
            )
        } else {
            Expr::IntLit(pd.color | 0xFF000000)
        };
        prog.fns.push(FnDecl {
            name: "draw".into(),
            params: vec![("e".into(), Ty::Entity(name.clone()))],
            body: vec![Stmt::Draw(
                pd.sprite,
                ef(&fx),
                ef(&fy),
                Expr::Call("ang".into(), vec![Expr::IntLit(0)]),
                scale,
                rgba,
            )],
            line: 0, every: None,
        });
        rows.push((
            format!("particles #{}", name),
            format!(
                "{} slots, burst {}, life {}f — entity + emit/update/draw synthesized (drag {:.2}, grav {:.2}); 0 runtime bytes, 0 new opcodes",
                pd.cap, pd.burst, pd.life,
                pd.drag_q8 as f32 / 256.0,
                pd.grav_fix as f32 / 256.0
            ),
        ));
    }
    Ok(rows)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn field(name: &str, ty: Ty, fix: i32) -> FieldDecl {
        FieldDecl { name: name.into(), ty, default_int: None, default_fix: Some(fix), default_bool: None, cold: false }
    }

    fn prog_with(entities: Vec<EntityDecl>) -> Program {
        Program { entities, ..Default::default() }
    }

    /// Child inherits every parent field; overrides swap defaults; new
    /// fields append; `from` is cleared so downstream sees flat entities.
    #[test]
    fn prefab_inherits_overrides_and_appends() {
        let mut p = prog_with(vec![
            EntityDecl {
                name: "Drone".into(),
                fields: vec![field("x", Ty::Fixed, 0), field("hp", Ty::UInt(4), 3)],
                fsm: None, from: None, max_live_override: None, arrs: Vec::new(), uses: Vec::new(), body: None,
            },
            EntityDecl {
                name: "FastDrone".into(),
                fields: vec![field("hp", Ty::UInt(4), 1), field("boost", Ty::Fixed, 128)],
                fsm: None,
                from: Some("Drone".into()),
                max_live_override: None,
                arrs: Vec::new(), uses: Vec::new(),
                body: None,
            },
        ]);
        let rows = expand(&mut p, &[], ".").unwrap();
        assert_eq!(rows.len(), 1, "one prefab row reported");
        let fd = &p.entities[1];
        assert!(fd.from.is_none(), "inheritance must be compiled away");
        assert_eq!(fd.fields.len(), 3, "x + hp + boost");
        assert_eq!(fd.fields[0].name, "x", "parent field first, parent default");
        assert_eq!(fd.fields[0].default_fix, Some(0));
        assert_eq!(fd.fields[1].name, "hp");
        assert_eq!(fd.fields[1].default_fix, Some(1), "child default overrides");
        assert_eq!(fd.fields[2].name, "boost", "new field appended");
        // parent untouched
        assert_eq!(p.entities[0].fields.len(), 2);
    }

    /// Forward references work (parent declared after the child) and unknown
    /// parents are loud build errors.
    #[test]
    fn prefab_forward_reference_and_unknown_parent() {
        let mut p = prog_with(vec![
            EntityDecl {
                name: "B".into(),
                fields: vec![field("v", Ty::Fixed, 5)],
                fsm: None,
                from: Some("A".into()),
                max_live_override: None,
                arrs: Vec::new(), uses: Vec::new(),
                body: None,
            },
            EntityDecl {
                name: "A".into(),
                fields: vec![field("x", Ty::Fixed, 0)],
                fsm: None, from: None, max_live_override: None, arrs: Vec::new(), uses: Vec::new(), body: None,
            },
        ]);
        expand(&mut p, &[], ".").unwrap();
        assert_eq!(p.entities[0].fields.len(), 2);
        assert_eq!(p.entities[0].fields[0].name, "x");

        let mut bad = prog_with(vec![EntityDecl {
            name: "C".into(), fields: vec![], fsm: None,
            from: Some("Ghost".into()), max_live_override: None, arrs: Vec::new(), uses: Vec::new(), body: None,
        }]);
        assert!(expand(&mut bad, &[], ".").is_err(), "unknown parent must fail the build");
    }

    /// Cycles are rejected (A from B from A) — not infinite-looped.
    #[test]
    fn prefab_cycle_rejected() {
        let mut p = prog_with(vec![
            EntityDecl {
                name: "A".into(), fields: vec![], fsm: None,
                from: Some("B".into()), max_live_override: None, arrs: Vec::new(), uses: Vec::new(), body: None,
            },
            EntityDecl {
                name: "B".into(), fields: vec![], fsm: None,
                from: Some("A".into()), max_live_override: None, arrs: Vec::new(), uses: Vec::new(), body: None,
            },
        ]);
        assert!(expand(&mut p, &[], ".").is_err());
    }

    /// A particles decl lowers to entity + emit_ helper + update + draw;
    /// field names are atom-prefixed so they cannot collide with user
    /// fields; the ttl width fits the lifetime; the capacity override rides
    /// along for the checker.
    #[test]
    fn particles_lower_to_entity_and_fns() {
        let mut p = Program::default();
        p.particles.push(ParticleDecl {
            atom: 0,
            cap: 192,
            sprite: 3,
            life: 22,
            speed_fix: 460,
            jitter_q8: 0,
            drag_q8: 235,
            grav_fix: 32,
            burst: 12,
            color: 0xFFB040,
            fade: true,
        });
        expand(&mut p, &["boomfx".to_string()], ".").unwrap();
        assert_eq!(p.entities.len(), 1);
        let e = &p.entities[0];
        assert_eq!(e.name, "boomfx");
        assert_eq!(e.max_live_override, Some(192));
        let names: Vec<&str> = e.fields.iter().map(|f| f.name.as_str()).collect();
        assert_eq!(names, vec!["boomfx_x", "boomfx_y", "boomfx_vx", "boomfx_vy", "boomfx_t"]);
        assert_eq!(e.fields[4].default_int, Some(22), "ttl starts at life");
        assert!(e.fields[4].ty == Ty::UInt(5), "22 fits u5");
        assert_eq!(p.fns.len(), 3, "emit + update + draw");
        assert_eq!(p.fns[0].name, "emit_boomfx");
        assert_eq!(p.fns[1].name, "update");
        assert_eq!(p.fns[2].name, "draw");
        // update body: drag on vx (Q8 const), drag+grav on vy, ttl--, kill at 0
        let up = &p.fns[1].body;
        assert_eq!(up.len(), 4, "vx drag, vy drag+grav, ttl--, if/kill");
    }

    /// Duplicate entity name vs a particles atom is a loud error.
    #[test]
    fn particles_name_collision_is_loud() {
        let mut p = prog_with(vec![EntityDecl {
            name: "boomfx".into(), fields: vec![], fsm: None, from: None, max_live_override: None, arrs: Vec::new(), uses: Vec::new(),
            body: None,
        }]);
        p.particles.push(ParticleDecl {
            atom: 0, cap: 64, sprite: 0, life: 10, speed_fix: 256, jitter_q8: 0,
            drag_q8: 256, grav_fix: 0, burst: 4, color: 0xFFFFFF, fade: false,
        });
        assert!(expand(&mut p, &["boomfx".to_string()], ".").is_err());
    }
}
