//! LILA codegen: typed AST -> instruction stream.
//! Types are computed via the checker's typing rules (expr_type) so codegen
//! and the checker can never disagree.

use crate::ast::*;
use crate::checker::{Ctx, CtxRefs, FnInfo, FnKind, VT, GLOBAL_ENT};
use std::collections::HashMap;

// ---- opcodes (must match the Zig VM) ----
pub const OP_PUSH_S8: u8 = 0x01;
pub const OP_PUSH_POOL: u8 = 0x02;
pub const OP_LD_LOCAL: u8 = 0x03;
pub const OP_ST_LOCAL: u8 = 0x04;
pub const OP_LD_GLBL: u8 = 0x05;
pub const OP_ST_GLBL: u8 = 0x06;
pub const OP_LD_ENT: u8 = 0x07;
pub const OP_ST_ENT: u8 = 0x08;
pub const OP_ADD_F: u8 = 0x09;
pub const OP_SUB_F: u8 = 0x0A;
pub const OP_MUL_F: u8 = 0x0B;
pub const OP_DIV_F: u8 = 0x0C;
pub const OP_ADD_I: u8 = 0x0D;
pub const OP_SUB_I: u8 = 0x0E;
pub const OP_MUL_I: u8 = 0x0F;
pub const OP_DIV_I: u8 = 0x10;
pub const OP_MOD_I: u8 = 0x11;
pub const OP_AND_I: u8 = 0x12;
pub const OP_OR_I: u8 = 0x13;
pub const OP_XOR_I: u8 = 0x14;
pub const OP_SHL: u8 = 0x15;
pub const OP_SHR: u8 = 0x16;
pub const OP_AND_B: u8 = 0x17;
pub const OP_OR_B: u8 = 0x18;
pub const OP_NOT_B: u8 = 0x19;
pub const OP_NEG: u8 = 0x1A;
pub const OP_EQ_F: u8 = 0x1B;
pub const OP_NE_F: u8 = 0x1C;
pub const OP_LT_F: u8 = 0x1D;
pub const OP_GT_F: u8 = 0x1E;
pub const OP_LE_F: u8 = 0x1F;
pub const OP_GE_F: u8 = 0x20;
pub const OP_EQ_I: u8 = 0x21;
pub const OP_NE_I: u8 = 0x22;
pub const OP_LT_I: u8 = 0x23;
pub const OP_GT_I: u8 = 0x24;
pub const OP_LE_I: u8 = 0x25;
pub const OP_GE_I: u8 = 0x26;
pub const OP_SIN: u8 = 0x27;
pub const OP_COS: u8 = 0x28;
pub const OP_RAND_MAX: u8 = 0x29;
pub const OP_ANIM: u8 = 0x2A;
pub const OP_KEY: u8 = 0x2B;
pub const OP_JMP: u8 = 0x2C;
pub const OP_JZ: u8 = 0x2D;
pub const OP_JNZ: u8 = 0x2E;
pub const OP_FOR_BGN: u8 = 0x2F;
pub const OP_FOR_ADV: u8 = 0x30;
pub const OP_SPAWN: u8 = 0x31;
pub const OP_KILL: u8 = 0x32;
pub const OP_SFX: u8 = 0x33;
pub const OP_MUSIC: u8 = 0x34;
pub const OP_STOP_MUSIC: u8 = 0x35;
pub const OP_GOTO: u8 = 0x36;
pub const OP_DRAW: u8 = 0x37;
pub const OP_DRAW_TEXT: u8 = 0x38;
pub const OP_DRAW_NUM: u8 = 0x39;
pub const OP_CALL_TBL: u8 = 0x3A;
pub const OP_COUNT: u8 = 0x3B;
pub const OP_RET: u8 = 0x3C;
pub const OP_CALL_FN: u8 = 0x3D;
pub const OP_I2F: u8 = 0x3E; // int -> fixed (x << 8)
pub const OP_F2I: u8 = 0x3F; // fixed -> int (x >> 8 arithmetic)
pub const OP_SHAKE: u8 = 0x40; // screen-shake: u8 amplitude (px)
// ---- v7: camera / persistence / aim math / music volume ----
pub const OP_CAMERA: u8 = 0x41;    // pops y, x (fixed) -> clamped camera center
pub const OP_MUSIC_VOL: u8 = 0x42; // u8 master music volume 0..16
pub const OP_SAVE: u8 = 0x43;      // pops v, ix -> SRAM slot (ix & 63)
pub const OP_SAVED: u8 = 0x44;     // pops ix -> pushes slot value (raw i32)
pub const OP_DIST: u8 = 0x45;     // pops y2 x2 y1 x1 -> pushes Q24.8 distance
pub const OP_ATAN2: u8 = 0x46;    // pops dx, dy -> pushes screen-convention ang
pub const OP_CAM_X: u8 = 0x47;    // pushes camera center x (fixed)
pub const OP_CAM_Y: u8 = 0x48;    // pushes camera center y (fixed)
// ---- v8 OPTIMIZER opcodes: physics / AI bit-planes ----
// (all branchless, all decided at compile time by the opt:: passes)
pub const OP_SWEPT: u8 = 0x49;         // pops hh hw by bx avy avx ay ax -> bool swept Minkowski interval
pub const OP_COLLIDE_MASK: u8 = 0x4A;  // pops cy cx -> u32 live-slot mask (Galois 32 lanes); a=type, b/c=pool hw/hh, extra=[x_tf,y_tf]
pub const OP_FOR_MASK_BGN: u8 = 0x4B;  // pops mask -> iterate set slots (a=local slot, b=type, c=exit rel)
pub const OP_FOR_MASK_ADV: u8 = 0x4C;  // advance ctz scan (a=body rel)
pub const OP_FSM_NEXT: u8 = 0x4D;      // pops s, em -> next = T[s*span + em] (bit-plane transition)
pub const OP_SEL: u8 = 0x4E;           // pops else, then, cond -> branchless conditional move

// ---- v11 ARRAYS + 3D ----
pub const OP_LD_GARR: u8 = 0x4F;       // a=array id; pops idx -> pushes elem (global arrays)
pub const OP_ST_GARR: u8 = 0x50;       // a=array id; pops val, idx -> store (bounds: mask|mod)
pub const OP_LD_EARR: u8 = 0x51;       // a=local slot, b=array id; pops idx -> pushes elem
pub const OP_ST_EARR: u8 = 0x52;       // a=local slot, b=array id; pops val, idx -> store
pub const OP_DUP: u8 = 0x53;           // duplicate top of stack (compound array assigns)
pub const OP_CAM3: u8 = 0x54;          // pops pitch, yaw, z, y, x -> 3D camera registers
pub const OP_PROJ3: u8 = 0x55;         // pops z, y, x -> scale; stashes screen x/y + ok flag
pub const OP_PROJ_X: u8 = 0x56;        // pushes stashed screen x (fixed)
pub const OP_PROJ_Y: u8 = 0x57;        // pushes stashed screen y (fixed)
pub const OP_PROJ_OK: u8 = 0x58;       // pushes stashed ok flag (bool: in front of camera)
pub const OP_DRAW3D: u8 = 0x59;        // a=array id; pops rgba, yaw, z, y, x, n -> mesh pass

// ---- v12 ARTICULATION: mat4/quat builtins over arrays + indexed meshes ----
// (all stack-arg ops: args pushed in source order, VM pops reversed)
pub const OP_QUAT_AA: u8 = 0x5A;       // pops ang, az, ay, ax, off, q_aid -> quat = axis-angle
pub const OP_Q_MUL: u8 = 0x5B;         // pops boff,b_aid,aoff,a_aid,doff,d_aid -> d = a*b (Hamilton)
pub const OP_M4_QT: u8 = 0x5C;         // pops tz,ty,tx,q_off,q_aid,m_off,m_aid -> M = T(t)*R(q)
pub const OP_M4_MUL: u8 = 0x5D;        // pops boff,b_aid,aoff,a_aid,doff,d_aid -> d = a*b (alias-safe)
pub const OP_SKIN3: u8 = 0x5E;         // pops z,y,x,m_off,m_aid,v_off,v_aid -> verts[voff..+2] = M*p
pub const OP_DRAW3DI: u8 = 0x5F;       // a=vert arr, b=idx arr; pops rgba, yaw, z, y, x, ni, nv -> indexed mesh pass

// ---- v17: expression language + engine services ----
// Appended, never renumbered: v1..v16 bytecode streams are unchanged and
// still load byte-identically. A game that emits ANY of these carries a
// v4 .libyte header; runtimes built before v17 reject v4 loudly with
// ERR_VERSION instead of misdecoding the stream.
pub const OP_RET_V: u8 = 0x60;        // pops v -> threadlocal ret register, then pops the frame
pub const OP_RET_GET: u8 = 0x61;       // pushes the threadlocal ret register (consumed right after each call)
pub const OP_ITER_POP: u8 = 0x62;     // pops one entity-iterator (break out of a for-loop)
pub const OP_KEY_EDGE: u8 = 0x63;     // a=key bit 0..31, b=0 pressed | 1 released -> bool
pub const OP_DIST_NEAR: u8 = 0x64;    // a=type, extra=[x_tf,y_tf]; pops y, x -> nearest Q24.8 dist (0x7FFFFFFF if none)
pub const OP_M4_LOOK: u8 = 0x65;       // pops tz,ty,tx,ez,ey,ex,m_off,m_aid -> M = look-at (eye->target, +Z up)

// ---- v20: f32 — software IEEE binary32 (deterministic float) ----
// All pure stack ops (operands: two f32 bit patterns; result on the stack).
// A file using any of them carries the v5 header. The values are RAW BITS
// on the VM stack; the runtime decodes through softfloat.zig (bit-exact on
// every platform — no libm, no FPU, no FTZ flags).
pub const OP_F32_ADD: u8 = 0x66;
pub const OP_F32_SUB: u8 = 0x67;
pub const OP_F32_MUL: u8 = 0x68;
pub const OP_F32_DIV: u8 = 0x69;
pub const OP_F32_SQRT: u8 = 0x6A;
pub const OP_F32_EQ: u8 = 0x6B;
pub const OP_F32_NE: u8 = 0x6C;
pub const OP_F32_LT: u8 = 0x6D;
pub const OP_F32_GT: u8 = 0x6E;
pub const OP_F32_LE: u8 = 0x6F;
pub const OP_F32_GE: u8 = 0x70;
pub const OP_I2F32: u8 = 0x71;   // int -> f32 (exact rounding)
pub const OP_F322I: u8 = 0x72;   // f32 -> int (truncate toward zero; NaN->0, saturate)
pub const OP_FIX2F32: u8 = 0x73; // Q24.8 -> f32 (value / 256)
pub const OP_F322FIX: u8 = 0x74; // f32 -> Q24.8 (round(x*256), ties-to-even, saturate)

// ---- v23 TIER-1: f64 software-IEEE binary64 ops ----
// Marks the fn as Tier-1 (see opt::tier). The tier purity fixpoint
// demotes any fn that uses these; the optimizer gates skip it.
// The runtime path is softfloat.zig::f64_* (binary64, ~270 lines added).
pub const OP_F64_ADD: u8 = 0xA0;
pub const OP_F64_SUB: u8 = 0xA1;
pub const OP_F64_MUL: u8 = 0xA2;
pub const OP_F64_DIV: u8 = 0xA3;
pub const OP_F64_SQRT: u8 = 0xA4;
pub const OP_F64_EQ: u8  = 0xA5;
pub const OP_F64_NE: u8  = 0xA6;
pub const OP_F64_LT: u8  = 0xA7;
pub const OP_F64_GT: u8  = 0xA8;
pub const OP_F64_LE: u8  = 0xA9;
pub const OP_F64_GE: u8  = 0xAA;
pub const OP_I2F64: u8   = 0xAB;   // int -> f64
pub const OP_F642I: u8   = 0xAC;   // f64 -> int (truncate toward zero; NaN->0, saturate)
pub const OP_FIX2F64: u8 = 0xAD;  // Q24.8 -> f64
pub const OP_F642FIX: u8 = 0xAE;   // f64 -> Q24.8 (round, ties-to-even, saturate)
pub const OP_F322F64: u8 = 0xAF;   // f32 -> f64 (exact widening)
pub const OP_F642F32: u8 = 0xB0;   // f64 -> f32 (round-to-nearest-even)

// ---- v23 STEP 5: SIMD vector opcodes (vec4 fixed + vec4 u8) ----
// These are TIER-0 opcodes — the tier purity fixpoint keeps vec4-touching
// fns Tier-0. The ops pop 4 values (or 1 packed i32 for vec4u8), operate
// pointwise, and push 4 results. The AOT backend (C + LLVM) lowers these
// to SSE/NEON intrinsics when targeting Tier-0-pure fns.
pub const OP_VEC4F_ADD: u8 = 0xB1;  // vec4fixed add: pops 8 (4+4), pushes 4
pub const OP_VEC4F_SUB: u8 = 0xB2;
pub const OP_VEC4F_MUL: u8 = 0xB3;  // Q24.8 mul: (a*b)>>8 pointwise
pub const OP_VEC4F_DOT: u8 = 0xB4;  // dot product: pops 8, pushes 1 (Q24.8)
pub const OP_VEC4U_ADD: u8 = 0xB5;  // vec4u8 add: pops 2 (packed i32), pushes 1
pub const OP_VEC4U_PACK: u8 = 0xB6; // pack 4 u8s into 1 i32
pub const OP_VEC4U_UNPACK: u8 = 0xB7; // unpack 1 i32 into 4 u8s
// v23.1: exceptions + stack hygiene (runtime implements these as of v23.1)
pub const OP_TRY: u8 = 0xB8;      // a = catch target idx (S16), b = catch-var slot
pub const OP_TRY_END: u8 = 0xB9;  // normal end of try body: drop handler
pub const OP_THROW: u8 = 0xBA;    // pops error value, unwinds to handler
pub const OP_DROP: u8 = 0xBB;     // pops and discards one cell
// ---- v23.6: f64 returns — the ret register is a (lo, hi) PAIR ----
// Appended, never renumbered. RET_V64 pops hi then lo (the f64 stack
// convention: hi on top), parks them in the ret pair, pops the frame.
// RET_GET64 pushes lo then hi — the exact inverse. The pair lives in the
// C-ABI prefix (ret_val + ret_hi), so AOT code reads/writes it directly.
pub const OP_RET_V64: u8 = 0xBC;   // pops (lo, hi) -> ret pair, pops the frame
pub const OP_RET_GET64: u8 = 0xBD; // pushes the ret pair (lo, hi — hi on top)

// ---- v20: pools — dynamic append-only side tables (C# List<T> analog) ----
// Appended after v17's 0x65; a file that emits ANY v20 opcode (or declares
// pools) carries a v5 .libyte header — pre-v20 runtimes reject v5 loudly.
// A pfield id is GLOBAL: pool_idx * 16 + field_idx (u16 operand).
pub const OP_PL_PUSH: u8 = 0x76;      // a=pool, b=n, extra=[field idx...]; pops n values -> append row (defaults for unlisted)
pub const OP_PL_REM: u8 = 0x77;      // a=slot, b=pool; gen-checked swap-remove (stale handles are a no-op)
pub const OP_PL_LEN: u8 = 0x78;      // a=pool -> live row count (int)
pub const OP_PL_LD: u8 = 0x79;        // a=slot, b=pfield -> cell value (stale handle reads 0)
pub const OP_PL_ST: u8 = 0x7A;        // a=slot, b=pfield; pops value -> cell store (stale no-op)
pub const OP_PL_FOR_BGN: u8 = 0x7B;  // a=pool, b=slot, c=exit rel; iterates 0..count in order
pub const OP_PL_FOR_ADV: u8 = 0x7C;  // a=body rel (the FOR_BGN's bgn+1)
pub const OP_AGG: u8 = 0x7D;      // a=type, b=mode 0=sum/1=min/2=max, extra=[tf]; engine-side live scan
pub const OP_SIGNAL: u8 = 0x7E;   // a=n handlers, extra=[fn idx...]; fires in order

// ---- v21: engine fundamentals (C++/C# game-dev parity, round 2) ----
// Appended after v20's 0x7E; a file that emits ANY of them carries the v5
// header (same contract as pools — pre-v20 runtimes reject v5 loudly).
pub const OP_PSORT: u8 = 0x7F;     // a=pool, b=pfield, c=dir 0 asc/1 desc — stable engine-side radix sort of live rows
pub const OP_M_PUT: u8 = 0x80;     // a=dict; pops val, key -> insert/overwrite (splitmix + linear probe)
pub const OP_M_GET: u8 = 0x81;     // a=dict; pops key -> value (0 if absent)
pub const OP_M_DEL: u8 = 0x82;     // a=dict; pops key -> backward-shift delete (missing: no-op)
pub const OP_M_LEN: u8 = 0x83;     // a=dict -> live entry count (int)
pub const OP_RAY: u8 = 0x84;      // a=grid array; pops maxd, ang, y, x -> Q24.8 dist (0x7FFFFFFF if none); stashes hit cell
pub const OP_RAY_X: u8 = 0x85;    // pushes the last ray hit cell x (int)
pub const OP_RAY_Y: u8 = 0x86;    // pushes the last ray hit cell y (int)
pub const OP_ASTAR: u8 = 0x87;    // a=grid array, b=path array; pops ty tx sy sx -> waypoint count (-1 unreachable)
pub const OP_FRAME: u8 = 0x88;    // pushes the 60Hz frame counter (int)
pub const OP_DRAW_NUMZ: u8 = 0x89; // a=digits 1..9; pops rgba, y, x, val -> zero-paded integer draw

// ---- v22: deterministic collections & contact edges (C++/C# parity round 3) ----
// Same contract as v21: any file emitting one of these is v5 (emitted_version
// sees op > OP_M4_LOOK) — pre-v20 runtimes reject loudly.
pub const OP_NOISE1: u8 = 0x8A;    // pops t (fixed) -> Q24.8 lattice noise in [0,1)
pub const OP_NOISE2: u8 = 0x8B;    // pops y, x (fixed) -> Q24.8 lattice noise in [0,1)
pub const OP_M_NEXT: u8 = 0x8C;   // a=dict; pops cursor -> next key or -1; stashes val+next cursor at page 0
pub const OP_M_NEXT_V: u8 = 0x8D;  // pushes the last mnext entry's value
pub const OP_M_NEXT_C: u8 = 0x8E;  // pushes the next mnext cursor (0xFFFFFFFF at end)
pub const OP_QPUSH: u8 = 0x8F;    // a=arr; pops val -> FIFO ring append (full: drop)
pub const OP_QPOP: u8 = 0x90;     // a=arr -> oldest entry (0 when empty)
pub const OP_QLEN: u8 = 0x91;     // a=arr -> entry count
pub const OP_SPUSH: u8 = 0x92;    // a=arr; pops val -> LIFO append (full: drop)
pub const OP_SPOP: u8 = 0x93;     // a=arr -> newest entry (0 when empty)
pub const OP_SLEN: u8 = 0x94;     // a=arr -> entry count
pub const OP_SPEEK: u8 = 0x95;     // a=arr -> top entry without popping (0 when empty)
pub const OP_AFILL: u8 = 0x96;    // a=arr; pops val -> fill the whole array
pub const OP_ACOPY: u8 = 0x97;    // a=dst, b=src; pops n -> copy first n cells (clamped)
pub const OP_ASHUF: u8 = 0x98;    // a=arr; pops n -> Fisher-Yates via the LCG chain
pub const OP_AFIND: u8 = 0x99;    // a=arr; pops val -> first index or -1
pub const OP_ACOUNT: u8 = 0x9A;   // a=arr; pops val -> match count

// operand signatures: (kind_a, kind_b, kind_c)
#[derive(Clone, Copy, PartialEq, Debug)]
pub enum OpK { None, U8, U16, S16, S8, PoolU16 }

pub fn sig(op: u8) -> (OpK, OpK, OpK) {
    use OpK::*;
    match op {
        OP_PUSH_S8 => (S8, None, None),
        OP_PUSH_POOL => (PoolU16, None, None),
        OP_LD_LOCAL | OP_ST_LOCAL | OP_COUNT => (U8, None, None),
        OP_KILL => (U8, U8, None),
        OP_LD_GLBL | OP_ST_GLBL => (U16, None, None),
        OP_LD_ENT | OP_ST_ENT => (U8, U16, None),
        OP_JMP | OP_JZ | OP_JNZ | OP_FOR_ADV | OP_TRY => (S16, None, None),
        OP_FOR_BGN => (U8, U8, S16),
        OP_CALL_FN => (U16, U8, None),
        OP_CALL_TBL => (U8, U8, None),
        OP_SFX | OP_MUSIC | OP_GOTO | OP_DRAW | OP_DRAW_TEXT | OP_ANIM | OP_KEY => (U16, None, None),
        OP_SHAKE => (U8, None, None),
        OP_MUSIC_VOL => (U8, None, None),
        OP_CAMERA | OP_SAVE | OP_SAVED | OP_DIST | OP_ATAN2 | OP_CAM_X | OP_CAM_Y => (None, None, None),
        OP_SPAWN => (U8, U8, None), // + extra U16 tf list; b = STACK CELLS (v23.1: f64 fields count two — the loader/VM width-walk the tf list)
        // v8: swept interval solve — 8 fixed args on the stack
        OP_SWEPT => (None, None, None),
        // v8: Galois collision mask — a=type, b/c = pool indices of hw/hh,
        // extra = [x_tf, y_tf] (resolved at compile time)
        OP_COLLIDE_MASK => (U8, PoolU16, PoolU16),
        OP_FOR_MASK_BGN => (U8, U8, S16),
        OP_FOR_MASK_ADV => (S16, None, None),
        OP_FSM_NEXT => (U16, None, None),
        OP_SEL => (None, None, None),
        // v11: arrays + 3D
        OP_LD_GARR | OP_ST_GARR | OP_DRAW3D => (U8, None, None),
        OP_LD_EARR | OP_ST_EARR => (U8, U8, None),
        OP_DUP | OP_CAM3 | OP_PROJ3 | OP_PROJ_X | OP_PROJ_Y | OP_PROJ_OK => (None, None, None),
        // v12: articulation — mat/quat ops are pure stack ops; the indexed
        // mesh pass carries both array ids as operands
        OP_QUAT_AA | OP_Q_MUL | OP_M4_QT | OP_M4_MUL | OP_SKIN3 => (None, None, None),
        OP_DRAW3DI => (U8, U8, None),
        // v17: expression language + engine services
        OP_RET_V | OP_RET_GET | OP_ITER_POP | OP_M4_LOOK => (None, None, None),
        OP_RET_V64 | OP_RET_GET64 => (None, None, None), // v23.6 f64 ret pair
        OP_KEY_EDGE => (U8, U8, None),
        OP_DIST_NEAR => (U8, None, None), // + extra [x_tf, y_tf]
        // v20: f32 — pure stack ops
        OP_F32_ADD | OP_F32_SUB | OP_F32_MUL | OP_F32_DIV | OP_F32_SQRT
        | OP_F32_EQ | OP_F32_NE | OP_F32_LT | OP_F32_GT | OP_F32_LE | OP_F32_GE
        | OP_I2F32 | OP_F322I | OP_FIX2F32 | OP_F322FIX => (None, None, None),
        // v20: pools
        OP_PL_PUSH => (U8, U8, None), // + extra U16 field-idx list (count in b)
        OP_PL_REM => (U8, U8, None),
        OP_PL_LEN => (U8, None, None),
        OP_PL_LD | OP_PL_ST => (U8, U16, None),
        OP_PL_FOR_BGN => (U8, U8, S16),
        OP_PL_FOR_ADV => (S16, None, None),
        OP_AGG => (U8, U8, None), // + extra [tf]
        // v21: engine fundamentals
        OP_PSORT => (U8, U16, U8),
        OP_M_PUT | OP_M_GET | OP_M_DEL => (U8, None, None),
        OP_M_LEN => (U8, None, None),
        OP_RAY => (U8, None, None),
        OP_RAY_X | OP_RAY_Y | OP_FRAME => (None, None, None),
        OP_ASTAR => (U8, U8, None),
        OP_DRAW_NUMZ => (U8, None, None),
        // v22: deterministic collections
        OP_M_NEXT | OP_QPUSH | OP_QPOP | OP_QLEN | OP_SPUSH | OP_SPOP | OP_SLEN
        | OP_SPEEK | OP_AFILL | OP_AFIND | OP_ACOUNT | OP_ASHUF => (U8, None, None),
        OP_ACOPY => (U8, U8, None),
        OP_NOISE1 | OP_NOISE2 | OP_M_NEXT_V | OP_M_NEXT_C => (None, None, None),
        // OP_SIGNAL 0x7E: RESERVED (never emitted — signals compile to
        // CALL_FN chains; the slot is kept so the numbering stays fixed)
        _ => (None, None, None),
    }
}

#[derive(Debug, Clone)]
pub struct Instr {
    pub op: u8,
    pub a: i32,
    pub b: i32,
    pub c: i32,
    pub extra: Vec<u16>, // SPAWN tf list
}

impl Instr {
    fn new(op: u8) -> Instr { Instr { op, a: 0, b: 0, c: 0, extra: Vec::new() } }
    fn a(op: u8, a: i32) -> Instr { Instr { op, a, b: 0, c: 0, extra: Vec::new() } }
    fn ab(op: u8, a: i32, b: i32) -> Instr { Instr { op, a, b, c: 0, extra: Vec::new() } }
    fn abc(op: u8, a: i32, b: i32, c: i32) -> Instr { Instr { op, a, b, c, extra: Vec::new() } }
}

pub struct FnCode {
    pub kind: FnKind,
    pub entity: u8,      // 0xFF none
    pub nparams: u8,
    pub nlocals: u8,     // total slots incl params
    pub start: u32,      // instr index into global stream
    pub len: u32,
}

pub struct Code {
    pub instrs: Vec<Instr>,
    pub pool: Vec<i32>,
    pub fns: Vec<FnCode>,
}

struct Gen<'a> {
    ctx: &'a Ctx,
    cur_max_locals: usize,
    tf: HashMap<(u8, String), usize>,
    gidx: HashMap<String, usize>,
    eidx: HashMap<String, usize>,
    fidx: HashMap<String, usize>,
    arrs: HashMap<(u8, String), usize>,
    /// v20 POOLS: pool name -> pool id (the registry order).
    pidx: HashMap<String, usize>,
    /// v21 DICTS: dict name -> dict id.
    didx: HashMap<String, usize>,
    instrs: Vec<Instr>,
    pool: Vec<i32>,
    pool_map: HashMap<i32, u16>,
    /// mask local name -> 32-lane window base (v9 multi-window Galois)
    mask_base: HashMap<String, i32>,
}

struct Env {
    locals: Vec<(String, VT)>,
    /// v17: stack of enclosing loops for break/continue binding. Each entry
    /// collects the jump sites to patch once the loop's exit/continue target
    /// is known, plus whether leaving needs an ITER_POP (entity for-loops
    /// keep an iterator on the VM's iterator stack).
    loops: Vec<LoopCtx>,
    /// fresh-name source for compiler temporaries ('#' can't appear in user
    /// identifiers, so these can never collide)
    temp_n: u32,
    /// v23.1: number of OP_TRY handlers currently registered lexically
    /// around the emission point. break/continue must emit one OP_TRY_END
    /// per try they unwind past, or the VM's handler stack would keep a
    /// stale entry pointing into an abandoned region.
    try_depth: usize,
}

#[derive(Default)]
struct LoopCtx {
    /// jump indices awaiting the loop-exit address (break)
    break_jumps: Vec<usize>,
    /// jump indices awaiting the continue-target address
    continue_jumps: Vec<usize>,
    /// entity for-loops must pop their iterator when breaking out
    break_pops_iter: bool,
    /// v23.1: try-depth when the loop was entered (break/continue unwind
    /// handlers down to THIS level)
    try_depth: usize,
}

pub fn gen(ctx: &Ctx) -> Result<Code, String> {
    let mut tf = HashMap::new();
    for (i, t) in ctx.typed_fields.iter().enumerate() {
        let fname = if t.ent == GLOBAL_ENT {
            ctx.globals[t.field as usize].name.clone()
        } else {
            ctx.entities[t.ent as usize].fields[t.field as usize].name.clone()
        };
        tf.insert((t.ent, fname), i);
    }
    let gidx: HashMap<String, usize> = ctx.globals.iter().enumerate()
        .map(|(i, g)| (g.name.clone(), i)).collect();
    let eidx: HashMap<String, usize> = ctx.entities.iter().enumerate()
        .map(|(i, e)| (e.name.clone(), i)).collect();
    let fidx: HashMap<String, usize> = ctx.fns.iter().enumerate()
        .map(|(i, f)| (f.name.clone(), i)).collect();
    let arrs: HashMap<(u8, String), usize> = ctx.arrays.iter().enumerate()
        .map(|(i, a)| ((a.ent, a.name.clone()), i)).collect();
    let pidx: HashMap<String, usize> = ctx.pools.iter().enumerate()
        .map(|(i, p)| (p.name.clone(), i)).collect();
    let didx: HashMap<String, usize> = ctx.dicts.iter().enumerate()
        .map(|(i, d)| (d.name.clone(), i)).collect();

    let mut g = Gen { ctx, tf, gidx, eidx, fidx, arrs, pidx, didx, instrs: Vec::new(), pool: Vec::new(), pool_map: HashMap::new(), cur_max_locals: 0, mask_base: HashMap::new() };

    // refs for typing (reuse checker typing rules)
    let refs = ctx.refs();

    let mut fns_meta = Vec::new();
    for f in &ctx.fns {
        let start = g.instrs.len() as u32;
        // v23.5: f64 params reserve TWO slots (value + hidden high) — the
        // callee's frame receives the caller's cells IN ORDER via callFn's
        // locals[0..n] copy, so the slot layout must match the caller's
        // push order: param k lands at the running cell offset, and an f64
        // param's high cell sits at offset+1 under the SAME hidden-name
        // convention the f64-local machinery uses (#hi_<name>).
        let mut param_slots: Vec<(String, VT)> = Vec::with_capacity(f.params.len() * 2);
        let mut cell_off: usize = 0;
        for (pn, pvt) in &f.params {
            param_slots.push((pn.clone(), *pvt));
            if *pvt == VT::F64 {
                param_slots.push((format!("#hi_{}", pn), VT::Int));
                cell_off += 2;
            } else {
                cell_off += 1;
            }
        }
        g.cur_max_locals = cell_off;
        let mut env = Env { locals: param_slots, loops: Vec::new(), temp_n: 0, try_depth: 0 };
        g.gen_block(&f.body, &mut env, f, &refs)?;
        // v17 RETURN VALUES: falling off the end of a VALUED fn returns 0
        // (the language's forgiving-arithmetic style; `return;` does too).
        // Void fns keep the plain implicit RET — byte-identical to v16.
        // v23.6: an f64 fn's zero is TWO zero cells (lo, hi) + RET_V64.
        if f.ret == Some(VT::F64) {
            g.instrs.push(Instr::a(OP_PUSH_S8, 0));
            g.instrs.push(Instr::a(OP_PUSH_S8, 0));
            g.instrs.push(Instr::new(OP_RET_V64));
        } else if f.ret.is_some() {
            g.instrs.push(Instr::a(OP_PUSH_S8, 0));
            g.instrs.push(Instr::new(OP_RET_V));
        } else {
            g.instrs.push(Instr::new(OP_RET));
        }
        // v12 LOUD LIMIT: the VM frame holds MAX_LOCALS slots. Codegen used
        // to silently drop stores past the limit (reads returned 0) — a
        // miscompile that hangs loops. Reject at build time instead.
        if g.cur_max_locals > 32 {
            return Err(format!(
                "fn '{}' needs {} local slots but the engine frame holds 32 (split the fn or shrink its scope)",
                f.name, g.cur_max_locals
            ));
        }
        fns_meta.push(FnCode {
            kind: f.kind,
            entity: f.entity.map(|e| e as u8).unwrap_or(0xFF),
            nparams: f.params.len() as u8,
            nlocals: g.cur_max_locals as u8,
            start,
            len: (g.instrs.len() as u32) - start,
        });
    }

    let mut code = Code { instrs: g.instrs, pool: g.pool, fns: fns_meta };
    // v23.2: reachability DCE — unreachable tails (code after `return`,
    // abandoned loop scaffolding) never reach the cartridge.
    dce(&mut code);
    Ok(code)
}



impl<'a> Gen<'a> {
    fn pool_idx(&mut self, v: i32) -> u16 {
        if let Some(&i) = self.pool_map.get(&v) { return i; }
        let i = self.pool.len() as u16;
        self.pool.push(v);
        self.pool_map.insert(v, i);
        i
    }

    fn push_const(&mut self, v: i32) {
        if (-128..=127).contains(&v) {
            self.instrs.push(Instr::a(OP_PUSH_S8, v));
        } else {
            let pi = self.pool_idx(v);
            self.instrs.push(Instr::a(OP_PUSH_POOL, pi as i32));
        }
    }

    fn tf_of(&self, ent: u8, name: &str) -> Result<usize, String> {
        self.tf.get(&(ent, name.to_string())).copied()
            .ok_or_else(|| crate::diag::internal(&format!("no typed field {}.{}", ent, name)))
    }

    /// v20 POOLS: the GLOBAL pfield id (pool_idx * 16 + field_idx) for a
    /// pool field reference. The checker proved it exists; this is the
    /// codegen-side lookup in registry order.
    fn pf_of(&self, pi: usize, fname: &str) -> Result<u16, String> {
        let p = self.ctx.pools.get(pi)
            .ok_or_else(|| crate::diag::internal("bad pool id"))?;
        let fi = p.fields.iter().position(|f| f.name == fname)
            .ok_or_else(|| crate::diag::internal(&format!("pool {} has no field {}", p.name, fname)))?;
        Ok(((pi * 16) + fi) as u16)
    }

    fn dom_pos(&self, dom: &[u16], atom: u16, what: &str) -> Result<u16, String> {
        dom.iter().position(|&x| x == atom)
            .map(|p| p as u16)
            .ok_or_else(|| crate::diag::internal(&format!("atom {} not in {} domain", atom, what)))
    }

    fn gen_block(&mut self, stmts: &[Stmt], env: &mut Env, f: &FnInfo, refs: &CtxRefs) -> Result<(), String> {
        // v23.1: STATEMENT-LEVEL TEMP RECYCLING (see the pop below). The
        // floor is this block's entry depth: temps allocated by an OUTER
        // statement that is still being emitted (a switch scrutinee read
        // inside its own arms, a loop's bounds temps) are protected — only
        // temps this block itself created become recyclable.
        let temp_floor = env.locals.len();
        for s in stmts {
            // v23.2 SPANS: publish the statement position for codegen errors
            // (locals-limit, arity-on-call-lowering, ...) exactly like the
            // checker does.
            match s {
                Stmt::At { line, col, .. } => crate::diag::set_pos(*line, *col),
                _ => crate::diag::set_pos(f.line, 0),
            }
            self.gen_stmt(s, env, f, refs)?;
            // Temps ('#' names) are stack-disciplined: their slots are dead
            // once the statement's code is emitted, so trailing temps pop
            // here and the slots are reused by the next statement.
            // smoothstep alone consumed six slots before this; a fn mixing
            // a few Mathf builtins blew the 32-local frame with a confusing
            // error. Slots are only ever popped from the END, so
            // already-emitted slot indices stay valid. f64 value slots and
            // their #hi_ placeholders are kept (the pair must stay adjacent
            // and live across statements).
            while env.locals.len() > temp_floor {
                let (name, vt) = env.locals.last().unwrap();
                if name.starts_with("#hi_") || name.starts_with("#lp")
                    || *vt == VT::F64 || !name.starts_with('#') {
                    break;
                }
                env.locals.pop();
            }
        }
        Ok(())
    }

    fn gen_stmt(&mut self, s: &Stmt, env: &mut Env, f: &FnInfo, refs: &CtxRefs) -> Result<(), String> {
        match s {
            // v23.2 SPANS: positional wrapper — recurse (position already set).
            Stmt::At { inner, .. } => self.gen_stmt(inner, env, f, refs),
            Stmt::Let(name, e) => {
                let vt = self.gen_expr(e, env, f, refs)?;
                // remember the window base of a Galois mask let so the
                // matching ForMask can carry it into the loop opcode
                if let Expr::Intrin(crate::ast::INTR_COLL_MASK, _, _, consts) = e {
                    self.mask_base.insert(name.clone(), consts.get(2).copied().unwrap_or(0));
                }
                let existing = env.locals.iter().position(|(n, _)| n == name);
                // v23.1: f64 locals occupy TWO slots. A let that rebinds a
                // non-f64 local AS f64 would need two ADJACENT slots it does
                // not have — loud gate (redeclaring under a fresh name works).
                if vt == VT::F64 {
                    if let Some(s) = existing {
                        if env.locals[s].1 != VT::F64 {
                            return Err(format!("cannot rebind local '{}' from {} to f64 in place (an f64 local needs two adjacent slots) — use a fresh name", name, if env.locals[s].1 == VT::Fixed { "fixed" } else { "int/other" }));
                        }
                    }
                }
                match vt {
                    VT::F64 => {
                        let slot = match existing {
                            Some(s) => s,
                            None => {
                                // reserve the pair: value slot + hidden high
                                // cell (the '#' name can never collide)
                                let s = env.locals.len();
                                env.locals.push((name.clone(), VT::F64));
                                env.locals.push((format!("#hi_{}", name), VT::Int));
                                s
                            }
                        };
                        // value is on the stack as (lo, hi): store hi first
                        self.instrs.push(Instr::a(OP_ST_LOCAL, (slot + 1) as i32));
                        self.instrs.push(Instr::a(OP_ST_LOCAL, slot as i32));
                    }
                    _ => {
                        let slot = match existing {
                            Some(s) => s,
                            None => env.locals.len(),
                        };
                        self.instrs.push(Instr::a(OP_ST_LOCAL, slot as i32));
                        env_set(env, name, vt);
                    }
                }
                if env.locals.len() > self.cur_max_locals {
                    self.cur_max_locals = env.locals.len();
                }
                Ok(())
            }
            Stmt::Assign(target, op, val) => {
                self.gen_assign(target, *op, val, env, f, refs)
            }
            Stmt::If(cond, then_b, else_b) => {
                let cvt = self.gen_expr(cond, env, f, refs)?;
                debug_assert_eq!(cvt, VT::Bool);
                let jz = self.instrs.len();
                self.instrs.push(Instr::a(OP_JZ, 0)); // patch target
                self.gen_block(then_b, env, f, refs)?;
                let jend: Option<usize> = if !else_b.is_empty() {
                    let j = self.instrs.len();
                    self.instrs.push(Instr::a(OP_JMP, 0));
                    Some(j)
                } else { None };
                // else starts here
                let else_start = self.instrs.len();
                self.instrs[jz].a = else_start as i32; // rel computed at pack time from indices
                if !else_b.is_empty() {
                    self.gen_block(else_b, env, f, refs)?;
                    let end = self.instrs.len();
                    self.instrs[jend.unwrap()].a = end as i32;
                }
                Ok(())
            }
            Stmt::While(cond, body) => {
                let top = self.instrs.len();
                let cond_base = env.locals.len();
                let cvt = self.gen_expr(cond, env, f, refs)?;
                // v23.1: every temp the condition allocated is re-read by
                // the back edge — rename them to the persistent #lp prefix
                // so the statement-level recycler can never free them.
                for i in cond_base..env.locals.len() {
                    if env.locals[i].0.starts_with("#t") {
                        env.locals[i].0 = format!("#lp{}", env.temp_n);
                        env.temp_n += 1;
                    }
                }
                debug_assert_eq!(cvt, VT::Bool);
                let jz = self.instrs.len();
                self.instrs.push(Instr::a(OP_JZ, 0));
                env.loops.push(LoopCtx { try_depth: env.try_depth, ..Default::default() });
                self.gen_block(body, env, f, refs)?;
                // v17 continue: jumps to the condition re-eval at `top`
                let lc = env.loops.pop().unwrap();
                for j in lc.continue_jumps { self.instrs[j].a = top as i32; }
                self.instrs.push(Instr::a(OP_JMP, top as i32));
                let end = self.instrs.len();
                self.instrs[jz].a = end as i32;
                for j in lc.break_jumps { self.instrs[j].a = end as i32; }
                Ok(())
            }
            Stmt::For(var, ent, body) => {
                let slot = match env.locals.iter().position(|(n, _)| n == var) {
                    Some(s) => s,
                    None => env.locals.len(),
                };
                // v20 POOLS: the same `for (v: T)` shape iterates a POOL when
                // T names one (checker guarantees pools and entities never
                // share names). Pool loops are count-ordered (push order);
                // same iterator stack, same break/continue shape.
                if let Some(&pi) = self.pidx.get(ent) {
                    env.locals.push((var.clone(), VT::Pool(pi)));
                    if env.locals.len() > self.cur_max_locals {
                        self.cur_max_locals = env.locals.len();
                    }
                    let bgn = self.instrs.len();
                    self.instrs.push(Instr::abc(OP_PL_FOR_BGN, pi as i32, slot as i32, 0)); // c patched to exit
                    env.loops.push(LoopCtx { break_pops_iter: true, try_depth: env.try_depth, ..Default::default() });
                    self.gen_block(body, env, f, refs)?;
                    let for_adv = self.instrs.len();
                    self.instrs.push(Instr::a(OP_PL_FOR_ADV, (bgn + 1) as i32));
                    let lc = env.loops.pop().unwrap();
                    for j in lc.continue_jumps { self.instrs[j].a = for_adv as i32; }
                    let exit = self.instrs.len();
                    self.instrs[bgn].c = exit as i32;
                    for j in lc.break_jumps { self.instrs[j].a = exit as i32; }
                    env.locals.pop();
                    return Ok(());
                }
                let ei = *self.eidx.get(ent).ok_or_else(|| format!("unknown entity {}", ent))?;
                env.locals.push((var.clone(), VT::Ent(ei)));
                if env.locals.len() > self.cur_max_locals {
                    self.cur_max_locals = env.locals.len();
                }
                let bgn = self.instrs.len();
                self.instrs.push(Instr::abc(OP_FOR_BGN, ei as i32, slot as i32, 0)); // c patched to exit
                env.loops.push(LoopCtx { break_pops_iter: true, try_depth: env.try_depth, ..Default::default() });
                self.gen_block(body, env, f, refs)?;
                let for_adv = self.instrs.len();
                self.instrs.push(Instr::a(OP_FOR_ADV, (bgn + 1) as i32)); // back to body start
                let lc = env.loops.pop().unwrap();
                // v17 continue: jumps INTO the FOR_ADV (it advances + re-enters
                // or pops the iterator when exhausted — exactly the next
                // iteration semantics)
                for j in lc.continue_jumps { self.instrs[j].a = for_adv as i32; }
                let exit = self.instrs.len();
                self.instrs[bgn].c = exit as i32;
                for j in lc.break_jumps { self.instrs[j].a = exit as i32; }
                env.locals.pop();
                Ok(())
            }
            // v17: `for (i: A..B) { ... }` — bounds evaluated ONCE into temps,
            // then the classic cond/inc loop shape. continue -> the increment;
            // break -> the exit. The loop var binds LIKE A `let` (Python
            // for-loop semantics: rebinds the name, stays in scope after) —
            // matching the checker, unlike entity for-loops (v16 pop rule).
            Stmt::ForNum(var, from, to, body) => {
                // v23.1: loop-carried — the ADV code after the body
                // re-reads these via the back edge
                let from_t = self.temp_local_loop(env);
                let to_t = self.temp_local_loop(env);
                let vt0 = self.gen_expr(from, env, f, refs)?;
                if vt0 == VT::Fixed { self.instrs.push(Instr::new(OP_F2I)); }
                self.instrs.push(Instr::a(OP_ST_LOCAL, from_t as i32));
                let vt1 = self.gen_expr(to, env, f, refs)?;
                if vt1 == VT::Fixed { self.instrs.push(Instr::new(OP_F2I)); }
                self.instrs.push(Instr::a(OP_ST_LOCAL, to_t as i32));
                // the loop var: let-style slot (reuse when the name exists)
                let slot = match env.locals.iter().position(|(n, _)| n == var) {
                    Some(s) => s,
                    None => env.locals.len(),
                };
                if slot == env.locals.len() {
                    env.locals.push((var.clone(), VT::Int));
                } else {
                    env.locals[slot].1 = VT::Int;
                }
                if env.locals.len() > self.cur_max_locals {
                    self.cur_max_locals = env.locals.len();
                }
                // INITIALIZE the counter from the (once-evaluated) lower
                // bound — the loop var reuses its slot across loops, so it
                // must be seeded every entry (found by test_v17: loop 2
                // started from loop 1's leftover counter!)
                self.instrs.push(Instr::a(OP_LD_LOCAL, from_t as i32));
                self.instrs.push(Instr::a(OP_ST_LOCAL, slot as i32));
                let top = self.instrs.len();
                self.instrs.push(Instr::a(OP_LD_LOCAL, slot as i32));
                self.instrs.push(Instr::a(OP_LD_LOCAL, to_t as i32));
                self.instrs.push(Instr::new(OP_LT_I));
                let jz = self.instrs.len();
                self.instrs.push(Instr::a(OP_JZ, 0));
                env.loops.push(LoopCtx { try_depth: env.try_depth, ..Default::default() });
                self.gen_block(body, env, f, refs)?;
                let inc = self.instrs.len();
                self.instrs.push(Instr::a(OP_LD_LOCAL, slot as i32));
                self.instrs.push(Instr::a(OP_PUSH_S8, 1));
                self.instrs.push(Instr::new(OP_ADD_I));
                self.instrs.push(Instr::a(OP_ST_LOCAL, slot as i32));
                self.instrs.push(Instr::a(OP_JMP, top as i32));
                let lc = env.loops.pop().unwrap();
                for j in lc.continue_jumps { self.instrs[j].a = inc as i32; }
                let end = self.instrs.len();
                self.instrs[jz].a = end as i32;
                for j in lc.break_jumps { self.instrs[j].a = end as i32; }
                Ok(())
            }
            // v17 LOOP CONTROL. break: (pop the iterator for entity for-
            // loops — the loop head pushed one) then jump to the exit,
            // patched when the loop closes. continue: jump to the continue
            // target (condition for while, increment for for-num, FOR_ADV
            // for entity for).
            Stmt::Break => {
                let lc = env.loops.last().expect("checker proved break is in a loop").clone();
                // v23.1: drop every try handler registered INSIDE the loop
                // (lexical unwind — innermost first, which is exactly the
                // VM's handler-stack order).
                for _ in lc.try_depth..env.try_depth {
                    self.instrs.push(Instr::new(OP_TRY_END));
                }
                if lc.break_pops_iter {
                    self.instrs.push(Instr::new(OP_ITER_POP));
                }
                let j = self.instrs.len();
                self.instrs.push(Instr::a(OP_JMP, 0));
                env.loops.last_mut().unwrap().break_jumps.push(j);
                Ok(())
            }
            Stmt::Continue => {
                let lc = env.loops.last().expect("checker proved continue is in a loop").clone();
                for _ in lc.try_depth..env.try_depth {
                    self.instrs.push(Instr::new(OP_TRY_END));
                }
                let j = self.instrs.len();
                self.instrs.push(Instr::a(OP_JMP, 0));
                env.loops.last_mut().unwrap().continue_jumps.push(j);
                Ok(())
            }
            // v17: switch — scrutinee evaluated ONCE into a temp local, then
            // a chain of equality tests per arm (labels OR-joined on the bool
            // stack). Int labels against a fixed scrutinee widen like `==`
            // (v << 8).
            Stmt::Switch(x, arms, dflt) => {
                let xvt = self.gen_expr(x, env, f, refs)?;
                // v23.1: the scrutinee temp is re-read by the search AND the
                // leaves on every re-execution — a switch inside a loop
                // replays it via back edges, so it must be persistent.
                let t = self.temp_local_loop(env);
                self.instrs.push(Instr::a(OP_ST_LOCAL, t as i32));
                // v23.1: BINARY-SEARCH dispatch. The old lowering was a
                // linear == chain — an N-arm switch cost O(N) comparisons
                // every frame. Labels are flattened (value -> arm), sorted,
                // and probed in a balanced binary search; the first arm
                // wins for duplicate labels (chain semantics preserved).
                // v23.1: labels are widened to the scrutinee's domain
                // FIRST (int literal vs fixed scrutinee widens like `==`),
                // then sorted — a total order, so a binary search over the
                // widened values is semantics-identical to the old chain.
                let is_fixed_scrut = xvt == VT::Fixed;
                let widen = |raw: i64, is_fix: bool| -> i64 {
                    if is_fix || !is_fixed_scrut { raw } else { raw << 8 }
                };
                let mut entries: Vec<(i64, usize)> = Vec::new();
                for (ai, (labels, _)) in arms.iter().enumerate() {
                    for (raw, is_fix) in labels {
                        let v = widen(*raw, *is_fix);
                        if !entries.iter().any(|(ev, _)| *ev == v) {
                            entries.push((v, ai));
                        }
                    }
                }
                entries.sort_by_key(|(v, _)| *v);
                let mut end_jumps: Vec<usize> = Vec::new();
                let mut leaf_jumps: Vec<Vec<usize>> = vec![Vec::new(); arms.len()];
                // v23.1: when NO label matches, execution must reach the
                // DEFAULT arm — the old chain fell into it naturally; the
                // search tree routes every exhausted subtree to the no-match
                // target explicitly (the draft version fell into the FIRST
                // arm's leaf — caught by the replay equivalence harness).
                let mut nomatch_jumps: Vec<usize> = Vec::new();
                if !entries.is_empty() {
                    self.emit_switch_search(&entries, t, is_fixed_scrut, &mut leaf_jumps, &mut nomatch_jumps, 0, entries.len());
                }
                // leaves: each arm's body emitted ONCE, reached by direct jump
                for (ai, (_, body)) in arms.iter().enumerate() {
                    if leaf_jumps[ai].is_empty() { continue; }
                    for j in &leaf_jumps[ai] { self.instrs[*j].a = self.instrs.len() as i32; }
                    self.gen_block(body, env, f, refs)?;
                    let j = self.instrs.len();
                    self.instrs.push(Instr::a(OP_JMP, 0));
                    end_jumps.push(j);
                }
                // no-match route: to the default if present, else the end
                let dflt_pos = self.instrs.len();
                for j in &nomatch_jumps { self.instrs[*j].a = dflt_pos as i32; }
                if let Some(d) = dflt {
                    self.gen_block(d, env, f, refs)?;
                }
                let end = self.instrs.len();
                for j in end_jumps { self.instrs[j].a = end as i32; }
                self.release_temp(env, t);
                Ok(())
            }
            Stmt::Spawn(ent, inits) => {
                let ei = *self.eidx.get(ent).ok_or_else(|| format!("unknown entity {}", ent))?;
                let ent_info = &self.ctx.entities[ei];
                let mut tfs = Vec::new();
                let mut cells: i32 = 0;
                // evaluate in source order; convert to field types
                for (fname, e) in inits {
                    let fi = ent_info.fields.iter().position(|x| &x.name == fname)
                        .ok_or_else(|| format!("entity {} has no field {}", ent, fname))?;
                    let fvt = ent_info.fields[fi].vt;
                    let vt = self.gen_expr(e, env, f, refs)?;
                    self.convert(vt, fvt);
                    // v23.1: f64 fields occupy TWO stack cells (lo, hi);
                    // the VM's SPAWN walks the tf list and consumes 1 or 2
                    // cells per field by schema width.
                    cells += if fvt == VT::F64 { 2 } else { 1 };
                    tfs.push(self.tf_of(ei as u8, fname)? as u16);
                }
                // v23.1: b = total STACK CELLS (f64 fields carry two).
                // The loader/VM walk the tf list, consuming 1 or 2 cells
                // per field by schema width — legacy carts (all 1-cell
                // fields) encode exactly the same bytes as before.
                let _ = cells;
                self.instrs.push(Instr { op: OP_SPAWN, a: ei as i32, b: cells, c: 0, extra: tfs });
                Ok(())
            }
            Stmt::Kill(e) => {
                // entity expr must be a variable; static type gives entity id
                if let Expr::Ident(v) = e {
                    let slot = self.slot_of(env, v);
                    let ei = match env.locals.iter().find(|(n, _)| n == v).map(|(_, vt)| *vt) {
                        Some(VT::Ent(i)) => i,
                        _ => return Err(crate::diag::internal("kill target has no entity type")),
                    };
                    self.instrs.push(Instr::ab(OP_KILL, slot as i32, ei as i32));
                    Ok(())
                } else {
                    Err(crate::diag::internal("kill target must be a variable"))
                }
            }
            // v20 SIGNALS: `emit #death;` — compiled to a SEQUENCE of plain
            // CALL_FN opcodes (one per handler, declaration order). The
            // runtime has no signal machinery at all: events are just
            // calls the compiler lined up. (A dedicated opcode was tried
            // and discarded — sequential handler firing falls out of the
            // CALL_FN ret_pc chain for free.)
            Stmt::Emit(atom) => {
                let si = *self.ctx.signal_index.get(atom)
                    .ok_or_else(|| crate::diag::internal("emit of undeclared signal"))?;
                let handlers = self.ctx.signals[si].handlers.clone();
                for &fi in &handlers {
                    self.instrs.push(Instr::ab(OP_CALL_FN, fi as i32, 0));
                }
                Ok(())
            }
            // v20 COROUTINES: lowered pre-check; reaching codegen is a bug
            Stmt::State(..) | Stmt::Wait(_) | Stmt::GotoState(_) => {
                Err(crate::diag::internal("coroutine statement reached codegen"))
            }
            // v21 DICTS: `mput(D, k, v);` — key then value on the stack (VM
            // pops val, key; raw 32-bit cells, ints stay raw, fixed stays Q24.8).
            Stmt::MapPut(d, k, v) => {
                let di = *self.didx.get(d)
                    .ok_or_else(|| crate::diag::internal("mput of unknown dict"))?;
                let _ = self.gen_expr(k, env, f, refs)?;
                let _ = self.gen_expr(v, env, f, refs)?;
                self.instrs.push(Instr::a(OP_M_PUT, di as i32));
                Ok(())
            }
            // v21 DICTS: `mdel(D, k);` — backward-shift delete (deterministic).
            Stmt::MapDel(d, k) => {
                let di = *self.didx.get(d)
                    .ok_or_else(|| crate::diag::internal("mdel of unknown dict"))?;
                let _ = self.gen_expr(k, env, f, refs)?;
                self.instrs.push(Instr::a(OP_M_DEL, di as i32));
                Ok(())
            }
            // v21 SORT: `psort(Pool, field);` — the global pfield id (pool*16+f)
            // names the key column; dir rides in c.
            Stmt::PSort(pool, field, dir) => {
                let pi = *self.pidx.get(pool)
                    .ok_or_else(|| crate::diag::internal("psort of unknown pool"))?;
                let pf = self.pf_of(pi, field)?;
                self.instrs.push(Instr::abc(OP_PSORT, pi as i32, pf as i32, *dir as i32));
                Ok(())
            }
            // v22 QUEUES: `qpush(Q, val);` — value on the stack, array id in a.
            Stmt::QPush(q, v) => {
                let ai = *self.arrs.get(&(GLOBAL_ENT, q.clone()))
                    .ok_or_else(|| crate::diag::internal(&format!("qpush of unknown queue {}", q)))?;
                let _ = self.gen_expr(v, env, f, refs)?;
                self.instrs.push(Instr::a(OP_QPUSH, ai as i32));
                Ok(())
            }
            // v22 STACKS: `spush(S, val);`
            Stmt::SPush(s, v) => {
                let ai = *self.arrs.get(&(GLOBAL_ENT, s.clone()))
                    .ok_or_else(|| crate::diag::internal(&format!("spush of unknown stack {}", s)))?;
                let _ = self.gen_expr(v, env, f, refs)?;
                self.instrs.push(Instr::a(OP_SPUSH, ai as i32));
                Ok(())
            }
            // v22 ARRAYS: `afill(A, val);` — value on the stack, fills cap cells.
            Stmt::AFill(a, v) => {
                let ai = *self.arrs.get(&(GLOBAL_ENT, a.clone()))
                    .ok_or_else(|| crate::diag::internal(&format!("afill of unknown array {}", a)))?;
                let _ = self.gen_expr(v, env, f, refs)?;
                self.instrs.push(Instr::a(OP_AFILL, ai as i32));
                Ok(())
            }
            // v22 ARRAYS: `acopy(dst, src, n);` — count on the stack, ids in a/b.
            Stmt::ACopy(d, s, n) => {
                let di = *self.arrs.get(&(GLOBAL_ENT, d.clone()))
                    .ok_or_else(|| crate::diag::internal(&format!("acopy dst {}", d)))?;
                let si = *self.arrs.get(&(GLOBAL_ENT, s.clone()))
                    .ok_or_else(|| crate::diag::internal(&format!("acopy src {}", s)))?;
                let _ = self.gen_expr(n, env, f, refs)?;
                self.instrs.push(Instr::ab(OP_ACOPY, di as i32, si as i32));
                Ok(())
            }
            // v22 ARRAYS: `ashuffle(A, n);` — count on the stack, array id in a.
            Stmt::AShuf(a, n) => {
                let ai = *self.arrs.get(&(GLOBAL_ENT, a.clone()))
                    .ok_or_else(|| crate::diag::internal(&format!("ashuffle of unknown array {}", a)))?;
                let _ = self.gen_expr(n, env, f, refs)?;
                self.instrs.push(Instr::a(OP_ASHUF, ai as i32));
                Ok(())
            }
            // v20 POOLS: `push Trail { x: 1.0, life: 30 };` — values evaluated
            // in written order (converted to field types), one opcode appends
            // the row with defaults filling the unlisted fields.
            Stmt::PoolPush(pool, inits) => {
                let pi = *self.pidx.get(pool).ok_or_else(|| format!("unknown pool {}", pool))?;
                let pinfo = &self.ctx.pools[pi];
                let mut fields = Vec::new();
                for (fname, e) in inits {
                    let fi = pinfo.fields.iter().position(|x| &x.name == fname)
                        .ok_or_else(|| format!("pool {} has no field {}", pool, fname))?;
                    let fvt = pinfo.fields[fi].vt;
                    let vt = self.gen_expr(e, env, f, refs)?;
                    self.convert(vt, fvt);
                    fields.push(fi as u16);
                    // v23.6: b stays the LISTED-FIELD count (the wire's extra
                    // list is decoded with b as the entry count); the runtime
                    // derives the cell window from the schema widths — a wide
                    // (f64) field's init value rides a (lo, hi) pair.
                }
                self.instrs.push(Instr { op: OP_PL_PUSH, a: pi as i32, b: fields.len() as i32, c: 0, extra: fields });
                Ok(())
            }
            // v20 POOLS: `remove(t);` — the handle variable's pool rides in
            // the operand (checker proved the type).
            Stmt::PoolRemove(e) => {
                if let Expr::Ident(v) = e {
                    let slot = self.slot_of(env, v);
                    let pi = match env.locals.iter().find(|(n, _)| n == v).map(|(_, vt)| *vt) {
                        Some(VT::Pool(i)) => i,
                        _ => return Err(crate::diag::internal("remove target has no pool type")),
                    };
                    self.instrs.push(Instr::ab(OP_PL_REM, slot as i32, pi as i32));
                    Ok(())
                } else {
                    Err(crate::diag::internal("remove target must be a variable"))
                }
            }
            Stmt::Sfx(a) => {
                let p = self.dom_pos(&self.ctx.sound, *a, "sound")?;
                self.instrs.push(Instr::a(OP_SFX, p as i32));
                Ok(())
            }
            Stmt::Music(a) => {
                let p = self.dom_pos(&self.ctx.music.iter().map(|m| m.atom).collect::<Vec<_>>(), *a, "music")?;
                self.instrs.push(Instr::a(OP_MUSIC, p as i32));
                Ok(())
            }
            Stmt::StopMusic => { self.instrs.push(Instr::new(OP_STOP_MUSIC)); Ok(()) }
            Stmt::Shake(amp) => {
                self.instrs.push(Instr::a(OP_SHAKE, *amp as i32));
                Ok(())
            }
            Stmt::Camera(x, y) => {
                // both args to fixed; engine clamps to the world
                self.gen_num_fixed(x, env, f, refs)?;
                self.gen_num_fixed(y, env, f, refs)?;
                self.instrs.push(Instr::new(OP_CAMERA));
                Ok(())
            }
            Stmt::Cam3(x, y, z, yaw, pitch) => {
                // v11 3D: push x, y, z (fixed), yaw, pitch (ang as-is) —
                // VM pops pitch, yaw, z, y, x into the page-0 registers.
                self.gen_num_fixed(x, env, f, refs)?;
                self.gen_num_fixed(y, env, f, refs)?;
                self.gen_num_fixed(z, env, f, refs)?;
                self.gen_expr(yaw, env, f, refs)?;
                self.gen_expr(pitch, env, f, refs)?;
                self.instrs.push(Instr::new(OP_CAM3));
                Ok(())
            }
            Stmt::Draw3d { arr, n, x, y, z, yaw, rgba } => {
                // v11 3D mesh pass: array id rides in `a`; stack args are
                // n (int), x/y/z (fixed), yaw (ang), rgba (int) — the VM
                // pops rgba, yaw, z, y, x, n and hands off to render3d.
                let id = *self.arrs.get(&(GLOBAL_ENT, arr.clone()))
                    .ok_or_else(|| crate::diag::internal(&format!("draw3d array {} missing", arr)))?;
                self.gen_expr(n, env, f, refs)?;
                self.gen_num_fixed(x, env, f, refs)?;
                self.gen_num_fixed(y, env, f, refs)?;
                self.gen_num_fixed(z, env, f, refs)?;
                self.gen_expr(yaw, env, f, refs)?;
                self.gen_expr(rgba, env, f, refs)?;
                self.instrs.push(Instr::a(OP_DRAW3D, id as i32));
                Ok(())
            }
            Stmt::Draw3DI { verts, nv, idx, ni, x, y, z, yaw, rgba } => {
                // v12 indexed mesh pass: a = vertex buffer id, b = index
                // buffer id; stack args nv, ni, x, y, z, yaw, rgba pushed in
                // source order — the VM pops rgba, yaw, z, y, x, ni, nv.
                let vid = *self.arrs.get(&(GLOBAL_ENT, verts.clone()))
                    .ok_or_else(|| crate::diag::internal(&format!("draw3di vertex buffer {} missing", verts)))?;
                let iid = *self.arrs.get(&(GLOBAL_ENT, idx.clone()))
                    .ok_or_else(|| crate::diag::internal(&format!("draw3di index buffer {} missing", idx)))?;
                self.gen_expr(nv, env, f, refs)?;
                self.gen_expr(ni, env, f, refs)?;
                self.gen_num_fixed(x, env, f, refs)?;
                self.gen_num_fixed(y, env, f, refs)?;
                self.gen_num_fixed(z, env, f, refs)?;
                self.gen_expr(yaw, env, f, refs)?;
                self.gen_expr(rgba, env, f, refs)?;
                self.instrs.push(Instr::ab(OP_DRAW3DI, vid as i32, iid as i32));
                Ok(())
            }
            Stmt::QuatAA { q, off, ax, ay, az, ang } => {
                // v12: quat_aa(q, off, ax, ay, az, ang) — array id pushed as
                // a raw int constant, then off/axis/angle. One native op.
                let qid = *self.arrs.get(&(GLOBAL_ENT, q.clone()))
                    .ok_or_else(|| crate::diag::internal(&format!("quat_aa array {} missing", q)))?;
                self.push_const(qid as i32);
                self.gen_expr(off, env, f, refs)?;
                self.gen_num_fixed(ax, env, f, refs)?;
                self.gen_num_fixed(ay, env, f, refs)?;
                self.gen_num_fixed(az, env, f, refs)?;
                self.gen_expr(ang, env, f, refs)?;
                self.instrs.push(Instr::new(OP_QUAT_AA));
                Ok(())
            }
            Stmt::QMul { d, doff, a, aoff, b, boff } => {
                let did = *self.arrs.get(&(GLOBAL_ENT, d.clone()))
                    .ok_or_else(|| crate::diag::internal(&format!("qmul array {} missing", d)))?;
                let aid = *self.arrs.get(&(GLOBAL_ENT, a.clone()))
                    .ok_or_else(|| crate::diag::internal(&format!("qmul array {} missing", a)))?;
                let bid = *self.arrs.get(&(GLOBAL_ENT, b.clone()))
                    .ok_or_else(|| crate::diag::internal(&format!("qmul array {} missing", b)))?;
                self.push_const(did as i32);
                self.gen_expr(doff, env, f, refs)?;
                self.push_const(aid as i32);
                self.gen_expr(aoff, env, f, refs)?;
                self.push_const(bid as i32);
                self.gen_expr(boff, env, f, refs)?;
                self.instrs.push(Instr::new(OP_Q_MUL));
                Ok(())
            }
            Stmt::M4QT { m, moff, q, qoff, tx, ty, tz } => {
                let mid = *self.arrs.get(&(GLOBAL_ENT, m.clone()))
                    .ok_or_else(|| crate::diag::internal(&format!("m4qt array {} missing", m)))?;
                let qid = *self.arrs.get(&(GLOBAL_ENT, q.clone()))
                    .ok_or_else(|| crate::diag::internal(&format!("m4qt array {} missing", q)))?;
                self.push_const(mid as i32);
                self.gen_expr(moff, env, f, refs)?;
                self.push_const(qid as i32);
                self.gen_expr(qoff, env, f, refs)?;
                self.gen_num_fixed(tx, env, f, refs)?;
                self.gen_num_fixed(ty, env, f, refs)?;
                self.gen_num_fixed(tz, env, f, refs)?;
                self.instrs.push(Instr::new(OP_M4_QT));
                Ok(())
            }
            Stmt::M4Mul { d, doff, a, aoff, b, boff } => {
                let did = *self.arrs.get(&(GLOBAL_ENT, d.clone()))
                    .ok_or_else(|| crate::diag::internal(&format!("m4mul array {} missing", d)))?;
                let aid = *self.arrs.get(&(GLOBAL_ENT, a.clone()))
                    .ok_or_else(|| crate::diag::internal(&format!("m4mul array {} missing", a)))?;
                let bid = *self.arrs.get(&(GLOBAL_ENT, b.clone()))
                    .ok_or_else(|| crate::diag::internal(&format!("m4mul array {} missing", b)))?;
                self.push_const(did as i32);
                self.gen_expr(doff, env, f, refs)?;
                self.push_const(aid as i32);
                self.gen_expr(aoff, env, f, refs)?;
                self.push_const(bid as i32);
                self.gen_expr(boff, env, f, refs)?;
                self.instrs.push(Instr::new(OP_M4_MUL));
                Ok(())
            }
            Stmt::SkinV { v, voff, m, moff, x, y, z } => {
                let vid = *self.arrs.get(&(GLOBAL_ENT, v.clone()))
                    .ok_or_else(|| crate::diag::internal(&format!("skinv array {} missing", v)))?;
                let mid = *self.arrs.get(&(GLOBAL_ENT, m.clone()))
                    .ok_or_else(|| crate::diag::internal(&format!("skinv array {} missing", m)))?;
                self.push_const(vid as i32);
                self.gen_expr(voff, env, f, refs)?;
                self.push_const(mid as i32);
                self.gen_expr(moff, env, f, refs)?;
                self.gen_num_fixed(x, env, f, refs)?;
                self.gen_num_fixed(y, env, f, refs)?;
                self.gen_num_fixed(z, env, f, refs)?;
                self.instrs.push(Instr::new(OP_SKIN3));
                Ok(())
            }
            Stmt::MusicVol(vol) => {
                self.instrs.push(Instr::a(OP_MUSIC_VOL, *vol as i32));
                Ok(())
            }
            Stmt::Save(ix, v) => {
                // push slot index, then the RAW value (no conversion — slots
                // are untyped 32-bit words; the read side picks the type)
                self.gen_expr(ix, env, f, refs)?;
                self.gen_expr(v, env, f, refs)?;
                self.instrs.push(Instr::new(OP_SAVE));
                Ok(())
            }
            Stmt::Goto(a) => {
                let scene_atoms: Vec<u16> = self.ctx.scenes.iter().map(|(s, _)| *s).collect();
                let p = self.dom_pos(&scene_atoms, *a, "scene")?;
                self.instrs.push(Instr::a(OP_GOTO, p as i32));
                Ok(())
            }
            Stmt::Draw(spr, x, y, rot, scale, rgba) => {
                let spr_atoms: Vec<u16> = self.ctx.sprites.iter().map(|s| s.atom).collect();
                let p = self.dom_pos(&spr_atoms, *spr, "sprite")?;
                // x, y: to fixed
                self.gen_num_fixed(x, env, f, refs)?;
                self.gen_num_fixed(y, env, f, refs)?;
                // rot: ang value or int literal
                let rvt = self.gen_expr(rot, env, f, refs)?;
                if rvt == VT::Int {
                    // int literal -> ang units 1:1 (already pushed)
                }
                self.gen_num_fixed(scale, env, f, refs)?;
                // rgba
                let _cvt = self.gen_expr(rgba, env, f, refs)?;
                self.instrs.push(Instr::a(OP_DRAW, p as i32));
                Ok(())
            }
            Stmt::DrawText(a, x, y, rgba) => {
                let text_atoms: Vec<u16> = self.ctx.texts.iter().map(|(t, _)| *t).collect();
                let p = self.dom_pos(&text_atoms, *a, "text")?;
                self.gen_num_fixed(x, env, f, refs)?;
                self.gen_num_fixed(y, env, f, refs)?;
                self.gen_expr(rgba, env, f, refs)?;
                self.instrs.push(Instr::a(OP_DRAW_TEXT, p as i32));
                Ok(())
            }
            Stmt::DrawNum(v, x, y, rgba) => {
                let vvt = self.gen_expr(v, env, f, refs)?;
                if vvt == VT::Fixed {
                    self.instrs.push(Instr::new(OP_F2I));
                }
                self.gen_num_fixed(x, env, f, refs)?;
                self.gen_num_fixed(y, env, f, refs)?;
                self.gen_expr(rgba, env, f, refs)?;
                self.instrs.push(Instr::new(OP_DRAW_NUM));
                Ok(())
            }
            // v21 ARCADE: draw_numz(v, digits, x, y, rgba) — zero-padded
            // integer draw (the scoreboard form). Same stack shape as
            // DRAW_NUM; the digit count rides in `a`.
            Stmt::DrawNumZ(v, digits, x, y, rgba) => {
                let vvt = self.gen_expr(v, env, f, refs)?;
                if vvt == VT::Fixed {
                    self.instrs.push(Instr::new(OP_F2I));
                }
                self.gen_num_fixed(x, env, f, refs)?;
                self.gen_num_fixed(y, env, f, refs)?;
                self.gen_expr(rgba, env, f, refs)?;
                self.instrs.push(Instr::a(OP_DRAW_NUMZ, *digits as i32));
                Ok(())
            }
            Stmt::CallStmt(name, args) => {
                let fi = *self.fidx.get(name)
                    .ok_or_else(|| format!("unknown fn {}", name))?;
                let target = &self.ctx.fns[fi];
                let mut arg_cells: i32 = 0;
                for (i, (_, pvt)) in target.params.iter().enumerate() {
                    let vt = self.gen_expr(&args[i], env, f, refs)?;
                    self.convert(vt, *pvt);
                    // v23.5: the arg window counts CELLS — f64 args carry two
                    arg_cells += if *pvt == VT::F64 { 2 } else { 1 };
                }
                self.instrs.push(Instr::ab(OP_CALL_FN, fi as i32, arg_cells));
                Ok(())
            }
            Stmt::CallTable(tname, key, entvar) => {
                let ti = self.ctx.tables.iter().position(|t| &t.name == tname)
                    .ok_or_else(|| format!("unknown table {}", tname))?;
                self.gen_expr(key, env, f, refs)?;
                let slot = self.slot_of(env, entvar);
                self.instrs.push(Instr::ab(OP_CALL_TBL, ti as i32, slot as i32));
                Ok(())
            }
            Stmt::Return(None) => {
                // v17: void return in a VALUED fn means `return 0;`
                // v23.6: in an f64 fn it means `return 0.0;` (two cells).
                if f.ret == Some(VT::F64) {
                    self.instrs.push(Instr::a(OP_PUSH_S8, 0));
                    self.instrs.push(Instr::a(OP_PUSH_S8, 0));
                    self.instrs.push(Instr::new(OP_RET_V64));
                } else if f.ret.is_some() {
                    self.instrs.push(Instr::a(OP_PUSH_S8, 0));
                    self.instrs.push(Instr::new(OP_RET_V));
                } else {
                    self.instrs.push(Instr::new(OP_RET));
                }
                Ok(())
            }
            Stmt::Return(Some(e)) => {
                // v17 RETURN VALUES: evaluate, convert to the fn's inferred
                // type, park it in the threadlocal ret register, pop frame.
                // v23.6: an f64 return widens int/fixed/f32 to the (lo, hi)
                // pair and parks BOTH cells (RET_V64).
                let evt = self.gen_expr(e, env, f, refs)?;
                let want = f.ret.expect("checker inferred a type for every valued fn");
                if want == VT::Fixed && evt == VT::Int {
                    self.instrs.push(Instr::new(OP_I2F));
                }
                if want == VT::F64 {
                    self.convert(evt, VT::F64);
                    self.instrs.push(Instr::new(OP_RET_V64));
                } else {
                    self.instrs.push(Instr::new(OP_RET_V));
                }
                Ok(())
            }
            // v17 3D: m4look — one native opcode over the rig arrays
            Stmt::M4Look { m, moff, ex, ey, ez, tx, ty, tz } => {
                let mid = *self.arrs.get(&(GLOBAL_ENT, m.clone()))
                    .ok_or_else(|| crate::diag::internal(&format!("m4look array {} missing", m)))?;
                self.push_const(mid as i32);
                self.gen_expr(moff, env, f, refs)?;
                self.gen_num_fixed(ex, env, f, refs)?;
                self.gen_num_fixed(ey, env, f, refs)?;
                self.gen_num_fixed(ez, env, f, refs)?;
                self.gen_num_fixed(tx, env, f, refs)?;
                self.gen_num_fixed(ty, env, f, refs)?;
                self.gen_num_fixed(tz, env, f, refs)?;
                self.instrs.push(Instr::new(OP_M4_LOOK));
                Ok(())
            }
            // v8 OPTIMIZER subsystem 3: Galois-lane candidate loop.
            // Emitted by opt::physics; the mask local was materialized by the
            // COLLIDE_MASK let right before this statement.
            Stmt::ForMask(var, ent_name, mask_local, body) => {
                let ei = *self.eidx.get(ent_name)
                    .ok_or_else(|| format!("unknown entity {}", ent_name))?;
                let slot = match env.locals.iter().position(|(n, _)| n == var) {
                    Some(s) => s,
                    None => env.locals.len(),
                };
                env.locals.push((var.clone(), VT::Ent(ei)));
                if env.locals.len() > self.cur_max_locals {
                    self.cur_max_locals = env.locals.len();
                }
                // push the mask, then open the ctz-scan loop. The window
                // base (from the mask's Let) rides in b's high bits.
                let mslot = self.slot_of(env, mask_local);
                self.instrs.push(Instr::a(OP_LD_LOCAL, mslot as i32));
                let base = self.mask_base.get(mask_local).copied().unwrap_or(0);
                let bgn = self.instrs.len();
                self.instrs.push(Instr::abc(OP_FOR_MASK_BGN, slot as i32, ei as i32 | (base << 8), 0));
                self.gen_block(body, env, f, refs)?;
                self.instrs.push(Instr::a(OP_FOR_MASK_ADV, (bgn + 1) as i32));
                let exit = self.instrs.len();
                self.instrs[bgn].c = exit as i32;
                env.locals.pop();
                Ok(())
            }
            // opt::fsm replaces these before codegen; reaching here is a bug.
            Stmt::FsmStep(_) => Err("internal: FsmStep survived the fsm pass".into()),
            // v23 STEP 8: try/catch + throw codegen. These are Tier-1
            // statements — the tier purity fixpoint has already demoted
            // the fn to Tier-1, and the optimizer gates have skipped it.
            // Codegen lowers try/catch to zero-cost unwind tables:
            //   - The try body emits normally
            //   - A landing pad is registered for the catch
            //   - throw lowers to a jump to the landing pad
            // For the v23 bridge, we emit the body + catch_body inline
            // (the unwind table machinery is the host's job — the AOT
            // backend's C/LLVM output handles it natively via __builtin_setjmp).
            // v23.1: REAL exception lowering against the VM's handler
            // stack (OP_TRY registers {catch pc, sp, fp, slot}; OP_THROW
            // unwinds to it; OP_TRY_END drops it on normal completion).
            // The handler stack is threadlocal interpreter state — the
            // snapshot hash chain never sees it.
            Stmt::TryCatch { body, catch_var, catch_body } => {
                // catch var: one Int slot
                env.locals.push((catch_var.clone(), VT::Int));
                let slot = env.locals.len() - 1;
                if env.locals.len() > self.cur_max_locals {
                    self.cur_max_locals = env.locals.len();
                }
                let try_idx = self.instrs.len();
                self.instrs.push(Instr::ab(OP_TRY, 0, slot as i32)); // a patched below
                env.try_depth += 1;
                self.gen_block(body, env, f, refs)?;
                env.try_depth -= 1;
                self.instrs.push(Instr::new(OP_TRY_END));
                // jump over the catch body on normal completion
                let jend = self.instrs.len();
                self.instrs.push(Instr::a(OP_JMP, 0));
                // catch landing pad: the VM pushes the error value here
                let catch_pc = self.instrs.len();
                self.instrs[try_idx].a = catch_pc as i32;
                self.instrs.push(Instr::a(OP_ST_LOCAL, slot as i32));
                self.gen_block(catch_body, env, f, refs)?;
                let after = self.instrs.len();
                self.instrs[jend].a = after as i32;
                Ok(())
            }
            Stmt::Throw(e) => {
                let _ = self.gen_expr(e, env, f, refs)?; // Int error code
                self.instrs.push(Instr::new(OP_THROW));
                Ok(())
            }
        }
    }

    /// v23.1: balanced binary-search dispatch for `switch`. Emits
    /// equality probes against the sorted, widened label values; equality
    /// jumps straight to the arm's leaf (patched later), less-than recurses
    /// left, fallthrough recurses right. O(log N) comparisons per frame
    /// instead of the old O(N) linear chain.
    fn emit_switch_search(
        &mut self,
        entries: &[(i64, usize)],
        t: usize,
        is_fixed_scrut: bool,
        leaf_jumps: &mut [Vec<usize>],
        nomatch_jumps: &mut Vec<usize>,
        lo: usize,
        hi: usize,
    ) {
        // empty range: nothing can match here — route to the default
        if lo >= hi {
            let j = self.instrs.len();
            self.instrs.push(Instr::a(OP_JMP, 0));
            nomatch_jumps.push(j);
            return;
        }
        let mid = (lo + hi) / 2;
        let (val, arm) = entries[mid];
        // probe: x == val ?
        self.instrs.push(Instr::a(OP_LD_LOCAL, t as i32));
        self.push_const(val as i32);
        self.instrs.push(Instr::new(if is_fixed_scrut { OP_EQ_F } else { OP_EQ_I }));
        let jeq = self.instrs.len();
        self.instrs.push(Instr::a(OP_JNZ, 0));
        if hi - lo > 1 {
            // x < val ? -> left half; fallthrough -> right half
            self.instrs.push(Instr::a(OP_LD_LOCAL, t as i32));
            self.push_const(val as i32);
            self.instrs.push(Instr::new(if is_fixed_scrut { OP_LT_F } else { OP_LT_I }));
            let jlt = self.instrs.len();
            self.instrs.push(Instr::a(OP_JNZ, 0));
            self.emit_switch_search(entries, t, is_fixed_scrut, leaf_jumps, nomatch_jumps, mid + 1, hi);
            let next = self.instrs.len();
            self.instrs[jlt].a = next as i32;
            self.emit_switch_search(entries, t, is_fixed_scrut, leaf_jumps, nomatch_jumps, lo, mid);
        } else {
            // single-entry range: not-equal means no match anywhere
            let j = self.instrs.len();
            self.instrs.push(Instr::a(OP_JMP, 0));
            nomatch_jumps.push(j);
        }
        // equality lands here — jump to the arm's leaf (emitted later)
        self.instrs[jeq].a = self.instrs.len() as i32;
        let j = self.instrs.len();
        self.instrs.push(Instr::a(OP_JMP, 0));
        leaf_jumps[arm].push(j);
    }

    fn gen_assign(&mut self, target: &Expr, op: AssignOp, val: &Expr, env: &mut Env, f: &FnInfo, refs: &CtxRefs) -> Result<(), String> {
        // v11 ARRAYS: element store / compound element update. The index is
        // evaluated exactly ONCE (DUP keeps it under the element for the
        // store), so rand()-carrying indices stay deterministic.
        // v17: gen_arr_index flattens 2-D accesses and emits the wrapped
        // linear cell index (each axis evaluated once on its own).
        if let Expr::Index(_base, _ix) = target {
            let (arr_id, elem_vt, ent_var) = self.gen_arr_index(target, env, f, refs)?;
            let earr_slot = ent_var.as_ref().map(|v| self.slot_of(env, v)).unwrap_or(0);
            match op {
                AssignOp::Set => {
                    // [idx] -> push val -> store
                    let vvt = self.gen_expr(val, env, f, refs)?;
                    self.convert(vvt, elem_vt);
                }
                _ => {
                    // [idx] -> DUP -> load elem -> push val -> op -> store
                    self.instrs.push(Instr::new(OP_DUP));
                    let ld_op = if self.ctx.arrays[arr_id].ent == GLOBAL_ENT { OP_LD_GARR } else { OP_LD_EARR };
                    if self.ctx.arrays[arr_id].ent == GLOBAL_ENT {
                        self.instrs.push(Instr::a(ld_op, arr_id as i32));
                    } else {
                        self.instrs.push(Instr::ab(ld_op, earr_slot as i32, arr_id as i32));
                    }
                    let vvt = self.gen_expr(val, env, f, refs)?;
                    match (elem_vt, vvt) {
                        (VT::Fixed, VT::Int) => { self.instrs.push(Instr::new(OP_I2F)); }
                        _ => {}
                    }
                    let opn = match (elem_vt, op) {
                        (VT::Fixed, AssignOp::Add) => OP_ADD_F,
                        (VT::Fixed, AssignOp::Sub) => OP_SUB_F,
                        (VT::Fixed, AssignOp::Mul) => OP_MUL_F,
                        // v23.1: the full compound-assign family
                        (VT::Fixed, AssignOp::Div) => OP_DIV_F,
                        (_, AssignOp::Add) => OP_ADD_I,
                        (_, AssignOp::Sub) => OP_SUB_I,
                        (_, AssignOp::Mul) => OP_MUL_I,
                        (_, AssignOp::Div) => OP_DIV_I,
                        (_, AssignOp::Mod) => OP_MOD_I,
                        (_, AssignOp::And) => OP_AND_I,
                        (_, AssignOp::Or) => OP_OR_I,
                        (_, AssignOp::Xor) => OP_XOR_I,
                        (_, AssignOp::Shl) => OP_SHL,
                        (_, AssignOp::Shr) => OP_SHR,
                        (VT::Fixed, AssignOp::Set) | (_, AssignOp::Set) => unreachable!(),
                    };
                    self.instrs.push(Instr::new(opn));
                }
            }
            // store: pops result, pops idx
            if self.ctx.arrays[arr_id].ent == GLOBAL_ENT {
                self.instrs.push(Instr::a(OP_ST_GARR, arr_id as i32));
            } else {
                self.instrs.push(Instr::ab(OP_ST_EARR, earr_slot as i32, arr_id as i32));
            }
            return Ok(());
        }
        // determine target kind + type
        let (tvt, ent_u8, tf_or_slot, is_local, name) = match target {
            Expr::Ident(name) => {
                if let Some(slot) = env.locals.iter().position(|(n, _)| n == name) {
                    let vt = env.locals[slot].1;
                    (vt, 0xFFu8, slot as usize, true, name.clone())
                } else if let Some(gi) = self.gidx.get(name) {
                    (self.ctx.globals[*gi].vt, GLOBAL_ENT, *gi, false, name.clone())
                } else { return Err(format!("unknown variable {}", name)); }
            }
            Expr::Field(base, fname) => {
                match &**base {
                    Expr::Ident(v) => {
                        // v20 POOLS: `t.x` where t is a pool handle — its own
                        // load/store opcode pair (a=handle slot, b=global pfield)
                        if let Some((_, VT::Pool(pi))) = env.locals.iter().find(|(n, _)| n == v) {
                            let fi = self.ctx.pools[*pi].fields.iter().position(|x| &x.name == fname)
                                .ok_or_else(|| format!("pool {} has no field {}", v, fname))?;
                            let pf = self.pf_of(*pi, fname)?;
                            let pvt = self.ctx.pools[*pi].fields[fi].vt;
                            let slot = self.slot_of(env, v);
                            // load current (compound ops)
                            if op != AssignOp::Set {
                                self.instrs.push(Instr::ab(OP_PL_LD, slot as i32, pf as i32));
                            }
                            let vvt = self.gen_expr(val, env, f, refs)?;
                            if op != AssignOp::Set {
                                match (pvt, vvt) {
                                    (VT::Fixed, VT::Int) => { self.instrs.push(Instr::new(OP_I2F)); }
                                    _ => {}
                                }
                            } else {
                                self.convert(vvt, pvt);
                            }
                            use AssignOp::*;
                            match (pvt, op) {
                                (VT::Fixed, Add) => self.instrs.push(Instr::new(OP_ADD_F)),
                                (VT::Fixed, Sub) => self.instrs.push(Instr::new(OP_SUB_F)),
                                (VT::Fixed, Mul) => self.instrs.push(Instr::new(OP_MUL_F)),
                                (VT::F32, Add) => self.instrs.push(Instr::new(OP_F32_ADD)),
                                (VT::F32, Sub) => self.instrs.push(Instr::new(OP_F32_SUB)),
                                (VT::F32, Mul) => self.instrs.push(Instr::new(OP_F32_MUL)),
                                (VT::F32, Set) => {}
                                // v23.6: wide fields compound over the (lo, hi)
                                // pair — the f64 opcodes pop 4, push 2 cells.
                                (VT::F64, Add) => self.instrs.push(Instr::new(OP_F64_ADD)),
                                (VT::F64, Sub) => self.instrs.push(Instr::new(OP_F64_SUB)),
                                (VT::F64, Mul) => self.instrs.push(Instr::new(OP_F64_MUL)),
                                (VT::F64, Set) => {}
                                (VT::Int, Add) | (VT::Ang, Add) => self.instrs.push(Instr::new(OP_ADD_I)),
                                (VT::Int, Sub) | (VT::Ang, Sub) => self.instrs.push(Instr::new(OP_SUB_I)),
                                (VT::Int, Mul) => self.instrs.push(Instr::new(OP_MUL_I)),
                                (VT::Bool, Set) | (VT::Ang, Set) | (VT::Int, Set) | (VT::Fixed, Set) => {}
                                _ => return Err(format!("internal: bad compound pool assign {:?} {:?}", pvt, op)),
                            }
                            self.instrs.push(Instr::ab(OP_PL_ST, slot as i32, pf as i32));
                            return Ok(());
                        }
                        if let Some((_, VT::Ent(ei))) = env.locals.iter().find(|(n, _)| n == v) {
                            let fi = self.ctx.entities[*ei].fields.iter().position(|x| &x.name == fname)
                                .ok_or_else(|| format!("entity {} no field {}", v, fname))?;
                            (self.ctx.entities[*ei].fields[fi].vt, *ei as u8, fi, false, fname.clone())
                        } else { return Err(format!("{} not entity", v)); }
                    }
                    _ => return Err("bad target".into()),
                }
            }
            _ => return Err("bad target".into()),
        };
        // tf index for non-local targets
        let tf_idx = if is_local { None } else {
            Some(self.tf_of(ent_u8, &name)?)
        };

        // load current value for compound ops
        if op != AssignOp::Set {
            if is_local {
                // v23.1: f64 local compound load pushes TWO cells
                if tvt == VT::F64 {
                    self.instrs.push(Instr::a(OP_LD_LOCAL, tf_or_slot as i32));
                    self.instrs.push(Instr::a(OP_LD_LOCAL, (tf_or_slot + 1) as i32));
                } else {
                    self.instrs.push(Instr::a(OP_LD_LOCAL, tf_or_slot as i32));
                }
            } else if ent_u8 == GLOBAL_ENT {
                self.instrs.push(Instr::a(OP_LD_GLBL, tf_idx.unwrap() as i32));
            } else {
                let slot = self.slot_of(env, &field_var_name(target));
                self.instrs.push(Instr::ab(OP_LD_ENT, slot as i32, tf_idx.unwrap() as i32));
            }
        }

        // value
        let vvt = self.gen_expr(val, env, f, refs)?;

        use AssignOp::*;
        // conversion for compound arithmetic
        if op != Set {
            match (tvt, vvt) {
                (VT::Fixed, VT::Int) => { self.instrs.push(Instr::new(OP_I2F)); }
                _ => {}
            }
        } else {
            self.convert(vvt, tvt);
        }
        // apply op
        match (tvt, op) {
            (VT::Fixed, Add) => self.instrs.push(Instr::new(OP_ADD_F)),
            (VT::Fixed, Sub) => self.instrs.push(Instr::new(OP_SUB_F)),
            (VT::Fixed, Mul) => self.instrs.push(Instr::new(OP_MUL_F)),
            (VT::F32, Add) => self.instrs.push(Instr::new(OP_F32_ADD)),
            (VT::F32, Sub) => self.instrs.push(Instr::new(OP_F32_SUB)),
            (VT::F32, Mul) => self.instrs.push(Instr::new(OP_F32_MUL)),
            (VT::F32, Set) => {}
            // v23.1: f64 compound ops (two-cell operands, two-cell result)
            (VT::F64, Add) => self.instrs.push(Instr::new(OP_F64_ADD)),
            (VT::F64, Sub) => self.instrs.push(Instr::new(OP_F64_SUB)),
            (VT::F64, Mul) => self.instrs.push(Instr::new(OP_F64_MUL)),
            (VT::F64, Div) => self.instrs.push(Instr::new(OP_F64_DIV)),
            (VT::F64, Set) => {}
            // v23.1: the full compound-assign family
            (VT::Fixed, Div) => self.instrs.push(Instr::new(OP_DIV_F)),
            (VT::F32, Div) => self.instrs.push(Instr::new(OP_F32_DIV)),
            (VT::F64, Div) => unreachable!(),
            (_, Div) => self.instrs.push(Instr::new(OP_DIV_I)),
            (_, Mod) => self.instrs.push(Instr::new(OP_MOD_I)),
            (_, And) => self.instrs.push(Instr::new(OP_AND_I)),
            (_, Or) => self.instrs.push(Instr::new(OP_OR_I)),
            (_, Xor) => self.instrs.push(Instr::new(OP_XOR_I)),
            (_, Shl) => self.instrs.push(Instr::new(OP_SHL)),
            (_, Shr) => self.instrs.push(Instr::new(OP_SHR)),
            // v23.1: vec4u8 lane-wise +=
            (VT::Vec4U8, Add) => self.instrs.push(Instr::new(OP_VEC4U_ADD)),
            (VT::Vec4U8, Set) => {}
            (VT::Int, Add) | (VT::Ang, Add) => self.instrs.push(Instr::new(OP_ADD_I)),
            (VT::Int, Sub) | (VT::Ang, Sub) => self.instrs.push(Instr::new(OP_SUB_I)),
            (VT::Int, Mul) => self.instrs.push(Instr::new(OP_MUL_I)),
            (VT::Bool, Set) | (VT::Ang, Set) | (VT::Int, Set) | (VT::Fixed, Set) => {}
            _ => return Err(format!("internal: bad compound assign {:?} {:?}", tvt, op)),
        }
        // auto-wrap injection: POSITION fields — exactly "x"/"y", matching
        // the auto-integrator's registered x/vx, y/vy pairs — get a bitwise
        // AND mask on store (the documented "you never write the wrap" rule).
        //
        // CRITICAL: match EXACT names, never suffixes. The old ends_with('x'/'y')
        // test also caught vx/vy (velocities!) — masking those corrupted their
        // sign domain: a stored -98px/frame became 130,974 raw, after which
        // every drag (`v -= v/40`), clamp, and accumulation operated on a
        // garbage magnitude. Negative velocities then "unwound" through the
        // wrap domain at up to 250px/frame — the ships-and-enemies-
        // teleporting bug. Only integrator-managed positions wrap; velocities
        // stay pure Q24.8 two's-complement.
        if self.ctx.game.wrap && tvt == VT::Fixed && (name == "x" || name == "y") {
            // v7: wrap domain is the WORLD (defaults to the screen — v1
            // behavior when no world_w/world_h is declared)
            let dim = if name == "x" {
                self.ctx.game.world_w.unwrap_or(self.ctx.game.width)
            } else {
                self.ctx.game.world_h.unwrap_or(self.ctx.game.height)
            };
            let mask = ((dim as i64) << 8) - 1;
            let mask = mask as i32;
            if (-128..=127).contains(&mask) {
                self.instrs.push(Instr::a(OP_PUSH_S8, mask));
            } else {
                let pi = self.pool_idx(mask);
                self.instrs.push(Instr::a(OP_PUSH_POOL, pi as i32));
            }
            self.instrs.push(Instr::new(OP_AND_I));
        }
        // store
        if is_local {
            // v23.1: f64 local store pops TWO cells (hi first) into the
            // value slot + hidden high slot allocated at declaration.
            if tvt == VT::F64 {
                self.instrs.push(Instr::a(OP_ST_LOCAL, (tf_or_slot + 1) as i32));
                self.instrs.push(Instr::a(OP_ST_LOCAL, tf_or_slot as i32));
            } else {
                self.instrs.push(Instr::a(OP_ST_LOCAL, tf_or_slot as i32));
            }
        } else if ent_u8 == GLOBAL_ENT {
            self.instrs.push(Instr::a(OP_ST_GLBL, tf_idx.unwrap() as i32));
        } else {
            let slot = self.slot_of(env, &field_var_name(target));
            self.instrs.push(Instr::ab(OP_ST_ENT, slot as i32, tf_idx.unwrap() as i32));
        }
        Ok(())
    }

    fn convert(&mut self, from: VT, to: VT) {
        match (from, to) {
            (VT::Int, VT::Fixed) => self.instrs.push(Instr::new(OP_I2F)),
            (VT::Fixed, VT::Int) => self.instrs.push(Instr::new(OP_F2I)),
            // v23.5: f64 arg widening (2-cell results, lo then hi)
            (VT::Int, VT::F64) => self.instrs.push(Instr::new(OP_I2F64)),
            (VT::Fixed, VT::F64) => self.instrs.push(Instr::new(OP_FIX2F64)),
            (VT::F32, VT::F64) => self.instrs.push(Instr::new(OP_F322F64)),
            _ => {}
        }
    }

    fn slot_of(&self, env: &Env, name: &str) -> usize {
        env.locals.iter().position(|(n, _)| n == name)
            .unwrap_or(0) // checker guarantees existence
    }

    /// v17: allocate a compiler temporary local. The name carries '#', which
    /// the lexer can never produce in an identifier, so it can't collide
    /// with user locals. Temps are NOT recycled (user `let`s inside
    /// expressions' enclosing statements push between allocations — index
    /// shifts would corrupt already-emitted LD/ST slots); they count toward
    /// the 32-slot frame exactly like hand-written locals, loudly.
    fn temp_local(&mut self, env: &mut Env) -> usize {
        let name = format!("#t{}", env.temp_n);
        env.temp_n += 1;
        env.locals.push((name, VT::Int));
        if env.locals.len() > self.cur_max_locals {
            self.cur_max_locals = env.locals.len();
        }
        env.locals.len() - 1
    }

    /// v23.1: loop-carried temps (while conditions, for-num bounds) are
    /// referenced by BACK-EDGES — code that re-executes after the statement
    /// ends — so they use the '#lp_' prefix the recycler skips and live for
    /// the fn's lifetime (a few slots per loop, bounded by the frame limit
    /// exactly like the pre-recycling status quo).
    fn temp_local_loop(&mut self, env: &mut Env) -> usize {
        let name = format!("#lp{}", env.temp_n);
        env.temp_n += 1;
        env.locals.push((name, VT::Int));
        if env.locals.len() > self.cur_max_locals {
            self.cur_max_locals = env.locals.len();
        }
        env.locals.len() - 1
    }

    /// temps stay allocated for the fn's lifetime (see temp_local) — release
    /// is a no-op kept for call-site readability.
    fn release_temp(&mut self, _env: &mut Env, _slot: usize) {}

    /// v17 2-D ARRAYS: emit the (wrapped, linear) element index for an access
    /// — `grid[i][j]` evaluates i and j ONCE each, wraps every axis on its own
    /// extent (AND when the extent is a power of two, MOD otherwise — the
    /// same no-trap contract as 1-D), and combines row-major
    /// (linear = i*W + j). Literal indices fold to one constant.
    /// Returns (array id, elem type, entity handle var for entity arrays).
    fn gen_arr_index(
        &mut self,
        base: &Expr,
        env: &mut Env,
        f: &FnInfo,
        refs: &CtxRefs,
    ) -> Result<(usize, VT, Option<String>), String> {
        use crate::checker::flatten_arr_access;
        let (root, indices) = flatten_arr_access(base);
        let ent_var = match root {
            Expr::Field(inner, _) => match &**inner {
                Expr::Ident(v) => Some(v.clone()),
                _ => return Err(crate::diag::internal("bad array base")),
            },
            _ => None,
        };
        let key = match root {
            Expr::Ident(name) => (GLOBAL_ENT, name.clone()),
            Expr::Field(_inner, fname) => {
                let v = ent_var.clone().ok_or_else(|| crate::diag::internal("bad array base"))?;
                let ei = match env.locals.iter().find(|(n, _)| *n == v).map(|(_, vt)| *vt) {
                    Some(VT::Ent(ei)) => ei,
                    _ => return Err(format!("'{}' is not an entity variable", v)),
                };
                (ei as u8, fname.clone())
            }
            _ => return Err(crate::diag::internal("bad array base")),
        };
        let arr_id = *self.arrs.get(&key)
            .ok_or_else(|| String::from("internal: array id missing"))?;
        let a = &self.ctx.arrays[arr_id];
        let elem = a.elem;

        if a.dims.is_empty() {
            // 1-D (the v11 path): evaluate the single index as before
            let ix = indices.into_iter().next()
                .ok_or_else(|| crate::diag::internal("1-D access with no index"))?;
            self.gen_expr(ix, env, f, refs)?;
            return Ok((arr_id, elem, ent_var));
        }

        // 2-D: fold literals; otherwise per-axis wrap + row-major combine.
        let all_lit = indices.iter().all(|ix| matches!(ix, Expr::IntLit(_)));
        if all_lit {
            let mut lin: i64 = 0;
            for (d, ix) in indices.iter().enumerate() {
                if let Expr::IntLit(v) = ix {
                    lin = lin * (a.dims[d] as i64) + (*v as i64);
                }
            }
            self.push_const(lin as i32);
            return Ok((arr_id, elem, ent_var));
        }
        // first axis: evaluate + wrap
        let wrap_axis = |g: &mut Gen, extent: u32| {
            if extent.is_power_of_two() {
                g.push_const((extent - 1) as i32);
                g.instrs.push(Instr::new(OP_AND_I));
            } else {
                g.push_const(extent as i32);
                g.instrs.push(Instr::new(OP_MOD_I));
            }
        };
        self.gen_expr(indices[0], env, f, refs)?;
        wrap_axis(self, a.dims[0]);
        // subsequent axes: lin = lin * extent + idx (idx wrapped)
        for (d, ix) in indices.iter().enumerate().skip(1) {
            let extent = a.dims[d];
            // stack: [lin] -> temp, evaluate + wrap idx, multiply, add back
            let t = self.temp_local(env);
            self.instrs.push(Instr::a(OP_ST_LOCAL, t as i32));
            self.gen_expr(ix, env, f, refs)?;
            wrap_axis(self, extent);
            self.push_const(extent as i32);
            self.instrs.push(Instr::new(OP_MUL_I));
            self.instrs.push(Instr::a(OP_LD_LOCAL, t as i32));
            self.instrs.push(Instr::new(OP_ADD_I));
        }
        Ok((arr_id, elem, ent_var))
    }

    fn gen_num_fixed(&mut self, e: &Expr, env: &mut Env, f: &FnInfo, refs: &CtxRefs) -> Result<(), String> {
        let vt = self.gen_expr(e, env, f, refs)?;
        if vt == VT::Int {
            self.instrs.push(Instr::new(OP_I2F));
        }
        Ok(())
    }

    /// Typed view for codegen decisions: optimizer intrinsics carry their
    /// proven result type; everything else re-derives via the checker.
    fn ty_of(&self, e: &Expr, env: &Env, f: &FnInfo, refs: &CtxRefs) -> VT {
        match e {
            Expr::Intrin(kind, _, args, _) if *kind == crate::ast::INTR_SEL => {
                // SEL takes the type of its THEN value (the select pass
                // proved both branches share one value class)
                refs.expr_type(&args[1], &env.locals, f).unwrap_or(VT::Int)
            }
            Expr::Intrin(kind, _, _, _) => match *kind {
                crate::ast::INTR_BIT01 | crate::ast::INTR_FSM_NEXT | crate::ast::INTR_COLL_MASK => VT::Int,
                _ => VT::Int,
            },
            _ => refs.expr_type(e, &env.locals, f).unwrap_or(VT::Int),
        }
    }

    fn gen_expr(&mut self, e: &Expr, env: &mut Env, f: &FnInfo, refs: &CtxRefs) -> Result<VT, String> {
        // optimizer intrinsics carry proven types: no checker re-derivation
        if let Expr::Intrin(kind, aux, args, consts) = e {
            return match *kind {
                crate::ast::INTR_BIT01 => {
                    // bools ARE 0/1 i32 at VM level: evaluate, retype to Int
                    self.gen_expr(&args[0], env, f, refs)?;
                    Ok(VT::Int)
                }
                crate::ast::INTR_FSM_NEXT => {
                    // stack: em, s -> OP_FSM_NEXT pops s then em
                    self.gen_expr(&args[0], env, f, refs)?;
                    self.gen_expr(&args[1], env, f, refs)?;
                    self.instrs.push(Instr::a(OP_FSM_NEXT, *aux as i32));
                    Ok(VT::Int)
                }
                crate::ast::INTR_COLL_MASK => {
                    // (cx, cy) fixed on the stack; hw/hh live in the pool;
                    // the type's x/y tf indices ride in `extra`, and the
                    // 32-lane WINDOW base rides in consts[2] (v9) — packed
                    // into the spare high bits of the `a` operand.
                    self.gen_expr(&args[0], env, f, refs)?;
                    self.gen_expr(&args[1], env, f, refs)?;
                    let hw = self.pool_idx(consts.first().copied().unwrap_or(0));
                    let hh = self.pool_idx(consts.get(1).copied().unwrap_or(0));
                    let base = consts.get(2).copied().unwrap_or(0);
                    let x_tf = self.tf_of(*aux as u8, "x")? as i32;
                    let y_tf = self.tf_of(*aux as u8, "y")? as i32;
                    self.instrs.push(Instr {
                        op: OP_COLLIDE_MASK, a: (*aux as i32) | (base << 8), b: hw as i32, c: hh as i32,
                        extra: vec![x_tf as u16, y_tf as u16],
                    });
                    Ok(VT::Int)
                }
                crate::ast::INTR_SEL => {
                    // branchless conditional move (subsystem 6): args are
                    // cond, then, else pushed in order -> OP_SEL pops else,
                    // then, cond and pushes the selected value. The result
                    // takes the THEN value's type (both branches were proven
                    // to share one value class by opt::select).
                    self.gen_expr(&args[0], env, f, refs)?;
                    self.gen_expr(&args[1], env, f, refs)?;
                    self.gen_expr(&args[2], env, f, refs)?;
                    self.instrs.push(Instr::new(OP_SEL));
                    Ok(refs.expr_type(&args[1], &env.locals, f).unwrap_or(VT::Int))
                }
                other => Err(format!("internal: unknown intrinsic kind {}", other)),
            };
        }
        // v20: f32 literal — raw bits as an i32 constant
        if let Expr::F32Lit(bits) = e {
            self.push_const(*bits as i32);
            return Ok(VT::F32);
        }
        let vt = refs.expr_type(e, &env.locals, f)?;
        match e {
            // optimizer intrinsics were handled (and returned) above; this arm
            // exists only for exhaustiveness — reaching it is a compiler bug.
            Expr::Intrin(..) => Err("internal: intrinsic reached late codegen".into()),
            Expr::IntLit(v) => { self.push_const(*v as i32); Ok(VT::Int) }
            Expr::FixLit(v) => { self.push_const(*v); Ok(VT::Fixed) }
            Expr::F32Lit(bits) => { self.push_const(*bits as i32); Ok(VT::F32) } // (early path above)
            // v23 TIER-1: f64 literal codegen. The 64-bit IEEE value is
            // stored as TWO i32 cells on the VM stack (low bits, then high
            // bits). The f64 opcodes (OP_F64_ADD etc.) know to pop 2 cells
            // per operand. This is the "two-cell" convention — simpler than
            // adding a separate 64-bit stack, and the tier purity fixpoint
            // has already demoted this fn + the optimizer gates skipped it.
            Expr::F64Lit(bits) => {
                self.push_const((bits & 0xFFFFFFFF) as i32);          // low 32 bits
                self.push_const(((bits >> 32) & 0xFFFFFFFF) as i32);  // high 32 bits
                Ok(VT::F64)
            }
            Expr::BoolLit(b) => { self.push_const(if *b { 1 } else { 0 }); Ok(VT::Bool) }
            Expr::Atom(_) => Err("internal: atom in expression".into()),
            Expr::Ident(name) => {
                if let Some(slot) = env.locals.iter().position(|(n, _)| n == name) {
                    let vt = env.locals[slot].1;
                    // v23.1: an f64 local occupies TWO slots (value + hidden
                    // high cell, allocated adjacently at declaration) and
                    // loads as TWO cells (low, high).
                    if vt == VT::F64 {
                        self.instrs.push(Instr::a(OP_LD_LOCAL, slot as i32));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, (slot + 1) as i32));
                    } else {
                        self.instrs.push(Instr::a(OP_LD_LOCAL, slot as i32));
                    }
                    return Ok(vt);
                }
                if let Some(gi) = self.gidx.get(name) {
                    let tfi = self.tf_of(GLOBAL_ENT, name)?;
                    // v23.1: 64-bit globals push TWO cells — the VM's
                    // LD_GLBL is schema-width-aware (bits > 32 => 2 cells).
                    self.instrs.push(Instr::a(OP_LD_GLBL, tfi as i32));
                    return Ok(self.ctx.globals[*gi].vt);
                }
                // v7 engine registers (checker rejects user shadowing)
                match name.as_str() {
                    "cam_x" => { self.instrs.push(Instr::new(OP_CAM_X)); return Ok(VT::Fixed); }
                    "cam_y" => { self.instrs.push(Instr::new(OP_CAM_Y)); return Ok(VT::Fixed); }
                    _ => {}
                }
                Err(format!("unknown var {}", name))
            }
            Expr::Field(base, fname) => {
                if let Expr::Ident(v) = &**base {
                    // v20 POOLS: `t.x` — pool handle field read (stale handles
                    // read as 0, exactly like entity fields).
                    if let Some((slot, VT::Pool(pi))) = env.locals.iter().enumerate()
                        .find(|(_, (n, _))| n == v).map(|(s, (_, vt))| (s, *vt)) {
                        let pf = self.pf_of(pi, fname)?;
                        self.instrs.push(Instr::ab(OP_PL_LD, slot as i32, pf as i32));
                        return Ok(self.ctx.pools[pi].fields.iter()
                            .find(|f| f.name == *fname).map(|f| f.vt).unwrap_or(VT::Int));
                    }
                    if let Some((slot, VT::Ent(ei))) = env.locals.iter().enumerate()
                        .find(|(_, (n, _))| n == v).map(|(s, (_, vt))| (s, *vt)) {
                        let tfi = self.tf_of(ei as u8, fname)?;
                        self.instrs.push(Instr::ab(OP_LD_ENT, slot as i32, tfi as i32));
                        return Ok(vt);
                    }
                }
                Err("internal: bad field access".into())
            }
            Expr::Index(_base, _ix) => {
                // v11 ARRAYS: resolve id, evaluate index (checker proved it
                // int + literal-in-range), then load the raw 32-bit cell.
                // v17: 2-D accesses flatten into one wrapped linear index
                // (the FULL access node is flattened — root + chained indices).
                let (arr_id, elem, ent_var) = self.gen_arr_index(e, env, f, refs)?;
                match self.ctx.arrays[arr_id].ent {
                    GLOBAL_ENT => self.instrs.push(Instr::a(OP_LD_GARR, arr_id as i32)),
                    _ => {
                        let slot = self.slot_of(env, ent_var.as_deref().unwrap_or(""));
                        self.instrs.push(Instr::ab(OP_LD_EARR, slot as i32, arr_id as i32));
                    }
                }
                Ok(elem)
            }
            // v17 TERNARY: lazy select — the taken arm evaluates, the other
            // never runs (identical to if/else semantics). One value is on
            // the stack at the end; conversions normalize arms to the
            // unified type the checker computed.
            Expr::Ternary(c, a, b) => {
                let cvt = self.gen_expr(c, env, f, refs)?;
                debug_assert_eq!(cvt, VT::Bool);
                let unified = refs.expr_type(e, &env.locals, f)?;
                let jz = self.instrs.len();
                self.instrs.push(Instr::a(OP_JZ, 0));
                let avt = self.gen_expr(a, env, f, refs)?;
                self.convert(avt, unified);
                let jend = self.instrs.len();
                self.instrs.push(Instr::a(OP_JMP, 0));
                let else_start = self.instrs.len();
                self.instrs[jz].a = else_start as i32;
                let bvt = self.gen_expr(b, env, f, refs)?;
                self.convert(bvt, unified);
                let end = self.instrs.len();
                self.instrs[jend].a = end as i32;
                Ok(unified)
            }
            Expr::Unary(UnOp::Neg, inner) => {
                let t = self.gen_expr(inner, env, f, refs)?;
                if t == VT::F32 {
                    // negate = flip the sign bit (exact IEEE negation)
                    self.push_const(0x8000_0000u32 as i32);
                    self.instrs.push(Instr::new(OP_XOR_I));
                } else if t == VT::F64 {
                    // v23.1: f64 negation — the value is two cells (lo, hi);
                    // XOR the sign bit into the HIGH cell only.
                    self.push_const(0x8000_0000u32 as i32);
                    self.instrs.push(Instr::new(OP_XOR_I));
                } else {
                    self.instrs.push(Instr::new(OP_NEG));
                }
                Ok(t)
            }
            Expr::Unary(UnOp::Not, inner) => {
                self.gen_expr(inner, env, f, refs)?;
                self.instrs.push(Instr::new(OP_NOT_B));
                Ok(VT::Bool)
            }
            Expr::Binary(op, a, b) => {
                // v23.1: compile-time constant folding on literal operands —
                // the VM's exact semantics, so folded code replays
                // bit-identically. Previously `2*3+1` executed a multiply
                // and an add every frame, forever.
                if std::env::var("LILA_NO_FOLD").is_err() {
                    if let Some(folded) = fold_binary(op, a, b) {
                        return self.gen_expr(&folded, env, f, refs);
                    }
                }
                let at = self.ty_of(a, env, f, refs);
                let bt = self.ty_of(b, env, f, refs);
                use BinOp::*;
                // v23.1: f64 arithmetic — strict, dedicated opcodes, TWO-cell
                // stack convention (low first). The tier fixpoint has already
                // demoted this fn to Tier-1 (interpreter-only).
                if at == VT::F64 || bt == VT::F64 {
                    if at != VT::F64 || bt != VT::F64 {
                        return Err(format!("internal: f64 op with non-f64 operand {:?} {:?}", at, bt));
                    }
                    self.gen_expr(a, env, f, refs)?;
                    self.gen_expr(b, env, f, refs)?;
                    let opn = match op {
                        Add => OP_F64_ADD,
                        Sub => OP_F64_SUB,
                        Mul => OP_F64_MUL,
                        Div => OP_F64_DIV,
                        Eq => OP_F64_EQ,
                        Ne => OP_F64_NE,
                        Lt => OP_F64_LT,
                        Gt => OP_F64_GT,
                        Le => OP_F64_LE,
                        Ge => OP_F64_GE,
                        other => return Err(format!("internal: f64 op {:?}", other)),
                    };
                    self.instrs.push(Instr::new(opn));
                    return Ok(match op {
                        Eq | Ne | Lt | Gt | Le | Ge => VT::Bool,
                        _ => VT::F64,
                    });
                }
                // v20: f32 arithmetic — strict, dedicated opcodes
                if at == VT::F32 || bt == VT::F32 {
                    self.gen_expr(a, env, f, refs)?;
                    self.gen_expr(b, env, f, refs)?;
                    let opn = match op {
                        Add => OP_F32_ADD,
                        Sub => OP_F32_SUB,
                        Mul => OP_F32_MUL,
                        Div => OP_F32_DIV,
                        Eq => OP_F32_EQ,
                        Ne => OP_F32_NE,
                        Lt => OP_F32_LT,
                        Gt => OP_F32_GT,
                        Le => OP_F32_LE,
                        Ge => OP_F32_GE,
                        other => return Err(format!("internal: f32 op {:?}", other)),
                    };
                    self.instrs.push(Instr::new(opn));
                    return Ok(match op {
                        Eq | Ne | Lt | Gt | Le | Ge => VT::Bool,
                        _ => VT::F32,
                    });
                }
                // emit with int->fixed widening on the int side
                match (at, bt) {
                    (VT::Fixed, VT::Int) => {
                        self.gen_expr(a, env, f, refs)?;
                        self.gen_expr(b, env, f, refs)?;
                        self.instrs.push(Instr::new(OP_I2F));
                    }
                    (VT::Int, VT::Fixed) => {
                        self.gen_expr(a, env, f, refs)?;
                        self.instrs.push(Instr::new(OP_I2F));
                        self.gen_expr(b, env, f, refs)?;
                    }
                    _ => {
                        self.gen_expr(a, env, f, refs)?;
                        self.gen_expr(b, env, f, refs)?;
                    }
                }
                // operator selection
                let is_fix = at == VT::Fixed || bt == VT::Fixed;
                let opn = match op {
                    Add => if is_fix { OP_ADD_F } else { OP_ADD_I },
                    Sub => if is_fix { OP_SUB_F } else { OP_SUB_I },
                    Mul => if is_fix { OP_MUL_F } else { OP_MUL_I },
                    Div => if is_fix { OP_DIV_F } else { OP_DIV_I },
                    Mod => OP_MOD_I,
                    And => OP_AND_I, Or => OP_OR_I, Xor => OP_XOR_I,
                    Shl => OP_SHL, Shr => OP_SHR,
                    Eq => if is_fix { OP_EQ_F } else { OP_EQ_I },
                    Ne => if is_fix { OP_NE_F } else { OP_NE_I },
                    Lt => if is_fix { OP_LT_F } else { OP_LT_I },
                    Gt => if is_fix { OP_GT_F } else { OP_GT_I },
                    Le => if is_fix { OP_LE_F } else { OP_LE_I },
                    Ge => if is_fix { OP_GE_F } else { OP_GE_I },
                    LAnd => OP_AND_B, LOr => OP_OR_B,
                };
                self.instrs.push(Instr::new(opn));
                Ok(match op {
                    LAnd | LOr | Eq | Ne | Lt | Gt | Le | Ge => VT::Bool,
                    _ => if is_fix { VT::Fixed } else { at },
                })
            }
            Expr::Call(name, args) => {
                match name.as_str() {
                    "key" => {
                        if let Expr::Atom(a) = &args[0] {
                            let p = self.dom_pos(&self.ctx.keys, *a, "key")?;
                            self.instrs.push(Instr::a(OP_KEY, p as i32));
                            Ok(VT::Bool)
                        } else { Err("internal: key()".into()) }
                    }
                    "sin" | "cos" => {
                        self.gen_expr(&args[0], env, f, refs)?;
                        self.instrs.push(Instr::new(if name == "sin" { OP_SIN } else { OP_COS }));
                        Ok(VT::Fixed)
                    }
                    "ang" => {
                        self.gen_expr(&args[0], env, f, refs)?;
                        Ok(VT::Ang) // int/ang 1:1 units
                    }
                    "fixed" => {
                        let t = self.gen_expr(&args[0], env, f, refs)?;
                        if t == VT::Int { self.instrs.push(Instr::new(OP_I2F)); }
                        else if t == VT::F32 { self.instrs.push(Instr::new(OP_F322FIX)); }
                        else if t == VT::F64 { self.instrs.push(Instr::new(OP_F642FIX)); }
                        Ok(VT::Fixed)
                    }
                    "int" => {
                        let t = self.gen_expr(&args[0], env, f, refs)?;
                        if t == VT::Fixed { self.instrs.push(Instr::new(OP_F2I)); }
                        else if t == VT::F32 { self.instrs.push(Instr::new(OP_F322I)); }
                        else if t == VT::F64 { self.instrs.push(Instr::new(OP_F642I)); }
                        Ok(VT::Int)
                    }
                    // v20: the f32 casts + exact sqrt + |x|
                    "f32" => {
                        let t = self.gen_expr(&args[0], env, f, refs)?;
                        match t {
                            VT::Int => self.instrs.push(Instr::new(OP_I2F32)),
                            VT::Fixed => self.instrs.push(Instr::new(OP_FIX2F32)),
                            _ => {}
                        }
                        Ok(VT::F32)
                    }
                    // v23.1: f64 cast + exact sqrt + |x| (two-cell convention)
                    "f64" => {
                        let t = self.gen_expr(&args[0], env, f, refs)?;
                        match t {
                            VT::Int => self.instrs.push(Instr::new(OP_I2F64)),
                            VT::Fixed => self.instrs.push(Instr::new(OP_FIX2F64)),
                            VT::F32 => self.instrs.push(Instr::new(OP_F322F64)),
                            _ => {}
                        }
                        Ok(VT::F64)
                    }
                    "fsqrt" => {
                        let t = self.gen_expr(&args[0], env, f, refs)?;
                        if t == VT::F64 {
                            self.instrs.push(Instr::new(OP_F64_SQRT));
                            return Ok(VT::F64);
                        }
                        self.instrs.push(Instr::new(OP_F32_SQRT));
                        Ok(VT::F32)
                    }
                    "fabs" => {
                        let t = self.gen_expr(&args[0], env, f, refs)?;
                        if t == VT::F64 {
                            // clear the sign bit of the HIGH cell
                            self.push_const(0x7FFF_FFFFu32 as i32);
                            self.instrs.push(Instr::new(OP_AND_I));
                            return Ok(VT::F64);
                        }
                        self.push_const(0x7FFF_FFFFu32 as i32);
                        self.instrs.push(Instr::new(OP_AND_I));
                        Ok(VT::F32)
                    }
                    // ---------------- v23.1: vec4 builtins ----------------
                    "v4u" => {
                        // push x,y,z,w then PACK (top = w)
                        for a in args { self.gen_expr(a, env, f, refs)?; }
                        self.instrs.push(Instr::new(OP_VEC4U_PACK));
                        Ok(VT::Vec4U8)
                    }
                    "v4ux" | "v4uy" | "v4uz" | "v4uw" => {
                        self.gen_expr(&args[0], env, f, refs)?;
                        self.instrs.push(Instr::new(OP_VEC4U_UNPACK)); // pushes x,y,z,w
                        // drop everything above the wanted lane
                        let keep = match name.as_str() {
                            "v4ux" => 0, "v4uy" => 1, "v4uz" => 2, _ => 3,
                        };
                        for _ in (keep + 1)..4 {
                            self.instrs.push(Instr::new(OP_DROP));
                        }
                        Ok(VT::Int)
                    }
                    "v4uadd" => {
                        self.gen_expr(&args[0], env, f, refs)?;
                        self.gen_expr(&args[1], env, f, refs)?;
                        self.instrs.push(Instr::new(OP_VEC4U_ADD));
                        Ok(VT::Vec4U8)
                    }
                    "v4f" => {
                        // pure sugar: four cells pushed x,y,z,w — no opcode
                        for a in args {
                            let t = self.gen_expr(a, env, f, refs)?;
                            if t == VT::Int { self.instrs.push(Instr::new(OP_I2F)); }
                        }
                        Ok(VT::Vec4Fixed)
                    }
                    "v4fadd" | "v4fsub" | "v4fmul" => {
                        self.gen_expr(&args[0], env, f, refs)?;
                        self.gen_expr(&args[1], env, f, refs)?;
                        let opn = match name.as_str() {
                            "v4fadd" => OP_VEC4F_ADD,
                            "v4fsub" => OP_VEC4F_SUB,
                            _ => OP_VEC4F_MUL,
                        };
                        self.instrs.push(Instr::new(opn));
                        Ok(VT::Vec4Fixed)
                    }
                    "v4fdot" => {
                        self.gen_expr(&args[0], env, f, refs)?;
                        self.gen_expr(&args[1], env, f, refs)?;
                        self.instrs.push(Instr::new(OP_VEC4F_DOT));
                        Ok(VT::Fixed)
                    }
                    "rand" => {
                        self.gen_expr(&args[0], env, f, refs)?;
                        self.instrs.push(Instr::new(OP_RAND_MAX));
                        Ok(VT::Int)
                    }
                    "anim" => {
                        self.gen_expr(&args[1], env, f, refs)?;
                        if let Expr::Atom(a) = &args[0] {
                            let anim_atoms: Vec<u16> = self.ctx.anims.iter().map(|x| x.atom).collect();
                            let p = self.dom_pos(&anim_atoms, *a, "anim")?;
                            self.instrs.push(Instr::a(OP_ANIM, p as i32));
                            Ok(VT::Fixed)
                        } else { Err("internal: anim()".into()) }
                    }
                    "count" => {
                        if let Expr::Ident(ent) = &args[0] {
                            let ei = *self.eidx.get(ent).ok_or_else(|| format!("unknown entity {}", ent))?;
                            self.instrs.push(Instr::a(OP_COUNT, ei as i32));
                            Ok(VT::Int)
                        } else { Err("internal: count()".into()) }
                    }
                    // v20 AGGREGATES: one scan opcode; tf rides extra
                    "sum" | "fmin" | "fmax" => {
                        let (ent, fld) = match (&args[0], &args[1]) {
                            (Expr::Ident(e), Expr::Ident(fl)) => (e, fl),
                            _ => return Err(crate::diag::internal("aggregate args")),
                        };
                        let ei = *self.eidx.get(ent).ok_or_else(|| format!("unknown entity {}", ent))?;
                        let tfi = self.tf_of(ei as u8, fld)? as i32;
                        let mode = match name.as_str() {
                            "sum" => 0i32,
                            "fmin" => 1,
                            _ => 2,
                        };
                        self.instrs.push(Instr { op: OP_AGG, a: ei as i32, b: mode, c: 0, extra: vec![tfi as u16] });
                        let fvt = self.ctx.entities[ei].fields.iter().find(|x| &x.name == fld)
                            .map(|x| x.vt).unwrap_or(VT::Int);
                        Ok(fvt)
                    }
                    // v20 POOLS: plen(P) = live rows, pfull(P) = count == cap
                    // (the C# List.Count / capacity parity — the whole API).
                    "plen" => {
                        if let Expr::Ident(pn) = &args[0] {
                            let pi = *self.pidx.get(pn).ok_or_else(|| format!("unknown pool {}", pn))?;
                            self.instrs.push(Instr::a(OP_PL_LEN, pi as i32));
                            Ok(VT::Int)
                        } else { Err("internal: plen()".into()) }
                    }
                    "pfull" => {
                        if let Expr::Ident(pn) = &args[0] {
                            let pi = *self.pidx.get(pn).ok_or_else(|| format!("unknown pool {}", pn))?;
                            self.instrs.push(Instr::a(OP_PL_LEN, pi as i32));
                            self.push_const(self.ctx.pools[pi].cap as i32);
                            self.instrs.push(Instr::new(OP_EQ_I));
                            Ok(VT::Bool)
                        } else { Err("internal: pfull()".into()) }
                    }
                    // ---------------- v21 DICTS ----------------
                    "mget" => {
                        if let Expr::Ident(d) = &args[0] {
                            let di = *self.didx.get(d)
                                .ok_or_else(|| crate::diag::internal("mget of unknown dict"))?;
                            let _ = self.gen_expr(&args[1], env, f, refs)?;
                            self.instrs.push(Instr::a(OP_M_GET, di as i32));
                            Ok(VT::Int) // raw cell — like saved()
                        } else { Err("internal: mget()".into()) }
                    }
                    "mlen" => {
                        if let Expr::Ident(d) = &args[0] {
                            let di = *self.didx.get(d)
                                .ok_or_else(|| crate::diag::internal("mlen of unknown dict"))?;
                            self.instrs.push(Instr::a(OP_M_LEN, di as i32));
                            Ok(VT::Int)
                        } else { Err("internal: mlen()".into()) }
                    }
                    // ---------------- v21 ENGINE: frame counter ----------------
                    "frame" => {
                        self.instrs.push(Instr::new(OP_FRAME));
                        Ok(VT::Int)
                    }
                    // ---------------- v21 QUERIES: raycast DDA ----------------
                    // ray(grid, gw, gh, x, y, ang, maxd): push gw, gh (raw
                    // ints), x, y (fixed), ang (raw), maxd (fixed) — the VM
                    // pops them reversed; the grid array id rides in `a`.
                    "ray" => {
                        let gid = match &args[0] {
                            Expr::Ident(g) => *self.arrs.get(&(GLOBAL_ENT, g.clone()))
                                .ok_or_else(|| crate::diag::internal(&format!("ray grid {}", g)))?,
                            _ => return Err("internal: ray grid".into()),
                        };
                        for a in args.iter().take(3).skip(1) {
                            let vt = self.gen_expr(a, env, f, refs)?;
                            if vt == VT::Fixed { self.instrs.push(Instr::new(OP_F2I)); }
                        }
                        self.gen_num_fixed(&args[3], env, f, refs)?;
                        self.gen_num_fixed(&args[4], env, f, refs)?;
                        let _ = self.gen_expr(&args[5], env, f, refs)?; // ang raw
                        self.gen_num_fixed(&args[6], env, f, refs)?;
                        self.instrs.push(Instr::a(OP_RAY, gid as i32));
                        Ok(VT::Fixed)
                    }
                    "rayx" => { self.instrs.push(Instr::new(OP_RAY_X)); Ok(VT::Int) }
                    "rayy" => { self.instrs.push(Instr::new(OP_RAY_Y)); Ok(VT::Int) }
                    // ---------------- v21 NAVIGATION: A* ----------------
                    // astar(grid, gw, gh, path, sx, sy, tx, ty): six int args
                    // on the stack; a=grid array, b=path array.
                    "astar" => {
                        let gid = match &args[0] {
                            Expr::Ident(g) => *self.arrs.get(&(GLOBAL_ENT, g.clone()))
                                .ok_or_else(|| crate::diag::internal(&format!("astar grid {}", g)))?,
                            _ => return Err("internal: astar grid".into()),
                        };
                        let pid = match &args[3] {
                            Expr::Ident(g) => *self.arrs.get(&(GLOBAL_ENT, g.clone()))
                                .ok_or_else(|| crate::diag::internal(&format!("astar path {}", g)))?,
                            _ => return Err("internal: astar path".into()),
                        };
                        for (i, a) in args.iter().enumerate() {
                            if i == 0 || i == 3 { continue; }
                            let vt = self.gen_expr(a, env, f, refs)?;
                            if vt == VT::Fixed {
                                self.instrs.push(Instr::new(OP_F2I));
                            }
                        }
                        self.instrs.push(Instr::ab(OP_ASTAR, gid as i32, pid as i32));
                        Ok(VT::Int)
                    }
                    // ---------------- v21 MATHF: Unity Mathf parity ----------------
                    // All lower to existing opcodes (branch diamonds over
                    // temps; opt::select may fuse later). Each argument is
                    // evaluated exactly once.
                    // ---------------- v22 NOISE: lattice value noise ----------------
                    // noise args are Q24.8 on the stack (int literals convert).
                    "noise1" => {
                        self.gen_num_fixed(&args[0], env, f, refs)?;
                        self.instrs.push(Instr::new(OP_NOISE1));
                        Ok(VT::Fixed)
                    }
                    "noise2" => {
                        self.gen_num_fixed(&args[0], env, f, refs)?;
                        self.gen_num_fixed(&args[1], env, f, refs)?;
                        self.instrs.push(Instr::new(OP_NOISE2));
                        Ok(VT::Fixed)
                    }
                    // ---------------- v22 DICT ITERATION ----------------
                    // mnext(D, cursor): cursor on the stack, dict id in a.
                    "mnext" => {
                        let di = match &args[0] {
                            Expr::Ident(d) => *self.didx.get(d)
                                .ok_or_else(|| crate::diag::internal(&format!("mnext dict {}", d)))?,
                            _ => return Err("internal: mnext dict".into()),
                        };
                        let _ = self.gen_expr(&args[1], env, f, refs)?;
                        self.instrs.push(Instr::a(OP_M_NEXT, di as i32));
                        Ok(VT::Int)
                    }
                    "mnextv" => { self.instrs.push(Instr::new(OP_M_NEXT_V)); Ok(VT::Int) }
                    "mnextc" => { self.instrs.push(Instr::new(OP_M_NEXT_C)); Ok(VT::Int) }
                    // ---------------- v22 QUEUES/STACKS/ARRAYS ----------------
                    "qpop" | "qlen" | "spop" | "slen" | "speek" | "afind" | "acount" => {
                        let ai = match &args[0] {
                            Expr::Ident(a) => *self.arrs.get(&(GLOBAL_ENT, a.clone()))
                                .ok_or_else(|| crate::diag::internal(&format!("{} array {}", name, a)))?,
                            _ => return Err("internal: array arg".into()),
                        };
                        if matches!(name.as_str(), "afind" | "acount") {
                            // value under the array id: evaluate it too
                            // (stack: val; VM pops val, then reads a)
                            let _ = self.gen_expr(&args[1], env, f, refs)?;
                        }
                        let op = match name.as_str() {
                            "qpop" => OP_QPOP, "qlen" => OP_QLEN,
                            "spop" => OP_SPOP, "slen" => OP_SLEN,
                            "speek" => OP_SPEEK, "afind" => OP_AFIND,
                            _ => OP_ACOUNT,
                        };
                        self.instrs.push(Instr::a(op, ai as i32));
                        Ok(VT::Int)
                    }
                    "floor" | "ceil" | "round" => {
                        self.gen_expr(&args[0], env, f, refs)?;
                        match name.as_str() {
                            "ceil" => { self.push_const(255); self.instrs.push(Instr::new(OP_ADD_I)); }
                            "round" => { self.push_const(128); self.instrs.push(Instr::new(OP_ADD_I)); }
                            _ => {}
                        }
                        self.push_const(-256); // 0xFFFFFF00: clears the 8 frac bits (two's-complement floor)
                        self.instrs.push(Instr::new(OP_AND_I));
                        Ok(VT::Fixed)
                    }
                    "sign" => {
                        let vt = self.gen_expr(&args[0], env, f, refs)?;
                        let t = self.temp_local(env);
                        self.instrs.push(Instr::a(OP_ST_LOCAL, t as i32));
                        let (lt, gt) = if vt == VT::Fixed { (OP_LT_F, OP_GT_F) } else { (OP_LT_I, OP_GT_I) };
                        // x > 0 ? 1 : (x < 0 ? -1 : 0) — constants in the
                        // value's class (fixed args yield fixed ±1.0)
                        let (one, negone) = if vt == VT::Fixed { (256i32, -256i32) } else { (1i32, -1i32) };
                        self.instrs.push(Instr::a(OP_LD_LOCAL, t as i32));
                        self.instrs.push(Instr::a(OP_PUSH_S8, 0));
                        self.instrs.push(Instr::new(gt));
                        let jz1 = self.instrs.len();
                        self.instrs.push(Instr::a(OP_JZ, 0));
                        self.push_const(one);
                        let je1 = self.instrs.len();
                        self.instrs.push(Instr::a(OP_JMP, 0));
                        self.instrs[jz1].a = self.instrs.len() as i32;
                        self.instrs.push(Instr::a(OP_LD_LOCAL, t as i32));
                        self.instrs.push(Instr::a(OP_PUSH_S8, 0));
                        self.instrs.push(Instr::new(lt));
                        let jz2 = self.instrs.len();
                        self.instrs.push(Instr::a(OP_JZ, 0));
                        self.push_const(negone);
                        let je2 = self.instrs.len();
                        self.instrs.push(Instr::a(OP_JMP, 0));
                        self.instrs[jz2].a = self.instrs.len() as i32;
                        self.instrs.push(Instr::a(OP_PUSH_S8, 0));
                        self.instrs[je1].a = self.instrs.len() as i32;
                        self.instrs[je2].a = self.instrs.len() as i32;
                        Ok(vt)
                    }
                    "smoothstep" => {
                        // t = clamp((x-e0)/(e1-e0), 0, 1); result = t*t*(3-2t)
                        let mut ts = [0usize; 3];
                        for (i, a) in args.iter().enumerate() {
                            let t = self.gen_expr(a, env, f, refs)?;
                            self.convert(t, VT::Fixed);
                            ts[i] = self.temp_local(env);
                            self.instrs.push(Instr::a(OP_ST_LOCAL, ts[i] as i32));
                        }
                        // q = (x - e0) / (e1 - e0)
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ts[2] as i32));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ts[0] as i32));
                        self.instrs.push(Instr::new(OP_SUB_F));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ts[1] as i32));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ts[0] as i32));
                        self.instrs.push(Instr::new(OP_SUB_F));
                        self.instrs.push(Instr::new(OP_DIV_F));
                        // clamp(q, 0, 1): max(min(q, 1), 0) — fixed 1.0 = 256
                        let tq = self.temp_local(env);
                        self.instrs.push(Instr::a(OP_ST_LOCAL, tq as i32));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, tq as i32));
                        self.push_const(256);
                        self.instrs.push(Instr::new(OP_GT_F));
                        let jz1 = self.instrs.len();
                        self.instrs.push(Instr::a(OP_JZ, 0));
                        self.push_const(256);
                        let je1 = self.instrs.len();
                        self.instrs.push(Instr::a(OP_JMP, 0));
                        self.instrs[jz1].a = self.instrs.len() as i32;
                        self.instrs.push(Instr::a(OP_LD_LOCAL, tq as i32));
                        self.instrs[je1].a = self.instrs.len() as i32;
                        let tm = self.temp_local(env);
                        self.instrs.push(Instr::a(OP_ST_LOCAL, tm as i32));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, tm as i32));
                        self.instrs.push(Instr::a(OP_PUSH_S8, 0));
                        self.instrs.push(Instr::new(OP_LT_F));
                        let jz2 = self.instrs.len();
                        self.instrs.push(Instr::a(OP_JZ, 0));
                        self.instrs.push(Instr::a(OP_PUSH_S8, 0));
                        let je2 = self.instrs.len();
                        self.instrs.push(Instr::a(OP_JMP, 0));
                        self.instrs[jz2].a = self.instrs.len() as i32;
                        self.instrs.push(Instr::a(OP_LD_LOCAL, tm as i32));
                        self.instrs[je2].a = self.instrs.len() as i32;
                        let tt = self.temp_local(env);
                        self.instrs.push(Instr::a(OP_ST_LOCAL, tt as i32));
                        // t*t*(3 - 2t) — the 2 and 3 are FIXED literals
                        self.instrs.push(Instr::a(OP_LD_LOCAL, tt as i32));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, tt as i32));
                        self.instrs.push(Instr::new(OP_MUL_F));
                        self.push_const(768); // 3.0
                        self.instrs.push(Instr::a(OP_LD_LOCAL, tt as i32));
                        self.push_const(512); // 2.0
                        self.instrs.push(Instr::new(OP_MUL_F));
                        self.instrs.push(Instr::new(OP_SUB_F));
                        self.instrs.push(Instr::new(OP_MUL_F));
                        Ok(VT::Fixed)
                    }
                    "move_to" => {
                        // move_to(cur, target, maxd) = |target-cur| <= maxd ? target
                        //   : cur + sign(target-cur) * maxd
                        let mut ts = [0usize; 3];
                        for (i, a) in args.iter().enumerate() {
                            let t = self.gen_expr(a, env, f, refs)?;
                            self.convert(t, VT::Fixed);
                            ts[i] = self.temp_local(env);
                            self.instrs.push(Instr::a(OP_ST_LOCAL, ts[i] as i32));
                        }
                        // d = target - cur
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ts[1] as i32));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ts[0] as i32));
                        self.instrs.push(Instr::new(OP_SUB_F));
                        let td = self.temp_local(env);
                        self.instrs.push(Instr::a(OP_ST_LOCAL, td as i32));
                        // far = d > maxd || -d > maxd
                        self.instrs.push(Instr::a(OP_LD_LOCAL, td as i32));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ts[2] as i32));
                        self.instrs.push(Instr::new(OP_GT_F));
                        let jz1 = self.instrs.len();
                        self.instrs.push(Instr::a(OP_JZ, 0));
                        self.instrs.push(Instr::a(OP_PUSH_S8, 1)); // true
                        let je1 = self.instrs.len();
                        self.instrs.push(Instr::a(OP_JMP, 0));
                        self.instrs[jz1].a = self.instrs.len() as i32;
                        self.instrs.push(Instr::a(OP_LD_LOCAL, td as i32));
                        self.instrs.push(Instr::new(OP_NEG));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ts[2] as i32));
                        self.instrs.push(Instr::new(OP_GT_F));
                        self.instrs[je1].a = self.instrs.len() as i32;
                        let jz2 = self.instrs.len();
                        self.instrs.push(Instr::a(OP_JZ, 0));
                        // far branch: cur + sign(d)*maxd — the sign is selected
                        // branchingly (+1.0 / -1.0), multiplied by maxd, added to cur
                        self.instrs.push(Instr::a(OP_LD_LOCAL, td as i32));
                        self.instrs.push(Instr::a(OP_PUSH_S8, 0));
                        self.instrs.push(Instr::new(OP_GE_F));
                        let jz3 = self.instrs.len();
                        self.instrs.push(Instr::a(OP_JZ, 0));
                        self.push_const(256); // +1.0
                        let je3 = self.instrs.len();
                        self.instrs.push(Instr::a(OP_JMP, 0));
                        self.instrs[jz3].a = self.instrs.len() as i32;
                        self.push_const(-256); // -1.0
                        self.instrs[je3].a = self.instrs.len() as i32;
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ts[2] as i32));
                        self.instrs.push(Instr::new(OP_MUL_F)); // sign * maxd
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ts[0] as i32));
                        self.instrs.push(Instr::new(OP_ADD_F)); // + cur
                        let jend = self.instrs.len();
                        self.instrs.push(Instr::a(OP_JMP, 0));
                        // near branch: target
                        self.instrs[jz2].a = self.instrs.len() as i32;
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ts[1] as i32));
                        self.instrs[jend].a = self.instrs.len() as i32;
                        Ok(VT::Fixed)
                    }
                    "repeat" => {
                        // repeat(t, len) = t - floor(t/len)*len (negative-safe).
                        // Push t FIRST so the final SUB_F computes t - prod.
                        let mut ts = [0usize; 2];
                        for (i, a) in args.iter().enumerate() {
                            let t = self.gen_expr(a, env, f, refs)?;
                            self.convert(t, VT::Fixed);
                            ts[i] = self.temp_local(env);
                            self.instrs.push(Instr::a(OP_ST_LOCAL, ts[i] as i32));
                        }
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ts[0] as i32)); // t
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ts[0] as i32));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ts[1] as i32));
                        self.instrs.push(Instr::new(OP_DIV_F));
                        self.push_const(-256);
                        self.instrs.push(Instr::new(OP_AND_I)); // floor(q)
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ts[1] as i32));
                        self.instrs.push(Instr::new(OP_MUL_F)); // floor*len
                        self.instrs.push(Instr::new(OP_SUB_F)); // t - prod
                        Ok(VT::Fixed)
                    }
                    "pingpong" => {
                        // pingpong(t, len) = len - |repeat(t, 2len) - len|
                        let mut ts = [0usize; 2];
                        for (i, a) in args.iter().enumerate() {
                            let t = self.gen_expr(a, env, f, refs)?;
                            self.convert(t, VT::Fixed);
                            ts[i] = self.temp_local(env);
                            self.instrs.push(Instr::a(OP_ST_LOCAL, ts[i] as i32));
                        }
                        // L = t - floor(t/(2len))*(2len); t first, 2 fixed
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ts[0] as i32)); // t
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ts[1] as i32));
                        self.push_const(512); // 2.0
                        self.instrs.push(Instr::new(OP_MUL_F)); // 2len on stack
                        let tl2 = self.temp_local(env);
                        self.instrs.push(Instr::a(OP_ST_LOCAL, tl2 as i32));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ts[0] as i32));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, tl2 as i32));
                        self.instrs.push(Instr::new(OP_DIV_F));
                        self.push_const(-256);
                        self.instrs.push(Instr::new(OP_AND_I)); // floor
                        self.instrs.push(Instr::a(OP_LD_LOCAL, tl2 as i32));
                        self.instrs.push(Instr::new(OP_MUL_F));
                        self.instrs.push(Instr::new(OP_SUB_F)); // t - prod = L
                        let tl = self.temp_local(env);
                        self.instrs.push(Instr::a(OP_ST_LOCAL, tl as i32));
                        // d = L - len
                        self.instrs.push(Instr::a(OP_LD_LOCAL, tl as i32));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ts[1] as i32));
                        self.instrs.push(Instr::new(OP_SUB_F));
                        let td = self.temp_local(env);
                        self.instrs.push(Instr::a(OP_ST_LOCAL, td as i32));
                        // |d| via branch (abs lowering)
                        self.instrs.push(Instr::a(OP_LD_LOCAL, td as i32));
                        self.instrs.push(Instr::a(OP_PUSH_S8, 0));
                        self.instrs.push(Instr::new(OP_LT_F));
                        let jz = self.instrs.len();
                        self.instrs.push(Instr::a(OP_JZ, 0));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, td as i32));
                        self.instrs.push(Instr::new(OP_NEG));
                        let je = self.instrs.len();
                        self.instrs.push(Instr::a(OP_JMP, 0));
                        self.instrs[jz].a = self.instrs.len() as i32;
                        self.instrs.push(Instr::a(OP_LD_LOCAL, td as i32));
                        self.instrs[je].a = self.instrs.len() as i32;
                        // len - |d|  =  len + (-|d|)
                        self.instrs.push(Instr::new(OP_NEG));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ts[1] as i32));
                        self.instrs.push(Instr::new(OP_ADD_F));
                        Ok(VT::Fixed)
                    }
                    "delta_ang" => {
                        // (b - a + 2048) & 4095 - 2048  [signed wrap-correct]
                        // SUB computes first-pushed minus second: b then a
                        let _ = self.gen_expr(&args[1], env, f, refs)?;
                        let _ = self.gen_expr(&args[0], env, f, refs)?;
                        self.instrs.push(Instr::new(OP_SUB_I));
                        self.push_const(2048);
                        self.instrs.push(Instr::new(OP_ADD_I));
                        self.push_const(4095);
                        self.instrs.push(Instr::new(OP_AND_I));
                        self.push_const(2048);
                        self.instrs.push(Instr::new(OP_SUB_I));
                        Ok(VT::Ang)
                    }
                    "lerp_ang" => {
                        // a + int(delta_ang(a,b) as fixed * t) & 4095
                        let ta = self.temp_local(env);
                        let tt = self.temp_local(env);
                        self.gen_expr(&args[0], env, f, refs)?;
                        self.instrs.push(Instr::a(OP_ST_LOCAL, ta as i32));
                        self.gen_expr(&args[1], env, f, refs)?;
                        self.instrs.push(Instr::a(OP_ST_LOCAL, tt as i32));
                        // d = delta_ang(ta, tb): (tb - ta + 2048) & 4095 - 2048
                        self.instrs.push(Instr::a(OP_LD_LOCAL, tt as i32));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ta as i32));
                        self.instrs.push(Instr::new(OP_SUB_I));
                        self.push_const(2048);
                        self.instrs.push(Instr::new(OP_ADD_I));
                        self.push_const(4095);
                        self.instrs.push(Instr::new(OP_AND_I));
                        self.push_const(2048);
                        self.instrs.push(Instr::new(OP_SUB_I));
                        self.instrs.push(Instr::new(OP_I2F)); // fixed(d)
                        let tvt = self.gen_expr(&args[2], env, f, refs)?;
                        self.convert(tvt, VT::Fixed);
                        self.instrs.push(Instr::new(OP_MUL_F));
                        self.instrs.push(Instr::new(OP_F2I));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ta as i32));
                        self.instrs.push(Instr::new(OP_ADD_I));
                        self.push_const(4095);
                        self.instrs.push(Instr::new(OP_AND_I));
                        Ok(VT::Ang)
                    }
                    "damp" => {
                        // damp(cur, target, rate): k = 1 - e^(-rate/60) baked
                        // at compile time; lowering = cur + (target-cur)*k.
                        let rate_val: f64 = match &args[2] {
                            Expr::FixLit(raw) => *raw as f64 / 256.0,
                            Expr::IntLit(v) => *v as f64,
                            _ => return Err(crate::diag::internal("damp rate not a literal")),
                        };
                        let mut k = (256.0 * (1.0 - (-rate_val / 60.0).exp())).round() as i32;
                        if k < 1 { k = 1; }
                        if k > 255 { k = 255; }
                        let mut ts = [0usize; 2];
                        for (i, a) in args.iter().take(2).enumerate() {
                            let t = self.gen_expr(a, env, f, refs)?;
                            self.convert(t, VT::Fixed);
                            ts[i] = self.temp_local(env);
                            self.instrs.push(Instr::a(OP_ST_LOCAL, ts[i] as i32));
                        }
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ts[1] as i32));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ts[0] as i32));
                        self.instrs.push(Instr::new(OP_SUB_F));
                        self.push_const(k); // k is already the Q24.8 raw of the fraction
                        self.instrs.push(Instr::new(OP_MUL_F));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ts[0] as i32));
                        self.instrs.push(Instr::new(OP_ADD_F));
                        Ok(VT::Fixed)
                    }
                    // v7: SRAM persistence (raw 32-bit slots)
                    "saved" | "savedf" => {
                        self.gen_expr(&args[0], env, f, refs)?;
                        self.instrs.push(Instr::new(OP_SAVED));
                        Ok(if name == "savedf" { VT::Fixed } else { VT::Int })
                    }
                    // v7: overflow-safe distance (i64 internals)
                    "dist" => {
                        for a in args { self.gen_num_fixed(a, env, f, refs)?; }
                        self.instrs.push(Instr::new(OP_DIST));
                        Ok(VT::Fixed)
                    }
                    // v7: screen-convention aim (integer CORDIC)
                    "atan2" => {
                        self.gen_num_fixed(&args[0], env, f, refs)?;
                        self.gen_num_fixed(&args[1], env, f, refs)?;
                        self.instrs.push(Instr::new(OP_ATAN2));
                        Ok(VT::Ang)
                    }
                    // v8 OPTIMIZER subsystem 3: swept Minkowski interval test
                    // (stack: ax ay avx avy bx by hw hh -> bool). ONE opcode,
                    // the whole continuous 1D inequality solve per axis.
                    "swept_hit" => {
                        for a in args { self.gen_num_fixed(a, env, f, refs)?; }
                        self.instrs.push(Instr::new(OP_SWEPT));
                        Ok(VT::Bool)
                    }
                    // ---------------- v11 3D + arrays ----------------
                    // proj3: pops z, y, x -> pushes scale; stash readable via
                    // projx/projy/projok (evaluation-order contract: they read
                    // the LAST proj3 in the same expression/statement).
                    "proj3" => {
                        for a in args { self.gen_num_fixed(a, env, f, refs)?; }
                        self.instrs.push(Instr::new(OP_PROJ3));
                        Ok(VT::Fixed)
                    }
                    "projx" => { self.instrs.push(Instr::new(OP_PROJ_X)); Ok(VT::Fixed) }
                    "projy" => { self.instrs.push(Instr::new(OP_PROJ_Y)); Ok(VT::Fixed) }
                    "projok" => { self.instrs.push(Instr::new(OP_PROJ_OK)); Ok(VT::Bool) }
                    // alen: the capacity is a compile-time constant — zero
                    // runtime bytes beyond the constant push.
                    "alen" => {
                        let cap = match &args[0] {
                            Expr::Ident(name) => {
                                let id = *self.arrs.get(&(GLOBAL_ENT, name.clone()))
                                    .ok_or_else(|| crate::diag::internal(&format!("alen array {}", name)))?;
                                self.ctx.arrays[id].cap as i32
                            }
                            Expr::Field(inner, fname) => {
                                let v = match &**inner {
                                    Expr::Ident(v) => v.clone(),
                                    _ => return Err("internal: alen base".into()),
                                };
                                let ei = match env.locals.iter().find(|(n, _)| *n == v).map(|(_, vt)| *vt) {
                                    Some(VT::Ent(ei)) => ei,
                                    _ => return Err(format!("'{}' is not an entity variable", v)),
                                };
                                let id = *self.arrs.get(&(ei as u8, fname.clone()))
                                    .ok_or_else(|| crate::diag::internal(&format!("alen array {}", fname)))?;
                                self.ctx.arrays[id].cap as i32
                            }
                            _ => return Err("internal: alen arg".into()),
                        };
                        self.push_const(cap);
                        Ok(VT::Int)
                    }
                    // ---------------- v17: scalar math builtins ----------------
                    // All lower to existing opcodes (branch diamonds over
                    // temps; opt::select may fuse later). Each argument is
                    // evaluated exactly once — rand() stays deterministic.
                    "abs" => {
                        let vt = self.gen_expr(&args[0], env, f, refs)?;
                        let t = self.temp_local(env);
                        self.instrs.push(Instr::a(OP_ST_LOCAL, t as i32));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, t as i32));
                        self.instrs.push(Instr::a(OP_PUSH_S8, 0));
                        self.instrs.push(Instr::new(if vt == VT::Fixed { OP_LT_F } else { OP_LT_I }));
                        let jz = self.instrs.len();
                        self.instrs.push(Instr::a(OP_JZ, 0));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, t as i32));
                        self.instrs.push(Instr::new(OP_NEG));
                        let jend = self.instrs.len();
                        self.instrs.push(Instr::a(OP_JMP, 0));
                        self.instrs[jz].a = self.instrs.len() as i32;
                        self.instrs[jend].a = self.instrs.len() as i32;
                        Ok(vt)
                    }
                    "min" | "max" => {
                        let is_min = name == "min";
                        // normalize both to the unified class, evaluate once
                        let unified = refs.expr_type(e, &env.locals, f)?;
                        let at = self.gen_expr(&args[0], env, f, refs)?;
                        self.convert(at, unified);
                        let ta = self.temp_local(env);
                        self.instrs.push(Instr::a(OP_ST_LOCAL, ta as i32));
                        let bt = self.gen_expr(&args[1], env, f, refs)?;
                        self.convert(bt, unified);
                        let tb = self.temp_local(env);
                        self.instrs.push(Instr::a(OP_ST_LOCAL, tb as i32));
                        // cond = ta < tb (min) / ta > tb (max)
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ta as i32));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, tb as i32));
                        self.instrs.push(Instr::new(match (unified, is_min) {
                            (VT::Fixed, true) => OP_LT_F,
                            (VT::Fixed, false) => OP_GT_F,
                            (_, true) => OP_LT_I,
                            (_, false) => OP_GT_I,
                        }));
                        let jz = self.instrs.len();
                        self.instrs.push(Instr::a(OP_JZ, 0));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, ta as i32));
                        let jend = self.instrs.len();
                        self.instrs.push(Instr::a(OP_JMP, 0));
                        self.instrs[jz].a = self.instrs.len() as i32;
                        self.instrs.push(Instr::a(OP_LD_LOCAL, tb as i32));
                        self.instrs[jend].a = self.instrs.len() as i32;
                        Ok(unified)
                    }
                    "clamp" => {
                        // clamp(v, lo, hi) = max(min(v, lo), hi)
                        let unified = refs.expr_type(e, &env.locals, f)?;
                        let cvt = |g: &mut Gen, a: &Expr, env: &mut Env| -> Result<(), String> {
                            let t = g.gen_expr(a, env, f, refs)?;
                            g.convert(t, unified);
                            Ok(())
                        };
                        let mut temps = [0usize; 3];
                        for (i, a) in args.iter().enumerate() {
                            cvt(self, a, env)?;
                            temps[i] = self.temp_local(env);
                            self.instrs.push(Instr::a(OP_ST_LOCAL, temps[i] as i32));
                        }
                        let lt = |g: &mut Gen, op: u8| g.instrs.push(Instr::new(op));
                        let (lt_f, gt_f) = (OP_LT_F, OP_GT_F);
                        let (lt_i, gt_i) = (OP_LT_I, OP_GT_I);
                        // m = v < lo ? lo : v
                        self.instrs.push(Instr::a(OP_LD_LOCAL, temps[0] as i32));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, temps[1] as i32));
                        if unified == VT::Fixed { lt(self, lt_f); } else { lt(self, lt_i); }
                        let jz1 = self.instrs.len();
                        self.instrs.push(Instr::a(OP_JZ, 0));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, temps[1] as i32));
                        let je1 = self.instrs.len();
                        self.instrs.push(Instr::a(OP_JMP, 0));
                        self.instrs[jz1].a = self.instrs.len() as i32;
                        self.instrs.push(Instr::a(OP_LD_LOCAL, temps[0] as i32));
                        self.instrs[je1].a = self.instrs.len() as i32;
                        let tm = self.temp_local(env);
                        self.instrs.push(Instr::a(OP_ST_LOCAL, tm as i32));
                        // r = m > hi ? hi : m
                        self.instrs.push(Instr::a(OP_LD_LOCAL, tm as i32));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, temps[2] as i32));
                        if unified == VT::Fixed { lt(self, gt_f); } else { lt(self, gt_i); }
                        let jz2 = self.instrs.len();
                        self.instrs.push(Instr::a(OP_JZ, 0));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, temps[2] as i32));
                        let je2 = self.instrs.len();
                        self.instrs.push(Instr::a(OP_JMP, 0));
                        self.instrs[jz2].a = self.instrs.len() as i32;
                        self.instrs.push(Instr::a(OP_LD_LOCAL, tm as i32));
                        self.instrs[je2].a = self.instrs.len() as i32;
                        Ok(unified)
                    }
                    "lerp" => {
                        // lerp(a, b, t) = a + (b - a) * t   [all Q24.8]
                        let mut lts = [0usize; 3];
                        for (i, a) in args.iter().enumerate() {
                            let t = self.gen_expr(a, env, f, refs)?;
                            self.convert(t, VT::Fixed);
                            lts[i] = self.temp_local(env);
                            self.instrs.push(Instr::a(OP_ST_LOCAL, lts[i] as i32));
                        }
                        // push b, a -> b - a
                        self.instrs.push(Instr::a(OP_LD_LOCAL, lts[1] as i32));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, lts[0] as i32));
                        self.instrs.push(Instr::new(OP_SUB_F));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, lts[2] as i32));
                        self.instrs.push(Instr::new(OP_MUL_F));
                        self.instrs.push(Instr::a(OP_LD_LOCAL, lts[0] as i32));
                        self.instrs.push(Instr::new(OP_ADD_F));
                        Ok(VT::Fixed)
                    }
                    // ---------------- v17: input edge detection ----------------
                    "key_pressed" | "key_released" => {
                        if let Expr::Atom(a) = &args[0] {
                            let p = self.dom_pos(&self.ctx.keys, *a, "key")?;
                            self.instrs.push(Instr::ab(OP_KEY_EDGE, p as i32, if name == "key_pressed" { 0 } else { 1 }));
                            Ok(VT::Bool)
                        } else { Err("internal: key edge()".into()) }
                    }
                    // ---------------- v17: nearest-entity query ----------------
                    "dist_nearest" => {
                        self.gen_num_fixed(&args[0], env, f, refs)?;
                        self.gen_num_fixed(&args[1], env, f, refs)?;
                        let ent_name = match &args[2] {
                            Expr::Ident(n) => n.clone(),
                            _ => return Err("internal: dist_nearest entity".into()),
                        };
                        let ei = *self.eidx.get(&ent_name)
                            .ok_or_else(|| format!("unknown entity {}", ent_name))?;
                        let x_tf = self.tf_of(ei as u8, "x")? as u16;
                        let y_tf = self.tf_of(ei as u8, "y")? as u16;
                        self.instrs.push(Instr { op: OP_DIST_NEAR, a: ei as i32, b: 0, c: 0, extra: vec![x_tf, y_tf] });
                        Ok(VT::Fixed)
                    }
                    // ---------------- v17: USER-FN CALLS IN EXPRESSIONS ----------------
                    // `let d = helper(x);` — call, then fetch the threadlocal
                    // return register. Statement-form calls (`call helper(x);`)
                    // skip the fetch (the register is write-only from their
                    // perspective), so both forms share one convention.
                    other => {
                        let Some(&fi) = self.fidx.get(other) else {
                            return Err(format!("internal: unknown call {}", other));
                        };
                        let target = &self.ctx.fns[fi];
                        let mut arg_cells: i32 = 0;
                        for (i, (_, pvt)) in target.params.iter().enumerate() {
                            let vt = self.gen_expr(&args[i], env, f, refs)?;
                            self.convert(vt, *pvt);
                            arg_cells += if *pvt == VT::F64 { 2 } else { 1 }; // v23.5 cells
                        }
                        self.instrs.push(Instr::ab(OP_CALL_FN, fi as i32, arg_cells));
                        // v23.6: an f64 callee parks a (lo, hi) pair — fetch
                        // both cells (hi ends on top, the f64 convention).
                        if target.ret == Some(VT::F64) {
                            self.instrs.push(Instr::new(OP_RET_GET64));
                        } else {
                            self.instrs.push(Instr::new(OP_RET_GET));
                        }
                        Ok(target.ret.ok_or_else(|| format!("internal: fn '{}' lost its return type", other))?)
                    }
                }
            }
        }
    }
}

fn env_set(env: &mut Env, name: &str, vt: VT) {
    if let Some(slot) = env.locals.iter_mut().find(|(n, _)| n == name) {
        slot.1 = vt;
    } else {
        env.locals.push((name.to_string(), vt));
    }
}


fn field_var_name(target: &Expr) -> String {
    if let Expr::Field(base, _) = target {
        if let Expr::Ident(v) = &**base { return v.clone(); }
    }
    String::new()
}


// ---------------- v23.1: compile-time constant folding ----------------
/// Fold a binary op over literal operands with the VM's EXACT semantics.
/// Returns a replacement literal expression, or None (emit as before).
pub fn fold_binary(op: &BinOp, a: &Expr, b: &Expr) -> Option<Expr> {
    use BinOp::*;
    // bool fast paths
    if let (Expr::BoolLit(x), Expr::BoolLit(y)) = (a, b) {
        return match op {
            LAnd => Some(Expr::BoolLit(*x && *y)),
            LOr => Some(Expr::BoolLit(*x || *y)),
            _ => None,
        };
    }
    // integer-domain literals: IntLit (raw u32/i32) or FixLit (Q24.8 cell).
    // A mixed int/fixed pair widens the int like the emitted I2F (x << 8).
    let as_i32 = |e: &Expr, fixed: bool| -> Option<i32> {
        match e {
            Expr::IntLit(v) => {
                let raw = *v as i32;
                Some(if fixed { raw.wrapping_shl(8) } else { raw })
            }
            Expr::FixLit(v) => {
                if fixed { None } else { Some(*v) } // fixed path uses raw cell
            }
            _ => None,
        }
    };
    let (fa, fb) = match (a, b) {
        (Expr::FixLit(_), Expr::FixLit(_)) => (true, true),
        (Expr::IntLit(_), Expr::IntLit(_)) => (false, false),
        (Expr::FixLit(_), Expr::IntLit(_)) => (true, true),
        (Expr::IntLit(_), Expr::FixLit(_)) => (true, true),
        _ => return None,
    };
    let x = as_i32(a, fa)?;
    let y = as_i32(b, fb)?;
    let both_fixed = fa && fb; // fixed-domain (raw cells are widened already)
    let out: i32 = match op {
        Add => x.wrapping_add(y),
        Sub => x.wrapping_sub(y),
        Mul => {
            if both_fixed {
                // VM mulF: i64 product, >> 8 truncating
                (((x as i64) * (y as i64)) >> 8) as i32
            } else {
                x.wrapping_mul(y)
            }
        }
        Div => {
            if y == 0 {
                return None; // runtime soft-lands 0 — keep the canonical path
            }
            if both_fixed {
                // VM divF: (x << 8) / b truncating (i64)
                (((x as i64) << 8).wrapping_div(y as i64)) as i32
            } else {
                x.wrapping_div(y)
            }
        }
        Mod => {
            if y == 0 {
                return None;
            }
            x.wrapping_rem(y)
        }
        And => x & y,
        Or => x | y,
        Xor => x ^ y,
        Shl => x.wrapping_shl((y as u32) & 31),
        Shr => x.wrapping_shr((y as u32) & 31),
        Eq => return Some(Expr::BoolLit(x == y)),
        Ne => return Some(Expr::BoolLit(x != y)),
        Lt => return Some(Expr::BoolLit(x < y)),
        Gt => return Some(Expr::BoolLit(x > y)),
        Le => return Some(Expr::BoolLit(x <= y)),
        Ge => return Some(Expr::BoolLit(x >= y)),
        LAnd | LOr => return None,
    };
    // preserve the domain: fixed ops yield a fixed literal, ints an int
    if both_fixed {
        Some(Expr::FixLit(out))
    } else if matches!(op, Eq | Ne | Lt | Gt | Le | Ge) {
        Some(Expr::BoolLit(out != 0))
    } else {
        Some(Expr::IntLit(out as u32))
    }
}

// ============================================================================
// v23.2 — BYTECODE DEAD-CODE ELIMINATION
// ============================================================================
//
// The structured codegen emits each statement linearly, so code after a
// `return` inside a block is still emitted (the probe: `return; let dead =
// f(); x = 6;` produced six unreachable instructions). This pass sweeps each
// fn's [start, start+len) range for reachability from the entry, drops the
// unreachable tail, and re-lays the whole stream (later fns shift; the fn
// table is rewritten to match).
//
// Safety: jump operands are ABSOLUTE instruction indices at this stage (the
// S16-relative encoding happens at pack time in libyte.rs). Targets are
// intra-fn by construction; if any target escapes its fn range the pass
// bails and the stream stays untouched (DCE is an optimization, never a
// correctness risk). Determinism: the reachability sweep and the compaction
// order are both fixed — same input, same output bytes, always.

fn instr_succs(code: &Code, pc: usize, lo: usize, hi: usize, out: &mut Vec<usize>) {
    let ins = &code.instrs[pc];
    let (ka, kb, kc) = sig(ins.op);
    // unconditional ends: no fallthrough successor
    let terminal = ins.op == OP_JMP || ins.op == OP_RET || ins.op == OP_RET_V || ins.op == OP_RET_V64 || ins.op == OP_THROW;
    if !terminal {
        out.push(pc + 1);
    }
    // S16-kind operands carry ABSOLUTE jump targets at codegen time
    for (k, v) in [(ka, ins.a), (kb, ins.b), (kc, ins.c)] {
        if k == OpK::S16 {
            let t = v as usize;
            if t >= lo && t < hi {
                out.push(t);
            }
        }
    }
}

/// Reachability DCE over the whole stream. Returns the number of
/// instructions removed (0 = nothing dead / pass bailed).
pub fn dce(code: &mut Code) -> usize {
    let total_before = code.instrs.len();
    let mut new_stream: Vec<Instr> = Vec::with_capacity(code.instrs.len());
    let mut new_fns: Vec<FnCode> = Vec::with_capacity(code.fns.len());
    // old absolute index -> new absolute index (populated per fn; targets
    // must stay intra-fn, verified below)
    let mut removed_total = 0usize;

    for f in &code.fns {
        let lo = f.start as usize;
        let hi = lo + f.len as usize;
        // 1) reachability worklist from the fn entry
        let mut reach = vec![false; hi];
        let mut stack = vec![lo];
        reach[lo] = true;
        while let Some(pc) = stack.pop() {
            let mut succs = Vec::new();
            instr_succs(code, pc, lo, hi, &mut succs);
            for s in succs {
                if !reach[s] {
                    reach[s] = true;
                    stack.push(s);
                }
            }
        }
        // 2) compaction map: old (in-fn) index -> new ABSOLUTE stream index
        let mut map: Vec<i32> = vec![-1; hi];
        {
            let mut n = new_stream.len() as i32;
            for pc in lo..hi {
                if reach[pc] {
                    map[pc] = n;
                    n += 1;
                }
            }
        }
        // 3) safety: every S16 operand of a KEPT instr must target a KEPT
        //    instr inside this fn (intra-fn invariant)
        let mut ok = true;
        for pc in lo..hi {
            if !reach[pc] { continue; }
            let ins = &code.instrs[pc];
            let (ka, kb, kc) = sig(ins.op);
            for (k, v) in [(ka, ins.a), (kb, ins.b), (kc, ins.c)] {
                if k == OpK::S16 {
                    let t = v as usize;
                    if t < lo || t >= hi || map[t] < 0 {
                        ok = false;
                    }
                }
            }
        }
        let new_start = new_stream.len() as u32;
        if ok {
            for pc in lo..hi {
                if !reach[pc] { continue; }
                let mut ins = code.instrs[pc].clone();
                let (ka, kb, kc) = sig(ins.op);
                if ka == OpK::S16 { ins.a = map[ins.a as usize]; }
                if kb == OpK::S16 { ins.b = map[ins.b as usize]; }
                if kc == OpK::S16 { ins.c = map[ins.c as usize]; }
                new_stream.push(ins);
            }
        } else {
            // bail for this fn only: copy verbatim
            for pc in lo..hi {
                new_stream.push(code.instrs[pc].clone());
            }
        }
        let new_len = new_stream.len() as u32 - new_start;
        removed_total += (f.len as usize) - (new_len as usize);
        new_fns.push(FnCode {
            kind: f.kind, entity: f.entity, nparams: f.nparams, nlocals: f.nlocals,
            start: new_start, len: new_len,
        });
    }

    code.instrs = new_stream;
    code.fns = new_fns;
    total_before - code.instrs.len()
}
