//! Statement checking: per-fn body rules, placement (draw fns), spawn
//! field typing, v11/v12 statement validation, assignment compatibility.
//! (split out of the checker monolith)

use super::*;
use super::expr::{expr_type, lvalue_type};

pub(crate) fn check_block(stmts: &[Stmt], env: &mut FnEnv, f: &FnInfo, r: &CtxRefs) -> Result<(), String> {
    for s in stmts {
        // v23.2 SPANS: publish the statement's own position before checking
        // it — error sites render diag::cur_pos() so semantic errors point
        // at the statement, not the fn. Synth/gameplay-generated statements
        // carry no At wrapper; they fall back to the fn's line (no worse
        // than before).
        match s {
            Stmt::At { line, col, .. } => crate::diag::set_pos(*line, *col),
            _ => crate::diag::set_pos(f.line, 0),
        }
        check_stmt(s, env, f, r)?;
    }
    Ok(())
}

pub(crate) fn is_draw_fn(f: &FnInfo) -> bool {
    matches!(f.kind, FnKind::Draw0 | FnKind::DrawEnt)
}

/// v17: which statements DISQUALIFY a fn from being callable from draw fns.
fn has_banned_draw_stmt(s: &Stmt) -> bool {
    match s {
        Stmt::Spawn(..) | Stmt::Kill(_) | Stmt::Save(..) | Stmt::Goto(_)
        | Stmt::FsmStep(_) | Stmt::CallTable(..)
        | Stmt::PoolPush(..) | Stmt::PoolRemove(_)
        | Stmt::Emit(_)
        | Stmt::MapPut(..) | Stmt::MapDel(..) | Stmt::PSort(..)
        | Stmt::QPush(..) | Stmt::SPush(..)
        | Stmt::AFill(..) | Stmt::ACopy(..) | Stmt::AShuf(..)
        | Stmt::QuatAA { .. } | Stmt::QMul { .. } | Stmt::M4QT { .. }
        | Stmt::M4Mul { .. } | Stmt::SkinV { .. } | Stmt::M4Look { .. } => true,
        Stmt::If(_, a, b) => a.iter().any(has_banned_draw_stmt) || b.iter().any(has_banned_draw_stmt),
        Stmt::While(_, b) | Stmt::For(_, _, b) | Stmt::ForNum(_, _, _, b) | Stmt::ForMask(_, _, _, b)
            => b.iter().any(has_banned_draw_stmt),
        Stmt::Switch(_, arms, dflt) => {
            arms.iter().any(|(_, body)| body.iter().any(has_banned_draw_stmt))
                || dflt.as_ref().map_or(false, |d| d.iter().any(has_banned_draw_stmt))
        }
        // v23.2 SPANS: look through the positional wrapper — a wrapped spawn
        // is still a spawn. (Same class of bug as the old walk_calls leak:
        // a catch-all here would let draw fns smuggle side effects.)
        Stmt::At { inner, .. } => has_banned_draw_stmt(inner),
        _ => false,
    }
}

/// v17 DRAW-SAFETY FIXPOINT: a fn is draw-safe when every statement in it is
/// presentation-only AND every fn it calls is draw-safe too (closes the old
/// bypass where a draw fn could `call` a helper that spawns). Mutual
/// recursion stays unsafe unless every member qualifies — the fixpoint
/// starts optimistic and removes violators until stable.
pub(crate) fn compute_draw_safe(fns: &[FnInfo]) -> Vec<bool> {
    let mut safe: Vec<bool> = fns.iter()
        .map(|f| !f.body.iter().any(has_banned_draw_stmt))
        .collect();
    // resolve call edges until stable (bounded by n^2 worst case — fine for
    // the 65535-fn ceiling in practice, games have tens)
    let mut changed = true;
    while changed {
        changed = false;
        for (i, f) in fns.iter().enumerate() {
            if !safe[i] { continue; }
            let mut calls_banned = false;
            walk_calls(&f.body, fns, &mut |name| {
                if let Some(fi) = fns.iter().position(|x| x.name == name && matches!(x.kind, FnKind::Helper | FnKind::Scene)) {
                    if !safe[fi] { calls_banned = true; }
                }
            });
            if calls_banned { safe[i] = false; changed = true; }
        }
    }
    safe
}

/// Render a raw Q24.8 literal for error messages ("1.5", "-0.25").
fn fixed_label_str(raw: i64) -> String {
    let v = raw as f64 / 256.0;
    format!("{}", v)
}

// v23.1: delegated to the shared TOTAL walker in ast.rs — the hand-rolled
// version visited only Stmt::CallStmt, so a call in expression position
// (`let d = helper(e);`, `x = f() + 1;`) could smuggle a spawning helper
// into a draw fn past this fixpoint.
fn walk_calls(stmts: &[Stmt], fns: &[FnInfo], f: &mut impl FnMut(&str)) {
    let _ = fns;
    crate::ast::walk_call_names_stmts(stmts, f);
}

pub(crate) fn check_stmt(s: &Stmt, env: &mut FnEnv, f: &FnInfo, r: &CtxRefs) -> Result<(), String> {
    match s {
        // v23.2 SPANS: the parser wraps every statement in At — positional
        // metadata only, recurse through it (check_block already published
        // the position).
        Stmt::At { inner, .. } => check_stmt(inner, env, f, r),
        Stmt::Let(name, e) => {
            if name == "cam_x" || name == "cam_y" {
                return Err(format!("line {}: local '{}' is reserved (engine camera registers)", crate::diag::cur_pos(), name));
            }
            let vt = expr_type(e, &env.locals, f, r)?;
            // `let` rebinds (Python-style): an existing local of the same name
            // is overwritten and re-typed; VM slots are untyped i32.
            if let Some(slot) = env.locals.iter_mut().find(|(n, _)| n == name) {
                slot.1 = vt;
            } else {
                env.locals.push((name.clone(), vt));
            }
            Ok(())
        }
        Stmt::Assign(target, op, val) => {
            let (tvt, desc) = lvalue_type(target, &env.locals, f, r)?;
            let vvt = expr_type(val, &env.locals, f, r)?;
            check_assign_compat(tvt, vvt, *op, &desc, crate::diag::cur_pos())?;
            Ok(())
        }
        Stmt::If(cond, a, b) => {
            let cvt = expr_type(cond, &env.locals, f, r)?;
            if cvt != VT::Bool {
                return Err(format!("line {}: if condition must be bool, got {:?}", crate::diag::cur_pos(), cvt));
            }
            check_block(a, env, f, r)?;
            check_block(b, env, f, r)?;
            Ok(())
        }
        Stmt::While(cond, body) => {
            let cvt = expr_type(cond, &env.locals, f, r)?;
            if cvt != VT::Bool {
                return Err(format!("line {}: while condition must be bool, got {:?}", crate::diag::cur_pos(), cvt));
            }
            check_block(body, env, f, r)?;
            Ok(())
        }
        Stmt::For(var, ent, body) => {
            // v20 POOLS: the same shape iterates a pool when the name is one
            // (pools and entity types never share names — checked earlier).
            if let Some(&pi) = r.pool_index.get(ent) {
                env.locals.push((var.clone(), VT::Pool(pi)));
                env.loop_depth += 1;
                let rc = check_block(body, env, f, r);
                env.loop_depth -= 1;
                env.locals.pop();
                return rc;
            }
            let ei = *r.ent_index.get(ent)
                .ok_or_else(|| format!("line {}: for-loop over unknown entity or pool '{}'", crate::diag::cur_pos(), ent))?;
            env.locals.push((var.clone(), VT::Ent(ei)));
            env.loop_depth += 1;
            let rc = check_block(body, env, f, r);
            env.loop_depth -= 1;
            env.locals.pop();
            rc
        }
        // v17: `for (i: A..B)` — integer counting loop (half-open, step +1).
        // Bounds are evaluated ONCE and must be int-typed; the loop var
        // binds LIKE A `let` (Python for-loop semantics: it rebinds an
        // existing name and stays in scope after the loop) — deliberately
        // unlike entity for-loops, whose variable is popped (v16 semantics).
        Stmt::ForNum(var, from, to, body) => {
            for (e, what) in [(from, "for range start"), (to, "for range end")] {
                let vt = expr_type(e, &env.locals, f, r)?;
                if vt != VT::Int {
                    return Err(format!("line {}: {} must be int (got {:?}) — use int() for fixed bounds", crate::diag::cur_pos(), what, vt));
                }
            }
            if let Some(slot) = env.locals.iter_mut().find(|(n, _)| n == var) {
                slot.1 = VT::Int; // rebind (let-style)
            } else {
                env.locals.push((var.clone(), VT::Int));
            }
            env.loop_depth += 1;
            let rc = check_block(body, env, f, r);
            env.loop_depth -= 1;
            rc
        }
        // v17 LOOP CONTROL — the checker proves they are inside a loop;
        // codegen binds them to the innermost one.
        Stmt::Break | Stmt::Continue => {
            if env.loop_depth == 0 {
                return Err(format!("line {}: '{}' outside a loop", crate::diag::cur_pos(),
                    if matches!(s, Stmt::Break) { "break" } else { "continue" }));
            }
            Ok(())
        }
        // v17: switch — scrutinee evaluated once; labels must match its
        // value class (int labels widen against a fixed scrutinee exactly
        // like `==`; fixed labels against an int scrutinee are a mismatch).
        Stmt::Switch(x, arms, _dflt) => {
            let svt = expr_type(x, &env.locals, f, r)?;
            if !matches!(svt, VT::Int | VT::Fixed | VT::Ang) {
                return Err(format!("line {}: switch scrutinee must be int, fixed or ang, got {:?}", crate::diag::cur_pos(), svt));
            }
            for (labels, _) in arms {
                for (raw, is_fix) in labels {
                    if *is_fix && svt != VT::Fixed {
                        return Err(format!("line {}: switch label '{}' is a fixed literal but the scrutinee is {:?}",
                            crate::diag::cur_pos(), fixed_label_str(*raw), svt));
                    }
                    if !*is_fix && svt == VT::Fixed {
                        // int literal against fixed scrutinee: widens (v << 8)
                    }
                    let _ = raw;
                }
            }
            // bodies check with the loop depth intact but no new scope
            let mut dflt_err = None;
            for (_, body) in arms {
                if let Err(e) = check_block(body, env, f, r) { return Err(e); }
            }
            if let Some(d) = _dflt {
                if let Err(e) = check_block(d, env, f, r) { dflt_err = Some(e); }
            }
            dflt_err.map_or(Ok(()), Err)
        }
        Stmt::Spawn(ent, inits) => {
            if is_draw_fn(f) {
                return Err(format!("line {}: spawn is not allowed in draw fns", crate::diag::cur_pos()));
            }
            let ei = *r.ent_index.get(ent)
                .ok_or_else(|| format!("line {}: spawn of unknown entity '{}'", crate::diag::cur_pos(), ent))?;
            for (fname, e) in inits {
                let fi = r.entities[ei].fields.iter().position(|x| &x.name == fname)
                    .ok_or_else(|| format!("line {}: entity {} has no field '{}'", crate::diag::cur_pos(), ent, fname))?;
                let fvt = r.entities[ei].fields[fi].vt;
                let vvt = expr_type(e, &env.locals, f, r)?;
                check_assign_compat(fvt, vvt, AssignOp::Set, &format!("spawn {}.{}", ent, fname), crate::diag::cur_pos())?;
            }
            Ok(())
        }
        Stmt::Kill(e) => {
            if is_draw_fn(f) {
                return Err(format!("line {}: kill is not allowed in draw fns", crate::diag::cur_pos()));
            }
            let vt = expr_type(e, &env.locals, f, r)?;
            match vt {
                VT::Ent(_) => Ok(()),
                _ => Err(format!("line {}: kill needs an entity reference, got {:?}", crate::diag::cur_pos(), vt)),
            }
        }
        // v20 POOLS: `push P { ... }` — append a row. Gameplay-side only; the
        // init list validates like spawn's (names + assign-compat + no dups).
        // v20 SIGNALS: `emit #death;` — the atom must be a declared signal.
        // Gameplay-side only: handlers are arbitrary helpers (may mutate).
        Stmt::Emit(atom) => {
            if is_draw_fn(f) {
                return Err(format!("line {}: emit is not allowed in draw fns (handlers may mutate game state)", crate::diag::cur_pos()));
            }
            if !r.signal_index.contains_key(atom) {
                return Err(format!("line {}: emit #{}: no such signal declared (signal #{} {{ handlers... }})",
                    crate::diag::cur_pos(), r.aname(*atom), r.aname(*atom)));
            }
            Ok(())
        }
        // v20 COROUTINES: lowered away by states::expand before checking;
        // reaching here means the pass missed a path — fail loudly.
        Stmt::State(..) | Stmt::Wait(_) | Stmt::GotoState(_) => {
            Err(format!("line {}: internal: coroutine statement reached the checker", crate::diag::cur_pos()))
        }
        // v21 DICTS: `mput(D, k, v);` — insert/overwrite. Gameplay-side only
        // (the table is game state). Keys and values are raw 32-bit cells:
        // int or fixed both legal (fixed keys hash their Q24.8 bit pattern).
        Stmt::MapPut(d, k, v) => {
            if is_draw_fn(f) {
                return Err(format!("line {}: mput is not allowed in draw fns", crate::diag::cur_pos()));
            }
            if !r.dict_index.contains_key(d) {
                return Err(format!("line {}: mput of unknown dict '{}' (dict {} (N))", crate::diag::cur_pos(), d, d));
            }
            let kvt = expr_type(k, &env.locals, f, r)?;
            if !matches!(kvt, VT::Fixed | VT::Int) {
                return Err(format!("line {}: mput key must be int or fixed, got {:?}", crate::diag::cur_pos(), kvt));
            }
            let vvt = expr_type(v, &env.locals, f, r)?;
            if !matches!(vvt, VT::Fixed | VT::Int | VT::Bool | VT::Ang | VT::F32) {
                return Err(format!("line {}: mput value must be a scalar, got {:?}", crate::diag::cur_pos(), vvt));
            }
            Ok(())
        }
        // v21 DICTS: `mdel(D, k);` — remove. Gameplay-side only.
        Stmt::MapDel(d, k) => {
            if is_draw_fn(f) {
                return Err(format!("line {}: mdel is not allowed in draw fns", crate::diag::cur_pos()));
            }
            if !r.dict_index.contains_key(d) {
                return Err(format!("line {}: mdel of unknown dict '{}' (dict {} (N))", crate::diag::cur_pos(), d, d));
            }
            let kvt = expr_type(k, &env.locals, f, r)?;
            if !matches!(kvt, VT::Fixed | VT::Int) {
                return Err(format!("line {}: mdel key must be int or fixed, got {:?}", crate::diag::cur_pos(), kvt));
            }
            Ok(())
        }
        // v21 SORT: `psort(Pool, field);` — stable engine-side radix sort of
        // the pool's live rows by the field key. Gameplay-side only (it
        // reorders rows — draw iteration sees the new order next frame).
        Stmt::PSort(pool, field, _dir) => {
            if is_draw_fn(f) {
                return Err(format!("line {}: psort is not allowed in draw fns", crate::diag::cur_pos()));
            }
            let pi = *r.pool_index.get(pool)
                .ok_or_else(|| format!("line {}: psort of unknown pool '{}'", crate::diag::cur_pos(), pool))?;
            if !r.pools[pi].fields.iter().any(|x| &x.name == field) {
                return Err(format!("line {}: pool '{}' has no field '{}' (psort key)", crate::diag::cur_pos(), pool, field));
            }
            Ok(())
        }
        // v21 ARCADE: `draw_numz(v, digits, x, y, rgba);` — zero-padded
        // integer. DRAW-PASS ONLY (like every draw statement).
        Stmt::DrawNumZ(v, _digits, x, y, rgba) => {
            if !is_draw_fn(f) {
                return Err(format!("line {}: draw_numz is a draw-pass statement (move it into draw())", crate::diag::cur_pos()));
            }
            let vvt = expr_type(v, &env.locals, f, r)?;
            if !matches!(vvt, VT::Fixed | VT::Int) {
                return Err(format!("line {}: draw_numz value must be int or fixed, got {:?}", crate::diag::cur_pos(), vvt));
            }
            check_num_arg(x, env, f, r, "draw_numz x")?;
            check_num_arg(y, env, f, r, "draw_numz y")?;
            check_num_arg(rgba, env, f, r, "draw_numz rgba")?;
            Ok(())
        }
        // v22 QUEUES: `qpush(Q, val);` — FIFO ring append onto the queue
        // decl's hidden array. Gameplay-side only. Any global array is a
        // legal substrate (the transparent-memory doctrine): cells 0/1 are
        // head/tail, data = 2 + i % (cap - 2). Full drops the value.
        Stmt::QPush(q, v) => {
            if is_draw_fn(f) {
                return Err(format!("line {}: qpush is not allowed in draw fns", crate::diag::cur_pos()));
            }
            let ai = *r.arr_index.get(&(GLOBAL_ENT, q.clone()))
                .ok_or_else(|| format!("line {}: qpush of unknown queue '{}' (declare `queue {} (N)` at top level)", crate::diag::cur_pos(), q, q))?;
            if r.arrays[ai].cap < 3 {
                return Err(format!("line {}: qpush: queue '{}' has no data cells (cap {} < 3)", crate::diag::cur_pos(), q, r.arrays[ai].cap));
            }
            let vvt = expr_type(v, &env.locals, f, r)?;
            if !matches!(vvt, VT::Fixed | VT::Int | VT::Bool | VT::Ang | VT::F32) {
                return Err(format!("line {}: qpush value must be a scalar, got {:?}", crate::diag::cur_pos(), vvt));
            }
            Ok(())
        }
        // v22 STACKS: `spush(S, val);` — LIFO append. Same substrate.
        Stmt::SPush(s, v) => {
            if is_draw_fn(f) {
                return Err(format!("line {}: spush is not allowed in draw fns", crate::diag::cur_pos()));
            }
            let ai = *r.arr_index.get(&(GLOBAL_ENT, s.clone()))
                .ok_or_else(|| format!("line {}: spush of unknown stack '{}' (declare `stack {} (N)` at top level)", crate::diag::cur_pos(), s, s))?;
            if r.arrays[ai].cap < 3 {
                return Err(format!("line {}: spush: stack '{}' has no data cells (cap {} < 3)", crate::diag::cur_pos(), s, r.arrays[ai].cap));
            }
            let vvt = expr_type(v, &env.locals, f, r)?;
            if !matches!(vvt, VT::Fixed | VT::Int | VT::Bool | VT::Ang | VT::F32) {
                return Err(format!("line {}: spush value must be a scalar, got {:?}", crate::diag::cur_pos(), vvt));
            }
            Ok(())
        }
        // v22 ARRAYS: `afill(A, val);` — fill the whole array (Array.Fill /
        // memset). Gameplay-side only.
        Stmt::AFill(a, v) => {
            if is_draw_fn(f) {
                return Err(format!("line {}: afill is not allowed in draw fns", crate::diag::cur_pos()));
            }
            if !r.arr_index.contains_key(&(GLOBAL_ENT, a.clone())) {
                return Err(format!("line {}: afill of unknown global array '{}'", crate::diag::cur_pos(), a));
            }
            let vvt = expr_type(v, &env.locals, f, r)?;
            if !matches!(vvt, VT::Fixed | VT::Int | VT::Bool | VT::Ang | VT::F32) {
                return Err(format!("line {}: afill value must be a scalar, got {:?}", crate::diag::cur_pos(), vvt));
            }
            Ok(())
        }
        // v22 ARRAYS: `acopy(dst, src, n);` — copy the first n cells
        // (Array.Copy / memcpy, clamped to both capacities).
        Stmt::ACopy(d, s, n) => {
            if is_draw_fn(f) {
                return Err(format!("line {}: acopy is not allowed in draw fns", crate::diag::cur_pos()));
            }
            if !r.arr_index.contains_key(&(GLOBAL_ENT, d.clone())) {
                return Err(format!("line {}: acopy of unknown global array '{}'", crate::diag::cur_pos(), d));
            }
            if !r.arr_index.contains_key(&(GLOBAL_ENT, s.clone())) {
                return Err(format!("line {}: acopy of unknown global array '{}'", crate::diag::cur_pos(), s));
            }
            let nvt = expr_type(n, &env.locals, f, r)?;
            if !matches!(nvt, VT::Int) {
                return Err(format!("line {}: acopy count must be int, got {:?}", crate::diag::cur_pos(), nvt));
            }
            Ok(())
        }
        // v22 ARRAYS: `ashuffle(A, n);` — Fisher-Yates over the first n
        // cells, driven by the hashed LCG chain (snapshot/rewind state).
        Stmt::AShuf(a, n) => {
            if is_draw_fn(f) {
                return Err(format!("line {}: ashuffle is not allowed in draw fns", crate::diag::cur_pos()));
            }
            if !r.arr_index.contains_key(&(GLOBAL_ENT, a.clone())) {
                return Err(format!("line {}: ashuffle of unknown global array '{}'", crate::diag::cur_pos(), a));
            }
            let nvt = expr_type(n, &env.locals, f, r)?;
            if !matches!(nvt, VT::Int) {
                return Err(format!("line {}: ashuffle count must be int, got {:?}", crate::diag::cur_pos(), nvt));
            }
            Ok(())
        }
        Stmt::PoolPush(pool, inits) => {
            if is_draw_fn(f) {
                return Err(format!("line {}: push is not allowed in draw fns", crate::diag::cur_pos()));
            }
            let pi = *r.pool_index.get(pool)
                .ok_or_else(|| format!("line {}: push of unknown pool '{}'", crate::diag::cur_pos(), pool))?;
            let mut seen = std::collections::HashSet::new();
            for (fname, e) in inits {
                let pf = r.pools[pi].fields.iter().find(|x| &x.name == fname)
                    .ok_or_else(|| format!("line {}: pool {} has no field '{}'", crate::diag::cur_pos(), pool, fname))?;
                if !seen.insert(fname.clone()) {
                    return Err(format!("line {}: push initializes '{}' twice", crate::diag::cur_pos(), fname));
                }
                let vvt = expr_type(e, &env.locals, f, r)?;
                check_assign_compat(pf.vt, vvt, AssignOp::Set, &format!("push {}.{}", pool, fname), crate::diag::cur_pos())?;
            }
            Ok(())
        }
        // v20 POOLS: `remove(t);` — gen-checked swap-remove. Gameplay-side only.
        Stmt::PoolRemove(e) => {
            if is_draw_fn(f) {
                return Err(format!("line {}: remove is not allowed in draw fns", crate::diag::cur_pos()));
            }
            if let Expr::Ident(_) = e {
                let vt = expr_type(e, &env.locals, f, r)?;
                match vt {
                    VT::Pool(_) => Ok(()),
                    _ => Err(format!("line {}: remove needs a pool handle variable (from for (t: Pool)), got {:?}", crate::diag::cur_pos(), vt)),
                }
            } else {
                Err(format!("line {}: remove takes a pool handle variable", crate::diag::cur_pos()))
            }
        }
        Stmt::Sfx(a) => {
            r.domain_pos(r.sound, *a, "sound")?;
            Ok(())
        }
        Stmt::Music(a) => {
            r.domain_pos(r.music_atoms, *a, "music")?;
            Ok(())
        }
        Stmt::StopMusic => Ok(()),
        Stmt::Shake(_) => Ok(()), // range enforced by parser (literal 0..255)
        Stmt::Camera(x, y) => {
            // v7: presentation-only — allowed in draw fns (like Unity moving
            // the camera in any pass); the write is clamped to the world.
            check_num_arg(x, env, f, r, "camera x")?;
            check_num_arg(y, env, f, r, "camera y")?;
            Ok(())
        }
        Stmt::Cam3(x, y, z, yaw, pitch) => {
            // v11 3D camera: gameplay-aimable presentation. x/y/z fixed|int,
            // yaw/pitch ang|int-literal (same rule as draw rot).
            check_num_arg(x, env, f, r, "cam3 x")?;
            check_num_arg(y, env, f, r, "cam3 y")?;
            check_num_arg(z, env, f, r, "cam3 z")?;
            for (e, what) in [(yaw, "cam3 yaw"), (pitch, "cam3 pitch")] {
                let vt = expr_type(e, &env.locals, f, r)?;
                match vt {
                    VT::Ang => {}
                    VT::Int => {
                        if !matches!(e, Expr::IntLit(_)) {
                            return Err(format!("line {}: {} must be ang-typed (or an int literal); use ang()", crate::diag::cur_pos(), what));
                        }
                    }
                    _ => return Err(format!("line {}: {} must be ang", crate::diag::cur_pos(), what)),
                }
            }
            Ok(())
        }
        Stmt::Draw3d { arr, n, x, y, z, yaw, rgba } => {
            // v11 3D mesh pass: DRAW-PASS ONLY (it emits into the per-frame
            // vertex stream — from update fns the verts would be reset away).
            if !is_draw_fn(f) {
                return Err(format!("line {}: draw3d is a draw-pass statement (move it into draw())", crate::diag::cur_pos()));
            }
            let id = r.arr_index.get(&(GLOBAL_ENT, arr.clone())).copied()
                .ok_or_else(|| format!("line {}: draw3d mesh '{}' is not a global array (meshes are shared geometry)", crate::diag::cur_pos(), arr))?;
            let nvt = expr_type(n, &env.locals, f, r)?;
            if nvt != VT::Int {
                return Err(format!("line {}: draw3d vertex count must be int, got {:?}", crate::diag::cur_pos(), nvt));
            }
            if let Expr::IntLit(v) = n {
                if v > &768 {
                    return Err(format!("line {}: draw3d vertex count {} exceeds the per-call budget 768 (256 triangles)", crate::diag::cur_pos(), v));
                }
                if (*v as u64) * 3 > r.arrays[id].cap as u64 {
                    return Err(format!("line {}: draw3d needs {} x 3 cells but array '{}' holds only {}", crate::diag::cur_pos(), v, arr, r.arrays[id].cap));
                }
            }
            check_num_arg(x, env, f, r, "draw3d x")?;
            check_num_arg(y, env, f, r, "draw3d y")?;
            check_num_arg(z, env, f, r, "draw3d z")?;
            let rvt = expr_type(yaw, &env.locals, f, r)?;
            match rvt {
                VT::Ang => {}
                VT::Int => {
                    if !matches!(yaw, Expr::IntLit(_)) {
                        return Err(format!("line {}: draw3d yaw must be ang-typed (or an int literal); use ang()", crate::diag::cur_pos()));
                    }
                }
                _ => return Err(format!("line {}: draw3d yaw must be ang", crate::diag::cur_pos())),
            }
            let cvt = expr_type(rgba, &env.locals, f, r)?;
            if cvt != VT::Int {
                return Err(format!("line {}: draw3d color must be int-typed (0xRRGGBBAA; alpha 0 = wireframe)", crate::diag::cur_pos()));
            }
            Ok(())
        }
        Stmt::Draw3DI { verts, nv, idx, ni, x, y, z, yaw, rgba } => {
            // v12 indexed mesh pass — draw-pass only, same budget family as
            // draw3d: nv unique verts (3 cells each), ni indices (3 per tri).
            if !is_draw_fn(f) {
                return Err(format!("line {}: draw3di is a draw-pass statement (move it into draw())", crate::diag::cur_pos()));
            }
            let vid = r.arr_index.get(&(GLOBAL_ENT, verts.clone())).copied()
                .ok_or_else(|| format!("line {}: draw3di vertex buffer '{}' is not a global array", crate::diag::cur_pos(), verts))?;
            let iid = r.arr_index.get(&(GLOBAL_ENT, idx.clone())).copied()
                .ok_or_else(|| format!("line {}: draw3di index buffer '{}' is not a global array", crate::diag::cur_pos(), idx))?;
            if iid == vid {
                return Err(format!("line {}: draw3di vertex and index buffers must be different arrays", crate::diag::cur_pos()));
            }
            let nvt = expr_type(nv, &env.locals, f, r)?;
            if nvt != VT::Int {
                return Err(format!("line {}: draw3di vertex count must be int, got {:?}", crate::diag::cur_pos(), nvt));
            }
            let nit = expr_type(ni, &env.locals, f, r)?;
            if nit != VT::Int {
                return Err(format!("line {}: draw3di index count must be int, got {:?}", crate::diag::cur_pos(), nit));
            }
            if let Expr::IntLit(v) = nv {
                if v > &768 {
                    return Err(format!("line {}: draw3di vertex count {} exceeds the per-call budget 768", crate::diag::cur_pos(), v));
                }
                if (*v as u64) * 3 > r.arrays[vid].cap as u64 {
                    return Err(format!("line {}: draw3di needs {} x 3 vertex cells but array '{}' holds only {}", crate::diag::cur_pos(), v, verts, r.arrays[vid].cap));
                }
            }
            if let Expr::IntLit(v) = ni {
                if v % 3 != 0 {
                    return Err(format!("line {}: draw3di index count {} must be a multiple of 3 (one tri = 3 indices)", crate::diag::cur_pos(), v));
                }
                if v > &768 {
                    return Err(format!("line {}: draw3di index count {} exceeds the per-call budget 768 (256 triangles)", crate::diag::cur_pos(), v));
                }
                if (*v as u64) > r.arrays[iid].cap as u64 {
                    return Err(format!("line {}: draw3di needs {} index cells but array '{}' holds only {}", crate::diag::cur_pos(), v, idx, r.arrays[iid].cap));
                }
            }
            check_num_arg(x, env, f, r, "draw3di x")?;
            check_num_arg(y, env, f, r, "draw3di y")?;
            check_num_arg(z, env, f, r, "draw3di z")?;
            let rvt = expr_type(yaw, &env.locals, f, r)?;
            match rvt {
                VT::Ang => {}
                VT::Int => {
                    if !matches!(yaw, Expr::IntLit(_)) {
                        return Err(format!("line {}: draw3di yaw must be ang-typed (or an int literal); use ang()", crate::diag::cur_pos()));
                    }
                }
                _ => return Err(format!("line {}: draw3di yaw must be ang", crate::diag::cur_pos())),
            }
            let cvt = expr_type(rgba, &env.locals, f, r)?;
            if cvt != VT::Int {
                return Err(format!("line {}: draw3di color must be int-typed (0xRRGGBBAA; alpha 0 = wireframe)", crate::diag::cur_pos()));
            }
            Ok(())
        }
        Stmt::QuatAA { q, off, ax, ay, az, ang } => {
            // state mutation: gameplay-side only (draw fns are presentation)
            if is_draw_fn(f) {
                return Err(format!("line {}: quat_aa is not allowed in draw fns (it writes rig state)", crate::diag::cur_pos()));
            }
            let id = r.arr_index.get(&(GLOBAL_ENT, q.clone())).copied()
                .ok_or_else(|| format!("line {}: quat_aa target '{}' is not a global array (quats live in shared rig storage)", crate::diag::cur_pos(), q))?;
            check_arr_off(off, id, 4, "quat_aa", q, env, f, r)?;
            check_num_arg(ax, env, f, r, "quat_aa ax")?;
            check_num_arg(ay, env, f, r, "quat_aa ay")?;
            check_num_arg(az, env, f, r, "quat_aa az")?;
            let avt = expr_type(ang, &env.locals, f, r)?;
            match avt {
                VT::Ang => {}
                VT::Int => {
                    if !matches!(ang, Expr::IntLit(_)) {
                        return Err(format!("line {}: quat_aa angle must be ang-typed (or an int literal); use ang()", crate::diag::cur_pos()));
                    }
                }
                _ => return Err(format!("line {}: quat_aa angle must be ang", crate::diag::cur_pos())),
            }
            Ok(())
        }
        Stmt::QMul { d, doff, a, aoff, b, boff } => {
            if is_draw_fn(f) {
                return Err(format!("line {}: qmul is not allowed in draw fns (it writes rig state)", crate::diag::cur_pos()));
            }
            check_quat_operands(d, doff, a, aoff, b, boff, "qmul", env, f, r)?;
            Ok(())
        }
        Stmt::M4QT { m, moff, q, qoff, tx, ty, tz } => {
            if is_draw_fn(f) {
                return Err(format!("line {}: m4qt is not allowed in draw fns (it writes rig state)", crate::diag::cur_pos()));
            }
            let mid = r.arr_index.get(&(GLOBAL_ENT, m.clone())).copied()
                .ok_or_else(|| format!("line {}: m4qt target '{}' is not a global array (matrices live in shared rig storage)", crate::diag::cur_pos(), m))?;
            let qid = r.arr_index.get(&(GLOBAL_ENT, q.clone())).copied()
                .ok_or_else(|| format!("line {}: m4qt quat '{}' is not a global array", crate::diag::cur_pos(), q))?;
            check_arr_off(moff, mid, 16, "m4qt mat", m, env, f, r)?;
            check_arr_off(qoff, qid, 4, "m4qt quat", q, env, f, r)?;
            check_num_arg(tx, env, f, r, "m4qt tx")?;
            check_num_arg(ty, env, f, r, "m4qt ty")?;
            check_num_arg(tz, env, f, r, "m4qt tz")?;
            Ok(())
        }
        Stmt::M4Mul { d, doff, a, aoff, b, boff } => {
            if is_draw_fn(f) {
                return Err(format!("line {}: m4mul is not allowed in draw fns (it writes rig state)", crate::diag::cur_pos()));
            }
            check_mat_operands(d, doff, a, aoff, b, boff, "m4mul", env, f, r)?;
            Ok(())
        }
        Stmt::SkinV { v, voff, m, moff, x, y, z } => {
            if is_draw_fn(f) {
                return Err(format!("line {}: skinv is not allowed in draw fns (it writes rig state)", crate::diag::cur_pos()));
            }
            let vid = r.arr_index.get(&(GLOBAL_ENT, v.clone())).copied()
                .ok_or_else(|| format!("line {}: skinv vertex buffer '{}' is not a global array", crate::diag::cur_pos(), v))?;
            let mid = r.arr_index.get(&(GLOBAL_ENT, m.clone())).copied()
                .ok_or_else(|| format!("line {}: skinv matrix '{}' is not a global array", crate::diag::cur_pos(), m))?;
            check_arr_off(voff, vid, 3, "skinv verts", v, env, f, r)?;
            check_arr_off(moff, mid, 16, "skinv mat", m, env, f, r)?;
            check_num_arg(x, env, f, r, "skinv x")?;
            check_num_arg(y, env, f, r, "skinv y")?;
            check_num_arg(z, env, f, r, "skinv z")?;
            Ok(())
        }
        Stmt::MusicVol(_) => Ok(()), // range enforced by parser (literal 0..16)
        Stmt::Save(ix, v) => {
            // v7: persistence is gameplay state, not presentation.
            if is_draw_fn(f) {
                return Err(format!("line {}: save is not allowed in draw fns", crate::diag::cur_pos()));
            }
            let ivt = expr_type(ix, &env.locals, f, r)?;
            if ivt != VT::Int {
                return Err(format!("line {}: save slot index must be int, got {:?}", crate::diag::cur_pos(), ivt));
            }
            let vvt = expr_type(v, &env.locals, f, r)?;
            if !matches!(vvt, VT::Int | VT::Fixed) {
                return Err(format!("line {}: save value must be int or fixed, got {:?}", crate::diag::cur_pos(), vvt));
            }
            Ok(())
        }
        Stmt::Goto(a) => {
            if is_draw_fn(f) {
                return Err(format!("line {}: goto is not allowed in draw fns", crate::diag::cur_pos()));
            }
            r.domain_pos(r.scene_atom_ids, *a, "scene")?;
            Ok(())
        }
        Stmt::Draw(spr, x, y, rot, scale, rgba) => {
            if !r.sprites.iter().any(|s| s.atom == *spr) {
                return Err(format!("line {}: #{} is not a sprite", crate::diag::cur_pos(), r.aname(*spr)));
            }
            check_num_arg(x, env, f, r, "draw x")?;
            check_num_arg(y, env, f, r, "draw y")?;
            // rot: ang expr or int literal
            let rvt = expr_type(rot, &env.locals, f, r)?;
            match rvt {
                VT::Ang => {}
                VT::Int => {
                    if !matches!(rot, Expr::IntLit(_)) {
                        return Err(format!("line {}: draw rot must be ang-typed (or an int literal); use ang()", crate::diag::cur_pos()));
                    }
                }
                _ => return Err(format!("line {}: draw rot must be ang", crate::diag::cur_pos())),
            }
            check_num_arg(scale, env, f, r, "draw scale")?;
            let cvt = expr_type(rgba, &env.locals, f, r)?;
            // v10: rgba may be any int-typed expression (particles compute
            // per-particle alpha from ttl). Int literals remain the idiomatic
            // form; previously-rejected programs are the only delta, so
            // existing games keep byte-identical output.
            if cvt != VT::Int {
                return Err(format!("line {}: draw color must be int-typed (0xRRGGBBAA literal or expression)", crate::diag::cur_pos()));
            }
            Ok(())
        }
        Stmt::DrawText(a, x, y, rgba) => {
            if !r.texts.iter().any(|(ta, _)| ta == a) {
                return Err(format!("line {}: #{} is not a text atom", crate::diag::cur_pos(), r.aname(*a)));
            }
            check_num_arg(x, env, f, r, "draw_text x")?;
            check_num_arg(y, env, f, r, "draw_text y")?;
            let cvt = expr_type(rgba, &env.locals, f, r)?;
            // v17: relaxed to any int-typed expression (same rule `draw`
            // got in v10) — state-reactive HUD colors without workarounds
            if cvt != VT::Int {
                return Err(format!("line {}: draw_text color must be int-typed (0xRRGGBBAA)", crate::diag::cur_pos()));
            }
            Ok(())
        }
        Stmt::DrawNum(v, x, y, rgba) => {
            let vvt = expr_type(v, &env.locals, f, r)?;
            if !matches!(vvt, VT::Int | VT::Fixed) {
                return Err(format!("line {}: draw_num value must be int or fixed, got {:?}", crate::diag::cur_pos(), vvt));
            }
            check_num_arg(x, env, f, r, "draw_num x")?;
            check_num_arg(y, env, f, r, "draw_num y")?;
            let cvt = expr_type(rgba, &env.locals, f, r)?;
            // v17: relaxed to any int-typed expression (matches draw/draw_text)
            if cvt != VT::Int {
                return Err(format!("line {}: draw_num color must be int-typed (0xRRGGBBAA)", crate::diag::cur_pos()));
            }
            Ok(())
        }
        Stmt::CallStmt(name, args) => {
            let fi = *r.fn_index.get(name)
                .ok_or_else(|| format!("line {}: call to unknown fn '{}'", crate::diag::cur_pos(), name))?;
            let target = &r.fns[fi];
            match target.kind {
                FnKind::Scene | FnKind::Helper => {
                    // v17: draw fns may only call DRAW-SAFE helpers (no
                    // spawn/kill/save/goto/fsm/rig math, transitively) — the
                    // pass discipline was bypassable through helpers before.
                    if is_draw_fn(f) && !r.draw_safe[fi] {
                        return Err(format!(
                            "line {}: fn '{}' is not draw-safe (it spawns/kills/saves/goes-to or calls something that does) — draw fns may only call presentation helpers",
                            crate::diag::cur_pos(), name));
                    }
                    if target.params.len() != args.len() {
                        return Err(format!("line {}: fn '{}' takes {} args, got {}",
                            crate::diag::cur_pos(), name, target.params.len(), args.len()));
                    }
                    for (i, (pn, pvt)) in target.params.iter().enumerate() {
                        let avt = expr_type(&args[i], &env.locals, f, r)?;
                        check_call_arg(*pvt, avt, &format!("arg '{}' of {}", pn, name), crate::diag::cur_pos())?;
                        // entity arg must be a plain variable (slot resolvable)
                        if matches!(pvt, VT::Ent(_)) && !matches!(args[i], Expr::Ident(_)) {
                            return Err(format!("line {}: entity arg '{}' of {} must be a variable", crate::diag::cur_pos(), pn, name));
                        }
                    }
                    Ok(())
                }
                _ => Err(format!("line {}: cannot call fn '{}' directly (it is auto-run)", crate::diag::cur_pos(), name)),
            }
        }
        Stmt::CallTable(tname, key, entvar) => {
            let tinfo = r.tables.iter().find(|t| &t.name == tname)
                .ok_or_else(|| format!("line {}: unknown table '{}'", crate::diag::cur_pos(), tname))?;
            let kvt = expr_type(key, &env.locals, f, r)?;
            if kvt != VT::Int {
                return Err(format!("line {}: table key must be int, got {:?}", crate::diag::cur_pos(), kvt));
            }
            // entity var must exist and match the table fns' entity type
            let need_ent = tinfo.entries.first()
                .and_then(|(_, fi)| r.fns.get(*fi as usize))
                .and_then(|tf| tf.entity);
            let v = entvar.as_str();
            match env.locals.iter().find(|(n, _)| n == v).map(|(_, vt)| *vt) {
                Some(VT::Ent(ei)) => {
                    if let Some(ne) = need_ent {
                        if ne != ei {
                            return Err(format!("line {}: table '{}' operates on a different entity type", crate::diag::cur_pos(), tname));
                        }
                    }
                    Ok(())
                }
                _ => Err(format!("line {}: '{}' is not an entity variable", crate::diag::cur_pos(), v)),
            }
        }
        Stmt::Return(None) => Ok(()),
        // v17 RETURN VALUES: the fn's inferred type (checker/mod.rs fixpoint)
        // is the contract — int widens to fixed, everything else must match.
        Stmt::Return(Some(e)) => {
            let evt = expr_type(e, &env.locals, f, r)?;
            match f.ret {
                Some(VT::Fixed) if matches!(evt, VT::Fixed | VT::Int) => Ok(()),
                Some(VT::Int) if evt == VT::Int => Ok(()),
                Some(VT::Bool) if evt == VT::Bool => Ok(()),
                Some(VT::Ang) if matches!(evt, VT::Ang | VT::Int) => Ok(()),
                // v23.6 GATE LIFT: f64 returns ride the (lo, hi) ret pair —
                // RET_V64 parks both cells, RET_GET64 fetches them, and the
                // ret registers are C-ABI prefix state (ABI v2 shared state),
                // so AOT callers read the full pair too. int/fixed/f32
                // widen exactly like f64 params do at call sites.
                Some(VT::F64) if matches!(evt, VT::F64 | VT::Int | VT::Fixed | VT::F32) => Ok(()),
                Some(want) => Err(format!("line {}: fn '{}' returns {:?} — cannot return {:?}",
                    crate::diag::cur_pos(), f.name, want, evt)),
                None => Err(crate::diag::internal("valued return in a fn with no inferred type")),
            }
        }
        // v17 3D: m4look — same placement + operand rules as m4qt (gameplay
        // side; writes rig state).
        Stmt::M4Look { m, moff, ex, ey, ez, tx, ty, tz } => {
            if is_draw_fn(f) {
                return Err(format!("line {}: m4look is not allowed in draw fns (it writes rig state)", crate::diag::cur_pos()));
            }
            let mid = r.arr_index.get(&(GLOBAL_ENT, m.clone())).copied()
                .ok_or_else(|| format!("line {}: m4look target '{}' is not a global array (matrices live in shared rig storage)", crate::diag::cur_pos(), m))?;
            check_arr_off(moff, mid, 16, "m4look mat", m, env, f, r)?;
            for (e, what) in [(ex, "m4look ex"), (ey, "m4look ey"), (ez, "m4look ez"),
                              (tx, "m4look tx"), (ty, "m4look ty"), (tz, "m4look tz")] {
                check_num_arg(e, env, f, r, what)?;
            }
            Ok(())
        }
        // v8 OPTIMIZER subsystem 5: `fsm_step(#name);` — must live in an
        // entity fn (update/table/helper with an entity param) whose entity
        // DRIVES that fsm. opt::fsm rewrites it into the branchless form.
        Stmt::FsmStep(atom) => {
            if is_draw_fn(f) {
                return Err(format!("line {}: fsm_step is not allowed in draw fns", crate::diag::cur_pos()));
            }
            let Some(ei) = f.entity else {
                return Err(format!("line {}: fsm_step needs an entity fn (update(e: T))", crate::diag::cur_pos()));
            };
            let fi = r.fsms.iter().find(|ff| ff.atom == *atom)
                .ok_or_else(|| format!("line {}: fsm_step: unknown fsm '{}'", crate::diag::cur_pos(), r.aname(*atom)))?;
            if fi.entity != ei {
                return Err(format!(
                    "line {}: fsm '{}' drives entity {}, not this fn's entity type",
                    crate::diag::cur_pos(), fi.name, r.entities[fi.entity].name));
            }
            Ok(())
        }
        // optimizer-only forms must never reach the checker from source
        Stmt::ForMask(..) => Err("internal: ForMask is produced only by the physics pass".into()),
        // v23 STEP 8: try/catch + throw. Tier-1 statements — the tier
        // purity fixpoint demotes the fn to Tier-1. The checker validates
        // the body + catch_body recursively. Codegen lowers to zero-cost
        // unwind tables (Tier-0 fns cannot throw — the fixpoint guarantees
        // this, so the optimizer can assume no exceptions in Tier-0 code).
        // v23.1: REAL exception semantics. The catch variable binds as an
        // Int local (error values are i32 codes) for the catch body's
        // scope; throw requires an Int-typed value.
        Stmt::TryCatch { body, catch_var, catch_body } => {
            if catch_var == "cam_x" || catch_var == "cam_y" {
                return Err(format!("line {}: catch var '{}' is reserved (engine camera registers)", crate::diag::cur_pos(), catch_var));
            }
            // Coroutines and scene jumps SUSPEND or abandon the pc — a
            // handler registered inside a try body would go stale across
            // the suspension (return from a try body is fine: popFrame
            // prunes handlers by frame depth).
            fn forbid_suspend(stmts: &[Stmt], f: &FnInfo) -> Result<(), String> {
                for s in stmts {
                    match s {
                        Stmt::Wait(_) => {
                            return Err(format!("line {}: `wait` inside a try block is not supported (the suspension would abandon the exception handler)", crate::diag::cur_pos()));
                        }
                        Stmt::GotoState(_) => {
                            return Err(format!("line {}: state transitions inside a try block are not supported (the suspension would abandon the exception handler)", crate::diag::cur_pos()));
                        }
                        Stmt::Goto(_) => {
                            return Err(format!("line {}: goto(#scene) inside a try block is not supported (it would abandon the exception handler)", crate::diag::cur_pos()));
                        }
                        Stmt::TryCatch { body, catch_body, .. } => {
                            forbid_suspend(body, f)?;
                            forbid_suspend(catch_body, f)?;
                        }
                        Stmt::If(_, a, b) => { forbid_suspend(a, f)?; forbid_suspend(b, f)?; }
                        Stmt::While(_, b) | Stmt::For(_, _, b) | Stmt::ForNum(_, _, _, b)
                        | Stmt::ForMask(_, _, _, b) | Stmt::State(_, b) => forbid_suspend(b, f)?,
                        Stmt::Switch(_, arms, dflt) => {
                            for (_, body) in arms { forbid_suspend(body, f)?; }
                            if let Some(d) = dflt { forbid_suspend(d, f)?; }
                        }
                        Stmt::At { inner, .. } => forbid_suspend(std::slice::from_ref(inner.as_ref()), f)?,
                        _ => {}
                    }
                }
                Ok(())
            }
            forbid_suspend(body, f)?;
            check_block(body, env, f, r)?;
            let depth = env.locals.len();
            env.locals.push((catch_var.clone(), VT::Int));
            check_block(catch_body, env, f, r)?;
            env.locals.truncate(depth);
            Ok(())
        }
        Stmt::Throw(e) => {
            let vt = expr_type(e, &env.locals, f, r)?;
            if vt != VT::Int {
                return Err(format!("line {}: throw takes an int error code, got {:?}", crate::diag::cur_pos(), vt));
            }
            Ok(())
        }
    }
}

pub(crate) fn check_num_arg(e: &Expr, env: &mut FnEnv, f: &FnInfo, r: &CtxRefs, what: &str) -> Result<(), String> {
    let vt = expr_type(e, &env.locals, f, r)?;
    match vt {
        VT::Fixed | VT::Int => Ok(()),
        _ => Err(format!("line {}: {} must be fixed or int, got {:?}", crate::diag::cur_pos(), what, vt)),
    }
}

// ---- v12 ARTICULATION helpers (mat4/quat over global arrays) ----

/// One (array, offset) pair: array must be global, offset int-typed; a
/// LITERAL offset is bounds-proven against `need` trailing cells exactly
/// like array indexing and the draw3d budgets — config errors are compile
/// errors, never runtime wraps.
pub(crate) fn check_arr_off(off: &Expr, id: usize, need: u32, what: &str, name: &str, env: &mut FnEnv, f: &FnInfo, r: &CtxRefs) -> Result<(), String> {
    let ovt = expr_type(off, &env.locals, f, r)?;
    if ovt != VT::Int {
        return Err(format!("line {}: {} offset must be int, got {:?}", crate::diag::cur_pos(), what, ovt));
    }
    if let Expr::IntLit(v) = off {
        if (*v as u64) + need as u64 > r.arrays[id].cap as u64 {
            return Err(format!("line {}: {} needs cells {}..{} but array '{}' holds only {}", crate::diag::cur_pos(), what, v, *v as i64 + need as i64 - 1, name, r.arrays[id].cap));
        }
    }
    Ok(())
}

/// qmul/m4mul: three global (array, offset) pairs; quat ops need 4 cells,
/// mat ops 16.
pub(crate) fn check_quat_operands(d: &str, doff: &Expr, a: &str, aoff: &Expr, b: &str, boff: &Expr, what: &str, env: &mut FnEnv, f: &FnInfo, r: &CtxRefs) -> Result<(), String> {
    let did = r.arr_index.get(&(GLOBAL_ENT, d.to_string())).copied()
        .ok_or_else(|| format!("line {}: {} destination '{}' is not a global array", crate::diag::cur_pos(), what, d))?;
    let aid = r.arr_index.get(&(GLOBAL_ENT, a.to_string())).copied()
        .ok_or_else(|| format!("line {}: {} operand '{}' is not a global array", crate::diag::cur_pos(), what, a))?;
    let bid = r.arr_index.get(&(GLOBAL_ENT, b.to_string())).copied()
        .ok_or_else(|| format!("line {}: {} operand '{}' is not a global array", crate::diag::cur_pos(), what, b))?;
    check_arr_off(doff, did, 4, &format!("{} dest", what), d, env, f, r)?;
    check_arr_off(aoff, aid, 4, &format!("{} a", what), a, env, f, r)?;
    check_arr_off(boff, bid, 4, &format!("{} b", what), b, env, f, r)?;
    Ok(())
}

pub(crate) fn check_mat_operands(d: &str, doff: &Expr, a: &str, aoff: &Expr, b: &str, boff: &Expr, what: &str, env: &mut FnEnv, f: &FnInfo, r: &CtxRefs) -> Result<(), String> {
    let did = r.arr_index.get(&(GLOBAL_ENT, d.to_string())).copied()
        .ok_or_else(|| format!("line {}: {} destination '{}' is not a global array", crate::diag::cur_pos(), what, d))?;
    let aid = r.arr_index.get(&(GLOBAL_ENT, a.to_string())).copied()
        .ok_or_else(|| format!("line {}: {} operand '{}' is not a global array", crate::diag::cur_pos(), what, a))?;
    let bid = r.arr_index.get(&(GLOBAL_ENT, b.to_string())).copied()
        .ok_or_else(|| format!("line {}: {} operand '{}' is not a global array", crate::diag::cur_pos(), what, b))?;
    check_arr_off(doff, did, 16, &format!("{} dest", what), d, env, f, r)?;
    check_arr_off(aoff, aid, 16, &format!("{} a", what), a, env, f, r)?;
    check_arr_off(boff, bid, 16, &format!("{} b", what), b, env, f, r)?;
    Ok(())
}

pub(crate) fn check_call_arg(pvt: VT, avt: VT, what: &str, pos: String) -> Result<(), String> {
    match (pvt, avt) {
        (VT::Fixed, VT::Fixed) | (VT::Fixed, VT::Int) => Ok(()), // int widens
        (VT::Int, VT::Int) => Ok(()),
        (VT::Bool, VT::Bool) => Ok(()),
        (VT::Ang, VT::Ang) => Ok(()),
        (VT::Ang, VT::Int) => Ok(()), // int literal-ish widening for ang
        (VT::Ent(a), VT::Ent(b)) if a == b => Ok(()),
        // v23.5: f64 params (2 cells). int/fixed/f32 widen exactly like
        // int widens to fixed — the conversions are the VM's deterministic
        // I2F64/FIX2F64/F322F64 (round-to-nearest-even, saturating).
        (VT::F64, VT::F64) => Ok(()),
        (VT::F64, VT::Int) | (VT::F64, VT::Fixed) | (VT::F64, VT::F32) => Ok(()),
        _ => Err(format!("{}: {}: expected {:?}, got {:?}", pos, what, pvt, avt)),
    }
}

pub(crate) fn check_assign_compat(tvt: VT, vvt: VT, op: AssignOp, what: &str, pos: String) -> Result<(), String> {
    match op {
        AssignOp::Set => match (tvt, vvt) {
            (VT::Fixed, VT::Fixed) | (VT::Fixed, VT::Int) => Ok(()),
            (VT::Int, VT::Int) => Ok(()),
            // v21: an ang value stored into an int target rides raw (ang IS
            // a 16-bit int in storage) — delta_ang results land in int
            // fields for signed math without a cast dance.
            (VT::Int, VT::Ang) => Ok(()),
            (VT::Bool, VT::Bool) => Ok(()),
            (VT::Ang, VT::Ang) | (VT::Ang, VT::Int) => Ok(()),
            (VT::F32, VT::F32) => Ok(()),
            // v23.1: f64 (two-cell) and vec4u8 (one packed cell) assign
            (VT::F64, VT::F64) => Ok(()),
            (VT::Vec4U8, VT::Vec4U8) => Ok(()),
            (VT::Vec4Fixed, _) => Err(format!("{}: {}: vec4fixed values are stack-immediate (four cells) — store lanes individually", pos, what)),
            (t, v) => Err(format!("{}: {}: cannot assign {:?} to {:?}", pos, what, v, t)),
        },
        AssignOp::Div => match (tvt, vvt) {
            (VT::Fixed, VT::Fixed) | (VT::Fixed, VT::Int) => Ok(()),
            (VT::Int, VT::Int) => Ok(()),
            (VT::F32, VT::F32) => Ok(()),
            (VT::F64, VT::F64) => Ok(()),
            (t, v) => Err(format!("{}: {}: cannot apply /= with {:?} to {:?}", pos, what, v, t)),
        },
        AssignOp::Mod => match (tvt, vvt) {
            (VT::Int, VT::Int) => Ok(()),
            (t, v) => Err(format!("{}: {}: cannot apply %= with {:?} to {:?} (int only — fixed has no fmod)", pos, what, v, t)),
        },
        AssignOp::And | AssignOp::Or | AssignOp::Xor | AssignOp::Shl | AssignOp::Shr => match (tvt, vvt) {
            (VT::Int, VT::Int) => Ok(()),
            (t, v) => Err(format!("{}: {}: bitwise compound assign needs int operands, got {:?} -> {:?}", pos, what, v, t)),
        },
        AssignOp::Add | AssignOp::Sub => match (tvt, vvt) {
            (VT::Fixed, VT::Fixed) | (VT::Fixed, VT::Int) => Ok(()),
            (VT::Int, VT::Int) => Ok(()),
            (VT::Ang, VT::Int) => Ok(()),
            (VT::F32, VT::F32) => Ok(()),
            // v23.1: f64 compound arithmetic; vec4u8 supports += (lane-wise)
            (VT::F64, VT::F64) => Ok(()),
            (VT::Vec4U8, VT::Vec4U8) if op == AssignOp::Add => Ok(()),
            (VT::Vec4U8, VT::Vec4U8) => Err(format!("{}: {}: vec4u8 has no -= (no lane-wise subtract opcode) — repack instead", pos, what)),
            (t, v) => Err(format!("{}: {}: cannot apply {} with {:?} to {:?}", pos, what,
                if op == AssignOp::Add { "+=" } else { "-=" }, v, t)),
        },
        AssignOp::Mul => match (tvt, vvt) {
            (VT::Fixed, VT::Fixed) | (VT::Fixed, VT::Int) | (VT::Int, VT::Int) => Ok(()),
            (VT::F32, VT::F32) => Ok(()),
            (VT::F64, VT::F64) => Ok(()),
            (t, v) => Err(format!("{}: {}: cannot apply *= with {:?} to {:?}", pos, what, v, t)),
        },
    }
}
