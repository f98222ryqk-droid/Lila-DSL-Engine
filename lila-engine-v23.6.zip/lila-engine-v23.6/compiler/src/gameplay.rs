//! ============================================================================
//! LILA v21 — GAMEPLAY FUNDAMENTALS (compile-time synthesis pass)
//! ============================================================================
//!
//! Four engine-grade authoring features that Unity/UE ship as RUNTIME
//! subsystems, lowered here into plain AST so the checker, codegen, VM and
//! file format never know they existed (the v10 synth.rs doctrine):
//!
//! 1. TIMERS — `fn tick_ambient() every 32 { ... }`  (InvokeRepeating)
//!    Lowered to a guard call at the top of update():
//!        if (frame() % 32 == 0) { call tick_ambient; }
//!    ZERO synthesized state — the engine's own page-0 frame counter is the
//!    time source (snapshot/rewind-safe by construction).
//!
//! 2. COLLIDE — `collide Bullet vs Rock (14) { hit_bullet_rock }`
//!    (OnCollisionEnter2D) Lowered to the nested live-scan loop appended to
//!    update(): for (a: A) { for (b: B) { if (dist < r) call handler(a, b); } }.
//!    With `optimize: true` the existing opt::physics pass rewrites the
//!    dist() call to Chebyshev guards + Galois bitmasks automatically — the
//!    collision "engine" is the game's own bytecode.
//!
//! 3. BODY — `entity Ball { x: fixed y: fixed vx: fixed vy: fixed
//!    body { gravity: 0.25 bounce: 0.5 drag: 0.02 } }` (Rigidbody2D-lite)
//!    The synthesized update prologue applies gravity + drag (semi-implicit
//!    Euler: velocity first, then the engine's own pos += vel integration),
//!    and reflects out-of-bounds positions with the restitution factor.
//!    There is NO physics engine in the runtime — the physics IS the update.
//!
//! 4. LEVELS — `level #arena { grid [ "..XX.." ] legend { X: place } }`
//!    (Tilemap-lite) Lowered to `call place(col, row);` statements appended
//!    to init(). The runtime never knows a level existed.
//!
//! Run order: after synth::expand + states::expand, before the checker.

use crate::ast::*;

/// Entry point: lower timers, collides, bodies and levels to plain AST.
/// Returns (kind, detail) rows for the build report.
pub fn expand(prog: &mut Program) -> Result<Vec<(String, String)>, String> {
    let mut rows = Vec::new();
    rows.extend(lower_timers(prog)?);
    rows.extend(lower_collides(prog)?);
    rows.extend(lower_bodies(prog)?);
    rows.extend(lower_levels(prog)?);
    Ok(rows)
}

// ---------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------

/// Find or create the global `fn update()` (0-param). Returns its index.
fn ensure_update(prog: &mut Program, line: u32) -> usize {
    if let Some(i) = prog.fns.iter().position(|f| f.name == "update" && f.params.is_empty()) {
        return i;
    }
    prog.fns.push(FnDecl {
        name: "update".into(),
        params: vec![],
        body: vec![],
        line,
        every: None,
    });
    prog.fns.len() - 1
}

/// Find or create `fn init()`. Returns its index.
fn ensure_init(prog: &mut Program, line: u32) -> usize {
    if let Some(i) = prog.fns.iter().position(|f| f.name == "init" && f.params.is_empty()) {
        return i;
    }
    // `start` is the documented alias of init — reuse it if present.
    if let Some(i) = prog.fns.iter().position(|f| f.name == "start" && f.params.is_empty()) {
        return i;
    }
    prog.fns.push(FnDecl {
        name: "init".into(),
        params: vec![],
        body: vec![],
        line,
        every: None,
    });
    prog.fns.len() - 1
}

fn int_lit(v: u32) -> Expr {
    Expr::IntLit(v)
}

// ---------------------------------------------------------------------------
// 1. TIMERS — `fn tick() every 32 { }` -> guarded call in update()
// ---------------------------------------------------------------------------

fn lower_timers(prog: &mut Program) -> Result<Vec<(String, String)>, String> {
    let mut rows = Vec::new();
    // Collect first (immutable borrow), then mutate.
    let timers: Vec<(String, u32, u32)> = prog.fns.iter()
        .filter(|f| f.every.is_some())
        .map(|f| (f.name.clone(), f.every.unwrap(), f.line))
        .collect();
    if timers.is_empty() {
        return Ok(rows);
    }
    // Validation: an every-fn is a 0-param helper fired by the guard.
    for (name, period, line) in &timers {
        let f = prog.fns.iter().find(|f| &f.name == name).unwrap();
        if !f.params.is_empty() {
            return Err(format!(
                "line {}: fn '{}' has params — `every` fns are 0-param (payload goes through globals, the atom philosophy)",
                line, name));
        }
        let _ = period;
    }
    // Prepend the guards to update() in declaration order. Each guard:
    //   if (frame() % N == 0) { call fn; }
    let guards: Vec<Stmt> = timers.iter().map(|(name, period, _)| {
        Stmt::If(
            Expr::Binary(
                BinOp::Eq,
                Box::new(Expr::Binary(
                    BinOp::Mod,
                    Box::new(Expr::Call("frame".into(), vec![])),
                    Box::new(int_lit(*period)),
                )),
                Box::new(int_lit(0)),
            ),
            vec![Stmt::CallStmt(name.clone(), vec![])],
            vec![],
        )
    }).collect();
    let (first_line, _) = (timers[0].2, 0u32);
    let ui = ensure_update(prog, first_line);
    let mut body = guards;
    body.extend(prog.fns[ui].body.clone());
    prog.fns[ui].body = body;
    for (name, period, _) in &timers {
        rows.push((
            "timer".into(),
            format!("fn {} every {} frames — frame()%{} guard in update(), 0 synthesized state",
                name, period, period),
        ));
    }
    // Clear the markers (they are authoring glue only).
    for f in prog.fns.iter_mut() {
        f.every = None;
    }
    Ok(rows)
}

// ---------------------------------------------------------------------------
// 2. COLLIDE — `collide A vs B (r) { handler }` -> nested loop in update()
// ---------------------------------------------------------------------------

fn lower_collides(prog: &mut Program) -> Result<Vec<(String, String)>, String> {
    let mut rows = Vec::new();
    if prog.collides.is_empty() {
        return Ok(rows);
    }
    let collides = std::mem::take(&mut prog.collides);
    // v22: group the decls by (a, b, radius). Stay collides keep v21's
    // exact scan (byte-compat with v21 games); enter/exit decls sharing a
    // group MERGE into one scan with a shared synthesized `touch` counter
    // field on A (the count of live B partners, refreshed per frame).
    //    for (a: A) {                        __n = 0
    //      for (b: B) { if (d < r) {          __n += 1 (stay: call h_stay;
    //        enter: call h_in on the first b when touch was 0) } }
    //      exit: if (touch != 0 && __n == 0) call h_out(a)
    //      a.touch = __n }                   (u16, saturating by MAX_ENT)
    // The touch field is image state (hashed, snapshot/rewind-safe for
    // free) — there is STILL no collision machinery in the runtime.
    #[derive(Default, Clone)]
    struct Group {
        enter: Option<(String, u32)>, // (handler, line)
        exit: Option<(String, u32)>,
    }
    let mut groups: Vec<((String, String, u32), Group)> = Vec::new();
    let mut emitted_order: Vec<Stmt> = Vec::new();
    for cd in &collides {
        // Both sides must be entity types with dense fixed x/y (the same
        // fields dist_nearest requires — the engine circle test reads them).
        for side in [&cd.a, &cd.b] {
            let Some(ed) = prog.entities.iter().find(|e| &e.name == side) else {
                return Err(format!("line {}: collide: unknown entity type '{}'", cd.line, side));
            };
            for coord in ["x", "y"] {
                if !ed.fields.iter().any(|f| f.name == coord && f.ty == Ty::Fixed) {
                    return Err(format!(
                        "line {}: collide: entity '{}' needs a dense fixed '{}' field (the circle test reads it)",
                        cd.line, side, coord));
                }
            }
        }
        if cd.a == cd.b {
            return Err(format!(
                "line {}: collide '{}' vs itself — use a single for-loop and an inner index check (self-collision has no pair semantics here)",
                cd.line, cd.a));
        }
        if !prog.fns.iter().any(|f| f.name == cd.handler) {
            return Err(format!(
                "line {}: collide: handler fn '{}' does not exist — write `fn {}(a: {}, b: {}) {{ ... }}` first",
                cd.line, cd.handler, cd.handler, cd.a, cd.b));
        }
        match cd.mode {
            CollMode::Stay => {
                // v21 scan, VERBATIM (golden regression: byte-identical)
                emitted_order.push(build_stay_scan(cd));
                rows.push((
                    "collide".into(),
                    format!("{} vs {} ({}px) -> {} — pair scan compiled into update()",
                        cd.a, cd.b, cd.radius, cd.handler),
                ));
            }
            CollMode::Enter => {
                // handler must take (a: A, b: B)
                let hf = prog.fns.iter().find(|f| f.name == cd.handler).unwrap();
                if hf.params.len() != 2 || !matches!(&hf.params[0].1, Ty::Entity(n) if *n == cd.a)
                    || !matches!(&hf.params[1].1, Ty::Entity(n) if *n == cd.b) {
                    return Err(format!(
                        "line {}: collide enter handler '{}' must take (a: {}, b: {}) — it fires once when contact begins, with the first touching partner",
                        cd.line, cd.handler, cd.a, cd.b));
                }
                let key = (cd.a.clone(), cd.b.clone(), cd.radius);
                match groups.iter_mut().find(|(k, _)| *k == key) {
                    Some((_, g)) => g.enter = Some((cd.handler.clone(), cd.line)),
                    None => groups.push((key, Group { enter: Some((cd.handler.clone(), cd.line)), exit: None })),
                }
            }
            CollMode::Exit => {
                // handler must take (a: A) — the departed partner is
                // unreachable by design (no dangling refs, ever)
                let hf = prog.fns.iter().find(|f| f.name == cd.handler).unwrap();
                if hf.params.len() != 1 || !matches!(&hf.params[0].1, Ty::Entity(n) if *n == cd.a) {
                    return Err(format!(
                        "line {}: collide exit handler '{}' must take exactly (a: {}) — contact-end has no partner to pass (it may already be dead)",
                        cd.line, cd.handler, cd.a));
                }
                let key = (cd.a.clone(), cd.b.clone(), cd.radius);
                match groups.iter_mut().find(|(k, _)| *k == key) {
                    Some((_, g)) => g.exit = Some((cd.handler.clone(), cd.line)),
                    None => groups.push((key, Group { enter: None, exit: Some((cd.handler.clone(), cd.line)) })),
                }
            }
        }
    }
    // synthesize the touch fields + the merged scans
    for ((a_name, b_name, radius), g) in &groups {
        let touch = format!("touch_{}_{}", b_name, radius);
        let ei = prog.entities.iter().position(|e| &e.name == a_name).unwrap();
        if let Some(why) = prog.entities[ei].fields.iter().find(|f| f.name == touch) {
            let _ = why;
            return Err(format!(
                "line {}: collide: entity '{}' already has a field '{}' — the touch counter name is reserved for the {} vs {} ({}) contact edges",
                g.enter.as_ref().or(g.exit.as_ref()).map(|(_, l)| *l).unwrap_or(0),
                a_name, touch, a_name, b_name, radius));
        }
        prog.entities[ei].fields.push(FieldDecl {
            name: touch.clone(),
            ty: Ty::UInt(16),
            default_int: Some(0), default_fix: None, default_bool: None, cold: false,
        });
        emitted_order.push(build_edge_scan(a_name, b_name, *radius, &touch,
            g.enter.clone(), g.exit.clone()));
        let mut what = Vec::new();
        if let Some((h, _)) = &g.enter { what.push(format!("enter -> {}", h)); }
        if let Some((h, _)) = &g.exit { what.push(format!("exit -> {}", h)); }
        rows.push((
            "collide".into(),
            format!("{} vs {} ({}px) [{}] — one merged pair scan + the synthesized {} field, edge events only",
                a_name, b_name, radius, what.join(", "), touch),
        ));
    }
    // append every scan to update() in declaration order
    if !emitted_order.is_empty() {
        let (first_line, _) = (collides[0].line, 0u32);
        let ui = ensure_update(prog, first_line);
        prog.fns[ui].body.extend(emitted_order);
    }
    Ok(rows)
}

/// The v21 stay scan, unchanged: nested live-scan + circle test + handler
/// call for EVERY overlapping pair, EVERY touching frame.
fn build_stay_scan(cd: &CollideDecl) -> Stmt {
    Stmt::For(
        "__a".into(), cd.a.clone(), vec![
            Stmt::For(
                "__b".into(), cd.b.clone(), vec![
                    Stmt::If(
                        Expr::Binary(
                            BinOp::Lt,
                            Box::new(Expr::Call("dist".into(), vec![
                                Expr::Field(Box::new(Expr::Ident("__a".into())), "x".into()),
                                Expr::Field(Box::new(Expr::Ident("__a".into())), "y".into()),
                                Expr::Field(Box::new(Expr::Ident("__b".into())), "x".into()),
                                Expr::Field(Box::new(Expr::Ident("__b".into())), "y".into()),
                            ])),
                            Box::new(Expr::FixLit((cd.radius as i32) << 8)),
                        ),
                        vec![Stmt::CallStmt(cd.handler.clone(), vec![
                            Expr::Ident("__a".into()),
                            Expr::Ident("__b".into()),
                        ])],
                        vec![],
                    ),
                ],
            ),
        ],
    )
}

/// The v22 edge scan: counts partners per A row, fires enter on the 0->n
/// edge (with the first partner), exit on the n->0 edge, and refreshes the
/// touch field — one pass, zero runtime machinery.
fn build_edge_scan(a_name: &str, b_name: &str, radius: u32, touch: &str,
                    enter: Option<(String, u32)>, exit: Option<(String, u32)>) -> Stmt {
    let af = |s: &str| Expr::Field(Box::new(Expr::Ident("__a".into())), s.into());
    let touch_field = || af(touch);
    // inner: if (dist < r) { enter-edge call; __n += 1; }
    let mut inner_body: Vec<Stmt> = Vec::new();
    if let Some((h, _)) = &enter {
        // fire once per contact BEGIN: first partner AND the field was 0
        inner_body.push(Stmt::If(
            Expr::Binary(
                BinOp::LAnd,
                Box::new(Expr::Binary(BinOp::Eq,
                    Box::new(Expr::Ident("__n".into())),
                    Box::new(int_lit(0)))),
                Box::new(Expr::Binary(BinOp::Eq, Box::new(touch_field()), Box::new(int_lit(0)))),
            ),
            vec![Stmt::CallStmt(h.clone(), vec![
                Expr::Ident("__a".into()),
                Expr::Ident("__b".into()),
            ])],
            vec![],
        ));
    }
    inner_body.push(Stmt::Assign(
        Expr::Ident("__n".into()), AssignOp::Add, int_lit(1)));
    // outer per-a: let __n = 0; for (b) { if (d<r) inner } ; exit edge ; touch = n
    let mut body: Vec<Stmt> = vec![Stmt::Let("__n".into(), int_lit(0))];
    body.push(Stmt::For(
        "__b".into(), b_name.to_string(), vec![
            Stmt::If(
                Expr::Binary(
                    BinOp::Lt,
                    Box::new(Expr::Call("dist".into(), vec![
                        Expr::Field(Box::new(Expr::Ident("__a".into())), "x".into()),
                        Expr::Field(Box::new(Expr::Ident("__a".into())), "y".into()),
                        Expr::Field(Box::new(Expr::Ident("__b".into())), "x".into()),
                        Expr::Field(Box::new(Expr::Ident("__b".into())), "y".into()),
                    ])),
                    Box::new(Expr::FixLit((radius as i32) << 8)),
                ),
                inner_body.clone(),
                vec![],
            ),
        ],
    ));
    if let Some((h, _)) = &exit {
        // exit edge: had partners last frame, has none now
        body.push(Stmt::If(
            Expr::Binary(
                BinOp::LAnd,
                Box::new(Expr::Binary(BinOp::Ne,
                    Box::new(touch_field()), Box::new(int_lit(0)))),
                Box::new(Expr::Binary(BinOp::Eq,
                    Box::new(Expr::Ident("__n".into())),
                    Box::new(int_lit(0)))),
            ),
            vec![Stmt::CallStmt(h.clone(), vec![Expr::Ident("__a".into())])],
            vec![],
        ));
    }
    // refresh the counter (MAX_ENT <= 512 < u16 range: no saturation issue)
    body.push(Stmt::Assign(touch_field(), AssignOp::Set, Expr::Ident("__n".into())));
    Stmt::For("__a".into(), a_name.to_string(), body)
}

// ---------------------------------------------------------------------------
// 3. BODY — gravity / drag / bounce, the update prologue
// ---------------------------------------------------------------------------

fn lower_bodies(prog: &mut Program) -> Result<Vec<(String, String)>, String> {
    let mut rows = Vec::new();
    let game = prog.game.clone().unwrap_or(crate::ast::GameDecl {
        title: String::new(), width: 512, height: 512, wrap: true,
        world_w: None, world_h: None, capacity: None, optimize: false,
        mem_mb: None, reflection: false,
    });
    let world_w = game.world_w.unwrap_or(game.width);
    let world_h = game.world_h.unwrap_or(game.height);
    let bodies: Vec<(usize, BodyDecl)> = prog.entities.iter().enumerate()
        .filter(|(_, e)| e.body.is_some())
        .map(|(i, e)| (i, e.body.clone().unwrap()))
        .collect();
    if bodies.is_empty() {
        return Ok(rows);
    }
    for (ei, bd) in &bodies {
        let name = prog.entities[*ei].name.clone();
        // the dynamics vocabulary: dense fixed x/y/vx/vy (auto-integration
        // pairs — the engine provides pos += vel for exactly these).
        for f in ["x", "y", "vx", "vy"] {
            if !prog.entities[*ei].fields.iter().any(|x| x.name == f && x.ty == Ty::Fixed) {
                return Err(format!(
                    "line {}: body on '{}' needs the dynamics vocabulary — dense fixed fields x, y, vx, vy (the engine integrates exactly those)",
                    bd.line, name));
            }
        }
        if bd.bounce.unwrap_or(0) > 0 && game.wrap {
            return Err(format!(
                "line {}: body on '{}': bounce needs walls — declare wrap: false (a wrapping world has no bounds to reflect off)",
                bd.line, name));
        }
        // -- the prologue: gravity + drag, velocity-first (semi-implicit Euler:
        //    the engine's integration pos += vel runs AFTER update, so this
        //    ordering gives v_{n+1} = v_n + g - drag*v_n; x_{n+1} = x_n + v_{n+1}).
        let mut prologue: Vec<Stmt> = Vec::new();
        if let Some(g) = bd.gravity {
            prologue.push(Stmt::Assign(
                Expr::Field(Box::new(Expr::Ident("__e".into())), "vy".into()),
                AssignOp::Add,
                Expr::FixLit(g),
            ));
        }
        if let Some(dr) = bd.drag {
            if dr > 0 {
                for axis in ["vx", "vy"] {
                    prologue.push(Stmt::Assign(
                        Expr::Field(Box::new(Expr::Ident("__e".into())), axis.into()),
                        AssignOp::Sub,
                        Expr::Binary(
                            BinOp::Mul,
                            Box::new(Expr::Field(Box::new(Expr::Ident("__e".into())), axis.into())),
                            Box::new(Expr::FixLit(dr)),
                        ),
                    ));
                }
            }
        }
        // -- the epilogue: reflect out-of-bounds positions (one frame of
        //    penetration at most — the classic fixed-step arcade contract).
        let mut epilogue: Vec<Stmt> = Vec::new();
        if let Some(bo) = bd.bounce {
            if bo > 0 {
                for (axis, w) in [("x", world_w), ("y", world_h)] {
                    let vaxis = if axis == "x" { "vx" } else { "vy" };
                    let ef = |s: &str| Expr::Field(Box::new(Expr::Ident("__e".into())), s.into());
                    // if (e.axis < 0) { e.axis = 0; e.v = (0 - e.v) * bounce; }
                    epilogue.push(Stmt::If(
                        Expr::Binary(BinOp::Lt, Box::new(ef(axis)), Box::new(Expr::IntLit(0))),
                        vec![
                            Stmt::Assign(ef(axis), AssignOp::Set, Expr::IntLit(0)),
                            Stmt::Assign(ef(vaxis), AssignOp::Set, Expr::Binary(
                                BinOp::Mul,
                                Box::new(Expr::Binary(BinOp::Sub, Box::new(Expr::IntLit(0)), Box::new(ef(vaxis)))),
                                Box::new(Expr::FixLit(bo)),
                            )),
                        ],
                        vec![],
                    ));
                    // if (e.axis > world) { e.axis = world; e.v = (0 - e.v) * bounce; }
                    epilogue.push(Stmt::If(
                        Expr::Binary(
                            BinOp::Gt,
                            Box::new(ef(axis)),
                            Box::new(Expr::FixLit((w as i32) << 8)),
                        ),
                        vec![
                            Stmt::Assign(ef(axis), AssignOp::Set, Expr::FixLit((w as i32) << 8)),
                            Stmt::Assign(ef(vaxis), AssignOp::Set, Expr::Binary(
                                BinOp::Mul,
                                Box::new(Expr::Binary(BinOp::Sub, Box::new(Expr::IntLit(0)), Box::new(ef(vaxis)))),
                                Box::new(Expr::FixLit(bo)),
                            )),
                        ],
                        vec![],
                    ));
                }
            }
        }
        // splice into `fn update(e: T)` — find or synthesize it.
        let ui = match prog.fns.iter().position(|f| f.name == "update"
            && f.params.len() == 1
            && matches!(&f.params[0].1, Ty::Entity(n) if *n == name)) {
            Some(i) => i,
            None => {
                prog.fns.push(FnDecl {
                    name: "update".into(),
                    params: vec![("__e".into(), Ty::Entity(name.clone()))],
                    body: vec![],
                    line: bd.line,
                    every: None,
                });
                prog.fns.len() - 1
            }
        };
        // the param NAME the user chose (`e` by convention but not required)
        let pname = prog.fns[ui].params[0].0.clone();
        let rename = |s: &mut Vec<Stmt>| {
            rename_entity_var(s, &pname);
        };
        let mut pro = prologue;
        let mut epi = epilogue;
        rename(&mut pro);
        rename(&mut epi);
        let mut body = pro;
        body.extend(prog.fns[ui].body.clone());
        body.extend(epi);
        prog.fns[ui].body = body;
        // clear the decl (authoring glue only)
        prog.entities[*ei].body = None;
        let mut what = Vec::new();
        if let Some(g) = bd.gravity { what.push(format!("gravity {:+.2}", g as f64 / 256.0)); }
        if let Some(d) = bd.drag { if d > 0 { what.push(format!("drag {:.2}", d as f64 / 256.0)); } }
        if let Some(b) = bd.bounce { if b > 0 { what.push(format!("bounce {:.2}", b as f64 / 256.0)); } }
        rows.push((
            "body".into(),
            format!("{}: [{}] — semi-implicit Euler synthesized into update(), no physics engine exists",
                name, what.join(", ")),
        ));
    }
    Ok(rows)
}

/// Replace the `__e` placeholder with the user's actual param name.
fn rename_entity_var(stmts: &mut [Stmt], pname: &str) {
    let mut fix = |e: &mut Expr| {
        if let Expr::Ident(n) = e {
            if n == "__e" { *n = pname.to_string(); }
        }
    };
    walk_exprs_mut(stmts, &mut fix);
}

/// Mutate every Ident inside the statement tree (used by the body pass to
/// rename its `__e` placeholder to the user's update-param name).
fn walk_exprs_mut(stmts: &mut [Stmt], f: &mut impl FnMut(&mut Expr)) {
    fn walk_e(e: &mut Expr, f: &mut impl FnMut(&mut Expr)) {
        f(e);
        match e {
            Expr::Field(b, _) | Expr::Index(b, _) | Expr::Unary(_, b) => walk_e(b, f),
            Expr::Binary(_, a, b) | Expr::Ternary(_, a, b) => {
                walk_e(a, f);
                walk_e(b, f);
            }
            Expr::Call(_, args) | Expr::Intrin(_, _, args, _) => {
                for a in args { walk_e(a, f); }
            }
            _ => {}
        }
    }
    fn walk_s(s: &mut Stmt, f: &mut impl FnMut(&mut Expr)) {
        // v23.2 SPANS: positional wrapper — visit the inner statement.
        if let Stmt::At { inner, .. } = s {
            walk_s(inner, f);
            return;
        }
        match s {
            Stmt::Let(_, e) | Stmt::Kill(e) | Stmt::PoolRemove(e) => walk_e(e, f),
            Stmt::Assign(t, _, v) => { walk_e(t, f); walk_e(v, f); }
            Stmt::If(c, a, b) => {
                walk_e(c, f);
                walk_s_vec(a, f);
                walk_s_vec(b, f);
            }
            Stmt::While(c, b) => { walk_e(c, f); walk_s_vec(b, f); }
            Stmt::For(_, _, b) | Stmt::ForNum(_, _, _, b) | Stmt::ForMask(_, _, _, b) => walk_s_vec(b, f),
            Stmt::Switch(sc, arms, d) => {
                walk_e(sc, f);
                for (_, b) in arms { walk_s_vec(b, f); }
                if let Some(d) = d { walk_s_vec(d, f); }
            }
            Stmt::Spawn(_, inits) => {
                for (_, e) in inits { walk_e(e, f); }
            }
            Stmt::Cam3(a, b, c, d, e) => { for x in [a, b, c, d, e] { walk_e(x, f); } }
            Stmt::Draw3d { n, x, y, z, yaw, rgba, .. } => {
                for x in [n, x, y, z, yaw, rgba] { walk_e(x, f); }
            }
            Stmt::Draw3DI { nv, ni, x, y, z, yaw, rgba, .. } => {
                for x in [nv, ni, x, y, z, yaw, rgba] { walk_e(x, f); }
            }
            Stmt::QuatAA { ax, ay, az, ang, off, .. } => {
                for x in [ax, ay, az, ang, off] { walk_e(x, f); }
            }
            Stmt::QMul { doff, aoff, boff, .. } | Stmt::M4Mul { doff, aoff, boff, .. } => {
                for x in [doff, aoff, boff] { walk_e(x, f); }
            }
            Stmt::M4QT { moff, qoff, tx, ty, tz, .. } => {
                for x in [moff, qoff, tx, ty, tz] { walk_e(x, f); }
            }
            Stmt::SkinV { voff, moff, x, y, z, .. } => {
                for q in [voff, moff, x, y, z] { walk_e(q, f); }
            }
            Stmt::M4Look { moff, ex, ey, ez, tx, ty, tz, .. } => {
                for x in [moff, ex, ey, ez, tx, ty, tz] { walk_e(x, f); }
            }
            Stmt::Camera(x, y) => { walk_e(x, f); walk_e(y, f); }
            Stmt::Save(ix, v) => { walk_e(ix, f); walk_e(v, f); }
            Stmt::Draw(_, x, y, r, s, c) => {
                for x in [x, y, r, s, c] { walk_e(x, f); }
            }
            Stmt::DrawText(_, x, y, c) => { walk_e(x, f); walk_e(y, f); walk_e(c, f); }
            Stmt::DrawNum(v, x, y, c) | Stmt::DrawNumZ(v, _, x, y, c) => {
                for q in [v, x, y, c] { walk_e(q, f); }
            }
            Stmt::CallStmt(_, args) => { for a in args { walk_e(a, f); } }
            Stmt::CallTable(_, k, _) => walk_e(k, f),
            Stmt::Return(Some(e)) => walk_e(e, f),
            Stmt::MapPut(_, k, v) => { walk_e(k, f); walk_e(v, f); }
            Stmt::MapDel(_, k) => walk_e(k, f),
            Stmt::QPush(_, v) | Stmt::SPush(_, v) | Stmt::AFill(_, v) | Stmt::AShuf(_, v) => walk_e(v, f),
            Stmt::ACopy(_, _, n) => walk_e(n, f),
            _ => {}
        }
    }
    fn walk_s_vec(v: &mut Vec<Stmt>, f: &mut impl FnMut(&mut Expr)) {
        for s in v { walk_s(s, f); }
    }
    for s in stmts { walk_s(s, f); }
}

// ---------------------------------------------------------------------------
// 4. LEVELS — ASCII grids -> placement calls in init()
// ---------------------------------------------------------------------------

fn lower_levels(prog: &mut Program) -> Result<Vec<(String, String)>, String> {
    let mut rows = Vec::new();
    if prog.levels.is_empty() {
        return Ok(rows);
    }
    let levels = std::mem::take(&mut prog.levels);
    for ld in &levels {
        if ld.grid.is_empty() {
            return Err(format!("line {}: level: empty grid", ld.line));
        }
        let w = ld.grid[0].chars().count() as u32;
        if w == 0 || w > 256 {
            return Err(format!("line {}: level: grid width {} out of range 1..=256", ld.line, w));
        }
        for (r, row) in ld.grid.iter().enumerate() {
            if row.chars().count() as u32 != w {
                return Err(format!(
                    "line {}: level: row {} has {} chars, expected {} (rectangular grids only)",
                    ld.line, r, row.chars().count(), w));
            }
        }
        // legend validation: every non-empty cell needs an entry; the entry
        // must be a 2-int-param fn (the checker will also verify the call).
        for (ch, fname) in &ld.legend {
            if !prog.fns.iter().any(|f| &f.name == fname) {
                return Err(format!(
                    "line {}: level legend '{}': fn '{}' does not exist — write `fn {}(c: u8, r: u8) {{ ... }}` first",
                    ld.line, ch, fname, fname));
            }
        }
        let mut calls: Vec<Stmt> = Vec::new();
        for (r, row) in ld.grid.iter().enumerate() {
            for (cc, ch) in row.chars().enumerate() {
                if ch == '.' || ch == ' ' { continue; }
                let Some((_, fname)) = ld.legend.iter().find(|(c, _)| c == &ch) else {
                    return Err(format!(
                        "line {}: level: cell '{}' (col {}, row {}) is not in the legend",
                        ld.line, ch, cc, r));
                };
                calls.push(Stmt::CallStmt(fname.clone(), vec![
                    int_lit(cc as u32), int_lit(r as u32),
                ]));
            }
        }
        let ii = ensure_init(prog, ld.line);
        prog.fns[ii].body.extend(calls);
        let placed: usize = ld.grid.iter()
            .map(|r| r.chars().filter(|c| *c != '.' && *c != ' ').count())
            .sum();
        rows.push((
            "level".into(),
            format!("{}x{} grid, {} placements -> calls in init(), no tile engine exists",
                w, ld.grid.len(), placed),
        ));
    }
    Ok(rows)
}
