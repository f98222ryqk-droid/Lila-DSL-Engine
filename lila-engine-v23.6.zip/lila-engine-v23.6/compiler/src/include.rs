//! v17 INCLUDES — multi-file games.
//!
//! `include "sprites.lila"` on its own line splices another source file at
//! that point. Implemented as a comment/string-aware textual splice BEFORE
//! lexing, with a per-line map back to (file, local line) — diagnostics
//! render through `diag::render_with_files` and show the REAL file and line.
//!
//! Rules (deliberately strict — a game is a small, loadable unit):
//!   - the directive must be alone on its line (trailing `// comment` ok):
//!         include "assets.lila"
//!   - paths resolve relative to the INCLUDING file's directory, then the
//!     main file's directory, then the CWD
//!   - include cycles are hard errors with the full chain named
//!   - depth is capped at 16, total files at 128 (loud, not silent)
//!   - the include line itself becomes a blank line in the spliced source,
//!     so every other line keeps its offset — one map, no arithmetic
//!
//! The runtime is untouched: includes are a DEV-TIME concept, gone by the
//! time the .libyte exists. `sfx ... from:` asset paths stay relative to the
//! MAIN file (existing behavior).

use std::path::{Path, PathBuf};

#[derive(Debug)]
pub struct FileSrc {
    pub path: String,
    pub text: String,
}

#[derive(Debug)]
pub struct Source {
    /// the spliced source handed to the lexer
    pub text: String,
    /// every source file, in load order ([0] = the root)
    pub files: Vec<FileSrc>,
    /// per SPLICED line (1-based indexing: line_map[L-1]): (file idx, local line)
    pub line_map: Vec<(u16, u32)>,
}

const MAX_DEPTH: usize = 16;
const MAX_FILES: usize = 128;

/// Parse one include directive line: `include "path"` (+ optional comment).
/// Returns the quoted path, or None when the line is not a directive.
fn parse_directive(line: &str) -> Option<Result<String, String>> {
    let t = line.trim();
    if !t.starts_with("include") {
        return None;
    }
    let rest = t[7..].trim_start();
    if !rest.starts_with('"') {
        return Some(Err(format!(
            "include directive must be `include \"file.lila\"` (alone on its line), got '{}'",
            t
        )));
    }
    let end = match rest[1..].find('"') {
        Some(e) => 1 + e,
        None => {
            return Some(Err(format!(
                "include path is missing its closing quote: '{}'",
                t
            )))
        }
    };
    let path = rest[1..end].to_string();
    let tail = rest[end + 1..].trim();
    if !tail.is_empty() && !tail.starts_with("//") {
        return Some(Err(format!(
            "include directive must be alone on its line (trailing junk '{}')",
            tail
        )));
    }
    Some(Ok(path))
}

/// Is the directive inside a `//` comment? (a line starting with `//` is
/// never a directive; `include` mid-line after code is not one either —
/// the parser will reject it as a stray identifier if it matters)
fn load_file(path: &Path) -> Result<String, String> {
    std::fs::read_to_string(path).map_err(|e| format!("cannot read '{}': {}", path.display(), e))
}

struct Loader {
    files: Vec<FileSrc>,
    line_map: Vec<(u16, u32)>,
    out: String,
    /// canonical paths of the files currently on the include stack
    stack: Vec<PathBuf>,
}

impl Loader {
    /// Append one file's lines, recursing into directives.
    fn append_file(&mut self, path: &Path, display: String, depth: usize) -> Result<(), String> {
        if depth > MAX_DEPTH {
            return Err(format!(
                "include depth exceeds {} (chain: {} -> {})",
                MAX_DEPTH,
                self.stack.iter().map(|p| p.display().to_string()).collect::<Vec<_>>().join(" -> "),
                display
            ));
        }
        let canonical = path.canonicalize().unwrap_or_else(|_| path.to_path_buf());
        if self.stack.contains(&canonical) {
            let mut chain: Vec<String> = self.stack.iter().map(|p| p.display().to_string()).collect();
            chain.push(display);
            return Err(format!("include cycle: {}", chain.join(" -> ")));
        }
        if self.files.len() >= MAX_FILES {
            return Err(format!("more than {} source files (include explosion?)", MAX_FILES));
        }
        let text = load_file(path)?;
        let file_idx = self.files.len() as u16;
        self.files.push(FileSrc { path: display.clone(), text: text.clone() });
        self.stack.push(canonical);

        for (li, line) in text.lines().enumerate() {
            match parse_directive(line) {
                Some(Ok(rel)) => {
                    // the directive line becomes a blank line (keeps offsets)
                    self.out.push('\n');
                    self.line_map.push((file_idx, li as u32 + 1));
                    // resolve: relative to the INCLUDING file's dir, then CWD
                    let base = path.parent().unwrap_or_else(|| Path::new("."));
                    let cand = base.join(&rel);
                    let resolved: PathBuf = if cand.exists() {
                        cand
                    } else {
                        PathBuf::from(&rel)
                    };
                    let display2 = resolved.display().to_string();
                    self.append_file(&resolved, display2, depth + 1)?;
                }
                Some(Err(e)) => {
                    return Err(format!("{}:{}: {}", display, li + 1, e));
                }
                None => {
                    self.out.push_str(line);
                    self.out.push('\n');
                    self.line_map.push((file_idx, li as u32 + 1));
                }
            }
        }
        self.stack.pop();
        Ok(())
    }
}

/// Load a root source file, splicing includes. When the root itself has no
/// includes, `files` stays single and the line map is the identity-ish
/// trivial one (still built — diag handles it uniformly).
pub fn load(root: &Path) -> Result<Source, String> {
    let display = root.display().to_string();
    let mut l = Loader { files: Vec::new(), line_map: Vec::new(), out: String::new(), stack: Vec::new() };
    l.append_file(root, display, 0)?;
    Ok(Source { text: l.out, files: l.files, line_map: l.line_map })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn directive_parsing() {
        assert_eq!(parse_directive("  include \"a.lila\"  ").unwrap().unwrap(), "a.lila");
        assert_eq!(parse_directive("include \"a.lila\" // x").unwrap().unwrap(), "a.lila");
        assert!(parse_directive("// include \"a.lila\"").is_none());
        assert!(parse_directive("let x = 1;").is_none());
        assert!(parse_directive("include \"a.lila\" ;").unwrap().is_err());
        assert!(parse_directive("include a.lila").unwrap().is_err());
    }

    #[test]
    fn splice_and_map() {
        let dir = std::env::temp_dir().join("lila_inc_test");
        let _ = std::fs::create_dir_all(&dir);
        std::fs::write(dir.join("lib.lila"), "global { a: u8 = 1 }\n// local 2\n").unwrap();
        std::fs::write(
            dir.join("main.lila"),
            "// main 1\ninclude \"lib.lila\"\n// main 3\n",
        )
        .unwrap();
        let src = load(&dir.join("main.lila")).unwrap();
        assert_eq!(src.files.len(), 2);
        // spliced lines: main1, blank(the directive), lib1, lib2, main3
        let lines: Vec<&str> = src.text.lines().collect();
        assert_eq!(lines[0], "// main 1");
        assert_eq!(lines[1], "");
        assert_eq!(lines[2], "global { a: u8 = 1 }");
        assert_eq!(lines[4], "// main 3");
        // map: line 3 -> lib.lila line 1
        assert_eq!(src.line_map[2], (1, 1));
        assert_eq!(src.line_map[4], (0, 3));
    }

    #[test]
    fn cycles_are_errors() {
        let dir = std::env::temp_dir().join("lila_cycle_test");
        let _ = std::fs::create_dir_all(&dir);
        std::fs::write(dir.join("a.lila"), "include \"b.lila\"\n").unwrap();
        std::fs::write(dir.join("b.lila"), "include \"a.lila\"\n").unwrap();
        let err = load(&dir.join("a.lila")).unwrap_err();
        assert!(err.contains("cycle"), "{}", err);
    }
}
